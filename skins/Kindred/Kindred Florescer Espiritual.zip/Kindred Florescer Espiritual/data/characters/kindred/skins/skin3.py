#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Kindred/Kindred.bin"
    "DATA/Kindred_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Kindred/Animations/Skin3.bin"
    "DATA/Kindred_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Kindred_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Kindred_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Kindred_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Kindred_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin22_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Kindred_Skins_Skin10_Skins_Skin11_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Kindred/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "KindredSkin03"
        AttributeFlags: u32 = 1
        MetaDataTags: string = "race:mythical,skinline:spiritblossom,subfaction:kanmei"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Kindred/skins/Skin03/KindredLoadScreen_3.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Kindred/skins/Skin03/KindredLoadscreen_3_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Kindred"
                "KindredSkin03"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Kindred_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kindred/Skins/Base/Kindred_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kindred/Skins/Base/Kindred_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kindred/Skins/Base/Kindred_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Kindred_Attack2DGeneral"
                        "Play_vo_Kindred_BuyItem2DBlackCleaver"
                        "Play_vo_Kindred_BuyItem2DBladeoftheRuinedKing"
                        "Play_vo_Kindred_BuyItem2DBloodthirster"
                        "Play_vo_Kindred_BuyItem2DGuardianAngel"
                        "Play_vo_Kindred_BuyItem2DInfinityEdge"
                        "Play_vo_Kindred_BuyItem2DLastWhisper"
                        "Play_vo_Kindred_CritAttack_cast3D"
                        "Play_vo_Kindred_Death3D"
                        "Play_vo_Kindred_FirstEncounter3DAmumu"
                        "Play_vo_Kindred_FirstEncounter3DBard"
                        "Play_vo_Kindred_FirstEncounter3DEkko"
                        "Play_vo_Kindred_FirstEncounter3DGangplank"
                        "Play_vo_Kindred_FirstEncounter3DKarthus"
                        "Play_vo_Kindred_FirstEncounter3DKatarina"
                        "Play_vo_Kindred_FirstEncounter3DMaokai"
                        "Play_vo_Kindred_FirstEncounter3DRengar"
                        "Play_vo_Kindred_FirstEncounter3DSion"
                        "Play_vo_Kindred_FirstEncounter3DUrgot"
                        "Play_vo_Kindred_FirstEncounter3DWarwick"
                        "Play_vo_Kindred_Joke3DGeneral"
                        "Play_vo_Kindred_KillNeutralMinion"
                        "Play_vo_Kindred_KindredBasicAttack_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackBounty1_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackBounty2_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackBounty3_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackOverrideLightBombFinal_cast3D"
                        "Play_vo_Kindred_KindredE_cast3D"
                        "Play_vo_Kindred_KindredLegendPassive_OnBuffCast"
                        "Play_vo_Kindred_KindredQ_cast3D"
                        "Play_vo_Kindred_KindredR_cast3D"
                        "Play_vo_Kindred_KindredW_cast3D"
                        "Play_vo_Kindred_Laugh3DGeneral"
                        "Play_vo_Kindred_Move2DFirst"
                        "Play_vo_Kindred_Move2DStandard"
                        "Play_vo_Kindred_P_Camp_Kill_Enemy"
                        "Play_vo_Kindred_P_Mark_Enemy"
                        "Play_vo_Kindred_P_Mark_Self"
                        "Play_vo_Kindred_Respawn2DGeneral"
                        "Play_vo_Kindred_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Kindred_Skin03_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Kindred/Skins/Skin03/Kindred_Skin03_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Kindred/Skins/Skin03/Kindred_Skin03_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_KindredSkin03_Dance3D_buffactivate_loop"
                        "Play_sfx_KindredSkin03_Death3D_cast"
                        "Play_sfx_KindredSkin03_Idle3D_run_buffactivate"
                        "Play_sfx_KindredSkin03_Joke3D_buffactivate"
                        "Play_sfx_KindredSkin03_KindredBasicAttack_OnCast"
                        "Play_sfx_KindredSkin03_KindredBasicAttack_OnHit"
                        "Play_sfx_KindredSkin03_KindredBasicAttack_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty1_OnCast"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty1_OnHit"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty1_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty2_OnCast"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty2_OnHit"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty2_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty3_OnCast"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty3_OnHit"
                        "Play_sfx_KindredSkin03_KindredBasicAttackBounty3_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredCritAttack_OnCast"
                        "Play_sfx_KindredSkin03_KindredCritAttack_OnHit"
                        "Play_sfx_KindredSkin03_KindredCritAttack_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredE_OnCast"
                        "Play_sfx_KindredSkin03_KindredE_OnHit"
                        "Play_sfx_KindredSkin03_KindredE_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredEWolfMissile_OnHitLocation"
                        "Play_sfx_KindredSkin03_KindredEWolfMissile_OnMissileCast"
                        "Play_sfx_KindredSkin03_KindredEWolfMissile_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredFakeCastTimeSpell_OnCast"
                        "Play_sfx_KindredSkin03_KindredP_collect_buffactivate"
                        "Play_sfx_KindredSkin03_KindredP_mark_buffactivate"
                        "Play_sfx_KindredSkin03_KindredP_mark_buffdeactivate"
                        "Play_sfx_KindredSkin03_KindredP_timer_buffactivate"
                        "Play_sfx_KindredSkin03_KindredQ_cast_ground"
                        "Play_sfx_KindredSkin03_KindredQ_missilelaunch_multi"
                        "Play_sfx_KindredSkin03_KindredQ_missilelaunch_single"
                        "Play_sfx_KindredSkin03_KindredQ_OnCast"
                        "Play_sfx_KindredSkin03_KindredQMissile_OnHit"
                        "Play_sfx_KindredSkin03_KindredQMissile_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_KindredR_buffactivate"
                        "Play_sfx_KindredSkin03_KindredR_buffdeactivate"
                        "Play_sfx_KindredSkin03_KindredR_heal_buffactivate"
                        "Play_sfx_KindredSkin03_KindredW_OnCast"
                        "Play_sfx_KindredSkin03_KindredWChargePassive_heal_buffactivate"
                        "Play_sfx_KindredSkin03_KindredWChargePassive_ready_buffactivate"
                        "Play_sfx_KindredSkin03_KindredWCloneBuff_missilelaunch"
                        "Play_sfx_KindredSkin03_KindredWCloneBuff_poof_buffactivate"
                        "Play_sfx_KindredSkin03_KindredWCloneBuff_ring_cast"
                        "Play_sfx_KindredSkin03_KindredWolfBasicAttack_OnCast"
                        "Play_sfx_KindredSkin03_KindredWolfBasicAttack_OnHit"
                        "Play_sfx_KindredSkin03_KindredWPassiveHealMissile_OnMissileLaunch"
                        "Play_sfx_KindredSkin03_Laugh3D_buffactivate"
                        "Play_sfx_KindredSkin03_Recall3D_buffactivate"
                        "Play_sfx_KindredSkin03_Recall3D_wolf_buffactivate"
                        "Play_sfx_KindredSkin03_Taunt3D_buffactivate"
                        "Play_vosfx_KindredSkin03_Idle_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredBasicAttack_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredBasicAttackBounty1_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredBasicAttackBounty2_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredBasicAttackBounty3_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredCritAttack_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredE_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredEWolfMissile_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredP_collect_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredP_mark_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredP_mark_buffdeactivate"
                        "Stop_sfx_KindredSkin03_KindredP_timer_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredQMissile_OnMissileLaunch"
                        "Stop_sfx_KindredSkin03_KindredR_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredR_buffdeactivate"
                        "Stop_sfx_KindredSkin03_KindredR_heal_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredWChargePassive_heal_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredWChargePassive_ready_buffactivate"
                        "Stop_sfx_KindredSkin03_KindredWCloneBuff_missilelaunch"
                        "Stop_sfx_KindredSkin03_KindredWCloneBuff_ring_cast"
                        "Stop_sfx_KindredSkin03_KindredWPassiveHealMissile_OnMissileLaunch"
                        "Stop_vosfx_KindredSkin03_Idle_buffactivate"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Kindred/Animations/Skin3"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Kindred/skins/Skin03/Kindred_Skin03.skl"
            SimpleSkin: string = "ASSETS/Characters/Kindred/skins/Skin03/Kindred_Skin03.skn"
            Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Lamb_Skin03_TX_CM.dds"
            SkinScale: f32 = 1.10000002
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 125, 175, 125 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "SpiritWisp Recallface Props"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Kindred_Skin03_Props_TX_CM.dds"
                    Submesh: string = "Props"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Kindred_Skin3_SpiritWisp_TX_CM.dds"
                    Submesh: string = "SpiritWisp"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Turn"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Kindred_I_Lamb_glow"
                BoneName: string = "Root"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Kindred/HUD/Kindred_Circle_3.dds"
        mContextualActionData: link = "Characters/Kindred/CAC/Kindred_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Kindred/HUD/Kindred_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Kindred/HUD/Kindred_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Kindred/Skins/Skin3/Resources"
    }
    "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_I_Trail" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 20 }
                }
                EmitterName: string = "Soft_Trail"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749019623 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.78039217, 0.737254918, 1, 0 }
                            { 0.70588237, 0.650980413, 1, 0.749019623 }
                            { 0.694117665, 0.631372571, 1, 0.749019623 }
                            { 0.278431386, 0.278431386, 0.278431386, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                DisableBackfaceCull: bool = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 600, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 101
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, -5, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 103
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, -3, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 450, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -20
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, -5, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0.800000012
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            15
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                EmitterName: string = "Sparks_"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1.10000002, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.10000002, 1 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    8
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -80
                                    80
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 5, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 2, 2 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -20
                                        20
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -25
                                        25
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 2, 2, 2 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, -5, -15 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 25, -5, -15 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.250980407, 0.156862751, 0.615686297, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.250980407, 0.156862751, 0.615686297, 0 }
                            { 0.250980407, 0.156862751, 0.615686297, 1 }
                            { 0.250980407, 0.156862751, 0.615686297, 1 }
                            { 0.162399083, 0.101499423, 0.398385227, 1 }
                            { 0.0738177598, 0.0461360998, 0.181084201, 0 }
                        }
                    }
                }
                Pass: i16 = 105
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                    0.649999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    1.29999995
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Jhin_base_R_Rose_petals.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.829999208, 0.76000613, 1, 0.76000613 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.829999208, 0.76000613, 1, 0 }
                            { 0.829999208, 0.76000613, 1, 0.76000613 }
                            { 0.829999208, 0.76000613, 1, 0.76000613 }
                            { 0.25388211, 0.217570379, 0.505882382, 0.76000613 }
                            { 0.113921463, 0.0894124806, 0.352941185, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "right_dissolve"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00600000005
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.459998488, 0.300007641, 1, 0.280003041 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.459998488, 0.300007641, 1, 0 }
                            { 0.459998488, 0.300007641, 1, 0.280003041 }
                            { 0.459998488, 0.300007641, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 3, 3, 3 }
                            { 0.25, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Z_Glow.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.600000024
                        }
                    }
                }
                EmitterName: string = "ShadowWisps"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 10, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, -10, -30 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.866666675, 0.788235307, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.866666675, 0.788235307, 1, 0 }
                            { 0.866666675, 0.788235307, 1, 1 }
                            { 0.866666675, 0.788235307, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 80, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 80, 80 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Cloud03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Kindred_Skin03_I_Trail"
        ParticlePath: string = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_I_Trail"
    }
    "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_W_wolf_PopSmoke" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            0.375
                            1.125
                        }
                    }
                }
                Lifetime: option[f32] = {
                    0.0500000007
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ShadowWisps"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 500, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 4, 4 }
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 30
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.480003059 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.752941191, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.752941191, 0.68235296, 1, 0 }
                            { 0.752941191, 0.68235296, 1, 1 }
                            { 0.752941191, 0.68235296, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 80, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 80, 80 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Cloud03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.07500005
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BurstGlow"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 150, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.643137276, 0.474509805, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.643137276, 0.474509805, 1, 1 }
                            { 0.643137276, 0.474509805, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 16
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 300, 150 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Z_Glow.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 9
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                Lifetime: option[f32] = {
                    0.0500000007
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal_BG2"
                Importance: u8 = 0
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.5
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 80, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 80, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 150, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.549996197, 0.429999232, 0.839993894, 0.469993144 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.549996197, 0.429999232, 0.839993894, 0 }
                            { 0.549996197, 0.429999232, 0.839993894, 0.469993144 }
                            { 0.549996197, 0.429999232, 0.839993894, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_FlipBook02EROS.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 150, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.5
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.5
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 150, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 1, 1.5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_FlipBook02.dds"
                NumFrames: u16 = 5
                StartFrame: u16 = 1
                TexDiv: vec2 = { 5, 1 }
            }
        }
        ParticleName: string = "Kindred_Skin03_W_wolf_PopSmoke"
        ParticlePath: string = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_W_wolf_PopSmoke"
        SoundOnCreateDefault: string = "Play_sfx_Kindred_KindredWCloneBuff_poof_buffactivate"
    }
    "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_I_Trail_Non" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ice_override"
                BlendMode: u8 = 4
                Pass: i16 = 10
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Wolf_Skin03_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.600000024
                        }
                    }
                }
                EmitterName: string = "ShadowWisps"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 10, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, -10, -30 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.866666675, 0.788235307, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.866666675, 0.788235307, 1, 0 }
                            { 0.866666675, 0.788235307, 1, 1 }
                            { 0.866666675, 0.788235307, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 80, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 80, 80 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Cloud03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 20 }
                }
                EmitterName: string = "Soft_Trail"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749019623 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.78039217, 0.737254918, 1, 0 }
                            { 0.70588237, 0.650980413, 1, 0.749019623 }
                            { 0.694117665, 0.631372571, 1, 0.749019623 }
                            { 0.278431386, 0.278431386, 0.278431386, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                DisableBackfaceCull: bool = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 600, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 101
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, -5, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 103
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, -3, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 450, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -20
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, -5, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0.800000012
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            15
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                EmitterName: string = "Sparks_"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1.10000002, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.10000002, 1 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    8
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -80
                                    80
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 5, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 2, 2 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -20
                                        20
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -25
                                        25
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 2, 2, 2 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, -5, -15 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 25, -5, -15 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.250980407, 0.156862751, 0.615686297, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.250980407, 0.156862751, 0.615686297, 0 }
                            { 0.250980407, 0.156862751, 0.615686297, 1 }
                            { 0.250980407, 0.156862751, 0.615686297, 1 }
                            { 0.162399083, 0.101499423, 0.398385227, 1 }
                            { 0.0738177598, 0.0461360998, 0.181084201, 0 }
                        }
                    }
                }
                Pass: i16 = 105
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                    0.649999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    1.29999995
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Jhin_base_R_Rose_petals.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.829999208, 0.76000613, 1, 0.76000613 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.829999208, 0.76000613, 1, 0 }
                            { 0.829999208, 0.76000613, 1, 0.76000613 }
                            { 0.829999208, 0.76000613, 1, 0.76000613 }
                            { 0.25388211, 0.217570379, 0.505882382, 0.76000613 }
                            { 0.113921463, 0.0894124806, 0.352941185, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "right_dissolve"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00600000005
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.459998488, 0.300007641, 1, 0.280003041 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.459998488, 0.300007641, 1, 0 }
                            { 0.459998488, 0.300007641, 1, 0.280003041 }
                            { 0.459998488, 0.300007641, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 3, 3, 3 }
                            { 0.25, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Z_Glow.DDS"
            }
        }
        ParticleName: string = "Kindred_Skin03_I_Trail_Non"
        ParticlePath: string = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_I_Trail_Non"
    }
    "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_Death_Avatar_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_dissove"
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -3 }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Lamb_Skin03_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_dissove1"
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.654901981, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.654901981, 0.262745112, 0 }
                            { 1, 0.654901981, 0.262745112, 1 }
                            { 1, 0.654901981, 0.262745112, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_W_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -5 }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/color-hold.dds"
            }
        }
        ParticleName: string = "Kindred_Skin03_Death_Avatar_01"
        ParticlePath: string = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_Death_Avatar_01"
        Flags: u16 = 198
    }
    "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_E_Excute" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wolf_head_glow"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 500 }
                            { 0, 0, -300 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 85 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.627451003, 0.411764711, 1, 1 }
                }
                Pass: i16 = -1
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 0, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_Z_Glow.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 20 }
                }
                EmitterName: string = "Soft_Trail"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749019623 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.78039217, 0.737254918, 1, 0 }
                            { 0.70588237, 0.650980413, 1, 0.749019623 }
                            { 0.694117665, 0.631372571, 1, 0.749019623 }
                            { 0.278431386, 0.278431386, 0.278431386, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                DisableBackfaceCull: bool = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail1"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 600, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 101
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.68235296, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.68235296, 1, 0 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 1 }
                            { 0.737254918, 0.68235296, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 103
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0.800000012
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            15
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                EmitterName: string = "Sparks_"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1.10000002, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.10000002, 1 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    8
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -80
                                    80
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 5, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 2, 2 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -20
                                        20
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -25
                                        25
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 2, 2, 2 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, -5, -15 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 25, -5, -15 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.250980407, 0.156862751, 0.615686297, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.250980407, 0.156862751, 0.615686297, 0 }
                            { 0.250980407, 0.156862751, 0.615686297, 1 }
                            { 0.250980407, 0.156862751, 0.615686297, 1 }
                            { 0.162399083, 0.101499423, 0.398385227, 1 }
                            { 0.0738177598, 0.0461360998, 0.181084201, 0 }
                        }
                    }
                }
                Pass: i16 = 105
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                    0.649999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    1.29999995
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Jhin_base_R_Rose_petals.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.829999208, 0.76000613, 1, 0.76000613 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.829999208, 0.76000613, 1, 0 }
                            { 0.829999208, 0.76000613, 1, 0.76000613 }
                            { 0.829999208, 0.76000613, 1, 0.76000613 }
                            { 0.25388211, 0.217570379, 0.505882382, 0.76000613 }
                            { 0.113921463, 0.0894124806, 0.352941185, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wolf_head1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/KindredWolf/skins/Skin03/KindredWolf_Skin03.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/KindredWolf/skins/Skin03/KindredWolf_Skin03.skl"
                        mAnimationName: string = "ASSETS/Characters/Kindred/skins/base/Particles/Kindred_Base_E_Wolf_shot.anm"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -45, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.39999998, 1.39999998, 1.39999998 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Wolf_Skin03_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 20 }
                }
                EmitterName: string = "Soft_Trail2"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 8, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749019623 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.78039217, 0.737254918, 1, 0 }
                            { 0.70588237, 0.650980413, 1, 0.749019623 }
                            { 0.694117665, 0.631372571, 1, 0.749019623 }
                            { 0.278431386, 0.278431386, 0.278431386, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                DisableBackfaceCull: bool = true
                DoesCastShadow: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin03/Particles/Kindred_Skin03_CloudsTrail_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
        }
        ParticleName: string = "Kindred_Skin03_E_Excute"
        ParticlePath: string = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_E_Excute"
        Flags: u16 = 198
    }
    "Characters/Kindred/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x454d6537 = "Characters/Kindred/Skins/Skin0/Particles/DoomBotsPlayerDarkSideDebuff_tar"
            0x348fab6a = "Characters/Kindred/Skins/Skin0/Particles/DoomBotsPlayerDarkSide_FakeMushroomBuf"
            0xc49b9cf7 = "Characters/Kindred/Skins/Skin0/Particles/DoomBots_TowerDestroyed_Idle"
            "Kindred_BA_Bounty01_hit_tar" = 0xb89937a9
            "Kindred_BA_Bounty01_mis" = 0x7375a7c7
            "Kindred_BA_Bounty02_hit_tar" = 0xed1b2138
            "Kindred_BA_Bounty02_mis" = 0xf5fcf57e
            "Kindred_BA_bounty03_hit_tar" = 0xa3ac907b
            "Kindred_BA_Bounty03_mis" = 0x7a9f0205
            "Kindred_BA_Crit_hit" = 0x62f92779
            "Kindred_BA_Crit_mis" = 0x1bdb74cf
            "Kindred_BA_hit_tar" = 0x3141a0e0
            "Kindred_BA_mis" = 0x8ffc2656
            "Kindred_BA_pre_attack" = 0x560fd139
            "Kindred_Death_Avatar_01" = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_Death_Avatar_01"
            "Kindred_Death_Effect" = 0xe00bbda9
            "Kindred_Death_tex_override" = 0xff8c9742
            "Kindred_Emote_Joke" = 0xe443d54d
            "Kindred_Emote_Joke_ground" = 0x513ae6e9
            "Kindred_Emote_Laugh" = 0x4fbbb37b
            "Kindred_E_Excute" = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_E_Excute"
            "Kindred_E_Full_stack_tar" = 0xb04f97d1
            "Kindred_E_trail_child" = 0x07314c1c
            "Kindred_E_mis" = 0x4be76e62
            "Kindred_E_mis_tar" = 0xb73a81fe
            "Kindred_E_Stack_1" = 0xdfd26589
            "Kindred_E_Stack_2" = 0xdcd260d0
            "Kindred_E_Stack_3" = 0xddd26263
            "Kindred_I_Lamb_glow" = 0x33af024d
            "Kindred_Joke_preshot" = 0x08f1a8b6
            "Kindred_P_Bounty_Collect" = 0x45a25e7c
            "Kindred_P_Camp_Kill_Sound_Enemy" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_Camp_Kill_Sound_Enemy"
            "Kindred_P_Mark_Activate" = 0xcba4fe0d
            "Kindred_P_Mark_deactivate" = 0x35423012
            "Kindred_P_Mark_Persistent" = 0x11408029
            "Kindred_P_Mark_Sound_Enemy" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_Mark_Sound_Enemy"
            "Kindred_P_Mark_Sound_Self" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_Mark_Sound_Self"
            "Kindred_P_Mark_Timer" = 0x79f24c2d
            "Kindred_P_VO_Death_Long" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_VO_Death_Long"
            "Kindred_P_VO_Death_Medium" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_VO_Death_Medium"
            "Kindred_P_VO_Death_Short" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_VO_Death_Short"
            "Kindred_Q_AS_Buf" = 0x05d3fce5
            "Kindred_Q_mis" = 0x146cfcf6
            "Kindred_Q_mis_tar" = 0x360ebfa2
            "Kindred_Q_Pre_attack" = 0x630d7899
            "Kindred_Recall_bow" = 0x9b475f61
            "Kindred_Recall_wolf_ground" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_Recall_wolf_ground"
            "Kindred_R_AOE" = 0x4b308b7f
            "Kindred_R_AOE_End" = 0xcd829b45
            0x8ade6fd1 = "Characters/Kindred/Skins/Skin0/Particles/Kindred_base_R_glow"
            "Kindred_R_heal" = 0x7f26445e
            "Kindred_R_NoDeath_Buff" = 0x78877429
            "Kindred_R_NoDeath_Buff_minion" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_R_NoDeath_Buff_minion"
            "Kindred_Wolf_E_wolf_mis" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_Wolf_E_wolf_mis"
            "Kindred_Wolf_I_Avatar" = 0x47b814da
            "Kindred_Wolf_I_Trail" = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_I_Trail"
            "Kindred_Wolf_I_Trail_Non" = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_I_Trail_Non"
            "Kindred_wolf_W_eye_glow" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_wolf_W_eye_glow"
            "Kindred_W_Heal" = 0x161d2e1f
            "Kindred_W_heal_mis" = 0x86f50bcb
            "Kindred_W_Indicator_Green" = 0x19fcf4c6
            "Kindred_W_RingCast_Sound" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_W_RingCast_Sound"
            "Kindred_W_Tar_Decoy_01" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_W_Tar_Decoy_01"
            "Kindred_W_wolf_bite" = 0xf74f84bc
            "Kindred_W_wolf_PopSmoke" = "Characters/Kindred/Skins/Skin3/Particles/Kindred_Skin03_W_wolf_PopSmoke"
            "SRUAP_Turret_Fortification_DamageReduction" = "Characters/Kindred/Skins/Skin0/Particles/SRUAP_Turret_Fortification_Base_DamageReduction"
            0xb25b3be4 = "Characters/Kindred/Skins/Skin0/Particles/Super_teleportarrive"
            0x14b101bc = "Characters/Kindred/Skins/Skin0/Particles/Super_TeleportHome"
            "Kindred_Death_Avatar" = 0x00000000
            "Kindred_W_Heal_Ready" = 0x4bc8a4f7
            "Kindred_W_Heal_Ready_Avatar" = 0xc140b171
            0xf03aa456 = 0x386fe572
            0xc26c64df = 0x2bdb22e3
            0xe90427c2 = 0x85164a9e
            0xb66ef422 = 0xa2267a26
            0x16ec8d90 = 0x14b6ecf4
            0x051e73a7 = 0xb0a05053
            0x903a70cf = 0x11d6a673
        }
    }
}
