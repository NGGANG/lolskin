#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Kindred/Kindred.bin"
    "DATA/Kindred_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Kindred/Animations/Skin23.bin"
    "DATA/Kindred_Skins_Skin23_Skins_Skin32.bin"
    "DATA/Kindred_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Kindred/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "KindredSkin23"
        AttributeFlags: u32 = 1
        MetaDataTags: string = "race:mythical,skinline:worldchampions2022"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Kindred/skins/Skin23/KindredLoadScreen_23.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Kindred/skins/Skin23/KindredLoadscreen_23_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Kindred"
                "KindredSkin23"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Kindred_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kindred/Skins/Base/Kindred_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kindred/Skins/Base/Kindred_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kindred/Skins/Base/Kindred_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Kindred_Attack2DGeneral"
                        "Play_vo_Kindred_BuyItem2DBlackCleaver"
                        "Play_vo_Kindred_BuyItem2DBladeoftheRuinedKing"
                        "Play_vo_Kindred_BuyItem2DBloodthirster"
                        "Play_vo_Kindred_BuyItem2DGuardianAngel"
                        "Play_vo_Kindred_BuyItem2DInfinityEdge"
                        "Play_vo_Kindred_BuyItem2DLastWhisper"
                        "Play_vo_Kindred_CritAttack_cast3D"
                        "Play_vo_Kindred_Death3D"
                        "Play_vo_Kindred_FirstEncounter3DAmumu"
                        "Play_vo_Kindred_FirstEncounter3DBard"
                        "Play_vo_Kindred_FirstEncounter3DEkko"
                        "Play_vo_Kindred_FirstEncounter3DGangplank"
                        "Play_vo_Kindred_FirstEncounter3DKarthus"
                        "Play_vo_Kindred_FirstEncounter3DKatarina"
                        "Play_vo_Kindred_FirstEncounter3DMaokai"
                        "Play_vo_Kindred_FirstEncounter3DRengar"
                        "Play_vo_Kindred_FirstEncounter3DSion"
                        "Play_vo_Kindred_FirstEncounter3DUrgot"
                        "Play_vo_Kindred_FirstEncounter3DWarwick"
                        "Play_vo_Kindred_Joke3DGeneral"
                        "Play_vo_Kindred_KillNeutralMinion"
                        "Play_vo_Kindred_KindredBasicAttack_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackBounty1_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackBounty2_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackBounty3_cast3D"
                        "Play_vo_Kindred_KindredBasicAttackOverrideLightBombFinal_cast3D"
                        "Play_vo_Kindred_KindredE_cast3D"
                        "Play_vo_Kindred_KindredLegendPassive_OnBuffCast"
                        "Play_vo_Kindred_KindredQ_cast3D"
                        "Play_vo_Kindred_KindredR_cast3D"
                        "Play_vo_Kindred_KindredW_cast3D"
                        "Play_vo_Kindred_Laugh3DGeneral"
                        "Play_vo_Kindred_Move2DFirst"
                        "Play_vo_Kindred_Move2DStandard"
                        "Play_vo_Kindred_P_Camp_Kill_Enemy"
                        "Play_vo_Kindred_P_Mark_Enemy"
                        "Play_vo_Kindred_P_Mark_Self"
                        "Play_vo_Kindred_Respawn2DGeneral"
                        "Play_vo_Kindred_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Kindred_Skin23_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Kindred/Skins/Skin23/Kindred_Skin23_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Kindred/Skins/Skin23/Kindred_Skin23_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_KindredSkin23_Dance3D_buffactivate_loop"
                        "Play_sfx_KindredSkin23_Death3D_cast"
                        "Play_sfx_KindredSkin23_Idle3D_run_buffactivate"
                        "Play_sfx_KindredSkin23_Joke3D_buffactivate"
                        "Play_sfx_KindredSkin23_KindredBasicAttack_OnCast"
                        "Play_sfx_KindredSkin23_KindredBasicAttack_OnHit"
                        "Play_sfx_KindredSkin23_KindredBasicAttack_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty1_OnCast"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty1_OnHit"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty1_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty2_OnCast"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty2_OnHit"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty2_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty3_OnCast"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty3_OnHit"
                        "Play_sfx_KindredSkin23_KindredBasicAttackBounty3_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredCritAttack_OnCast"
                        "Play_sfx_KindredSkin23_KindredCritAttack_OnHit"
                        "Play_sfx_KindredSkin23_KindredCritAttack_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredE_OnCast"
                        "Play_sfx_KindredSkin23_KindredE_OnHit"
                        "Play_sfx_KindredSkin23_KindredE_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredEWolfMissile_OnHitLocation"
                        "Play_sfx_KindredSkin23_KindredEWolfMissile_OnMissileCast"
                        "Play_sfx_KindredSkin23_KindredEWolfMissile_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredFakeCastTimeSpell_OnCast"
                        "Play_sfx_KindredSkin23_KindredP_collect_buffactivate"
                        "Play_sfx_KindredSkin23_KindredP_mark_buffactivate"
                        "Play_sfx_KindredSkin23_KindredP_mark_buffdeactivate"
                        "Play_sfx_KindredSkin23_KindredP_timer_buffactivate"
                        "Play_sfx_KindredSkin23_KindredQ_cast_ground"
                        "Play_sfx_KindredSkin23_KindredQ_missilelaunch_multi"
                        "Play_sfx_KindredSkin23_KindredQ_missilelaunch_single"
                        "Play_sfx_KindredSkin23_KindredQ_OnCast"
                        "Play_sfx_KindredSkin23_KindredQMissile_OnHit"
                        "Play_sfx_KindredSkin23_KindredQMissile_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_KindredR_buffactivate"
                        "Play_sfx_KindredSkin23_KindredR_buffdeactivate"
                        "Play_sfx_KindredSkin23_KindredR_heal_buffactivate"
                        "Play_sfx_KindredSkin23_KindredW_OnCast"
                        "Play_sfx_KindredSkin23_KindredWChargePassive_heal_buffactivate"
                        "Play_sfx_KindredSkin23_KindredWChargePassive_ready_buffactivate"
                        "Play_sfx_KindredSkin23_KindredWCloneBuff_missilelaunch"
                        "Play_sfx_KindredSkin23_KindredWCloneBuff_poof_buffactivate"
                        "Play_sfx_KindredSkin23_KindredWCloneBuff_ring_cast"
                        "Play_sfx_KindredSkin23_KindredWolfBasicAttack_OnCast"
                        "Play_sfx_KindredSkin23_KindredWolfBasicAttack_OnHit"
                        "Play_sfx_KindredSkin23_KindredWPassiveHealMissile_OnMissileLaunch"
                        "Play_sfx_KindredSkin23_Laugh3D_buffactivate"
                        "Play_sfx_KindredSkin23_Recall3D_buffactivate"
                        "Play_sfx_KindredSkin23_Recall3D_wolf_buffactivate"
                        "Play_sfx_KindredSkin23_Taunt3D_buffactivate"
                        "Play_vosfx_KindredSkin23_Idle_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredBasicAttack_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredBasicAttackBounty1_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredBasicAttackBounty2_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredBasicAttackBounty3_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredCritAttack_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredE_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredEWolfMissile_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredP_collect_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredP_mark_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredP_mark_buffdeactivate"
                        "Stop_sfx_KindredSkin23_KindredP_timer_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredQMissile_OnMissileLaunch"
                        "Stop_sfx_KindredSkin23_KindredR_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredR_buffdeactivate"
                        "Stop_sfx_KindredSkin23_KindredR_heal_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredWChargePassive_heal_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredWChargePassive_ready_buffactivate"
                        "Stop_sfx_KindredSkin23_KindredWCloneBuff_missilelaunch"
                        "Stop_sfx_KindredSkin23_KindredWCloneBuff_ring_cast"
                        "Stop_sfx_KindredSkin23_KindredWPassiveHealMissile_OnMissileLaunch"
                        "Stop_vosfx_KindredSkin23_Idle_buffactivate"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = 0x03240102
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23.skl"
            SimpleSkin: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23.skn"
            Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_TX_CM.dds"
            SkinScale: f32 = 1.10000002
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 125, 175, 125 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Recall Coin Coin1 Coin2"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_RecallProps_TX_CM.dds"
                    Submesh: string = "Recall"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xd95d177e
                    Submesh: string = "Fire"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xe5c98091
                    Submesh: string = "FireVFX"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_TX_CM.dds"
                    Submesh: string = "Weapon"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x7c18cad8
                    Submesh: string = "BowVFX"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x9d354c20
                    Submesh: string = "Horn"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x7c18cad8
                    Submesh: string = "HornVFX"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x62cef2c3
                    Submesh: string = "RArm"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Turn"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Kindred_I_Lamb_glow"
                BoneName: string = "Root"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Kindred/HUD/Kindred_Circle_23.dds"
        mContextualActionData: link = "Characters/Kindred/CAC/Kindred_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Kindred/HUD/Kindred_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Kindred/HUD/Kindred_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/1"
                mLoadingScreenAnchor: u32 = 1
            }
        }
        mResourceResolver: link = 0x08796b9f
    }
    0x01f40fb9 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                EmitterName: string = "flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Size: vec3 = { 10, 50, 10 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.600000024, 0.809994638, 1, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.600000024, 0.809994638, 1, 0.500007629 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 100, 450 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/TFT_Base_5_11.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLinger: option[f32] = {
                    13
                }
                EmitterName: string = "Basic"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    50
                                    120
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        10
                                        -10
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -35
                                        75
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        10
                                        -10
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 1, 1, 1 }
                            }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.478431374, 1, 0.568627477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.482352942, 0.0274509806, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -45
                                    45
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    60
                                    85
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_lamb_glow.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.699999988 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.400000006
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 0.699999988 }
                        }
                    }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_W_Noise_02_01.dds"
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -0.100000001
                                        0.100000001
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 0.200000003 }
                            }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_I_Lamb_glow"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_I_Lamb_glow"
    }
    0x02f2dcf6 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.75
                }
                Lifetime: option[f32] = {
                    1.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "distot_activate"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_distort_RGBA_01.dds"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.0399999991
                    NormalMapTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_P_glow_distort_01.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { -180, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, 120 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1.39999998, 1.39999998, 1.39999998 }
                            { 1.70000005, 1.70000005, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Start_flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0, 0, 0.498039007, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -25
                                    25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 75, 75 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 2, 2, 2 }
                            { 2.5, 2.5, 2.5 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Start_flash1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0, 0, 0.498039007, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -25
                                    25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 75, 75 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 2, 2, 2 }
                            { 2.5, 2.5, 2.5 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.600000024
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                Lifetime: option[f32] = {
                    5.75
                }
                IsSingleParticle: flag = true
                EmitterName: string = "End_suck"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.749019623, 0.396078438, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -25
                                    25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/DRX_Square.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.300000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "end_flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.800000012, 0.396078438, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.800000012, 0.396078438, 1 }
                            { 1, 0.800000012, 0.396078438, 1 }
                            { 0, 0.266666383, 0.396078438, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 3, 3, 1.5 }
                            { 5, 0.100000001, 1.75 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_SuperSparkle.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.300000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                IsSingleParticle: flag = true
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAccelerationDefinitions: list[embed] = {
                        VfxFieldAccelerationDefinitionData {
                            IsLocalSpace: bool = false
                        }
                    }
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 430, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                        }
                    }
                }
                EmitterName: string = "flash_explore1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    150
                                    300
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.20000005, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "sparks"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.100000001, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 10, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Radius: f32 = 70
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.815686285, 0.254901975, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.75686276, 0.793331802, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.75686276, 0.793331802, 1, 0 }
                            { 0.75686276, 0.793331802, 1, 1 }
                            { 0.421468675, 0.441776931, 0.556862772, 0 }
                        }
                    }
                }
                Pass: i16 = 1000
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                DirectionVelocityScale: f32 = 0.00499999989
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 45, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 45, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_SparkleB.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.600000024
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.230000004
                }
                ParticleLinger: option[f32] = {
                    0.230000004
                }
                Lifetime: option[f32] = {
                    1.89999998
                }
                EmitterName: string = "flat"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.160006106, 0.97999543, 0.540001512 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.831372559, 1, 0.80392158, 0 }
                        }
                    }
                }
                Pass: i16 = 62
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 45, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 45, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.300000012, 0.300000012 }
                            { 1, 0.300000012, 0.300000012 }
                            { 0.5, 0.300000012, 0.300000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1.39999998, 4 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.0500000007 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.0500000007 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.600000024
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dist"
                Importance: u8 = 4
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_color_bellcurve32.dds"
                BlendMode: u8 = 1
                Pass: i16 = 1000
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.5
                    NormalMapTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Circle07.dds"
                }
                DepthBiasFactors: vec2 = { -1, -50 }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 45, 409.859985 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 5, 0 }
                            { 5, 5, 0 }
                            { 4, 5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            9
                            3
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    8
                }
                Lifetime: option[f32] = {
                    2.5
                }
                EmitterName: string = "flash2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.480003059 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 1
                StencilRef: u8 = 7
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 150, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 150, 450 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 1, 1 }
                            { 0.899999976, 0.899999976, 1 }
                            { 0.899999976, 0.899999976, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.800000012, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Shared/Particles/3026_Items_color.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 90
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 0.5 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.5 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "flash3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Size: vec3 = { 50, 50, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.710002303 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.349996179, 0.549996197, 1, 0.710002303 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 1
                StencilRef: u8 = 7
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 100, 450 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/TFT_Base_5_11.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 20, 450 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_flash_tar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Pass: i16 = 99
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.800000012
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Caitlyn_Skin39_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.699999988, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.469993144, 0.770000756, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.800000012
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Caitlyn_Skin39_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.00999999, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.699999988, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.200000003 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.549327195, 0.439461768, 0.156616688, 1 }
                        }
                    }
                }
                Pass: i16 = 99
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.400000006, 0.400000006 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                            { 0.970000029, 1, 1 }
                            { 1.04999995, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.229999244 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.400000006, 0.400000006 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                            { 0.970000029, 1, 1 }
                            { 1.04999995, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 45
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1.39999998, 4 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.0500000007 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.0500000007 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering2"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.549327195, 0.439461768, 0.156616688, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.400000006, 0.400000006 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                            { 0.970000029, 1, 1 }
                            { 1.04999995, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Akshan_Skin10_Caitlin_mis_trail.dds"
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 70
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.179995418, 0.37000075, 0.970000744, 0.500007629 }
                }
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.800000012
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Caitlyn_Skin39_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 140, 90, 90 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Decal_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 1, 1, 0.701960802 }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.800000012
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Caitlyn_Skin39_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 140, 90, 90 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Decal_01.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Akshan_Skin10_Caitlin_mis_trail.dds"
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 70
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash5"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 20, 450 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_flash_tar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            20
                            100
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[f32] = {
                            2
                            1.60000002
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    2.4000001
                }
                EmitterLinger: option[f32] = {
                    1.79999995
                }
                EmitterName: string = "SoftBeams2"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 430, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.480003059, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0800030529 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -45
                                    -135
                                    -180
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -180
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 65, 70 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 65, 70 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 8, 3, 0 }
                            { 3, 5, 0 }
                            { 1, 7, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_soft_ray.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Kindred_Skin23_P_Mark_deactivate"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_P_Mark_deactivate"
        SoundPersistentDefault: string = "Play_sfx_Kindred_KindredP_mark_buffdeactivate"
        Flags: u16 = 212
    }
    0x145c4f21 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_dissove2"
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xa7fc5a40
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xa7fc5a40
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Finisher_Mask_RGBA.dds"
                BlendMode: u8 = 3
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 40
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Death_Lamb.dds"
            }
        }
        ParticleName: string = "Kindred_Skin23_Death_Avatar_01"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_Death_Avatar_01"
        Flags: u16 = 199
    }
    0x53c84211 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    10
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 20, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0500038154, 0.11999695, 0.300007641, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -20
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1.29999995, 0, 0 }
                            { 1.29999995, 1.60000002, 1.60000002 }
                            { 1, 1.35000002, 1.35000002 }
                            { 0.300000012, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_WolfI_Trail_3.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.5
                }
                EmitterLinger: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "head_1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.349996179, 1, 0.400000006 }
                }
                Pass: i16 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 55, 105, 100 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/common_Aura_Self.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.25
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                Lifetime: option[f32] = {
                    0.5
                }
                EmitterName: string = "sparks"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 300, 100 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 100, 300, 100 }
                            { 100, 300, 100 }
                            { 43.47826, 143.478256, 43.47826 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 20, 20, 20 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.215686277, 0.490196079, 1, 1 }
                }
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                DirectionVelocityScale: f32 = 0.00499999989
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 45, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 45, 45, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Sparks_DRX.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    50
                }
                EmitterName: string = "Smoke"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Radius: f32 = 30
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.489997715, 0.459998488, 0.450003803, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                ColorLookUpTypeY: u8 = 3
                AlphaRef: u8 = 15
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                1
                            }
                            Values: list[f32] = {
                                0.200000003
                                0.200000003
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_SmokeErosion01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1.25
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Smoke01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2000
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.550000012
                }
                EmitterLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Trail Backing"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 60 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.298039228 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                        }
                    }
                }
                Pass: i16 = 14
                MeshRenderFlags: u8 = 0
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.699999988, 1, 1 }
                            { 0.100000001, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2000
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.550000012
                }
                EmitterLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Trail Backing1"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 50 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0500038154, 0.130006865, 0.300007641, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0500038154, 0.130006865, 0.300007641, 0 }
                            { 0.0500038154, 0.130006865, 0.300007641, 0.800000012 }
                            { 0.0500038154, 0.130006865, 0.300007641, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0, 0 }
                            { 0.699999988, 1, 1 }
                            { 0, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 200
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    0.300000012
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    0.449999988
                }
                EmitterName: string = "DirtBits1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -1, 0, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.600000024
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 500, 200 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 6, 0 }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 10, 0, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -70, 50 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 1 }
                        }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -600
                                    600
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 5, 5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1.25
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 5, 5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Sparks_DRX.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "glow_front"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 50 }
                }
                FalloffTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/DefaultFalloff.DDS"
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Color_Aatrox_W_blood.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.480003059, 0.500007629, 0.949996173, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.470588237, 1, 1, 0 }
                            { 0.470588237, 1, 1, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 1 }
                        }
                    }
                }
                Pass: i16 = 510
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    -0.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 200, 200 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    0.800000012
                }
                EmitterName: string = "DustSpikes"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 1 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                        }
                    }
                }
                Pass: i16 = 11
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Idle_alphaslice_mesh005.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -30 }
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    80
                                    50
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -8
                                    8
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 30, 70 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.39999998
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.200000003
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    0.600000024
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 30, 70 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0, 0 }
                            { 5, 5.5, 0 }
                            { 6, 5.75, 1 }
                            { 6.5, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Arcus_Base_AnimeShapes02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    0.800000012
                }
                EmitterName: string = "DustSpikes1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Radius: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.466666669, 0.768627465, 1, 1 }
                            { 0.466666669, 0.768627465, 1, 1 }
                            { 0.352941185, 0.552941203, 1, 0.270588249 }
                            { 0.184313729, 0.372549027, 0.968627453, 0 }
                        }
                    }
                }
                Pass: i16 = 18
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.5
                    ErosionSliceWidth: f32 = 1.60000002
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Noise.dds"
                }
                DepthBiasFactors: vec2 = { -1, -30 }
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    80
                                    50
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -8
                                    8
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 50, 40 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 50, 40 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 0 }
                            { 3, 3, 1 }
                            { 4, 4, 1 }
                            { 5, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Arcus_Base_AnimeShapes02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 7
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            14
                            3.5
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Trail_Tech"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 50 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_mis_Tech_Mesh.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.819607854, 0.458823532, 0.400000006 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 600
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { 0, -80 }
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 5 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.300000012, 0.600000024 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.349999994, 0.349999994, 0.349999994 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2000
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.550000012
                }
                EmitterLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Trail Backing2"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 60 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749996185 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0, 1, 1, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                Pass: i16 = 15
                MeshRenderFlags: u8 = 0
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.699999988, 1, 1 }
                            { 0, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wolf_head1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 500 }
                            { 0, 0, -300 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -50, 20 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Excute.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Excute.skl"
                        mAnimationName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Wolf_shot_01.anm"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 20
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -45, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.39999998, 1.39999998, 1.39999998 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/KindredWolf_Skin23_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short2"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 20, 50 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749996185 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0, 1, 1, 1 }
                            { 0, 1, 1, 0.298039228 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                        }
                    }
                }
                Pass: i16 = 17
                MeshRenderFlags: u8 = 0
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_WolfI_Trail_03.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Dragon.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = -90
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.600000024, 1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wolf_head2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 500 }
                            { 0, 0, -300 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -50, 20 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Excute.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Excute.skl"
                        mAnimationName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Wolf_shot_01.anm"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                }
                Pass: i16 = 21
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.407843143, 0.619607866, 1, 0 }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -45, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.39999998, 1.39999998, 1.39999998 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/KindredWolf_Skin23_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2000
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.550000012
                }
                EmitterLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Trail Backing3"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 40 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.549019635 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0, 1, 1, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                Pass: i16 = 15
                MeshRenderFlags: u8 = 0
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.699999988, 1, 1 }
                            { 0.100000001, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2000
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.550000012
                }
                EmitterLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Trail Backing4"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 40 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.68235296, 0.68235296, 0.68235296, 0.611764729 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.298039228 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                        }
                    }
                }
                Pass: i16 = 14
                MeshRenderFlags: u8 = 0
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.699999988, 1, 1 }
                            { 0.100000001, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_E_Excute"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_E_Excute"
        Flags: u16 = 198
    }
    0x59837a38 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 120
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.850000024
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.25
                }
                EmitterLinger: option[f32] = {
                    2
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 160, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 250
                            }
                            Acceleration: embed = ValueFloat {
                                ConstantValue: f32 = 900
                            }
                        }
                    }
                }
                EmitterName: string = "spin5"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1000, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    700
                                    1200
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1000, 1, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.05000019, 5.05000019, 5.05000019 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -20, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    350
                                    -350
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    3
                                    10
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.850000024
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.25
                }
                EmitterLinger: option[f32] = {
                    2
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 160, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 250
                            }
                            Acceleration: embed = ValueFloat {
                                ConstantValue: f32 = 900
                            }
                        }
                    }
                }
                EmitterName: string = "spin4"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 700, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    700
                                    1000
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 700, 1, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.05000019, 5.05000019, 5.05000019 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -20, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.849288762, 0.543544769, 0.0690349862, 1 }
                        }
                    }
                }
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    350
                                    -350
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                DirectionVelocityScale: f32 = 0.00300000003
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    3
                                    10
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_SparkleB.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.04999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.699999988
                }
                Lifetime: option[f32] = {
                    2.04999995
                }
                IsSingleParticle: flag = true
                EmitterName: string = "distot_activate1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 160, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_distort_RGBA_01.dds"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.0399999991
                    NormalMapTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_distort_wave.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { -180, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1.39999998, 1.39999998, 1.39999998 }
                            { 1.70000005, 1.70000005, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.10000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    2.29999995
                }
                IsSingleParticle: flag = true
                EmitterName: string = "end_flash4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 0 }
                            { 0.352941185, 0.552941203, 1, 1 }
                            { 0.352941185, 0.552941203, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 4, 4, 4 }
                            { 5, 5, 5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Flash_sharp_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "God_ray_bright1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 5, 1600, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.800000012
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 5, 1600, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            180
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.300007999 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.376470596, 0.698039234, 1, 0 }
                            { 0.403921574, 0.494117647, 1, 0.149415746 }
                            { 0.647058845, 0.53725493, 1, 0.300007999 }
                            { 0.505882382, 0.352941185, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                IsDirectionOriented: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 420, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 420, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1.5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1.60000002, 4.5, 1 }
                            { 3, 4.5, 1 }
                            { 6, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.850000024
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.25
                }
                EmitterLinger: option[f32] = {
                    2
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 160, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 250
                            }
                            Acceleration: embed = ValueFloat {
                                ConstantValue: f32 = 900
                            }
                        }
                    }
                }
                EmitterName: string = "spin6"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1700, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    700
                                    1200
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1700, 1, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.05000019, 5.05000019, 5.05000019 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -20, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    350
                                    -350
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    3
                                    10
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "center_glow2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.650003791 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.407843143, 0.619607866, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.407843143, 0.619607866, 1, 0 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.407843143, 0.619607866, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -3
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 3, 3, 3 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 70
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.850000024
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.25
                }
                EmitterLinger: option[f32] = {
                    2
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 160, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 250
                            }
                            Acceleration: embed = ValueFloat {
                                ConstantValue: f32 = 900
                            }
                        }
                    }
                }
                EmitterName: string = "spin7"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -2, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -2, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1700, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    700
                                    1200
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1700, 1, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.05000019, 5.05000019, 5.05000019 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -20, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    350
                                    -350
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    3
                                    10
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "center_glow3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.407843143, 0.619607866, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.364406794
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 3, 3, 3 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                IsSingleParticle: flag = true
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAccelerationDefinitions: list[embed] = {
                        VfxFieldAccelerationDefinitionData {
                            IsLocalSpace: bool = false
                        }
                    }
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 430, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                        }
                    }
                }
                EmitterName: string = "flash_explore1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    800
                                    1200
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_SparkleB.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                IsSingleParticle: flag = true
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAccelerationDefinitions: list[embed] = {
                        VfxFieldAccelerationDefinitionData {
                            IsLocalSpace: bool = false
                        }
                    }
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 430, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                        }
                    }
                }
                EmitterName: string = "flash_explore2"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    800
                                    1200
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.10000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            50
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.600000024
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterLinger: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "SoftBeams"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 160, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.478431374, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.478431374, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0800030529 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -101
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -45
                                    -135
                                    -180
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -180
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 60, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, 60, 80 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 8, 3, 0 }
                            { 3, 5, 0 }
                            { 1, 7, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_soft_ray.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.10000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    2.0999999
                }
                IsSingleParticle: flag = true
                EmitterName: string = "center_glow4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.650003791 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.407843143, 0.619607866, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.407843143, 0.619607866, 1, 0 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.407843143, 0.619607866, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -3
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 3, 3, 3 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.75
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    3.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Sparkles_Blue1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 80, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.200000003
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 80, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 80
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    80
                                }
                            }
                        }
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                        { 0, 0, 1.00000012 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 160, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 30, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 120
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            120
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.800000012
                }
                EmitterLinger: option[f32] = {
                    1.79999995
                }
                EmitterName: string = "SoftBeams1"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 160, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.478431374, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.478431374, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0800030529 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -101
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -45
                                    -135
                                    -180
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -180
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 45, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 45, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 8, 3, 0 }
                            { 3, 5, 0 }
                            { 1, 7, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_soft_ray.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.29999995
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 99
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { 0.184313729, 0.372549027, 0.968627453, 0 }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.699999988, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.29999995
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.469993144, 0.770000756, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.00999999, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.699999988, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.200000003 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.04999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 99
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { 0.184313729, 0.372549027, 0.968627453, 0 }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.100000001
                            0.150000006
                            0.200000003
                            0.930000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.80000007, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                            { 1.6500001, 1, 1 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                            { 0.150000006, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.04999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh3"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.469993144, 0.770000756, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.00999999, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.100000001
                            0.150000006
                            0.200000003
                            0.930000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.80000007, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                            { 1.6500001, 1, 1 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                            { 0.150000006, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.200000003 }
                            }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_P_bounty_collect"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_P_bounty_collect"
        SoundPersistentDefault: string = "Play_sfx_Kindred_KindredP_collect_buffactivate"
        Flags: u16 = 212
    }
    0x953dfde5 = VfxSystemDefinitionData {
        ParticleName: string = "Kindred_Skin23_Idle"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_Idle"
        Flags: u16 = 132
    }
    0x99c38f31 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ice_override"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0 }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/KindredWolf_Skin23_TX_CM.dds"
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        OverrideBlendMode: u32 = 2
                        BaseTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/empty32.dds"
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.65882355 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_WolfI_Trail_03.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Dragon.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = -90
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.600000024, 0.800000012 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 20 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.25, 0.25 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.200000003, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.200000003
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 0.800000012 }
                            { 0.482352942, 0.498039216, 0.945098042, 0.800000012 }
                            { 0.200000003, 0.480003059, 1, 0.240006119 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 135, 135, 135 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.800000012, 1, 1 }
                            { 0.200000003, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/DRX_Flame_Trail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.180392161, 0.368627459, 0.972549021, 1 }
                            { 0.179995418, 0.37000075, 0.970000744, 0.600000024 }
                            { 0.0899977088, 0.209994659, 0.500007629, 0.300007641 }
                            { 0.0549019612, 0.121568628, 0.301960796, 0 }
                        }
                    }
                }
                Pass: i16 = -3
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 135, 135 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.200000003, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, -20 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.25, 0.25 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.699999988
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 50 }
                }
                EmitterName: string = "Shape_Trail_full"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                Velocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 350, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.600000024 }
                            { 1, 1, 1, 0.600000024 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -60
                DisableBackfaceCull: bool = true
                DoesCastShadow: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                            { 0.300000012, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_WolfI_Trail_3.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "right_dissolve"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.349019617, 1, 0.501960814 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.349019617, 1, 0 }
                            { 0, 0.349019617, 1, 0.501960814 }
                            { 0, 0.349019617, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 3, 3, 3 }
                            { 0.25, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "Sparks_"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 1, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 30, 30, 30 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "Sparks_1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1.10000002, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.10000002, 1 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 5, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 30, 30, 30 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Sparks_DRX.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.550000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 400, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.919996977, 0.7400015, 0.259998471, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 150
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Decal018_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random3"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, 25 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.919996977, 0.7400015, 0.259998471, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 150
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Decal018_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random4"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, -25 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.919996977, 0.7400015, 0.259998471, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                            { 0.919996977, 0.7400015, 0.259998471, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 150
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Decal018_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.300000012, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                EmitterName: string = "ShadowWisps"
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 10, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 0, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.480003059, 1, 0.600000024 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.480003059, 1, 0 }
                            { 0.200000003, 0.480003059, 1, 0.600000024 }
                            { 0.00784313772, 0.103530072, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Caitlyn_Skin39_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 55, 80, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 55, 80, 80 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_Cloud03_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random5"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 1000, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0941176489, 0.20784314, 0.498039216, 0.760784328 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.150000006
                            0.300000012
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.760784328 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.760784328 }
                            { 0.029176686, 0.060274031, 0.254001141, 0.0684688464 }
                            { 0.0129181091, 0.0244521331, 0.175778553, 0 }
                        }
                    }
                }
                Pass: i16 = -50
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_Trail04_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "right_dissolve1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.129411772, 0.200000003, 0.815686285, 0.278431386 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.129411772, 0.200000003, 0.815686285, 0 }
                            { 0.129411772, 0.200000003, 0.815686285, 0.278431386 }
                            { 0.129411772, 0.200000003, 0.815686285, 0 }
                        }
                    }
                }
                Pass: i16 = 500
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 3, 3, 3 }
                            { 0.25, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "DustSpikes"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Height: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -5, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 1 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Idle_alphaslice_mesh005.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -30 }
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    120
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    60
                                    90
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 16, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.39999998
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.200000003
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    0.600000024
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 16, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0, 0 }
                            { 5, 5.5, 0 }
                            { 6, 5.75, 1 }
                            { 6.5, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Arcus_Base_AnimeShapes02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "DustSpikes1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Radius: f32 = 20
                    Height: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 5, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.469993144, 0.770000756, 1, 1 }
                            { 0.466666669, 0.768627465, 1, 1 }
                            { 0.352941185, 0.552941203, 1, 0.270588249 }
                            { 0.184313729, 0.372549027, 0.968627453, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.5
                    ErosionSliceWidth: f32 = 1.60000002
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Noise.dds"
                }
                DepthBiasFactors: vec2 = { -1, -30 }
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    120
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    60
                                    90
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 7, 10, 8 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.39999998
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.200000003
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    0.600000024
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 7, 10, 8 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0, 0 }
                            { 5, 5.5, 0 }
                            { 6, 5.75, 1 }
                            { 6.5, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Arcus_Base_AnimeShapes02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Kindred_Skin23_I_Trail_Non"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_I_Trail_Non"
    }
    0xb76e8003 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    7.5
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    4
                }
                EmitterName: string = "DEcal_"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Circle_Faded_BG.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.130006865, 0.179995418, 0.289997697, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 58, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0149999997
                            0.0250000004
                            0.0399999991
                            1
                        }
                        Values: list[vec3] = {
                            { 0.349999994, 0.349999994, 0.349999994 }
                            { 1.05999994, 1.05999994, 1.05999994 }
                            { 0.949999988, 0.949999988, 0.949999988 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Volibear_skin5_R_color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1.5
                }
                Lifetime: option[f32] = {
                    4.5
                }
                EmitterName: string = "StarsUp1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 525, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.949999988
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 525, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            0
                            20
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1.5
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterLinger: option[f32] = {
                    4
                }
                EmitterName: string = "GoldenLotus"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 0, 5, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 510, 10, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.400000006
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 510, 10, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 2, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.800000012
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Start_flash_ring"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0399938971, 0.549996197, 1, 0.229999244 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0399938971, 0.549996197, 1, 0 }
                            { 0.0399938971, 0.549996197, 1, 0.229999244 }
                            { 0.0399938971, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.800000012
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_InvertMult_01.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 2, 2, 2 }
                            { 2.5, 2.5, 2.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Dot.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_glow"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, -10 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 0 }
                            { 0.352941185, 0.552941203, 1, 1 }
                            { 0.239215687, 0.400000006, 0.776470602, 0.200000003 }
                            { 0.270588249, 0.403921574, 0.772549033, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                1
                            }
                            Values: list[f32] = {
                                0
                                -1
                                -1.29999995
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_3161Glow.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1000, 10, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_3161Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dark Alpha"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.560006082, 0.850003839, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.574999988
                            0.600000024
                            0.649999976
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.149996191 }
                            { 1, 1, 1, 0.229999244 }
                            { 1, 1, 1, 0.220004573 }
                            { 1, 1, 1, 0.60999465 }
                            { 1, 1, 1, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 330, 330 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Decal.dds"
                TexDiv: vec2 = { 1, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Cylinder Panning 1"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Mesh.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.482352942, 0.498039216, 0.945098042, 0.400000006 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.150000006
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.259998471 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1004
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 12.1999998, 4, 12.1999998 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Dragon_tex.dds"
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 0, -0.200000003 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec2] = {
                            { 0, -0.200000003 }
                            { 0, -0.600000024 }
                        }
                    }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 0.699999988 }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 180
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 10, 1 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 0.300000012 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Cylinder Scales"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Mesh.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.179995418, 0.37000075, 0.970000744, 0.600000024 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.150000006
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.220004573 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1003
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 12.1999998, 4, 12.1999998 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Dragon_tex.dds"
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 0, -0.200000003 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec2] = {
                            { 0, -0.200000003 }
                            { 0, -0.600000024 }
                        }
                    }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 0.699999988 }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 180
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.29999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -350, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1.5, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 250, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.450003803 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4000
                MeshRenderFlags: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0.800000012
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 15, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.29999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh3"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -350, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1.5, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 250, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0899977088, 0.0899977088, 0.200000003, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.450003803 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5000
                MeshRenderFlags: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                            }
                            Values: list[f32] = {
                                0.800000012
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0.129411772, 0.129411772, 0.215686277, 1 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.576470613, 0.619607866, 0.996078432, 0 }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 15, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 20, 20 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "hightligh"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.489997715, 0.689997733, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            0.649999976
                            0.754000008
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.110002287 }
                            { 1, 1, 1, 0.689997733 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 330, 330 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 599.999939, 329.999969, 329.999969 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Decal_light02.dds"
                TexDiv: vec2 = { 1, -1 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_color_01.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 0.699999988 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.29999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            6
                            2
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    4.5
                }
                EmitterLinger: option[f32] = {
                    2
                }
                EmitterName: string = "flash7"
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                            { 0, -100, 0 }
                            { 0, -200, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.300007641 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 300, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 300, 450 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 1, 1 }
                            { 0.899999976, 0.899999976, 1 }
                            { 0.899999976, 0.899999976, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.800000012, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Shared/Particles/3026_Items_color.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 90
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 0.5 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.5 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.29999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    4.5
                }
                EmitterLinger: option[f32] = {
                    2
                }
                EmitterName: string = "flash8"
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                            { 0, -100, 0 }
                            { 0, -200, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Size: vec3 = { 50, 50, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 250, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.710002303 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.349996179, 0.549996197, 1, 0.710002303 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 6000
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 100, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 100, 450 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/TFT_Base_5_11.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Skin"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.850980401 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.699999988
                        }
                        Values: list[vec4] = {
                            { 0.180392161, 0.368627459, 0.972549021, 0 }
                            { 0.180392161, 0.368627459, 0.972549021, 0.373763949 }
                            { 0.180392161, 0.368627459, 0.972549021, 0.690795839 }
                            { 0.109803922, 0.109803922, 0.156862751, 0.323706269 }
                            { 0.109803922, 0.109803922, 0.156862751, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 2
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.300000012
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.300000012
                                0.400000006
                                0.200000003
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_hit_flash_110.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 530, 550, -100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.600000024, 0.600000024 }
                            { 1, 1, 1 }
                            { 1.01999998, 1.10000002, 1.04999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Dot.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Dragon017.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 20
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.5, 1 }
                    }
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = -30
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "center_ground_flash"
                Importance: u8 = 2
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.649999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 0.400000006 }
                            { 0, 0, 0, 0.0500038154 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.400000006
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.100000001
                                0.600000024
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_hit_flash_116.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 800, 340, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 0 }
                            { 0.899999976, 1, 1 }
                            { 1.10000002, 1.20000005, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Dot.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 45
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1.39999998, 5 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0399999991
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "center_ground_flash3"
                Importance: u8 = 2
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.980392158, 0.980392158, 0.980392158, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.176855057, 0.961168766, 0.872741282, 1 }
                            { 0.15763168, 0.961168766, 0.911188006, 0.458823532 }
                            { 0.111495577, 0.622837365, 0.588235319, 0.219607845 }
                            { 0.0845828578, 0.65743947, 0.638216078, 0.0392156877 }
                            { 0.173010379, 0.0422914289, 0.326797396, 0 }
                        }
                    }
                }
                Pass: i16 = 150
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.300000012
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_hit_flash_116.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 570, 340, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.097508125
                            0.149512455
                            0.236186355
                            0.331527621
                            0.459371626
                            0.645720482
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.300000012, 0.300000012 }
                            { 0.45991379, 0.462707043, 0.462707043 }
                            { 0.671120703, 0.663196743, 0.663196743 }
                            { 0.812931061, 0.806188941, 0.806188941 }
                            { 0.885344803, 0.882864058, 0.876829624 }
                            { 0.936637938, 0.936023355, 0.936023355 }
                            { 0.978879333, 0.969690859, 0.969690859 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Dot.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0399999991
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "center_ground_flash4"
                Importance: u8 = 2
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.809994638 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.97999543, 0.97999543, 0.97999543, 0.60999465 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.349999994
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.97999543, 0.97999543, 0.60999465 }
                            { 0.176783487, 0.361253232, 0.953093588, 0.60999465 }
                            { 0.176783487, 0.361253232, 0.953093588, 0.385133862 }
                            { 0.176783487, 0.361253232, 0.953093588, 0.212900087 }
                            { 0.176783487, 0.361253232, 0.953093588, 0.114822522 }
                            { 0.0845486224, 0.0845486224, 0.192155972, 0 }
                        }
                    }
                }
                Pass: i16 = -150
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.100000001
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.300000012
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_hit_flash_116.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 800, 340, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.097508125
                            0.149512455
                            0.236186355
                            0.331527621
                            0.459371626
                            0.645720482
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0.300000012, 0.300000012 }
                            { 0.45991379, 0.462707043, 0.462707043 }
                            { 0.671120703, 0.663196743, 0.663196743 }
                            { 0.812931061, 0.806188941, 0.806188941 }
                            { 0.885344803, 0.882864058, 0.876829624 }
                            { 0.936637938, 0.936023355, 0.936023355 }
                            { 0.978879333, 0.969690859, 0.969690859 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Dot.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0399999991
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ClockBase"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_huan_3.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.899999976
                        }
                        Values: list[vec4] = {
                            { 0.411764711, 0.619607866, 1, 0.700007617 }
                            { 0.411764711, 0.619607866, 1, 0.609418392 }
                            { 0.180392161, 0.368627459, 0.972549021, 0.159217417 }
                            { 0.00392156886, 0.0784313753, 0.0588235296, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.300000012
                                1
                            }
                            Values: list[f32] = {
                                0.300000012
                                2
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_glow_6.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 45, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 4, 3.70000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.097508125
                            0.149512455
                            0.236186355
                            0.331527621
                            0.459371626
                            0.645720482
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.300000012, 0.300000012 }
                            { 0.45991379, 0.462707043, 0.462707043 }
                            { 0.671120703, 0.663196743, 0.663196743 }
                            { 0.812931061, 0.806188941, 0.806188941 }
                            { 0.885344803, 0.882864058, 0.876829624 }
                            { 0.936637938, 0.936023355, 0.936023355 }
                            { 0.978879333, 0.969690859, 0.969690859 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_glow_5.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0399999991
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ClockBase1"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_huan_3.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.839993894 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.899999976
                        }
                        Values: list[vec4] = {
                            { 0.411764711, 0.619607866, 1, 0.700007617 }
                            { 0.411764711, 0.619607866, 1, 0.609418392 }
                            { 0.180392161, 0.368627459, 0.972549021, 0.159217417 }
                            { 0.00392156886, 0.0784313753, 0.0588235296, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.300000012
                                1
                            }
                            Values: list[f32] = {
                                0.300000012
                                2
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_glow_6.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 45, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 6, 6, -3.70000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.097508125
                            0.149512455
                            0.236186355
                            0.331527621
                            0.459371626
                            0.645720482
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.300000012, 0.300000012 }
                            { 0.45991379, 0.462707043, 0.462707043 }
                            { 0.671120703, 0.663196743, 0.663196743 }
                            { 0.812931061, 0.806188941, 0.806188941 }
                            { 0.885344803, 0.882864058, 0.876829624 }
                            { 0.936637938, 0.936023355, 0.936023355 }
                            { 0.978879333, 0.969690859, 0.969690859 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_glow_5.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.75
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Lines_"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1850, 0, -1850 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -1850, 0, -1850 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 0, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 0, 3 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 400, 0, 150 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 180 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.510002315 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349019617, 0.549019635, 1, 0.509803951 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.200000003
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 0.349019617, 0.549019635, 1, 0 }
                            { 0.349019617, 0.549019635, 1, 0.509803951 }
                            { 0.349019617, 0.549019635, 1, 0.509803951 }
                            { 0.349019617, 0.549019635, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                UvScrollClamp: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                DirectionVelocityScale: f32 = 0.00300000003
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.0399999991, 6, 0.200000003 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    30
                                    60
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    65
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    30
                                    50
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.0399999991, 6, 0.200000003 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_hit_flash_201.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                TexAddressModeBase: u8 = 2
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.75
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Lines_1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1850, 0, 1850 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1850, 0, 1850 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 0, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 0, 3 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 400, 0, 110 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -250, 0, -200 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.450003803 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349019617, 0.549019635, 1, 0.490196079 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.200000003
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 0.349019617, 0.549019635, 1, 0 }
                            { 0.349019617, 0.549019635, 1, 0.490196079 }
                            { 0.349019617, 0.549019635, 1, 0.490196079 }
                            { 0.349019617, 0.549019635, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                UvScrollClamp: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                DirectionVelocityScale: f32 = 0.00300000003
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.0700000003, 6, 0.200000003 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    30
                                    60
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    65
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    30
                                    50
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.0700000003, 6, 0.200000003 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_hit_flash_201.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                TexAddressModeBase: u8 = 2
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.200000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Gold_additive"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 0.701960802 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0250000004
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 19
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 330, 330 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 599.999939, 329.999969, 329.999969 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Decal_light_gold.dds"
                TexDiv: vec2 = { 1, -1 }
                TextureMult: pointer = 0xb097c1bd {
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 2, 0.5 }
                    }
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = -80
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    7
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0xa31240fd
                        }
                    }
                }
                EmitterName: string = "light"
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Pass: i16 = 5000
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1.5
                }
                Lifetime: option[f32] = {
                    4.5
                }
                EmitterName: string = "StarsUp2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 525, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.949999988
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 525, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.219607845, 0.623529434, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.219607845, 0.623529434, 1, 0 }
                            { 0.219607845, 0.623529434, 1, 1 }
                            { 0.219607845, 0.623529434, 1, 1 }
                            { 0.219607845, 0.623529434, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Stardust.dds"
                NumFrames: u16 = 4
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Additive"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.152941182, 0.305882365, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 638, 330, 330 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Decal_light.dds"
                TexDiv: vec2 = { 1, -1 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/DRX_Square.dds"
                    TexAddressModeMult: u8 = 3
                    UvScaleMult: embed = ValueVector2 {
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                                1.20000005
                            }
                            Values: list[vec2] = {
                                { 0, 0 }
                                { 5, 5 }
                            }
                        }
                    }
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 35
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.75
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "LOGO_alpha"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.113466084, 0.467963696, 0.918242157, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.100007631 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 15
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { 0, -60 }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 206, 300, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.00100000005
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0 }
                            { 1.20000005, 1.20000005, 1 }
                            { 1.20000005, 1.20000005, 0 }
                            { 1.20000005, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Logo_Icon_DRX_Stroke.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    TexAddressModeMult: u8 = 2
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.699999988, 0.699999988 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec2] = {
                                { 0.419999987, 0.419999987 }
                                { 0.699999988, 0.699999988 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 3
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "LOGO_and"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 13, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.659998477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.560006082 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 8
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.75
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 206, 150, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.00100000005
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0 }
                            { 1.20000005, 1.20000005, 1 }
                            { 1.20000005, 1.20000005, 0 }
                            { 1, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Logo_Icon_DRX.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    6
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Space_Aurora_keep"
                Importance: u8 = 2
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Core_Area_DragonScales.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.337254912, 0.58431375, 0.952941179, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.337254912, 0.58431375, 0.952941179, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.489997715 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.97000003, 0.300000012, 1.97000003 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.5, 1 }
                            { 1, 1.5, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Base_BeamMult.dds"
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -3
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 0.100000001 }
                        }
                    }
                }
                TexAddressModeBase: u8 = 3
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/21.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.400000006, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.400000006, 0.200000003 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    6
                }
                EmitterLinger: option[f32] = {
                    4
                }
                EmitterName: string = "and"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.250003815 }
                            { 0.409994662, 0.620004594, 1, 1 }
                            { 0.407843143, 0.619607866, 1, 1 }
                            { 0.0899977088, 0.209994659, 0.500007629, 0.850003839 }
                            { 0.0549019612, 0.121568628, 0.301960796, 0 }
                        }
                    }
                }
                Pass: i16 = 7
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 210, 150, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.00100000005
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0 }
                            { 1.20000005, 1.20000005, 1 }
                            { 1.20000005, 1.20000005, 0 }
                            { 1, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Logo_Icon_DRX_Stroke_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 90
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 3 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -0.5 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, -0.5 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.5, 0.5 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.5, 0.5 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    1.14999998
                }
                IsSingleParticle: flag = true
                EmitterName: string = "blend"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -95, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_StormMesh01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.125490203, 0.211764708, 0.349019617, 0.200000003 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -465
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 80, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -10, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 7, 6, 7 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Clould_10.dds"
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0.5 }
                }
                ParticleUvRotateRate: embed = IntegratedValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "HotPink-psychePurple"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Burnout.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.400000006, 0.450003803, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 63, 37.5, 37.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.300000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_common_color_bellcurve.dds"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Einstein_03_mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 2, 1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5.30000019
                }
                ParticleLinger: option[f32] = {
                    5.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dark Alpha3"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.259998471 }
                            { 0.0500038154, 0.11999695, 0.300007641, 0 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Caitlyn_Skin39_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 330, 330 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 599.999939, 329.999969, 329.999969 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0149999997
                            0.0250000004
                            0.0399999991
                            1
                        }
                        Values: list[vec3] = {
                            { 0.349999994, 0.349999994, 0.349999994 }
                            { 1.05999994, 1.05999994, 1.05999994 }
                            { 0.949999988, 0.949999988, 0.949999988 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Decal06.dds"
                TexDiv: vec2 = { 1, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    3.75
                }
                EmitterName: string = "Dark_stage_light_outside6"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_R_Shine01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.478431374, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.066001378, 0.157885641, 1, 0 }
                            { 0.200000003, 0.478431374, 1, 0.360006094 }
                            { 0.200000003, 0.478431374, 1, 0.719996929 }
                            { 0.200000003, 0.478431374, 1, 1 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1000
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                }
                                KeyValues: list[f32] = {
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.80000019, 7, 5.80000019 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_alpha_02.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                }
                TexAddressModeBase: u8 = 2
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = -90
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Einstein_03_mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 5, 0.300000012 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                                0.800000012
                                1
                            }
                            Values: list[vec2] = {
                                { 0, 0.25 }
                                { 0, 1 }
                                { 0, 0.25 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.75
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    3.75
                }
                EmitterName: string = "Dark_stage_light_outside7"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_R_Shine01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 0.811764717 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.521568656, 0.521568656, 0.521568656, 0.34117648 }
                            { 0.58431375, 0.58431375, 0.58431375, 0 }
                        }
                    }
                }
                Pass: i16 = 1001
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 50
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                UvScrollClamp: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.80000019, 15, 5.80000019 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 5.80000019, 15, 5.80000019 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.5, 1 }
                            { 1, 1, 1 }
                            { 1, 1.20000005, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_cylinder_01.dds"
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Emote_Fire014.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -0.5 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    1.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterLinger: option[f32] = {
                    3.5
                }
                EmitterName: string = "Dark_stage_light_outside9"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_R_Shine01.scb"
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.407843143, 0.619607866, 1, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.859998465, 0.859998465, 0.859998465, 0.300004572 }
                            { 0.58431375, 0.58431375, 0.58431375, 0 }
                        }
                    }
                }
                Pass: i16 = 1002
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 50
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                UvScrollClamp: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.5999999, 5, 5.5999999 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.5, 1 }
                            { 1, 1, 1 }
                            { 1, 1.20000005, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 2, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_color_01.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 90
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.200000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    4.19999981
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    4
                }
                EmitterName: string = "outside_light_up"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Mesh_Up01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.478431374, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.150000006
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.478431374, 1, 0 }
                            { 0.200000003, 0.478431374, 1, 0.200000003 }
                            { 0.200000003, 0.478431374, 1, 1 }
                            { 0.200000003, 0.478431374, 1, 0.349004 }
                            { 0, 0.318954408, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1000
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                UvScrollClamp: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.80000019, 5.80000019, 5.80000019 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.100000001, 1 }
                            { 1, 1, 1 }
                            { 1, 1.20000005, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_R_outside_light_up.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, -0.100000001 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.150000006
                                    -0.150000006
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, -0.100000001 }
                        }
                    }
                }
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.200000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Gold_additive1"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.972549021, 0.654901981, 0.105882354, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.972549021, 0.654901981, 0.105882354, 0 }
                            { 0.972549021, 0.654901981, 0.105882354, 1 }
                            { 0.972549021, 0.654901981, 0.105882354, 1 }
                            { 0.972549021, 0.654901981, 0.105882354, 0 }
                        }
                    }
                }
                Pass: i16 = 20
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 330, 330 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 599.999939, 329.999969, 329.999969 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Decal_light_gold.dds"
                TexDiv: vec2 = { 1, -1 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/common_color-bellcurve.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 2, 2 }
                    }
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = -50
                    }
                    0xdd36a38c: embed = IntegratedValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "active_spark"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 150, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.905882001, 1, 0.913725019, 0 }
                            { 1, 1, 1, 1 }
                            { 0, 0, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 520, 400, 400 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_Flash_sharp_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.125
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                Lifetime: option[f32] = {
                    1.125
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "lenz_flare"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 150, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.470588237, 1, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.901961029, 1, 0.909803987, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.349004 }
                            { 0, 0, 1, 0 }
                        }
                    }
                }
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 700, 300, 400 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                            { 1.5, 0.25, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_BA_heal_sparks_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLinger: option[f32] = {
                    4.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.407843143, 0.619607866, 1, 0.501960814 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.701960802, 0.862745106, 1 }
                            { 0.831372559, 0.964705884, 1, 1 }
                            { 1, 0.913725495, 0.737254918, 1 }
                            { 0.717647076, 0.470588237, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 50, 50 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterLinger: option[f32] = {
                    3.75
                }
                EmitterName: string = "Dark_stage_light_outside10"
                Disabled: bool = true
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_R_Shine01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.478431374, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.478431374, 1, 0 }
                            { 0.200000003, 0.478431374, 1, 0.200000003 }
                            { 0.200000003, 0.478431374, 1, 1 }
                            { 0.0660013705, 0.320545763, 1, 1 }
                            { 0.0666665956, 0.159476951, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1000
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                UvScrollClamp: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                }
                                KeyValues: list[f32] = {
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5.80000019, 15, 5.80000019 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin22_R_outside_light_up.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 0 }
                        }
                    }
                }
                TexAddressModeBase: u8 = 2
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_cylinder_01.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 2, 1 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -0.5 }
                    }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_R_AOE"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_R_AOE"
        SoundPersistentDefault: string = "Play_sfx_Kindred_KindredR_buffactivate"
        Flags: u16 = 214
    }
    0xb9702d41 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    0.75
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "distot_activate"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_E_Mark_distort_RGBA_01.dds"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.0299999993
                    NormalMapTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_P_glow_distort_01.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { -180, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1.39999998, 1.39999998, 1.39999998 }
                            { 1.70000005, 1.70000005, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Volibear_skin5_R_color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Start_flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0, 0, 0.498039007, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -25
                                    25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 75, 75 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 2, 2, 2 }
                            { 2.5, 2.5, 2.5 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.75
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                Lifetime: option[f32] = {
                    5.75
                }
                IsSingleParticle: flag = true
                EmitterName: string = "End_suck"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.749019623, 0.396078438, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -25
                                    25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/DRX_Square.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 3
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "end_flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.800000012, 0.396078438, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.800000012, 0.396078438, 1 }
                            { 1, 0.800000012, 0.396078438, 1 }
                            { 0, 0.266666383, 0.396078438, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 3, 3, 1.5 }
                            { 5, 0.100000001, 1.75 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_R_SuperSparkle.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 35
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    2.5
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 430, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 500
                            }
                            Acceleration: embed = ValueFloat {
                                ConstantValue: f32 = 200
                            }
                        }
                    }
                }
                EmitterName: string = "flash_spark"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        50
                                        100
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                        ValueFloat {
                            ConstantValue: f32 = 100
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 1.00000012 }
                        { 1.00000012, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 5, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.5, 1.5, 1.5 }
                            { 0.349999994, 0.349999994, 0.349999994 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 3
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                IsSingleParticle: flag = true
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAccelerationDefinitions: list[embed] = {
                        VfxFieldAccelerationDefinitionData {
                            IsLocalSpace: bool = false
                        }
                    }
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 430, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                        }
                    }
                }
                EmitterName: string = "flash_explore"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    150
                                    300
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.20000005, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "sparks1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.100000001, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 10, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Radius: f32 = 70
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.815686285, 0.254901975, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.75686276, 0.793331802, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.75686276, 0.793331802, 1, 0 }
                            { 0.75686276, 0.793331802, 1, 1 }
                            { 0.421468675, 0.441776931, 0.556862772, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                DirectionVelocityScale: f32 = 0.00499999989
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 45, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 45, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_SparkleB.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 3
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.230000004
                }
                ParticleLinger: option[f32] = {
                    0.230000004
                }
                Lifetime: option[f32] = {
                    1.89999998
                }
                EmitterName: string = "flat_end"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.160006106, 0.97999543, 0.540001512 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.831372559, 1, 0.80392158, 0 }
                        }
                    }
                }
                Pass: i16 = 62
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 45, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 45, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.300000012, 0.300000012 }
                            { 1, 0.300000012, 0.300000012 }
                            { 0.5, 0.300000012, 0.300000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1.39999998, 4 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.0500000007 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.0500000007 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 3
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                Lifetime: option[f32] = {
                    1.85000002
                }
                EmitterName: string = "spawn_end"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, -2, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.749996185 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.20784314, 0.921568632, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.20784314, 0.921568632, 1, 0 }
                            { 0.20784314, 0.921568632, 1, 1 }
                            { 0.20784314, 0.921568632, 1, 1 }
                            { 0.20784314, 0.921568632, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 79
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0.699999988
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Dance_Einstein_01_mult.dds"
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    10
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 65, 45, 2 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0.200000003 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0 }
                            { 1, 0.699999988, 0 }
                            { 2, 1.70000005, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_XGlitchFlip.dds"
                FrameRate: f32 = 40
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_GlitchMultColor.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 50 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 3
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dist end"
                Importance: u8 = 4
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_color_bellcurve32.dds"
                BlendMode: u8 = 1
                Pass: i16 = 1000
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.5
                    NormalMapTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Circle07.dds"
                }
                DepthBiasFactors: vec2 = { -1, -50 }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 45, 409.859985 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 5, 0 }
                            { 5, 5, 0 }
                            { 4, 5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    2.9000001
                }
                EmitterName: string = "flash1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Size: vec3 = { 50, 50, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.710002303 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.349996179, 0.549996197, 1, 0.710002303 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 100, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 120, 100, 450 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/TFT_Base_5_11.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            20
                            100
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[f32] = {
                            2
                            1.60000002
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    2.4000001
                }
                EmitterLinger: option[f32] = {
                    1.79999995
                }
                EmitterName: string = "SoftBeams"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 430, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.480003059, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0800030529 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -45
                                    -135
                                    -180
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -180
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 65, 70 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 65, 70 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 8, 3, 0 }
                            { 3, 5, 0 }
                            { 1, 7, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_soft_ray.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 20, 450 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_flash_tar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 3
                Pass: i16 = 99
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { 0.184313729, 0.372549027, 0.968627453, 0 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.699999988, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.469993144, 0.770000756, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.00999999, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.699999988, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.200000003 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.549327195, 0.439461768, 0.156616688, 1 }
                        }
                    }
                }
                Pass: i16 = 99
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.400000006, 0.400000006 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                            { 0.970000029, 1, 1 }
                            { 1.04999995, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.229999244 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.400000006, 0.400000006 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                            { 0.970000029, 1, 1 }
                            { 1.04999995, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 45
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1.39999998, 4 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.0500000007 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.0500000007 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering2"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.549327195, 0.439461768, 0.156616688, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.400000006, 0.400000006 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                            { 0.970000029, 1, 1 }
                            { 1.04999995, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Akshan_Skin10_Caitlin_mis_trail.dds"
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 70
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.179995418, 0.37000075, 0.970000744, 0.500007629 }
                }
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 140, 90, 90 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Decal_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.9000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 1, 1, 0.701960802 }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 140, 90, 90 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Decal_01.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Akshan_Skin10_Caitlin_mis_trail.dds"
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 70
                    }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_P_Mark_Activate"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_P_Mark_Activate"
        SoundPersistentDefault: string = "Play_sfx_Kindred_KindredP_mark_buffactivate"
        Flags: u16 = 212
    }
    0xcc40a955 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "sparks"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.100000001, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 10, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Radius: f32 = 70
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.815686285, 0.254901975, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.75686276, 0.793331802, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.75686276, 0.793331802, 1, 0 }
                            { 0.75686276, 0.793331802, 1, 1 }
                            { 0.421468675, 0.441776931, 0.556862772, 0 }
                        }
                    }
                }
                Pass: i16 = 1000
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                DirectionVelocityScale: f32 = 0.00499999989
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 45, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 45, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_SparkleB.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            9
                            3
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    8
                }
                Lifetime: option[f32] = {
                    2.5
                }
                EmitterName: string = "flash2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.480003059 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 1
                StencilRef: u8 = 7
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 150, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 150, 450 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.5, 0.5 }
                            { 0.449999988, 0.449999988, 0.5 }
                            { 0.449999988, 0.449999988, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.800000012, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Shared/Particles/3026_Items_color.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 90
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 0.5 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.5 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "flash3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Size: vec3 = { 50, 50, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/color-hold.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.549996197, 1, 0.710002303 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.349996179, 0.549996197, 1, 0.710002303 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 110
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 1
                StencilRef: u8 = 7
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 450 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 100, 450 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                }
                Texture: string = "ASSETS/Shared/Particles/TFT_Base_5_11.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Glow_Light.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    1
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            100
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    0.699999988
                }
                EmitterLinger: option[f32] = {
                    1.79999995
                }
                EmitterName: string = "SoftBeams1"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 430, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.490196079, 0.286274523, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.490196079, 0.286274523, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0800030529 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -101
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -45
                                    -135
                                    -180
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -180
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 65, 70 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 65, 70 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.600000024, 0.600000024 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0.600000024, 0 }
                            { 4.80000019, 1.79999995, 0 }
                            { 1.79999995, 3, 0 }
                            { 0.600000024, 4.19999981, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_soft_ray.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
                TextureMult: pointer = 0xb097c1bd {
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 2, 0 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Pass: i16 = 99
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.48999998, 0, 0 }
                            { 0.699999988, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    8
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 17, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Default.scb"
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.469993144, 0.770000756, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 45, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.00999999, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 0.48999998, 0, 0 }
                            { 0.699999988, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_Trophy_TX_CM.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Noise_01.dds"
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.200000003 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.549327195, 0.439461768, 0.156616688, 1 }
                        }
                    }
                }
                Pass: i16 = 99
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.349999994, 0.400000006, 0.400000006 }
                            { 0.770000041, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.67900002, 1, 1 }
                            { 0.734999955, 1, 1 }
                            { 0.699999988, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.229999244 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.349999994, 0.400000006, 0.400000006 }
                            { 0.770000041, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.67900002, 1, 1 }
                            { 0.734999955, 1, 1 }
                            { 0.699999988, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Z_hit_flash_113.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = 45
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1.39999998, 4 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 0.0500000007 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 0.0500000007 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ground_firering2"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.921568632, 0.737254918, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.921568632, 0.737254918, 0.262745112, 0 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.921568632, 0.737254918, 0.262745112, 1 }
                            { 0.549327195, 0.439461768, 0.156616688, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Dragon05.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 45 }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.349999994, 0.400000006, 0.400000006 }
                            { 0.770000041, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.67900002, 1, 1 }
                            { 0.734999955, 1, 1 }
                            { 0.699999988, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_p_Decal_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Akshan_Skin10_Caitlin_mis_trail.dds"
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 70
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.179995418, 0.37000075, 0.970000744, 0.500007629 }
                }
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 140, 90, 90 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Decal_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Decal1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 1, 1, 0.701960802 }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 140, 90, 90 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Decal_01.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Akshan_Skin10_Caitlin_mis_trail.dds"
                    BirthUvRotateRateMult: embed = ValueFloat {
                        ConstantValue: f32 = 70
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            20
                            100
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[f32] = {
                            2
                            1.60000002
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    2.4000001
                }
                EmitterLinger: option[f32] = {
                    1.79999995
                }
                EmitterName: string = "SoftBeams2"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 430, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.480003059, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0800030529 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -45
                                    -135
                                    -180
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0
                                    -180
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 65, 70 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 65, 70 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 8, 3, 0 }
                            { 3, 5, 0 }
                            { 1, 7, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_P_Mark_soft_ray.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Kindred_Skin23_P_Mark_Persistent"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_P_Mark_Persistent"
        Flags: u16 = 197
    }
    0xda2de94d = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ice_override"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0 }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/KindredWolf_Skin23_TX_CM.dds"
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        OverrideBlendMode: u32 = 2
                        BaseTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/empty32.dds"
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.200000003, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.200000003
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 0.800000012 }
                            { 0.482352942, 0.498039216, 0.945098042, 0.800000012 }
                            { 0.200000003, 0.480003059, 1, 0.240006119 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 135, 135, 135 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.800000012, 1, 1 }
                            { 0.200000003, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/DRX_Flame_Trail_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, -20 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.25, 0.25 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                            { 0.0549019612, 0.121568628, 0.301960796, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.180392161, 0.368627459, 0.972549021, 1 }
                            { 0.179995418, 0.37000075, 0.970000744, 0.600000024 }
                            { 0.0899977088, 0.209994659, 0.500007629, 0.300007641 }
                            { 0.0549019612, 0.121568628, 0.301960796, 0 }
                        }
                    }
                }
                Pass: i16 = -3
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 135, 135 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 0.699999988, 1, 1 }
                            { 0.200000003, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.699999988
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 50 }
                }
                EmitterName: string = "Shape_Trail_full1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 0, 0 }
                }
                Velocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 350, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.600000024 }
                            { 1, 1, 1, 0.600000024 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -60
                DisableBackfaceCull: bool = true
                DoesCastShadow: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                            { 0.300000012, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_WolfI_Trail_3.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "right_dissolve"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.349019617, 1, 0.501960814 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.349019617, 1, 0 }
                            { 0, 0.349019617, 1, 0.501960814 }
                            { 0, 0.349019617, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 3, 3, 3 }
                            { 0.25, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "Sparks_"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 1, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 30, 30, 30 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    2
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Particle_GlassTech.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "Sparks_1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1.10000002, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.10000002, 1 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 5, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 5, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 30, 30, 30 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.352941185, 0.552941203, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -180
                                    180
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                            { 1.5, 1.5, 1.5 }
                            { 0.100000001, 0.100000001, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Sparks_DRX.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "ShadowWisps"
                Importance: u8 = 2
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 10, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 0, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.480003059, 1, 0.319996953 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.480003059, 1, 0 }
                            { 0.0227450989, 0.133647904, 0.666666687, 0.319996953 }
                            { 0.0156862754, 0.0865887851, 0.43921569, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_SmokeErosion01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    180
                                    6360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 80, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 45, 80, 80 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1.10000002, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_E_Smoke01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random7"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 1000, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0941176489, 0.20784314, 0.498039216, 0.760784328 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.150000006
                            0.300000012
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.760784328 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.760784328 }
                            { 0.029176686, 0.060274031, 0.254001141, 0.0684688464 }
                            { 0.0129181091, 0.0244521331, 0.175778553, 0 }
                        }
                    }
                }
                Pass: i16 = -50
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_Trail04_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "right_dissolve1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.129411772, 0.200000003, 0.815686285, 0.278431386 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.129411772, 0.200000003, 0.815686285, 0 }
                            { 0.129411772, 0.200000003, 0.815686285, 0.278431386 }
                            { 0.129411772, 0.200000003, 0.815686285, 0 }
                        }
                    }
                }
                Pass: i16 = 500
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 3, 3, 3 }
                            { 0.25, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "DustSpikes"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Radius: f32 = 20
                    Height: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -5, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.352941185, 0.552941203, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 1 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Idle_alphaslice_mesh005.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -30 }
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    120
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    60
                                    90
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 16, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.39999998
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.200000003
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    0.600000024
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 16, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0, 0 }
                            { 5, 5.5, 0 }
                            { 6, 5.75, 1 }
                            { 6.5, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Arcus_Base_AnimeShapes02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "DustSpikes1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Radius: f32 = 20
                    Height: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 5, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.469993144, 0.770000756, 1, 0 }
                            { 0.466666669, 0.768627465, 1, 1 }
                            { 0.466666669, 0.768627465, 1, 1 }
                            { 0.349996179, 0.549996197, 1, 0 }
                            { 0.184313729, 0.372549027, 0.968627453, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.5
                    ErosionSliceWidth: f32 = 1.60000002
                    ErosionMapName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Aatrox_Skin30_Noise.dds"
                }
                DepthBiasFactors: vec2 = { -1, -30 }
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    90
                                    120
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    60
                                    90
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 7, 14, 8 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.39999998
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.200000003
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    0.600000024
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 7, 14, 8 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.850000024
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0, 0 }
                            { 5, 5.5, 0 }
                            { 6, 5.75, 1 }
                            { 6.5, 6, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Arcus_Base_AnimeShapes02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Soft_Trail_short5"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.65882355 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin12_WolfI_Trail_03.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Dragon.dds"
                    UvRotationMult: embed = ValueFloat {
                        ConstantValue: f32 = -90
                    }
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.600000024, 0.800000012 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_random8"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.125
                            0.25
                            0.375
                            0.5
                            0.625
                            0.699999988
                            0.824999988
                            1
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                            { 300, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 15, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 0, 20 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                            { 1, 1, 1, 0.800000012 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 0 }
                            { 0.482352942, 0.498039216, 0.945098042, 1 }
                            { 0.184313729, 0.372549027, 0.968627453, 0.431372553 }
                            { 0.0941176489, 0.20784314, 0.498039216, 0.0666666701 }
                            { 0.0862745121, 0.0862745121, 0.196078435, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.25, 0.25 }
                            { 0.800000012, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Trail_Flame.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.600000024, 0 }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_I_Trail"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_I_Trail"
        Flags: u16 = 197
    }
    0xe21c5dc6 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -15, 0 }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 1
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.10000002, 1.10000002, 1 }
                }
                Texture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/KindredWolf_Skin23_TX_CM.dds"
            }
        }
        ParticleName: string = "Kindred_Skin23_I_Avatar"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_I_Avatar"
    }
    0xf40c24a6 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1.60000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_Mask1"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.600000024
                            0.800000012
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        SubMeshName: option[string] = {
                            "Body"
                        }
                        BaseTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Death_Lamb01.dds"
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1.60000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_Mask2"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.600000024
                            0.800000012
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        SubMeshName: option[string] = {
                            "Horn"
                        }
                        BaseTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Death_Lamb01.dds"
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1.60000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_Mask3"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.600000024
                            0.800000012
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        SubMeshName: option[string] = {
                            "RArm"
                        }
                        BaseTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Death_Lamb01.dds"
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1.60000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wolf_Mask4"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.600000024
                            0.800000012
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        SubMeshName: option[string] = {
                            "HornVFX"
                        }
                        BaseTexture: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_TX_Horn.dds"
                    }
                }
            }
        }
        ParticleName: string = "Kindred_Skin23_Death_tex_override"
        ParticlePath: string = "Characters/Kindred/Skins/Skin23/Particles/Kindred_Skin23_Death_tex_override"
        Flags: u16 = 199
    }
    "Characters/Kindred/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x454d6537 = 0xc7d6e688
            0x348fab6a = 0x0593c93d
            0xc49b9cf7 = 0x953dfde5
            "Kindred_BA_Bounty01_hit_tar" = 0xb99c9d5d
            "Kindred_BA_Bounty01_mis" = 0xdad05e5b
            "Kindred_BA_Bounty02_hit_tar" = 0xc9c34bdc
            "Kindred_BA_Bounty02_mis" = 0x0887d672
            "Kindred_BA_bounty03_hit_tar" = 0xbc8451cf
            "Kindred_BA_Bounty03_mis" = 0x8cbf2e09
            "Kindred_BA_Crit_hit" = 0xe2feae95
            "Kindred_BA_Crit_mis" = 0x0d420a4b
            "Kindred_BA_hit_tar" = 0xc1dd8964
            "Kindred_BA_mis" = 0xe995ba8a
            "Kindred_BA_pre_attack" = 0x9dfe5f1d
            "Kindred_Death_Avatar_01" = 0x145c4f21
            "Kindred_Death_Effect" = 0xda39ba35
            "Kindred_Death_tex_override" = 0xf40c24a6
            "Kindred_Emote_Joke" = 0x2b0c10e1
            "Kindred_Emote_Joke_ground" = 0xdbd79415
            "Kindred_Emote_Laugh" = 0xcafc2a5f
            "Kindred_E_Excute" = 0x53c84211
            "Kindred_E_Full_stack_tar" = 0xf6b69c65
            "Kindred_E_trail_child" = 0x57adcc20
            "Kindred_E_mis" = 0xb8a7f816
            "Kindred_E_mis_tar" = 0x74fe5c02
            "Kindred_E_Stack_1" = 0xb5743635
            "Kindred_E_Stack_2" = 0xb274317c
            "Kindred_E_Stack_3" = 0xb374330f
            "Kindred_I_Lamb_glow" = 0x01f40fb9
            "Kindred_Joke_preshot" = 0x51fb0b5a
            "Kindred_P_Bounty_Collect" = 0x59837a38
            "Kindred_P_Camp_Kill_Sound_Enemy" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_Camp_Kill_Sound_Enemy"
            "Kindred_P_Mark_Activate" = 0xb9702d41
            "Kindred_P_Mark_deactivate" = 0x02f2dcf6
            "Kindred_P_Mark_Persistent" = 0xcc40a955
            "Kindred_P_Mark_Sound_Enemy" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_Mark_Sound_Enemy"
            "Kindred_P_Mark_Sound_Self" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_P_Mark_Sound_Self"
            "Kindred_P_Mark_Timer" = 0x4b495951
            "Kindred_P_VO_Death_Long" = 0xcdb0aab7
            "Kindred_P_VO_Death_Medium" = 0x2dd6d702
            "Kindred_P_VO_Death_Short" = 0x0a715d91
            "Kindred_Q_AS_Buf" = 0xf78a0489
            "Kindred_Q_mis" = 0x1d143e02
            "Kindred_Q_mis_tar" = 0xf90a51de
            "Kindred_Q_Pre_attack" = 0x81e95385
            "Kindred_Recall_bow" = 0x4bdd94f5
            "Kindred_Recall_wolf_ground" = 0x79bd4cfb
            "Kindred_R_AOE" = 0xb76e8003
            "Kindred_R_AOE_End" = 0xee9ae829
            0x8ade6fd1 = 0x82d344c1
            "Kindred_R_heal" = 0xb2f4ac1a
            "Kindred_R_NoDeath_Buff" = 0xd340be7d
            "Kindred_R_NoDeath_Buff_minion" = 0x2673e76c
            "Kindred_Wolf_E_wolf_mis" = "Characters/Kindred/Skins/Skin0/Particles/Kindred_Base_Wolf_E_wolf_mis"
            "Kindred_Wolf_I_Avatar" = 0xe21c5dc6
            "Kindred_Wolf_I_Trail" = 0xda2de94d
            "Kindred_Wolf_I_Trail_Non" = 0x99c38f31
            "Kindred_wolf_W_eye_glow" = 0x73465312
            "Kindred_W_Heal" = 0x3e51e9c3
            "Kindred_W_heal_mis" = 0x3bbe21bf
            "Kindred_W_Indicator_Green" = 0xb8a6a82a
            "Kindred_W_RingCast_Sound" = 0x434ce370
            "Kindred_W_Tar_Decoy_01" = 0xda6a0737
            "Kindred_W_wolf_bite" = 0xe8d78310
            "Kindred_W_wolf_PopSmoke" = 0x55b5875a
            "SRUAP_Turret_Fortification_DamageReduction" = 0xff1fb7ba
            0xb25b3be4 = 0x88aa3d4f
            0x14b101bc = 0xb020d06f
            "Kindred_Death_Avatar" = 0x00000000
            "Kindred_W_Heal_Ready" = 0xbed18803
            "Kindred_W_Heal_Ready_Avatar" = 0xc85afc9d
            0x8593bbdc = 0xc62043d0
            0x54b3b060 = 0x12fba6f0
            0xa31240fd = 0xad42322d
            0xa11ba85e = 0xb9e00ece
            0xf606a2a2 = 0x0f04a112
            0x5f9b88c3 = 0x586de113
            0xfae4b306 = 0x14cb1e96
            0x8a7776c3 = 0xa6a80793
            0xc86bf96d = 0x9909bd7d
            0xa14cf1e0 = 0xec67fdb0
            0x1ce23f57 = 0xa046c687
            0x93b1da5a = 0x318a590a
        }
    }
    0x62cef2c3 = StaticMaterialDef {
        Name: string = "Characters/Kindred/Skins/Skin23/Materials/Kindred_Skin23_MultiMask_Panner_Fresnel2_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "AlphaMask_Fresnel"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/common_Black.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_01"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Karma_Skin26_Q_SphereScroll_01.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_mask_Fresnel.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_02"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Dance_Einstein_01_mult.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_03"
                TextureName: string = "ASSETS/Characters/LeeSin/Skins/Skin31/Particles/LeeSin_Skin31_E_Bottom_02.dds"
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 0.644999981, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Texture_UV_Scale01"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 0, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Panning_Noise_Color"
                Value: vec4 = { 0.0899977088, 0.209994659, 0.500007629, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollTexture_Control01"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Texture_UV_Scale02"
                Value: vec4 = { 8, 5, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollTexture_Control02"
                Value: vec4 = { -0.200000003, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Texture_UV_Scale03"
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollTexture_Control03"
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomIntensity"
                Value: vec4 = { 3, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "INVERT_FRESNEL"
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_DIFFUSE_ALPHA"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/MultiMask_Panner_Fresnel"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {}
    }
    0x7c18cad8 = StaticMaterialDef {
        Name: string = "Characters/Kindred/Skins/Skin23/Materials/Kindred_Skin23_Flame_Horn_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Materials_color.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Panning_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Materials_Flame.dds"
                AddressV: u32 = 2
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Panning_Scale"
                Value: vec4 = { 1, 2, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Panning_Speed"
                Value: vec4 = { 0, 0.5, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Control"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = 0x6e9b4f0f
                        BlendEnable: bool = true
                        CullEnable: bool = false
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {}
    }
    0x9d354c20 = StaticMaterialDef {
        Name: string = "Characters/Kindred/Skins/Skin23/Materials/Kindred_Skin23_Horn_01_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Kindred_Skin23_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture_red"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_TX_Horn.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 2, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.203921571, 0.501960814, 0.945098042, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_ALPHA"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Diffuse_Bloom"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Mask_Texture_red"
                }
            }
        }
    }
    0xd95d177e = StaticMaterialDef {
        Name: string = "Characters/Kindred/Skins/Skin23/Materials/Kindred_Skin23_Fire01_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_TX_CM01.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_SoulFlowNoise.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "EmissionR_DistortionG_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_FlowDistortion.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "RMA_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin02_i_White.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "RMA_Value"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Levels"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Contrast"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Darkness"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Outline_Color"
                Value: vec4 = { 1, 0.752941191, 0.125490203, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Outline_Control"
                Value: vec4 = { 0.400000006, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "OutlineBlendValue"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_UV_Tile"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_UV_Scroll_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_UV_Tile"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_UV_Scroll_Speed"
                Value: vec4 = { 0.5, 0.5, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_B_UV_Tile"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_B_UV_Scroll_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "TintColor"
                Value: vec4 = { 1, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveValue"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveEdgePowObjSize"
                Value: vec4 = { 40, 500, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveEdgeColor"
                Value: vec4 = { 1, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveStrengthLength"
                Value: vec4 = { 1, 1, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DeformWaveController"
                Value: vec4 = { 0.5, 3, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DeformWaveStrength"
                Value: vec4 = { 1, 1.25, 0.300000012, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_Tint"
                Value: vec4 = { 0, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_Tint"
                Value: vec4 = { 0.300000012, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_MaskStrength"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomPow_RGB"
                Value: vec4 = { 0, 0.349996179, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "EdgeBloomColor_RGB"
                Value: vec4 = { 0, 0, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveLocationOffset"
                Value: vec4 = { 0, 240, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "EmissionColor"
                Value: vec4 = { 0, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DistortionStrength"
                Value: vec4 = { 0.00999999978, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveDirNoiseA"
                Value: vec4 = { 1.75, 1.75, 1.75, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveDirNoiseB"
            }
            StaticMaterialShaderParamDef {
                Name: string = "All_Additive_Strength"
                Value: vec4 = { 0.899999976, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "VFX_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_ALPHA_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_G_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_R_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "DEFORM_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "TWO_D_DEFORM_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "OUTLINE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "BLOOM_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "DISTORTION_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "ALL_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "ADDITIVE_OUTLINE_ONLY"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = 0xe790456d
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "DissolveValue"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Respawn"
                                    }
                                }
                                mValue: pointer = RemapFloatMaterialDriver {
                                    mDriver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Respawn"
                                    }
                                    mMinValue: f32 = 0.200000003
                                    mMaxValue: f32 = 0.800000012
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Recall_Winddown"
                                    }
                                }
                                mValue: pointer = RemapFloatMaterialDriver {
                                    mDriver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Recall_Winddown"
                                    }
                                    mMinValue: f32 = 0.200000003
                                    mMaxValue: f32 = 0.699999988
                                }
                            }
                        }
                        mDefaultValue: pointer = FloatLiteralMaterialDriver {
                            mValue: f32 = 1
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "DissolveEdgeColor"
                    Driver: pointer = 0x22d8a036 {
                        0x0e4fb927: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                            mAnimationNames: list[hash] = {
                                "Respawn"
                                "Recall_Winddown"
                            }
                        }
                        OnValue: vec4 = { 1, 0.600000024, 0, 1 }
                        OffValue: vec4 = { 1, 1, 1, 1 }
                        0x9aae8e3b: f32 = 1.75
                        0x1ea12a67: f32 = 0
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Outline_Color"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Respawn"
                                    }
                                }
                                mValue: pointer = ColorGraphMaterialDriver {
                                    Driver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Respawn"
                                    }
                                    Colors: embed = VfxAnimatedColorVariableData {
                                        Times: list[f32] = {
                                            0
                                            0.529999971
                                            0.560000002
                                            0.800000012
                                        }
                                        Values: list[vec4] = {
                                            { 1, 0, 0, 1 }
                                            { 1, 0, 0, 1 }
                                            { 1, 1, 1, 1 }
                                            { 1, 0, 0, 1 }
                                        }
                                    }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Recall_Winddown"
                                    }
                                }
                                mValue: pointer = ColorGraphMaterialDriver {
                                    Driver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Recall_Winddown"
                                    }
                                    Colors: embed = VfxAnimatedColorVariableData {
                                        Times: list[f32] = {
                                            0
                                            0.529999971
                                            0.560000002
                                            0.800000012
                                        }
                                        Values: list[vec4] = {
                                            { 1, 0, 0, 1 }
                                            { 1, 0, 0, 1 }
                                            { 1, 1, 1, 1 }
                                            { 1, 0, 0, 1 }
                                        }
                                    }
                                }
                            }
                        }
                        mDefaultValue: pointer = 0xf4c0192d {
                            Value: vec4 = { 0, 0, 0, 0 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Outline_Control"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Respawn"
                                    }
                                }
                                mValue: pointer = ColorGraphMaterialDriver {
                                    Driver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Respawn"
                                    }
                                    Colors: embed = VfxAnimatedColorVariableData {
                                        Times: list[f32] = {
                                            0
                                            0.529999971
                                            0.560000002
                                            0.649999976
                                        }
                                        Values: list[vec4] = {
                                            { 0.200000003, 0.200000003, 0, 0 }
                                            { 0.200000003, 0.200000003, 0, 0 }
                                            { 1, 0.200000003, 0, 0 }
                                            { 0.200000003, 0.200000003, 0, 0 }
                                        }
                                    }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Respawn"
                                    }
                                }
                                mValue: pointer = ColorGraphMaterialDriver {
                                    Driver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Respawn"
                                    }
                                    Colors: embed = VfxAnimatedColorVariableData {
                                        Times: list[f32] = {
                                            0
                                            0.529999971
                                            0.560000002
                                            0.649999976
                                        }
                                        Values: list[vec4] = {
                                            { 0.200000003, 0.200000003, 0, 0 }
                                            { 0.200000003, 0.200000003, 0, 0 }
                                            { 1, 0.200000003, 0, 0 }
                                            { 0.200000003, 0.200000003, 0, 0 }
                                        }
                                    }
                                }
                            }
                        }
                        mDefaultValue: pointer = 0xf4c0192d {
                            Value: vec4 = { 0, 0, 0, 0 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "EmissionColor"
                    Enabled: bool = false
                    Driver: pointer = TimeMaterialDriver {}
                }
            }
        }
    }
    0xe5c98091 = StaticMaterialDef {
        Name: string = "Characters/Kindred/Skins/Skin23/Materials/Kindred_Skin23_ToonShading_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin02_i_White.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_Texture"
                TextureName: string = "ASSETS/Characters/Kindred/skins/Skin23/Particles/Kindred_Skin23_Air_Swoosh02.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "EmissionR_DistortionG_Texture"
                TextureName: string = "ASSETS/Shared/Materials/BC_TestTexture.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "RMA_Texture"
                TextureName: string = "ASSETS/Shared/Materials/white.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "RMA_Value"
                Value: vec4 = { 1, 1, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Levels"
                Value: vec4 = { 1.27499998, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Contrast"
                Value: vec4 = { 0.449999988, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Darkness"
                Value: vec4 = { 1.02499998, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Outline_Color"
                Value: vec4 = { 0.0941176489, 0.20784314, 0.498039216, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Outline_Control"
            }
            StaticMaterialShaderParamDef {
                Name: string = "OutlineBlendValue"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_UV_Tile"
                Value: vec4 = { 1, 2, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_UV_Scroll_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_UV_Tile"
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_UV_Scroll_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_B_UV_Tile"
                Value: vec4 = { 2, 0.400000006, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_B_UV_Scroll_Speed"
                Value: vec4 = { 0, 0.300000012, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "TintColor"
                Value: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 0.549019635 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveValue"
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveEdgePowObjSize"
                Value: vec4 = { 0, 350, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveEdgeColor"
                Value: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveStrengthLength"
                Value: vec4 = { 1, 1, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DeformWaveController"
                Value: vec4 = { 0.5, 3, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DeformWaveStrength"
                Value: vec4 = { 1, 1.25, 0.300000012, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_Tint"
                Value: vec4 = { 1, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_Tint"
                Value: vec4 = { 0, -0.200000003, -0.200000003, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_MaskStrength"
                Value: vec4 = { 1.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomPow_RGB"
                Value: vec4 = { 0.179995418, 0.37000075, 0.970000744, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "EdgeBloomColor_RGB"
                Value: vec4 = { 0.0549019612, 0.121568628, 0.301960796, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveLocationOffset"
            }
            StaticMaterialShaderParamDef {
                Name: string = "EmissionColor"
                Value: vec4 = { 0, 1, 1, 0.349996179 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DistortionStrength"
                Value: vec4 = { 0.61500001, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveDirNoiseA"
                Value: vec4 = { 1, 1, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveDirNoiseB"
                Value: vec4 = { 2, 2, 2, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "All_Additive_Strength"
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "VFX_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_ALPHA_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_G_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_R_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "DEFORM_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "TWO_D_DEFORM_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "OUTLINE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "BLOOM_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "DISTORTION_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "ALL_ADDITIVE_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ADDITIVE_OUTLINE_ONLY"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = 0xe790456d
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "DissolveValue"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Respawn"
                                    }
                                }
                                mValue: pointer = FloatGraphMaterialDriver {
                                    Driver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Respawn"
                                    }
                                    Graph: embed = VfxAnimatedFloatVariableData {
                                        Times: list[f32] = {
                                            0
                                            0.640243888
                                            1
                                        }
                                        Values: list[f32] = {
                                            0
                                            0
                                            1
                                        }
                                    }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Recall_Winddown"
                                    }
                                }
                                mValue: pointer = FloatGraphMaterialDriver {
                                    Driver: pointer = AnimationFractionDynamicMaterialFloatDriver {
                                        mAnimationName: hash = "Recall_Winddown"
                                    }
                                    Graph: embed = VfxAnimatedFloatVariableData {
                                        Times: list[f32] = {
                                            0
                                            0.640243888
                                            1
                                        }
                                        Values: list[f32] = {
                                            0
                                            0
                                            1
                                        }
                                    }
                                }
                            }
                        }
                        mDefaultValue: pointer = FloatLiteralMaterialDriver {
                            mValue: f32 = 1
                        }
                    }
                }
            }
        }
    }
}
