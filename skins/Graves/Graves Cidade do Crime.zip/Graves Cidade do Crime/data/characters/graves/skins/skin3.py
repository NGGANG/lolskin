#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Graves/Graves.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin2_Skins_Skin25_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin5_Skins_Skin6_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin2_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin26_Skins_Skin3_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Graves/Animations/Skin3.bin"
    "DATA/Graves_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin42_Skins_Skin43_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin2_Skins_Skin26_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Graves_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin6.bin"
}
entries: map[hash,embed] = {
    "Characters/Graves/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "MafiaGraves"
        MetaDataTags: string = "faction:bilgewater,gender:male,race:human,skinline:crimecity"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Graves/Skins/Skin03/GravesLoadScreen_3.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Graves"
                "MafiaGraves"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Graves_Skin03_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Graves/Skins/Skin03/Graves_Skin03_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Graves/Skins/Skin03/Graves_Skin03_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_MafiaGraves_GravesBasicAttack_OnHit"
                        "Play_sfx_MafiaGraves_GravesBasicAttack_OnMissileCast"
                        "Play_sfx_MafiaGraves_GravesBasicAttack_OnMissileLaunch"
                        "Play_sfx_MafiaGraves_GravesClusterShotSoundMissile_OnMissileCast"
                        "Play_sfx_MafiaGraves_GravesCritAttack_OnHit"
                        "Play_sfx_MafiaGraves_GravesCritAttack_OnMissileCast"
                        "Play_sfx_MafiaGraves_GravesCritAttack_OnMissileLaunch"
                        "Stop_sfx_MafiaGraves_GravesClusterShotSoundMissile_OnMissileCast"
                    }
                }
                BankUnit {
                    Name: string = "Graves_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Graves/Skins/Base/Graves_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Graves/Skins/Base/Graves_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    Name: string = "Graves_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Graves/Skins/Base/Graves_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Graves/Skins/Base/Graves_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Graves/Skins/Base/Graves_Base_VO_audio.wpk"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Graves/Animations/Skin3"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Graves/Skins/Skin03/Graves_mafia.skl"
            SimpleSkin: string = "ASSETS/Characters/Graves/Skins/Skin03/Graves_mafia.skn"
            Texture: string = "ASSETS/Characters/Graves/Skins/Skin03/Graves_mafia_TX_CM.dds"
            SkinScale: f32 = 1.20000005
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
        }
        ArmorMaterial: string = "Flesh"
        IconAvatar: string = "ASSETS/Characters/Graves/HUD/Graves_Circle_3.dds"
        mContextualActionData: link = "Characters/Graves/CAC/Graves_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Graves/HUD/Graves_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Graves/HUD/Graves_Square.dds"
        }
        UncensoredIconCircles: map[hash,string] = {
            "tobacco" = "ASSETS/Characters/Graves/HUD/Graves_Circle_Tobacco.dds"
        }
        UncensoredIconSquares: map[hash,string] = {
            "tobacco" = "ASSETS/Characters/Graves/HUD/Graves_Square_Tobacco.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/29"
            }
        }
        mResourceResolver: link = "Characters/Graves/Skins/Skin3/Resources"
    }
    "Characters/Graves/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x2d2c7118 = 0x61f5cf44
            "Graves_BA_cas" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_BA_cas"
            "Graves_BA_Dummy_Controller" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_BA_Dummy_Controller"
            "Graves_BA_mis" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_BA_mis"
            "Graves_BA_Tar" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_BA_tar"
            "Graves_E_buf" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf"
            "Graves_E_buf_1" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf_1"
            "Graves_E_buf_2" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf_2"
            "Graves_E_buf_3" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf_3"
            "Graves_E_buf_4" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf_4"
            "Graves_E_buf_5" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf_5"
            "Graves_E_buf_6" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_buf_6"
            "Graves_E_cas" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_E_cas"
            "Graves_Idle" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Idle"
            "Graves_P_ShotAttack_01" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_P_ShotAttack_01"
            "Graves_Q_Bomb" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Bomb"
            "Graves_Q_Bomb_Wall" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Bomb_Wall"
            "Graves_Q_cas" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_cas"
            "Graves_Q_Explosion" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Explosion"
            "Graves_Q_Mis" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Mis"
            "Graves_Q_Return_Mis" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Return_Mis"
            "Graves_Q_Tar" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Tar"
            "Graves_Q_Tar_Return" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_Q_Tar_Return"
            "Graves_R_ChargeShot_cas_01" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_R_ChargeShot_cas_01"
            "Graves_R_hit" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_R_hit"
            "Graves_R_mis" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_R_mis"
            "Graves_W_cas" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_W_cas"
            "Graves_W_hit" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_W_hit"
            "Graves_W_mis" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_W_mis"
            "Graves_W_tar_green" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_W_tar_green"
            "Graves_W_tar_red" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_W_tar_red"
            "Graves_W_Nearsight" = "Characters/Graves/Skins/Skin0/Particles/Graves_Base_W_Nearsight"
            0x9b589354 = 0x5f2b90d1
        }
    }
}
