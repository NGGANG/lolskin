#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Jayce/Jayce.bin"
    "DATA/Characters/Jayce/Animations/Skin3.bin"
    "DATA/Jayce_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jayce_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jayce_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jayce_Skins_Skin0_Skins_Skin3_Skins_Skin4.bin"
    "DATA/Jayce_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4.bin"
    "DATA/Jayce_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jayce_Skins_Skin0_Skins_Skin24_Skins_Skin3_Skins_Skin4.bin"
}
entries: map[hash,embed] = {
    "Characters/Jayce/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "JayceSkin03"
        MetaDataTags: string = "gender:male,faction:piltover,race:human,element:dark,skinline:legacy"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Jayce/Skins/Skin03/JayceLoadScreen_3.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Jayce"
                "JayceSkin03"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Jayce_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jayce/Skins/Base/Jayce_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jayce/Skins/Base/Jayce_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jayce/Skins/Base/Jayce_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Jayce_Attack2DGeneral"
                        "Play_vo_Jayce_Death3D"
                        "Play_vo_Jayce_JayceBasicAttack2_cast3D"
                        "Play_vo_Jayce_JayceBasicAttack_cast3D"
                        "Play_vo_Jayce_JayceCritAttack_cast3D"
                        "Play_vo_Jayce_JayceShockBlast_cast3D"
                        "Play_vo_Jayce_JayceShockBlastWallSound_OnBuffActivate"
                        "Play_vo_Jayce_JayceShockBlastWallSoundHit_OnBuffActivate"
                        "Play_vo_Jayce_JayceStanceGtH_cast3D"
                        "Play_vo_Jayce_JayceStanceHtG_cast3D"
                        "Play_vo_Jayce_JayceThunderingBlow_cast3D"
                        "Play_vo_Jayce_JayceToTheSkies_cast3D"
                        "Play_vo_Jayce_Joke3DGeneral"
                        "Play_vo_Jayce_Laugh3DGeneral"
                        "Play_vo_Jayce_Move2DStandard"
                        "Play_vo_Jayce_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Jayce_Skin03_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jayce/Skins/Skin03/Jayce_Skin03_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jayce/Skins/Skin03/Jayce_Skin03_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jayce/Skins/Skin03/Jayce_Skin03_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_JayceSkin03_Attack2DGeneral"
                        "Play_vo_JayceSkin03_Death3D"
                        "Play_vo_JayceSkin03_JayceBasicAttack2_cast3D"
                        "Play_vo_JayceSkin03_JayceBasicAttack_cast3D"
                        "Play_vo_JayceSkin03_JayceCritAttack_cast3D"
                        "Play_vo_JayceSkin03_JayceShockBlast_cast3D"
                        "Play_vo_JayceSkin03_JayceShockBlastWallSound_OnBuffActivate"
                        "Play_vo_JayceSkin03_JayceShockBlastWallSoundHit_OnBuffActivate"
                        "Play_vo_JayceSkin03_JayceStanceGtH_cast3D"
                        "Play_vo_JayceSkin03_JayceStanceHtG_cast3D"
                        "Play_vo_JayceSkin03_JayceThunderingBlow_cast3D"
                        "Play_vo_JayceSkin03_JayceToTheSkies_cast3D"
                        "Play_vo_JayceSkin03_Joke3DGeneral"
                        "Play_vo_JayceSkin03_Laugh3DGeneral"
                        "Play_vo_JayceSkin03_Move2DStandard"
                        "Play_vo_JayceSkin03_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Jayce_Skin03_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Jayce/Skins/Skin03/Jayce_Skin03_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Jayce/Skins/Skin03/Jayce_Skin03_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_JayceSkin03_Dance3D_buffactivate"
                        "Play_sfx_JayceSkin03_Dance3D_buffactivate_loop"
                        "Play_sfx_JayceSkin03_Death3D_cast"
                        "Play_sfx_JayceSkin03_JayceAccelerationGate_OnCast"
                        "Play_sfx_JayceSkin03_JayceAcceleratorBeam_buffactivate_loop"
                        "Play_sfx_JayceSkin03_JayceAcceleratorBeam_buffdeactivate"
                        "Play_sfx_JayceSkin03_JayceAcceleratorChampionBuff_OnBuffActivate"
                        "Play_sfx_JayceSkin03_JayceBasicAttack2_OnCast"
                        "Play_sfx_JayceSkin03_JayceBasicAttack2_OnHit"
                        "Play_sfx_JayceSkin03_JayceBasicAttack_OnCast"
                        "Play_sfx_JayceSkin03_JayceBasicAttack_OnHit"
                        "Play_sfx_JayceSkin03_JayceCritAttack_OnCast"
                        "Play_sfx_JayceSkin03_JayceCritAttack_OnHit"
                        "Play_sfx_JayceSkin03_JayceHyperCharge_OnBuffActivate"
                        "Play_sfx_JayceSkin03_JayceHyperCharge_OnBuffDeactivate"
                        "Play_sfx_JayceSkin03_JayceHyperCharge_OnCast"
                        "Play_sfx_JayceSkin03_JayceHyperChargeRangedAttack_OnCast"
                        "Play_sfx_JayceSkin03_JayceHyperChargeRangedAttack_OnHit"
                        "Play_sfx_JayceSkin03_JayceHyperChargeRangedAttack_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JaycePassiveMeleeAttack_OnCast"
                        "Play_sfx_JayceSkin03_JaycePassiveMeleeAttack_OnHit"
                        "Play_sfx_JayceSkin03_JaycePassiveRangedAttack_hit"
                        "Play_sfx_JayceSkin03_JaycePassiveRangedAttack_OnCast"
                        "Play_sfx_JayceSkin03_JaycePassiveRangedAttack_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JayceRangedAttack2_OnCast"
                        "Play_sfx_JayceSkin03_JayceRangedAttack2_OnHit"
                        "Play_sfx_JayceSkin03_JayceRangedAttack2_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JayceRangedAttack_OnCast"
                        "Play_sfx_JayceSkin03_JayceRangedAttack_OnHit"
                        "Play_sfx_JayceSkin03_JayceRangedAttack_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JayceRangedCritAttack_OnCast"
                        "Play_sfx_JayceSkin03_JayceRangedCritAttack_OnHit"
                        "Play_sfx_JayceSkin03_JayceRangedCritAttack_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JayceShockBlast_OnCast"
                        "Play_sfx_JayceSkin03_JayceShockBlastMis_hit"
                        "Play_sfx_JayceSkin03_JayceShockBlastMis_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JayceShockBlastWallMis_hit"
                        "Play_sfx_JayceSkin03_JayceShockBlastWallMis_OnMissileLaunch"
                        "Play_sfx_JayceSkin03_JayceStanceGtH_OnCast"
                        "Play_sfx_JayceSkin03_JayceStanceHtG_OnCast"
                        "Play_sfx_JayceSkin03_JayceStaticField_OnBuffActivate"
                        "Play_sfx_JayceSkin03_JayceStaticField_OnBuffDeactivate"
                        "Play_sfx_JayceSkin03_JayceStaticField_OnCast"
                        "Play_sfx_JayceSkin03_JayceThunderingBlow_OnCast"
                        "Play_sfx_JayceSkin03_JayceThunderingBlow_OnHit"
                        "Play_sfx_JayceSkin03_JayceToTheSkies_hit"
                        "Play_sfx_JayceSkin03_JayceToTheSkies_OnCast"
                        "Play_sfx_JayceSkin03_Joke3D_buffactivate"
                        "Play_sfx_JayceSkin03_Laugh3D_buffactivate"
                        "Play_sfx_JayceSkin03_Recall_leadin"
                        "Play_sfx_JayceSkin03_Recall_Winddown3D_leadin"
                        "Play_sfx_JayceSkin03_Recall_Winddown3D_leadout_melee"
                        "Play_sfx_JayceSkin03_Recall_Winddown3D_leadout_ranged"
                        "Play_sfx_JayceSkin03_Taunt3D_buffactivate"
                        "Stop_sfx_JayceSkin03_JayceHyperCharge_OnBuffActivate"
                        "Stop_sfx_JayceSkin03_JayceShockBlastMis_OnMissileLaunch"
                        "Stop_sfx_JayceSkin03_JayceShockBlastWallMis_OnMissileLaunch"
                        "Stop_sfx_JayceSkin03_JayceStaticField_OnBuffActivate"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Jayce/Animations/Skin3"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Jayce/Skins/Skin03/Jayce_Skin03.skl"
            SimpleSkin: string = "ASSETS/Characters/Jayce/Skins/Skin03/Jayce_Skin03.skn"
            Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Jayce_Forsaken_TX_CM.dds"
            SkinScale: f32 = 0.949999988
            SelfIllumination: f32 = 0.699999988
            UsesSkinVo: bool = true
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Idle1_flowerstill"
        }
        IconAvatar: string = "ASSETS/Characters/Jayce/HUD/Jayce_Circle_3.dds"
        mContextualActionData: link = "Characters/Jayce/CAC/Jayce_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Jayce/HUD/Jayce_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Jayce/HUD/Jayce_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/29"
            }
        }
        mResourceResolver: link = "Characters/Jayce/Skins/Skin3/Resources"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_end_RED" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wall_Ball_End"
                Importance: u8 = 2
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wall_Ball_EndR"
                Importance: u8 = 2
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_02.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_accel_gate_end_RED"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_end_RED"
        SoundOnCreateDefault: string = "Play_sfx_Jayce_JayceAcceleratorBeam_buffdeactivate"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_end" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wall_Ball_End"
                Importance: u8 = 2
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Wall_Ball_EndR"
                Importance: u8 = 2
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -100
                                    -50
                                    50
                                    100
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_01.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_accel_gate_end"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_end"
        SoundOnCreateDefault: string = "Play_sfx_Jayce_JayceAcceleratorBeam_buffdeactivate"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_2" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.666666985, 0, 1, 1 }
                            { 0.262744993, 0, 0, 1 }
                            { 0.164706007, 0, 0, 0.800000012 }
                            { 0.333332986, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, 120 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 120, 120, 120 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1.29999995, 1.29999995, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ring"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 140, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Center_Glow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.337254912 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.666666985, 0, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 0.25, 0.400000006, 0.25 }
                            { 2, 0, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_BA_2"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_2"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_1" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 0.262744993, 0, 0, 1 }
                            { 0.164706007, 0, 0, 0.800000012 }
                            { 0.333332986, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, 120 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 120, 120, 120 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1.29999995, 1.29999995, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ring"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 140, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Center_Glow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.337254912 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 0.25, 0.400000006, 0.25 }
                            { 2, 0, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_BA_1"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_1"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Model_Swap2" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -1200, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 450, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 45, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 20, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Beam_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -500, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_04.dds"
                FrameRate: f32 = 26
                NumFrames: u16 = 8
                StartFrame: u16 = 1
                TexDiv: vec2 = { 8, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Center_Glow"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.701960802, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 300, 600 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 0.25, 0.400000006, 0.25 }
                            { 2, 0, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Upper"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568635, 0, 0, 1 }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 2.5, 2.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1.5, 2.5, 2.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 20
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.576470613 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0.486274987 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ground_Glow"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.525490224 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 0, 0, 0 }
                            { 0.435294002, 0.145098001, 0, 1 }
                            { 0.345097989, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 300, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    9
                }
                IsSingleParticle: flag = true
                EmitterName: string = "avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.494117647, 0.0784313753, 0.266666681, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.494117647, 0.0784313753, 0.266666681, 1 }
                            { 0.494117647, 0.0784313753, 0.266666681, 0 }
                        }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                ParticleIsLocalOrientation: flag = true
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/common_color-hold.dds"
                UvMode: u8 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.0500000007, -0.0250000004 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 3, 3 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_IndicatorMult_01.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.5, 0.5 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -0.5 }
                    }
                }
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_Model_Swap2"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Model_Swap2"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Range" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                EmitterName: string = "Bits_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -15, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.501960814 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.231372997, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Stance_Range"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Range"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_StaticStorm_Hit" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 16
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.699999988
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "Electricity"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Radius: f32 = 50
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -10
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_IndicatorMult_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                FrameRate: f32 = 16
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    0.5
                }
                EmitterName: string = "GlowJayce"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1000, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 45, 15 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 50
                    Height: f32 = 50
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -30, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.439993888 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.117647059, 0.117647059, 0.388235301 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.117647059, 0.117647059, 0.388235301 }
                            { 1, 0.117647059, 0.117647059, 0.388235301 }
                            { 1, 0.117647059, 0.117647059, 0 }
                            { 1, 0.117647059, 0.117647059, 0.388235301 }
                            { 1, 0.117647059, 0.117647059, 0.388235301 }
                            { 1, 0.117647059, 0.117647059, 0 }
                            { 1, 0.117647059, 0.117647059, 0.388235301 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 10, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Flicker"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00300000003
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 0.721568644 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.439993888 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 200
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.188752443
                            0.381706536
                            0.581124783
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.743064523, 0, 0 }
                            { 0.987927556, 0, 0 }
                            { 0.253458887, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 16
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.699999988
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "Electricity1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Radius: f32 = 50
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 0.666666687, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_IndicatorMult_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                FrameRate: f32 = 16
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_StaticStorm_Hit"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_StaticStorm_Hit"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_OrbLightningCharged" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1000
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Sparks1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 3000, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -300
                                    300
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -300
                                    300
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 3000, 1 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -200, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -100, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                ColorRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                DirectionVelocityScale: f32 = 0.00800000038
                DirectionVelocityMinScale: f32 = 1.29999995
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 5, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Sparks_01.dds"
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Light_Projected"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -100, -100 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 0.180392161 }
                }
                ColorRenderFlags: u8 = 1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Ribbon_1"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                ColorRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Ribbon_2"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                ColorRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Red"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.498039007, 1 }
                            { 1, 0, 0.498039007, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                ColorRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 190, 200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 190, 200, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Black"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.156862751, 0.156862751, 0.156862751, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                ColorRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 90, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 90, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Smoke_01"
                Importance: u8 = 2
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                ColorRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 360 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 190, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 190, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Sphere_Stretch"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_sphere_stretch.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.505882382, 0, 0, 1 }
                }
                Pass: i16 = 11
                ColorRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Wrap.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -5 }
                }
                TexDiv: vec2 = { 0.5, 1 }
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_OrbLightningCharged"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_OrbLightningCharged"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                EmitterName: string = "Bits_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 80 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 40 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Hex_Buff_Ready"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_ThunderingBlow_Hit" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    0.5
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                Lifetime: option[f32] = {
                    0.0500000007
                }
                IsSingleParticle: flag = true
                EmitterName: string = "vecalign"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 2, 1000 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -500
                                    500
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -250
                                    250
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 2, 1000 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 4, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 4, 3 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -200, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 150 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                DirectionVelocityScale: f32 = 0.00800000038
                DirectionVelocityMinScale: f32 = 1.29999995
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 2, 5, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Sparks_01.dds"
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Hit_Center_Flash"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 150 }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.352941185 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 80, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 1, 5 }
                            { 1, 0.100000001, 1 }
                            { 1, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 150 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 0.227450997, 0, 0, 1 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "fireRing"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 150 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0299999993
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 350, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flare_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                Lifetime: option[f32] = {
                    0.0500000007
                }
                IsSingleParticle: flag = true
                EmitterName: string = "vecalign1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 2, 1000 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -500
                                    500
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -250
                                    250
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 2, 1000 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 4, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 4, 3 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 150 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                DirectionVelocityScale: f32 = 0.00800000038
                DirectionVelocityMinScale: f32 = 1.29999995
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    10.3500004
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_Mesh"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 500 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 80, 300 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.258823544, 0, 0, 1 }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 2, 5 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 30
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
        }
        ParticleName: string = "Jayce_Skin03_ThunderingBlow_Hit"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_ThunderingBlow_Hit"
        Flags: u16 = 132
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Death_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            25
                            50
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Vents1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -100, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Hyper_Charge_Blasts.sco"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.172549024, 0.172549024, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 360, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 200, 200, 200 }
                            { 300, 300, 300 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 1 }
                            { 1.29999995, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flare_Directional_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Death_01"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Death_01"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Death_02" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Pre-Burst"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.384313762, 0.384313762, 1 }
                }
                Pass: i16 = 101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 160, 160 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 1.5, 1.5 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Burst"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 180, 180 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    10.8000002
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "hagaSphere"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_z_sphere_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0, 0, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.600000024 }
                            { 0, 0, 0, 0.300000012 }
                        }
                    }
                }
                Pass: i16 = 12
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.5, 2.5, 2.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Sphere_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.5 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                Lifetime: option[f32] = {
                    1.05999994
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Blend1"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 13
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 30
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 230, 230, 230 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "distort"
                ParticleColorTexture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_color-rampdown32_03.dds"
                BlendMode: u8 = 1
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.100000001
                    NormalMapTexture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_distort-shockwave.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 220, 220 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_Aura_Self.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_Death_02"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Death_02"
        Flags: u16 = 195
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_W_Attk1_Hex_Buff_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    10.1000004
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Vents"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Hyper_Charge_Blasts.sco"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.172549024, 0.172549024, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 360, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 100, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 3 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flare_Directional_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_W_Attk1_Hex_Buff_01"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_W_Attk1_Hex_Buff_01"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_PassiveReadyMelee" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.449999988
                }
                EmitterName: string = "Bits_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 40 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                EmitterName: string = "Bits_2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 500, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.447058856 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Smoke_02.dds"
                NumFrames: u16 = 8
                TexDiv: vec2 = { 4, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_PassiveReadyMelee"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_PassiveReadyMelee"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Wall_Accel_Buf" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "flashring"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.376470625, 0.321568638, 1, 0.545098066 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 800, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 200, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.5, 1.5, 1.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Shockwave.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "SpeedLines"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 1, -30 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        150
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 1, -30 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.631372988, 0.49019599, 0.478430986, 0 }
                            { 0.631372988, 0.478430986, 0.478430986, 1 }
                            { 0.631372988, 0.368627012, 0.368627012, 1 }
                            { 0.631372988, 0.384314001, 0.384314001, 0 }
                        }
                    }
                }
                ColorLookUpScales: vec2 = { 1, 0.300000012 }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.20000005
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.20000005
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 30, 30, 30 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Speedlines_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1.5 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 0 }
                        }
                    }
                }
                TexDiv: vec2 = { 1, 3 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "ThinTrail_A"
                BirthVelocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, 100, 0 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 600
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 600, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.486000001 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0, 0, 0.297317803 }
                            { 1, 0, 0, 0.247764751 }
                            { 0.494118005, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 20, 20, 20 }
                            { 20, 20, 20 }
                            { 20, 20, 20 }
                            { 2, 20, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "ThinTrail_B"
                BirthVelocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 100, 0 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 600
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 600, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.486000001 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0, 0, 0.297317803 }
                            { 1, 0, 0, 0.247764751 }
                            { 0.494118005, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 20, 20, 20 }
                            { 20, 20, 20 }
                            { 20, 20, 20 }
                            { 2, 20, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Glow_01.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_Wall_Accel_Buf"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Wall_Accel_Buf"
        Flags: u16 = 132
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Range_Hammer" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    10.1000004
                }
                EmitterName: string = "Lightning_demon1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 20, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Lightning_Offset_UV_UP.sco"
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0.341176003, 0.341176003, 0.800000012 }
                            { 0.666666985, 0, 0, 0 }
                        }
                    }
                }
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 360, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 360, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 60, 60 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 60, 60 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 100, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.25
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 100, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.5, 1 }
                            { 1, 0.5, 1 }
                            { 1, 0.200000003, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Plasma_Beam1.dds"
                FrameRate: f32 = 5
                NumFrames: u16 = 8
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 0.100000001 }
                        }
                    }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    10
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 1, 0.5 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Lightning_demon2"
                Importance: u8 = 2
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 8, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Lighting_Cyl_UV_UP.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0, 0.266667008, 0.800000012 }
                            { 0.784313977, 0, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 360, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 360, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 60, 60 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 60, 60 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 500, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.25
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 500, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.5, 1 }
                            { 1, 0.5, 1 }
                            { 1, 0.200000003, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Plasma_Beam1.dds"
                FrameRate: f32 = 2
                NumFrames: u16 = 8
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 0.100000001 }
                        }
                    }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    10
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 1, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Stance_Range_Hammer"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Range_Hammer"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Charged_Hit_Ranged" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_04.dds"
                FrameRate: f32 = 26
                NumFrames: u16 = 8
                StartFrame: u16 = 1
                TexDiv: vec2 = { 8, 1 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0.294117987, 1 }
                            { 0.133332998, 0, 0, 1 }
                            { 0.066666998, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 4
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_01.dds"
                NumFrames: u16 = 3
                TexDiv: vec2 = { 3, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ground_Glow"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.525490224 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.329412013, 0, 0.141176, 0 }
                            { 0.431373, 0, 0.223528996, 1 }
                            { 0.337255001, 0, 0.0980390012, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 300, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.576470613 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0.486274987 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.75, 0.75, 0.75 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.150000006, 0.150000006, 0.150000006 }
                            { 0.450000018, 0.450000018, 0.450000018 }
                            { 0.900000036, 0.900000036, 0.900000036 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Upper"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568635, 0, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 2 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 10
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Flash_Big"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 15, 15, 15 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 15, 15, 15 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.670588255, 0.0745098069, 0.533333361, 0.470588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.150000006
                        }
                    }
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Flicker"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00300000003
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.670588255, 0.0156862754, 0.113725491, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.188752443
                            0.381706536
                            0.581124783
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.743064523, 0, 0 }
                            { 0.987927556, 0, 0 }
                            { 0.253458887, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 2
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.556862772, 0.866666675, 0.223529413, 1 }
                }
                Pass: i16 = -10
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.193151683
                            0.293151677
                            0.715684831
                            0.815684795
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.202471912, 0, 0 }
                            { 1, 0, 0 }
                            { 1, 0, 0 }
                            { 0.224943832, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_Charged_Hit_Ranged"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Charged_Hit_Ranged"
        SoundOnCreateDefault: string = "Play_sfx_Jayce_JaycePassiveRangedAttack_hit"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Melee" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                EmitterName: string = "Bits_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -20, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -15, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Stance_Melee"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Melee"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Idle_Melee" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                EmitterName: string = "Mesh_2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 3, 49, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_idle_melee.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.427451015, 0.427451015, 0.427451015, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.75, 0.800000012 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Noise_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1.5 }
                }
                TexDiv: vec2 = { 0.5, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    13
                }
                EmitterName: string = "Mesh_3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 3, 49, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_idle_melee.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.223529428, 0.223529428, 0.223529428, 0.337254912 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.75, 0.800000012 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Noise_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1 }
                }
                TexDiv: vec2 = { 0.25, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Mesh_1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 3, 49, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_idle_melee.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.333333343, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.75, 0.800000012 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1.10000002, 1.10000002, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Clouds_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1.5 }
                }
                TexDiv: vec2 = { 0.5, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Idle_Melee"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Idle_Melee"
        Flags: u16 = 197
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Model_Swap" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ground_Glow"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.525490224 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 0, 0, 0 }
                            { 0.435294002, 0.145098001, 0, 1 }
                            { 0.345097989, 0, 0, 0 }
                        }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 300, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 0.133332998, 0, 0, 1 }
                            { 0.066666998, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 4
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_01.dds"
                NumFrames: u16 = 3
                TexDiv: vec2 = { 3, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_04.dds"
                FrameRate: f32 = 26
                NumFrames: u16 = 8
                StartFrame: u16 = 1
                TexDiv: vec2 = { 8, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Center_Glow1"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 300, 600 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 0.25, 0.400000006, 0.25 }
                            { 2, 0, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.576470613 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.666666985, 0.400000006, 0.49019599 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Upper"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568635, 0, 0, 1 }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 2.5, 2.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1.5, 2.5, 2.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 20
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    9
                }
                IsSingleParticle: flag = true
                EmitterName: string = "avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.494117647, 0.0823529437, 0.0901960805, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.494117647, 0.0823529437, 0.0901960805, 1 }
                            { 0.494117647, 0.0823529437, 0.0901960805, 0 }
                        }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                ParticleIsLocalOrientation: flag = true
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/common_color-hold.dds"
                UvMode: u8 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.0500000007, -0.0250000004 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 3, 3 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_IndicatorMult_01.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.5, 0.5 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -0.5 }
                    }
                }
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_Model_Swap"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Model_Swap"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Basic_Mis_Crit" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Ribbon_1"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Ribbon_3"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Ribbon_4"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                EmitterName: string = "Ribbon_2"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 7
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterName: string = "Center2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.219607994, 0.0862749964, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.219607994, 0.0433066823, 0, 0 }
                            { 0.219607994, 0.0473666973, 0, 0.545098007 }
                            { 0.219607994, 0.0274049938, 0, 0.215685993 }
                            { 0.136070862, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -10
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 180, -1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Black"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -95, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 80, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 130, 80, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Red"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -95, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 150, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_Range_Basic_Mis_Crit"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Basic_Mis_Crit"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_PassiveReadyRange" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                EmitterName: string = "Bits_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 40 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                EmitterName: string = "Bits_2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 80, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 500, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.447058856 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.231372997, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Smoke_02.dds"
                NumFrames: u16 = 8
                TexDiv: vec2 = { 4, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_PassiveReadyRange"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_PassiveReadyRange"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Recall_Crack" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Hit_Center_Flash"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.352941185 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.666666985, 0, 1 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 80, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 1, 5 }
                            { 1, 0.100000001, 1 }
                            { 1, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Crack"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 0.423528999, 0.423528999, 1 }
                            { 0.168626994, 0, 0, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Crack_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 0 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.150000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.1499996
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dust1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 20, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 150, 50, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.300000012
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 150, 50, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                        ValueFloat {
                            ConstantValue: f32 = 1
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0.454901993 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 12, 12, 12 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 4, 4, 4 }
                            { 6, 6, 6 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Recall_Crack"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Recall_Crack"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Recall_Trail" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 800
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Trail"
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0.100000001, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0199999996
                            0.101000004
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 0 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Beam_01.dds"
                TexDiv: vec2 = { 5000, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Recall_Trail"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Recall_Trail"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_CA_ranged" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Sparks"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1200, 450, 1200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1200, 450, 1200 }
                            { 1200, 450, 1200 }
                            { 1200, 450, 1200 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 8, 8, 8 }
                }
                Velocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 450, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 450, 0 }
                        }
                    }
                }
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                UseNavmeshMask: flag = true
                DirectionVelocityScale: f32 = 0.00999999978
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 30, 30, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 1.25, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Embers.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 2
                Pass: i16 = 105
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.128086612
                            0.249612138
                            0.550000012
                            0.750840306
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.815286398, 0, 0 }
                            { 0.998123825, 0, 0 }
                            { 1, 0, 0 }
                            { 0.252536565, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Burst"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 120, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_03.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                }
                Pass: i16 = 50
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.128086612
                            0.249612138
                            0.550000012
                            0.750840306
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.815286398, 0, 0 }
                            { 0.998123825, 0, 0 }
                            { 1, 0, 0 }
                            { 0.252536565, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "GlowSubtleDark1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.117647059, 0.117647059, 0.470588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow5"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 2
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.556862772, 0.866666675, 0.223529413, 1 }
                }
                Pass: i16 = -1
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.193151683
                            0.293151677
                            0.715684831
                            0.815684795
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.202471912, 0, 0 }
                            { 1, 0, 0 }
                            { 1, 0, 0 }
                            { 0.224943832, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_CA_ranged"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_CA_ranged"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_OrbLightning" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Light_Projected"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -50, -100 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 0.46274513 }
                }
                ColorRenderFlags: u8 = 1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Core_1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -140, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.480003059, 0.349996179, 0.659998477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                ColorRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 250, 280 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 1.20000005, 1 }
                            { 1.5, 0.5, 1 }
                            { 1.5, 0.5, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Mis_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Core_2"
                BirthVelocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.349999994
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 2
                ColorRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 250, 280 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.20000005, 1 }
                            { 1, 0.800000012, 1 }
                            { 1.5, 0.5, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Mis_01.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Noise_01.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Pre-Burst"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 120, 0 }
                }
                BlendMode: u8 = 1
                Pass: i16 = 101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, -1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 1.5, 1.5 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                EmitterName: string = "Ribbon_1"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                ColorRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                EmitterName: string = "Ribbon_3"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.666666687, 0, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                ColorRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 200, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 8
                ColorRenderFlags: u8 = 1
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 20
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3999996
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Smoke_01"
                Importance: u8 = 2
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0, 0.294117987, 1 }
                            { 0.666666985, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                ColorRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 360 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 190, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 190, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Smoke_02.dds"
                NumFrames: u16 = 8
                TexDiv: vec2 = { 4, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Sphere_Stretch"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_sphere_stretch.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.505882382, 0.0235294122, 0.0313725509, 1 }
                }
                Pass: i16 = 11
                ColorRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.800000012, 1.5 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Wrap.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -5 }
                }
                TexDiv: vec2 = { 0.5, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Black1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.156862751, 0.156862751, 0.156862751, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                ColorRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 90, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 180, 90, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Black"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                ColorRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 190, 300, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 190, 300, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_OrbLightning"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_OrbLightning"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Q_Trail_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 800
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Trail"
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0.100000001, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0199999996
                            0.101000004
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 0 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Beam_01.dds"
                TexDiv: vec2 = { 5000, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Q_Trail_01"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Q_Trail_01"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_start" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "LightL"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.529411793, 0.53725493, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0399999991
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "LightR"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.592156887, 0.592156887, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0399999991
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_Ball"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_BallR"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_Ball_Start"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1400, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 8, 1 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_Ball_StartR"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1400, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 8, 1 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    4.0999999
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Bits_R"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -200, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 325, 125, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 1 }
                            { 0, 0.333332986, 1, 1 }
                            { 0, 0.333332986, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    4.0999999
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Bits_L"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -325, 125, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 1 }
                            { 0, 0.333332986, 1, 1 }
                            { 0, 0.333332986, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "CoverupL"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 1, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "CoverupR"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 1, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.00999999978
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.25
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    20
                }
                EmitterName: string = "Constant_CoverupL"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -340, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.666666687, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 5, 5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.00999999978
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.25
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    20
                }
                EmitterName: string = "Constant_CoverupR"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 340, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.666666687, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 5, 5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    9.89999962
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Highlight"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 1 }
                            { 0, 0.333332986, 1, 1 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 7 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 30
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    10
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Dark"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.333333343, 1, 1 }
                }
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 3.0999999 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_02.dds"
                FrameRate: f32 = 40
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    10.25
                }
                EmitterName: string = "Beam_Black_Right"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 1 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 11 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_02.dds"
                NumFrames: u16 = 3
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.300000012, 0 }
                }
                TexDiv: vec2 = { 1, 3 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    10
                }
                EmitterName: string = "Beam_Black_Left"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 1 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 11 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_02.dds"
                FrameRate: f32 = 5
                NumFrames: u16 = 3
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.300000012, 0 }
                }
                TexDiv: vec2 = { 1, 3 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    10
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Color"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 4
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_02.dds"
                FrameRate: f32 = 40
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_ColorRamp_Blue.dds"
                    TexDivMult: vec2 = { 2, 8 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.349999994
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    3.3499999
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Add"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 1, 1, 1 }
                            { 0, 0.333332986, 1, 1 }
                            { 0, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_03.dds"
                FrameRate: f32 = 25
                NumFrames: u16 = 8
                StartFrame: u16 = 1
                TexDiv: vec2 = { 1, 8 }
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_accel_gate_start"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_start"
        SoundPersistentDefault: string = "Play_sfx_Jayce_JayceAcceleratorBeam_buffactivate_loop"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_start_RED" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "LightL"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.509803951, 0.517647088, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0399999991
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "LightR"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.572549045, 0.580392182, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0399999991
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_Ball"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_02.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_BallR"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_Ball_Start"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1400, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 8, 1 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Wall_Ball_StartR"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1400, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 8, 1 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_gate_01.scb"
                    }
                }
                BlendMode: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Gate_02.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    4.0999999
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Bits_R"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -200, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 325, 125, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    4.0999999
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Bits_L"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -325, 125, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "CoverupL"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -350, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.0156862754, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "CoverupR"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 350, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.0156862754, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.00999999978
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.25
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    20
                }
                EmitterName: string = "Constant_CoverupL"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -340, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.517647088, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 5, 5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.00999999978
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.25
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    20
                }
                EmitterName: string = "Constant_CoverupR"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 340, 125, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.517647088, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 5, 5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    9.89999962
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Highlight"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 7 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 30
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    10
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Dark"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.0156862754, 1 }
                }
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 3.0999999 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_02.dds"
                FrameRate: f32 = 40
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    10.25
                }
                EmitterName: string = "Beam_Black_Right"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 11 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_02.dds"
                NumFrames: u16 = 3
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.300000012, 0 }
                }
                TexDiv: vec2 = { 1, 3 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    10
                }
                EmitterName: string = "Beam_Black_Left"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 11 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_02.dds"
                FrameRate: f32 = 5
                NumFrames: u16 = 3
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.300000012, 0 }
                }
                TexDiv: vec2 = { 1, 3 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    10
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Color"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 4
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4.80000019, 10, 3 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_02.dds"
                FrameRate: f32 = 40
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_ColorRamp_Red.dds"
                    TexDivMult: vec2 = { 2, 8 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.349999994
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    3.3499999
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Beam_Add"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 125, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_e_beam_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_03.dds"
                FrameRate: f32 = 25
                NumFrames: u16 = 8
                StartFrame: u16 = 1
                TexDiv: vec2 = { 1, 8 }
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_accel_gate_start_RED"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_start_RED"
        SoundPersistentDefault: string = "Play_sfx_Jayce_JayceAcceleratorBeam_buffactivate_loop"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready2" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            30
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                EmitterName: string = "Vents1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Hyper_Charge_Blasts.sco"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.172549024, 0.172549024, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 360, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 200, 200 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 1 }
                            { 1.29999995, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flare_Directional_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Hex_Buff_Ready2"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready2"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready3" = VfxSystemDefinitionData {
        ParticleName: string = "Jayce_Skin03_Hex_Buff_Ready3"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready3"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_ranged" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 2
                Pass: i16 = 102
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.128086612
                            0.249612138
                            0.550000012
                            0.750840306
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.815286398, 0, 0 }
                            { 0.998123825, 0, 0 }
                            { 1, 0, 0 }
                            { 0.252536565, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Burst"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 90, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_03.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                }
                Pass: i16 = 101
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.128086612
                            0.249612138
                            0.550000012
                            0.750840306
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.815286398, 0, 0 }
                            { 0.998123825, 0, 0 }
                            { 1, 0, 0 }
                            { 0.252536565, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "GlowSubtleDark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.117647059, 0.117647059, 0.470588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 2
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.556862772, 0.866666675, 0.223529413, 1 }
                }
                Pass: i16 = -1
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.193151683
                            0.293151677
                            0.715684831
                            0.815684795
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.202471912, 0, 0 }
                            { 1, 0, 0 }
                            { 1, 0, 0 }
                            { 0.224943832, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_BA_ranged"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_ranged"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_ThunderingBlow_tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.3999996
                }
                Lifetime: option[f32] = {
                    0.560000002
                }
                EmitterName: string = "Ring_Elec"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.70588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 13
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 18
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_ThunderingBlow_tar"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_ThunderingBlow_tar"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_CA_1" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.666666985, 0, 1, 1 }
                            { 0.262744993, 0, 0, 1 }
                            { 0.164706007, 0, 0, 0.800000012 }
                            { 0.333332986, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, 120 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 120, 120, 120 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1.29999995, 1.29999995, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_03.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ring"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.666666985, 0, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 140, 140, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Center_Glow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.337254912 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.666666985, 0, 1, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 50, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 3 }
                            { 0.25, 0.400000006, 0.25 }
                            { 2, 0, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring1"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.576470613 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.666666985, 0.400000006, 0.49019599 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "fireRing"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0299999993
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 90 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flare_01.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_CA_1"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_CA_1"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_StaticStormShock" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                Lifetime: option[f32] = {
                    4
                }
                EmitterName: string = "Ground_Glow"
                Importance: u8 = 0
                TranslationOverride: vec3 = { 0, 150, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -120, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.525490224 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 0, 0, 0 }
                            { 0.435294002, 0.145098001, 0, 1 }
                            { 0.345097989, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 300, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "Ring_Ground_1"
                Importance: u8 = 2
                TranslationOverride: vec3 = { 0, 150, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -120, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_z_indicatorring_01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 0.313725501 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 9.5, 9.5, 9.5 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Indicator_01.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_IndicatorMult_01.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 0.100000001 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.100000001, 0.100000001 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "Ring_Ground_2"
                Importance: u8 = 2
                TranslationOverride: vec3 = { 0, 150, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 5, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -120, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.623529434 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0, 0, 0.800000012 }
                            { 1, 0, 0, 0.800000012 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 290, 290, 290 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Indicator_02.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_IndicatorMult_02.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.300000012, 0.300000012 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.300000012, 0.300000012 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.3999996
                }
                Lifetime: option[f32] = {
                    3.55999994
                }
                EmitterName: string = "Ring_Elec"
                TranslationOverride: vec3 = { 0, 150, 0 }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -100, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.70588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 13
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.70000005, 1.70000005, 1.70000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.949999988, 0.949999988, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 18
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "Mesh_Donut_1"
                Importance: u8 = 2
                TranslationOverride: vec3 = { 0, 150, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -150, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_w_donut_01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.717647076 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0.333332986, 0, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.800000012, 0.899999976 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 40
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "Twirl_1"
                Importance: u8 = 2
                TranslationOverride: vec3 = { 0, 150, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -120, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_w_twirl_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 1, 0.899999976 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Wrap.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.800000012 }
                }
                TexDiv: vec2 = { 0.5, 3 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_W_ColorRamp.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 7
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "Ring_Energy_1"
                TranslationOverride: vec3 = { 0, 150, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -150, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_z_indicatorring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 0.227450997, 0, 0, 1 }
                            { 0.0509800017, 0.0509800017, 0.0509800017, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 9.5, 9.5, 9.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.10000002, 1.10000002, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_01.dds"
                TexDiv: vec2 = { 0.5, 1 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Beam_03.dds"
                    TexDivMult: vec2 = { 0.5, 1 }
                }
            }
        }
        ParticleName: string = "Jayce_Skin03_StaticStormShock"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_StaticStormShock"
        Flags: u16 = 192
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Q_XP_Gate" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Pre-Burst"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.384313762, 0.384313762, 1 }
                }
                Pass: i16 = 101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 160, 160 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 1.5, 1.5 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Burst"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 180, 180 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    10.8000002
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "hagaSphere"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_z_sphere_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0, 0, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.600000024 }
                            { 0, 0, 0, 0.300000012 }
                        }
                    }
                }
                Pass: i16 = 12
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.5, 2.5, 2.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Sphere_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.5 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                Lifetime: option[f32] = {
                    1.05999994
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Blend1"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 13
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 30
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 230, 230, 230 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "distort"
                ParticleColorTexture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_color-rampdown32_03.dds"
                BlendMode: u8 = 1
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.100000001
                    NormalMapTexture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_distort-shockwave.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 220, 220 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_Aura_Self.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_Range_Q_XP_Gate"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Q_XP_Gate"
        SoundOnCreateDefault: string = "Play_sfx_Jayce_JayceShockBlastWallMis_hit"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Basic_Mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    10.1000004
                }
                EmitterName: string = "Ribbon_1"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 300
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    10.1000004
                }
                EmitterName: string = "Ribbon_2"
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 1, 1, 1 }
                            { 0.100000001, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Ribbon_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 0 }
                }
                TexDiv: vec2 = { 0.5, -1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 7
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterName: string = "Center2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.219607994, 0.0862749964, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.219607994, 0.0433066823, 0, 0 }
                            { 0.219607994, 0.0473666973, 0, 0.545098007 }
                            { 0.219607994, 0.0274049938, 0, 0.215685993 }
                            { 0.136070862, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -10
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 180, -1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Black"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -95, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.156862751, 0.156862751, 0.156862751, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 80, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 130, 80, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Red"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2000, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -95, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0.36470601, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 150, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0, 1 }
                            { 1, 1, 1 }
                            { 0.699999988, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_BA_Missile_02.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_Range_Basic_Mis"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Basic_Mis"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Joke_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLinger: option[f32] = {
                    10.1000004
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_Crawl"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 360, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 360, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 60, 60 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 60, 60 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.200000003, 0.200000003, 0.200000003 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Beam_03.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 0 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0.100000001, 0 }
                        }
                    }
                }
                TexDiv: vec2 = { 0.5, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_Crawl1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 360, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 360, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 60, 60 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 60, 60 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.200000003, 0.200000003, 0.200000003 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_05.dds"
                FrameRate: f32 = 30
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 150
                }
                ParticleLinger: option[f32] = {
                    13
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                EmitterName: string = "Fizzle"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 800, 800, 800 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 800, 800, 800 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -500, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -500, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 10, 10, 10 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        5
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 10, 10, 10 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 360
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            1
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    360
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Confetti_Color.dds"
                BlendMode: u8 = 1
                Pass: i16 = 100
                ColorLookUpTypeY: u8 = 3
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 360 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 600, 600 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 600, 600, 600 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 15, 15 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 15, 15 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Confetti.dds"
                NumFrames: u16 = 10
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Joke_01"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Joke_01"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Charged_Hit" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_04.dds"
                FrameRate: f32 = 26
                NumFrames: u16 = 8
                StartFrame: u16 = 1
                TexDiv: vec2 = { 8, 1 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Lightning_2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 0.133332998, 0, 0, 1 }
                            { 0.066666998, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 4
                DisableBackfaceCull: bool = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 1280, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Elec_Strike_01.dds"
                NumFrames: u16 = 3
                TexDiv: vec2 = { 3, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ground_Glow"
                Importance: u8 = 0
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.525490224 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 0, 0, 0 }
                            { 0.435294002, 0.145098001, 0, 1 }
                            { 0.345097989, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 300, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.576470613 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.666666985, 0.400000006, 0.49019599 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.75, 0.75, 0.75 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.150000006, 0.150000006, 0.150000006 }
                            { 0.450000018, 0.450000018, 0.450000018 }
                            { 0.900000036, 0.900000036, 0.900000036 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Upper"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568635, 0, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 2 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 10
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Flash_Big"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 15, 15, 15 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 15, 15, 15 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.670588255, 0.298039228, 0.0509803928, 0.470588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.150000006
                        }
                    }
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Flicker"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00300000003
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.670588255, 0.0156862754, 0.113725491, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeX: u8 = 3
                ColorLookUpTypeY: u8 = 1
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.188752443
                            0.381706536
                            0.581124783
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.743064523, 0, 0 }
                            { 0.987927556, 0, 0 }
                            { 0.253458887, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Alpha_Backdrop.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 2
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.141176477, 0.894117653, 0.745098054, 1 }
                }
                Pass: i16 = -10
                DepthBiasFactors: vec2 = { -1, -10 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 20, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.193151683
                            0.293151677
                            0.715684831
                            0.815684795
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.202471912, 0, 0 }
                            { 1, 0, 0 }
                            { 1, 0, 0 }
                            { 0.224943832, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Flash_01.dds"
            }
        }
        VisibilityRadius: f32 = 5000
        ParticleName: string = "Jayce_Skin03_Charged_Hit"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Charged_Hit"
        Flags: u16 = 198
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_E_Trail_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 800
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Trail"
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0.100000001, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0199999996
                            0.101000004
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 0 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_E_Beam_01.dds"
                TexDiv: vec2 = { 5000, 1 }
            }
        }
        ParticleName: string = "Jayce_Skin03_E_Trail_01"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_E_Trail_01"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Jump_Land" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Hit_Center_Flash"
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.352941185 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.666666985, 0, 1 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 350, 175, 350 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 5, 1, 5 }
                            { 1, 0.100000001, 1 }
                            { 1, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Glow_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Crack"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 0.423528999, 0.423528999, 1 }
                            { 0.168626994, 0, 0, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 1 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Crack_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "fireRing"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0299999993
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 90 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 350, 350, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flare_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    10.25
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "centerFlare"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0299999993
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 90 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 202.5, 202.5, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 0 }
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Ring_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.150000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.1499996
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dust1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 20, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 150, 50, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.300000012
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 150, 50, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                        ValueFloat {
                            ConstantValue: f32 = 1
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.333332986, 0, 1 }
                            { 1, 0, 0, 0.454901993 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 12, 12, 12 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 4, 4, 4 }
                            { 6, 6, 6 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Bits_03.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Jayce_Skin03_Jump_Land"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Jump_Land"
        SoundOnCreateDefault: string = "Play_sfx_Jayce_JayceToTheSkies_hit"
    }
    "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Q_XP" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Light"
                Importance: u8 = 0
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.133332998, 0.133332998, 1 }
                            { 1, 0.066666998, 0.066666998, 1 }
                            { 0.756862998, 0, 0, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 250, 250 }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Base/Particles/Jayce_Aura.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Pre-Burst"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.384313762, 0.384313762, 1 }
                }
                Pass: i16 = 101
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, -1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 1.5, 1.5 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_04.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Burst"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.670588017, 0.400000006, 0 }
                            { 1, 0.172548994, 0.172548994, 1 }
                            { 1, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 160, 160 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_Flares_03.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    10.8000002
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "hagaSphere"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_z_sphere_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0, 0, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.600000024 }
                            { 0, 0, 0, 0.300000012 }
                        }
                    }
                }
                Pass: i16 = 12
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Q_Sphere_01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.5 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0599999987
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    10.8000002
                }
                Lifetime: option[f32] = {
                    1.05999994
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_Mesh_Blend1"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/jayce_skin03_q_ring_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 13
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.800000012, 1.20000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/Jayce_Skin03_Z_ElecAnim_01.dds"
                FrameRate: f32 = 18
                NumFrames: u16 = 16
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 8 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "distort"
                ParticleColorTexture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_color-rampdown32_03.dds"
                BlendMode: u8 = 1
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.100000001
                    NormalMapTexture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_distort-shockwave.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Jayce/Skins/Skin03/Particles/common_Aura_Self.dds"
            }
        }
        ParticleName: string = "Jayce_Skin03_Range_Q_XP"
        ParticlePath: string = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Q_XP"
        SoundOnCreateDefault: string = "Play_sfx_Jayce_JayceShockBlastMis_hit"
    }
    "Characters/Jayce/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Jayce_accel_gate_end" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_end"
            "Jayce_accel_gate_end_RED" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_end_RED"
            "Jayce_accel_gate_start" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_start"
            "Jayce_accel_gate_start_RED" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_accel_gate_start_RED"
            "Jayce_BA_1" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_1"
            "Jayce_BA_2" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_2"
            "Jayce_CA_1" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_CA_1"
            "Jayce_Death_1" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Death_1"
            "Jayce_Death_SFX_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Death_SFX_01"
            "Jayce_Death_XP_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Death_XP_01"
            "Jayce_Emote_Dance_Loop_sfx_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Dance_Loop_sfx_01"
            "Jayce_Emote_Dance_windup_sfx_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Dance_windup_sfx_01"
            "Jayce_Emote_FX_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_FX_01"
            "Jayce_Emote_Joke_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Joke_01"
            "Jayce_Emote_Joke_SFX_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Joke_SFX_01"
            "Jayce_Emote_Laught_sfx_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Laught_sfx_01"
            "Jayce_Emote_Taunt_Dust_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Taunt_Dust_01"
            "Jayce_Emote_Taunt_SFX_01" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Emote_Taunt_SFX_01"
            "Jayce_Hex_Buff_Ready" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready"
            "Jayce_Hex_Buff_Ready2" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready2"
            "Jayce_Idle_Dust_Foot" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Idle_Dust_Foot"
            "Jayce_Jump_Reticle" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Jump_Reticle"
            "Jayce_Model_Swap" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Model_Swap"
            "Jayce_Model_Swap2" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Model_Swap2"
            "Jayce_OrbLightning" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_OrbLightning"
            "Jayce_OrbLightningCharged" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_OrbLightningCharged"
            "Jayce_PassiveReadyMelee" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_PassiveReadyMelee"
            "Jayce_PassiveReadyRange" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_PassiveReadyRange"
            "Jayce_P_charged_hit" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Charged_Hit"
            "Jayce_P_charged_hit_ranged" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Charged_Hit_Ranged"
            "Jayce_Q_jump_land" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Jump_Land"
            "Jayce_Q_range_xp" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Q_XP"
            "Jayce_Q_range_xp_gate" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Q_XP_Gate"
            "Jayce_Range_Basic_Mis" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Basic_Mis"
            "Jayce_Range_Basic_Mis_Crit" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Range_Basic_Mis_Crit"
            "Jayce_Stance_Melee" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Melee"
            "Jayce_Stance_Range" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Range"
            "Jayce_Stance_Range_Hammer" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Stance_Range_Hammer"
            "Jayce_StaticStormShock" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_StaticStormShock"
            "Jayce_StaticStorm_aura" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_StaticStorm_aura"
            "Jayce_ThunderingBlow_Hit" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_ThunderingBlow_Hit"
            "Jayce_ThunderingBlow_tar" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_ThunderingBlow_tar"
            "Jayce_Wall_Accel_Buf" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Wall_Accel_Buf"
            "Jayce_W_Attk1_Hex_Buff_01" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_W_Attk1_Hex_Buff_01"
            "Jayce_Z_global_slow" = "Characters/Jayce/Skins/Skin0/Particles/Jayce_Base_Z_global_slow"
            0x1eca46a9 = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_ranged"
            0x1bca41f0 = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_BA_ranged"
            0xc3ab2be3 = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_CA_ranged"
            0x084d0b6e = 0x1b797e3d
            0x6f3aa0d7 = 0x56e8d907
            0xb9a5c5b9 = 0xa3fb7c89
            0x18053321 = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_StaticStorm_Hit"
            "Jayce_Death_01" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Death_01"
            "Jayce_Death_02" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Death_02"
            "Jayce_E_Trail_01" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_E_Trail_01"
            "Jayce_Hex_Buff_Ready3" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Hex_Buff_Ready3"
            "Jayce_Idle_Melee" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Idle_Melee"
            "Jayce_Joke_01" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Joke_01"
            "Jayce_Q_Trail_01" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Q_Trail_01"
            "Jayce_Recall_Crack" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Recall_Crack"
            "Jayce_Recall_Trail" = "Characters/Jayce/Skins/Skin3/Particles/Jayce_Skin03_Recall_Trail"
        }
    }
}
