#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Zeri/Zeri.bin"
    "DATA/Characters/Zeri/Animations/Skin1.bin"
    "DATA/Zeri_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zeri_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zeri_Skins_Skin0_Skins_Skin1_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zeri_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    0xdc6954c3 = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "Zeri"
        MetaDataTags: string = "faction:zaun,gender:female,race:human,skinline:witheredrose"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Zeri/Skins/Skin01/ZeriLoadscreen_1.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Zeri"
                "ZeriSkin01"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Zeri_Skin01_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Zeri/Skins/Skin01/Zeri_Skin01_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Zeri/Skins/Skin01/Zeri_Skin01_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_ZeriSkin01_Dance3D_cast"
                        "Play_sfx_ZeriSkin01_Dance3D_loop"
                        "Play_sfx_ZeriSkin01_Death3D_cast"
                        "Play_sfx_ZeriSkin01_Homeguard3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Homeguard3D_cast"
                        "Play_sfx_ZeriSkin01_Homeguard3D_foley"
                        "Play_sfx_ZeriSkin01_IdleIn01_buffactivate"
                        "Play_sfx_ZeriSkin01_IdleIn02_buffactivate"
                        "Play_sfx_ZeriSkin01_Joke3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Laugh3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Recall3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Respawn3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Spawn3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Taunt3D_buffactivate"
                        "Play_sfx_ZeriSkin01_Winddown3D_buffactivate"
                        "Play_sfx_ZeriSkin01_ZeriBasicAttack_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriBasicAttack_OnHit"
                        "Play_sfx_ZeriSkin01_ZeriCritAttack_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriCritAttack_OnHit"
                        "Play_sfx_ZeriSkin01_ZeriE_cast"
                        "Play_sfx_ZeriSkin01_ZeriE_end"
                        "Play_sfx_ZeriSkin01_ZeriE_foley_land_hit"
                        "Play_sfx_ZeriSkin01_ZeriE_foley_long_cast"
                        "Play_sfx_ZeriSkin01_ZeriE_foley_long_loop"
                        "Play_sfx_ZeriSkin01_ZeriE_foley_med_cast"
                        "Play_sfx_ZeriSkin01_ZeriE_foley_short_cast"
                        "Play_sfx_ZeriSkin01_ZeriESpecialRounds_OnBuffActivate"
                        "Play_sfx_ZeriSkin01_ZeriESpecialRounds_OnBuffDeactivate"
                        "Play_sfx_ZeriSkin01_ZeriPassive_hit"
                        "Play_sfx_ZeriSkin01_ZeriPassiveShield_OnBuffActivate"
                        "Play_sfx_ZeriSkin01_ZeriPassiveShield_OnBuffDeactivate"
                        "Play_sfx_ZeriSkin01_ZeriQ_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriQBasicAttack_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriQBasicAttack_OnHit"
                        "Play_sfx_ZeriSkin01_ZeriQBasicAttackEmpowered_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriQBasicAttackEmpowered_OnHit"
                        "Play_sfx_ZeriSkin01_ZeriQCritAttack_hit"
                        "Play_sfx_ZeriSkin01_ZeriQMis_hit"
                        "Play_sfx_ZeriSkin01_ZeriQMis_hit_champ_self"
                        "Play_sfx_ZeriSkin01_ZeriQMis_OnMissileLaunch"
                        "Play_sfx_ZeriSkin01_ZeriQMisEmpowered_hit"
                        "Play_sfx_ZeriSkin01_ZeriQMisEmpowered_OnMissileLaunch"
                        "Play_sfx_ZeriSkin01_ZeriQMisEmpoweredPierce_OnMissileLaunch"
                        "Play_sfx_ZeriSkin01_ZeriQMisEmpoweredPierceParent_OnMissileCast"
                        "Play_sfx_ZeriSkin01_ZeriQMisPierce_OnMissileLaunch"
                        "Play_sfx_ZeriSkin01_ZeriQMisPierceParent_OnMissileCast"
                        "Play_sfx_ZeriSkin01_ZeriQPassiveReady_OnBuffCast"
                        "Play_sfx_ZeriSkin01_ZeriR_buffcast"
                        "Play_sfx_ZeriSkin01_ZeriR_kill_stingers"
                        "Play_sfx_ZeriSkin01_ZeriR_kill_stingers_penta"
                        "Play_sfx_ZeriSkin01_ZeriR_OnBuffActivate"
                        "Play_sfx_ZeriSkin01_ZeriR_OnBuffDeactivate"
                        "Play_sfx_ZeriSkin01_ZeriR_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriRChain_hit"
                        "Play_sfx_ZeriSkin01_ZeriW_beam_buffactivate"
                        "Play_sfx_ZeriSkin01_ZeriW_hit"
                        "Play_sfx_ZeriSkin01_ZeriW_OnCast"
                        "Play_sfx_ZeriSkin01_ZeriW_OnMissileCast"
                        "Play_sfx_ZeriSkin01_ZeriW_OnMissileLaunch"
                        "Stop_sfx_ZeriSkin01_ZeriQMis_OnMissileLaunch"
                        "Stop_sfx_ZeriSkin01_ZeriQMisEmpowered_OnMissileLaunch"
                        "Stop_sfx_ZeriSkin01_ZeriQMisEmpoweredPierce_OnMissileLaunch"
                        "Stop_sfx_ZeriSkin01_ZeriQMisPierce_OnMissileLaunch"
                        "Stop_sfx_ZeriSkin01_ZeriW_OnMissileLaunch"
                    }
                }
                BankUnit {
                    Name: string = "Zeri_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Zeri/Skins/Base/Zeri_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Zeri/Skins/Base/Zeri_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Zeri/Skins/Base/Zeri_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Zeri_Death3D"
                        "Play_vo_Zeri_FirstEncounter3DBlitzcrank"
                        "Play_vo_Zeri_FirstEncounter3DCaitlyn"
                        "Play_vo_Zeri_FirstEncounter3DEkko"
                        "Play_vo_Zeri_FirstEncounter3DEzreal"
                        "Play_vo_Zeri_FirstEncounter3DHeimerdinger"
                        "Play_vo_Zeri_FirstEncounter3DJanna"
                        "Play_vo_Zeri_FirstEncounter3DJinx"
                        "Play_vo_Zeri_FirstEncounter3DSeraphine"
                        "Play_vo_Zeri_FirstEncounter3DTwitch"
                        "Play_vo_Zeri_FirstEncounter3DVi"
                        "Play_vo_Zeri_FirstEncounter3DZeri"
                        "Play_vo_Zeri_FirstEncounter3DZiggs"
                        "Play_vo_Zeri_Joke3DGeneral"
                        "Play_vo_Zeri_JokeResponse3DGeneral"
                        "Play_vo_Zeri_Kill3DBlitzcrank"
                        "Play_vo_Zeri_Kill3DCaitlyn"
                        "Play_vo_Zeri_Kill3DEkko"
                        "Play_vo_Zeri_Kill3DEzreal"
                        "Play_vo_Zeri_Kill3DGeneral"
                        "Play_vo_Zeri_Kill3DHeimerdinger"
                        "Play_vo_Zeri_Kill3DJanna"
                        "Play_vo_Zeri_Kill3DJinx"
                        "Play_vo_Zeri_Kill3DPenta"
                        "Play_vo_Zeri_Kill3DQuadra"
                        "Play_vo_Zeri_Kill3DSeraphine"
                        "Play_vo_Zeri_Kill3DTriple"
                        "Play_vo_Zeri_Kill3DTwitch"
                        "Play_vo_Zeri_Kill3DVi"
                        "Play_vo_Zeri_Kill3DZeri"
                        "Play_vo_Zeri_Kill3DZiggs"
                        "Play_vo_Zeri_Laugh3DGeneral"
                        "Play_vo_Zeri_Move2DFirst"
                        "Play_vo_Zeri_Move2DLong"
                        "Play_vo_Zeri_Move2DStandard"
                        "Play_vo_Zeri_Recall3DGeneral"
                        "Play_vo_Zeri_Receive3DShieldHeal"
                        "Play_vo_Zeri_Respawn2DGeneral"
                        "Play_vo_Zeri_Spell3DRActivate"
                        "Play_vo_Zeri_Taunt3DGeneral"
                        "Play_vo_Zeri_TauntResponse3DGeneral"
                        "Play_vo_Zeri_ZeriE_cast3D"
                        "Play_vo_Zeri_ZeriQ_cast3D"
                        "Play_vo_Zeri_ZeriQBasicAttack_cast3D"
                        "Play_vo_Zeri_ZeriQBasicAttackEmpowered_cast3D"
                        "Play_vo_Zeri_ZeriQPassiveReady_OnBuffActivate"
                        "Play_vo_Zeri_ZeriR_cast3D"
                        "Play_vo_Zeri_ZeriR_OnBuffDeactivate"
                        "Play_vo_Zeri_ZeriW_cast3D"
                        "Play_vo_Zeri_ZeriW_miss3D"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Zeri/Animations/Skin1"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin01.skl"
            SimpleSkin: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin01.skn"
            Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_TX_CM.dds"
            SkinScale: f32 = 1.10000002
            SelfIllumination: f32 = 0.699999988
            BrushAlphaOverride: f32 = 0.400000006
            Material: link = "Characters/Zeri/Skins/Skin1/Materials/Bloom_Parts_Body_inst"
            InitialSubmeshToHide: string = "Hairspike Props"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/FresnelAlpha_Ebuff_Zeri_Skin1_inst"
                    Submesh: string = "Gun"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/Bloom_Parts_HairSpike_inst"
                    Submesh: string = "HairSpike"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst"
                    Submesh: string = "Jacket"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst"
                    Submesh: string = "Body"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst"
                    Submesh: string = "Hair"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst"
                    Submesh: string = "HairSpike"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst_Table"
                    Submesh: string = "Props"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Idle1_Safe"
        }
        IconAvatar: string = "ASSETS/Characters/Zeri/HUD/Zeri_Circle_1.dds"
        mContextualActionData: link = "Characters/Zeri/CAC/Zeri_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Zeri/HUD/Zeri_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Zeri/HUD/Zeri_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
            0xe784dd2f: u32 = 7
        }
        mResourceResolver: link = 0xf3e9ee1a
    }
    "Characters/Zeri/Skins/Skin1/Materials/Bloom_Parts_Body_inst" = StaticMaterialDef {
        Name: string = "Characters/Zeri/Skins/Skin1/Materials/Bloom_Parts_Body_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture_red"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_Bloom_TX.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0, 1, 0.749019623, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_ALPHA"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Diffuse_Bloom"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
    "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst" = StaticMaterialDef {
        Name: string = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Dissolve_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_Caustic02.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Alt_Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "DissolveBias"
                Value: vec4 = { 1.5575, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Power"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Emissive_Factor"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Lighting_Intensity"
                Value: vec4 = { 3, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Color"
                Value: vec4 = { 0.498039216, 0.137254909, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.200000003, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWidth"
                Value: vec4 = { 0.100000001, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "DARKEN_DIFFUSE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "DEBUG_VIEW_DISSOLVE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_POST_LIGHT"
            }
            StaticMaterialSwitchDef {
                Name: string = "DISSOLVE_OUT_ALPHA"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Dissolve_Diffuse_Or_Alpha"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "DissolveBias"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                            mAnimationNames: list[hash] = {
                                "Death"
                            }
                        }
                        mOnValue: f32 = -0.100000001
                        mOffValue: f32 = 1.10000002
                        mTurnOnTimeSec: f32 = 5
                        mTurnOffTimeSec: f32 = 0
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "DissolveBias"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                            mAnimationNames: list[hash] = {
                                "Respawn"
                            }
                        }
                        mOnValue: f32 = 1.10000002
                        mOffValue: f32 = -0.100000001
                        mTurnOnTimeSec: f32 = 3
                        mTurnOffTimeSec: f32 = 0
                    }
                }
            }
            StaticSwitch: pointer = DynamicMaterialStaticSwitch {
                Name: string = "DISSOLVE_OUT_ALPHA"
                Driver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                    mAnimationNames: list[hash] = {
                        "Death"
                        "Respawn"
                    }
                }
            }
        }
    }
    "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst_Table" = StaticMaterialDef {
        Name: string = "Characters/Zeri/Skins/Skin1/Materials/Dissolve_inst_Table"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_Props_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Dissolve_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/ground_pool_erosion.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Alt_Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_Props_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "DissolveBias"
                Value: vec4 = { 1.5575, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Power"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Emissive_Factor"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Lighting_Intensity"
                Value: vec4 = { 3, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Color"
                Value: vec4 = { 0.125490203, 0.0941176489, 0.164705887, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.200000003, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWidth"
                Value: vec4 = { 0.100000001, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "DARKEN_DIFFUSE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "DEBUG_VIEW_DISSOLVE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_POST_LIGHT"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "DISSOLVE_OUT_ALPHA"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Dissolve_Diffuse_Or_Alpha"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "DissolveBias"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = DelayedBoolMaterialDriver {
                            mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Recall_Winddown"
                                }
                            }
                            mDelayOn: f32 = 1.20000005
                        }
                        mOnValue: f32 = -0.100000001
                        mOffValue: f32 = 1.10000002
                        mTurnOnTimeSec: f32 = 0.200000003
                        mTurnOffTimeSec: f32 = 0
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "DissolveBias"
                    Enabled: bool = false
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = DelayedBoolMaterialDriver {
                            mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Recall"
                                }
                            }
                            mDelayOn: f32 = 2
                        }
                        mOnValue: f32 = 0
                        mOffValue: f32 = 1
                        mTurnOffTimeSec: f32 = 0
                    }
                }
            }
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Dissolve_Texture"
                    Enabled: bool = false
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Recall"
                                }
                            }
                            TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_Props_RoseMask_Inverted_TX.dds"
                        }
                    }
                }
            }
            StaticSwitch: pointer = DynamicMaterialStaticSwitch {
                Name: string = "DISSOLVE_OUT_ALPHA"
                Driver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                    mAnimationNames: list[hash] = {
                        "Recall_Winddown"
                        "Recall"
                    }
                }
            }
        }
    }
    "Characters/Zeri/Skins/Skin1/Materials/Bloom_Parts_HairSpike_inst" = StaticMaterialDef {
        Name: string = "Characters/Zeri/Skins/Skin1/Materials/Bloom_Parts_HairSpike_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_UltHair_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture_red"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_UltHairSpike_TX.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 10, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.694117665, 0.345098048, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_ALPHA"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Diffuse_Bloom"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Bloom_Color"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "ZeriR"
                        }
                    }
                }
            }
        }
    }
    "Characters/Zeri/Skins/Skin1/Materials/FresnelAlpha_Ebuff_Zeri_Skin1_inst" = StaticMaterialDef {
        Name: string = "Characters/Zeri/Skins/Skin1/Materials/FresnelAlpha_Ebuff_Zeri_Skin1_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Zeri_Skin1_Gun_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask"
                TextureName: string = "ASSETS/Shared/Materials/StepsMask.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 32, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Diffuse_Alpha_Override"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.333333343, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.300000012, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Size"
                Value: vec4 = { 3, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 0.949019611, 0.223529413, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Bias"
                Value: vec4 = { 0.0500000007, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "INVERT_FRESNEL"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/FresnelAlpha_Basic"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Bloom_Intensity"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "zeriespecialrounds"
                        }
                        mOnValue: f32 = 0.5
                        mTurnOnTimeSec: f32 = 0.300000012
                        mTurnOffTimeSec: f32 = 0.119999997
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "FresnelColor_Size"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "zeriespecialrounds"
                        }
                        mTurnOnTimeSec: f32 = 0.300000012
                        mTurnOffTimeSec: f32 = 0.119999997
                    }
                }
            }
        }
    }
    0x281fc457 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.25
                        }
                    }
                }
                EmitterName: string = "Electricity_Large"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 40, 70, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 20 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.505882382, 1, 0.862745106, 1 }
                            { 0.403921574, 0.823529422, 1, 1 }
                            { 0.68235296, 0.36470589, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 10, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 1.04999995, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/Zeri_Base_W_Lightning_flipbook.dds"
                FrameRate: f32 = 18
                NumFrames: u16 = 9
                StartFrame: u16 = 6
                TexDiv: vec2 = { 3, 3 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0700000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Floor_Glow"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/Zeri_Base_R_Disc_TopView.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.541176498, 0.894117653, 1, 0.200000003 }
                }
                MeshRenderFlags: u8 = 0
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 9, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/common_glow-soft.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                EmitterName: string = "Floor_Glow_Flicker"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/Zeri_Base_R_Disc_TopView.scb"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/Zeri_Base_Flicker.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.600000024, 0.466666669, 1, 0.298039228 }
                }
                MeshRenderFlags: u8 = 0
                ColorLookUpScales: vec2 = { 0.5, 1 }
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 9, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 9, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/common_glow-soft.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar_Jacket_Dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x100e165b
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 2
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.396078438, 0.494117647, 0.274509817, 1 }
                }
                MeshRenderFlags: u8 = 0
                DepthBiasFactors: vec2 = { -1, -1 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_R_Jacket_Darken_TX.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar_Jacket_Caustic"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x100e165b
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.53725493, 0.894117653, 1, 1 }
                }
                Pass: i16 = 2
                MeshRenderFlags: u8 = 0
                DepthBiasFactors: vec2 = { -1, -1 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_R_Jacket_TX.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/ground_pool_erosion.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 4 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar_Jacket_SolidGlow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x100e165b
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.607843161, 0.898039222, 1, 1 }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                DepthBiasFactors: vec2 = { -1, -1 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_R_Jacket_noRose_TX.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Zeri_Skin01_Rainbow02.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 5, 5 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -0.800000012 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Sparks"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, -200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, -200 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 50, 70, 10 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 150, -10 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 70
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Petal_AntiRose.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Sparks1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, -200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, -200 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 50, 70, 10 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 150, -10 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.137254909, 0.0980392173, 0.184313729, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Swain_Skin12_rose_leafs.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 60
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar_Gun"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x3e352725
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0, 0, 0 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.325490206, 0.729411781, 1, 0 }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Zeri/Skins/Base/Particles/common_color-hold.dds"
            }
        }
        ParticleName: string = "Zeri_Skin01_R_State"
        ParticlePath: string = "Characters/Zeri/Skins/Skin1/Particles/Zeri_Skin01_R_State"
        OverrideScaleCap: option[f32] = {
            -1
        }
    }
    "Characters/Zeri/Skins/Skin1/Particles/Zeri_Skin01_Emote_Respawn_Body" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.70000005
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar_Dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x100e165b
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.168627456, 0.117647059, 0.286274523, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.631372571, 0.631372571, 0.631372571, 1 }
                            { 0.360006094, 0.360006094, 0.360006094, 1 }
                            { 0.360006094, 0.360006094, 0.360006094, 0 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Evelynn_Skin24_Z_Mult02.dds"
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Evelynn_Skin24_Z_Mult02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 150
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            75
                            225
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Basic"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.300000012, 0.300000012, 0.300000012 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0.300000012, 0.300000012 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -100, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 100, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 40, 50, 40 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 40, 50, 40 }
                                { 40, 0, 40 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                            { 0, 400, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.937254906, 0.564705908, 1, 0 }
                            { 0.937254906, 0.564705908, 1, 1 }
                            { 0.0980392173, 0.0823529437, 0.129411772, 1 }
                            { 0.100007631, 0.0800030529, 0.130006865, 1 }
                        }
                    }
                }
                Pass: i16 = 50
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.341666669
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1.20000005, 0, 0 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Black_Banner_Ashes.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            20
                            60
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Basic_additive"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.300000012, 0.300000012, 0.300000012 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 0.300000012, 0.300000012 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -100, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 100, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 40, 50, 40 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 40, 50, 40 }
                                { 40, 0, 40 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                            { 0, 400, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.776470602, 0.615686297, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.87843138, 0.768627465, 1, 1 }
                            { 0.607843161, 0.78039217, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                DepthBiasFactors: vec2 = { 0, -100 }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.341666669
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1.20000005, 0, 0 }
                            { 0.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zeri/Skins/Skin01/Particles/Black_Banner_Ashes.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Zeri_Skin01_Emote_Respawn_Body"
        ParticlePath: string = "Characters/Zeri/Skins/Skin1/Particles/Zeri_Skin01_Emote_Respawn_Body"
        Flags: u16 = 197
    }
    0xd4ebd651 = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x73802601 = 0xb8dd3088
            0xe8ae7e0b = 0xf54021ae
            0x04699c96 = 0xcb020740
            0x1e11f637 = 0x638920d4
            0xd7819a48 = 0x389fd3e1
            0x03968a3a = 0x613f1cc1
            0x8bcc536d = 0xdeacd5b0
            0xc8234c8f = 0xa82ea618
            0xf449bd3f = 0x72418c86
            0xdbf7c2bc = 0x981cb1d3
            0x80a26838 = 0xc78dab33
            0x89916d7a = 0x076ace65
            0xb693eff1 = 0x37b0276e
            0x62490729 = 0xac00eec0
            0x283d235a = 0x2390f1cf
            0xe3e37669 = 0xf4c91208
            0x933fc97a = 0x15bac1a7
            0x0db726b9 = 0xe6bc5a94
            0xe8d96d96 = 0x9b960857
            0x102b34a6 = 0x2788f9f3
            0xd73d792e = 0xb4acd3ed
            0x00b347b8 = 0x08e5d7e1
            0x21068f15 = 0x654865e8
            0x13830060 = 0x47998759
            0x834e421a = 0xb61bae51
            0x248ec0ff = 0xf9204056
            0x7722a5c6 = 0x8f58e483
            0xac661ccd = 0xcb153874
            0x4d44fa52 = 0x281fc457
            0x6ff3138f = 0x66b16fb6
            0x177dce35 = 0xf4ef9042
            0xb71f9198 = 0xf7795b47
            0x51ab9025 = 0x7d4fd1bc
            0x4be7b021 = 0x4dc51e6a
            0xb8cee6ef = 0x132cf508
            0xb72a0295 = 0x7990ea20
            0x80d37671 = 0xefdfe0fa
            0x4936f46f = 0x713e4d24
            0xc0ea3ca2 = 0x26c66463
            0x37fa0847 = 0x33fa8298
            0xfc7001eb = 0xeb8060c0
            0x09737eec = 0x857ab463
            0x691d3e4d = 0x3d2a210c
            0xfe4b0cea = 0xdebf7c07
            0xb00fa3b3 = 0xda38cf0e
            0xef724e22 = 0x0d1bddaf
            0x04b741da = 0x181622ed
            0x355c3651 = 0x748ca278
            0x1a20cbc4 = 0x77563d45
            0x538b8e22 = 0x73dae499
            0x381e0d04 = 0xa16984f9
            0x5b8c5276 = 0x99f8c91b
            0x61188962 = 0xaa311227
            0xa53ac40e = 0xde1c2fdd
            0x5b574907 = 0x4a56635e
            0x399a34ee = 0x1cc86f9d
            0xc053e566 = 0x05b5c26b
            0x9964da59 = 0xff01765c
            0x86be383f = 0x3fdf9e62
            0xe2389472 = 0xbf10704d
            0x93375cf2 = 0xe04cd775
            0x32ed086a = 0x12187b95
            0x95c87820 = 0xe63cc6ad
            0x58a5aa17 = 0x83ba4ca0
            0x2393826f = 0xf353af5c
            0x31b99d90 = 0x2c3ab4e1
            0x80988457 = 0x1d2a51ba
            0xf11b2e4d = 0x4d7e2e80
            0xbfe9b3bd = 0x48f105a4
            0x7750c7f7 = 0xfe350d68
            0xbae51555 = 0xe8ceb7ce
            0x2687e8af = 0xea45dc52
            0x605fdc87 = 0x6a5db73e
            0xe440435b = 0x39066776
            0xbccf5e28 = 0x683ef5bd
            0x47c94424 = 0xd19d68a5
            0x8cc7aa0b = 0x60c201e6
            0x46190d40 = 0xbff28d07
            0xfee0b775 = 0x5b860312
            0x6d46087e = 0x5d0d0863
            0x93e9513c = 0x8f43d4cf
            0x20e751ba = 0x8555f25e
            0x9b6a054c = 0x1f7dfcab
            0xf84a07ed = 0x4b2f5a3a
            0xfa2adf76 = 0xc8470815
            0x3d68c2dd = 0x00801d3e
            0x0faf8413 = 0xceae204c
            0x6f891e9e = 0x3aa7956f
            0xd4e0c941 = 0xe03e73e2
            0x48cebf17 = 0xf292fa5e
            0x12a92eaa = 0xeed973db
            0xf4a1acd9 = 0xf2ae879c
            0xfebe7a36 = "Characters/Zeri/Skins/Skin1/Particles/Zeri_Skin01_Emote_Respawn_Body"
            0x653faaaa = 0xc77ea783
            0x2964df97 = 0x176f39e4
        }
    }
}
