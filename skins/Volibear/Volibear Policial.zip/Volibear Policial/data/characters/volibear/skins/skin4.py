#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Volibear_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6.bin"
    "DATA/Characters/Volibear/Volibear.bin"
    "DATA/Volibear_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Volibear_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Characters/Volibear/Animations/Skin4.bin"
    "DATA/Volibear_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Volibear_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5.bin"
    "DATA/Volibear_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin4_Skins_Skin5_Skins_Skin6.bin"
    "DATA/Volibear_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin4_Skins_Skin5.bin"
}
entries: map[hash,embed] = {
    "Characters/Volibear/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "Captain Volibear"
        AttributeFlags: u32 = 1
        MetaDataTags: string = "faction:freljord,gender:male,element:lightning,race:demigod,skinline:police,skinline:copsandrobbers"
        SkinUpgradeData: embed = SkinUpgradeData {
            mGearSkinUpgrades: list[link] = {
                0x7a6182ad
                0x83810054
                0x6c5cb829
                0xedf63288
            }
        }
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Volibear/Skins/Skin04/VolibearLoadScreen_4.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Volibear"
                "VolibearSkin04"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Volibear_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Volibear/Skins/Base/Volibear_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Volibear/Skins/Base/Volibear_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Volibear/Skins/Base/Volibear_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Volibear_Attack2DGeneral"
                        "Play_vo_Volibear_Attack2DHuman"
                        "Play_vo_Volibear_Dance3DGeneral"
                        "Play_vo_Volibear_Death3D"
                        "Play_vo_Volibear_FirstEncounter3DAnivia"
                        "Play_vo_Volibear_FirstEncounter3DAshe"
                        "Play_vo_Volibear_FirstEncounter3DBraum"
                        "Play_vo_Volibear_FirstEncounter3DGeneral"
                        "Play_vo_Volibear_FirstEncounter3DHuman"
                        "Play_vo_Volibear_FirstEncounter3DLissandra"
                        "Play_vo_Volibear_FirstEncounter3DNunu"
                        "Play_vo_Volibear_FirstEncounter3DOrnn"
                        "Play_vo_Volibear_FirstEncounter3DRengar"
                        "Play_vo_Volibear_FirstEncounter3DSejuani"
                        "Play_vo_Volibear_FirstEncounter3DTryndamere"
                        "Play_vo_Volibear_FirstEncounter3DYuumi"
                        "Play_vo_Volibear_FirstEncounter3DZilean"
                        "Play_vo_Volibear_Idle3DGeneral"
                        "Play_vo_Volibear_Joke3DGeneral"
                        "Play_vo_Volibear_Kill3DAnivia"
                        "Play_vo_Volibear_Kill3DGeneral"
                        "Play_vo_Volibear_Kill3DHuman"
                        "Play_vo_Volibear_Kill3DOrnn"
                        "Play_vo_Volibear_Kill3DTurret"
                        "Play_vo_Volibear_Laugh3DGeneral"
                        "Play_vo_Volibear_Move2DFirst"
                        "Play_vo_Volibear_Move2DLong"
                        "Play_vo_Volibear_Move2DStandard"
                        "Play_vo_Volibear_Recall3DGeneral"
                        "Play_vo_Volibear_Respawn2DGeneral"
                        "Play_vo_Volibear_Taunt3DGeneral"
                        "Play_vo_Volibear_TauntResponse3DGeneral"
                        "Play_vo_Volibear_VolibearBasicAttack2_cast3D"
                        "Play_vo_Volibear_VolibearBasicAttack3_cast3D"
                        "Play_vo_Volibear_VolibearBasicAttack_cast3D"
                        "Play_vo_Volibear_VolibearCritAttack_cast3D"
                        "Play_vo_Volibear_VolibearE_cast3D"
                        "Play_vo_Volibear_VolibearQ_cast3D"
                        "Play_vo_Volibear_VolibearR_cast3D"
                        "Play_vo_Volibear_VolibearW_cast3D"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Volibear_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Volibear/Skins/Base/Volibear_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Volibear/Skins/Base/Volibear_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    Name: string = "Volibear_Skin04_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Volibear/Skins/Skin04/Volibear_Skin04_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Volibear/Skins/Skin04/Volibear_Skin04_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_VolibearSkin04_VolibearBasicAttack_OnHit"
                        "Play_sfx_VolibearSkin04_VolibearCritAttack_OnHit"
                        "Play_sfx_VolibearSkin04_VolibearPApplicator_OnBuffActivate"
                        "Play_sfx_VolibearSkin04_VolibearPApplicator_OnBuffDeactivate"
                        "Play_sfx_VolibearSkin04_VolibearQ_OnBuffActivate"
                        "Play_sfx_VolibearSkin04_VolibearQ_OnBuffDeactivate"
                        "Play_sfx_VolibearSkin04_VolibearQ_OnCast"
                        "Play_sfx_VolibearSkin04_VolibearQAttack_OnCast"
                        "Play_sfx_VolibearSkin04_VolibearQAttack_OnHit"
                        "Play_sfx_VolibearSkin04_VolibearQPostAttack_OnHit"
                        "Play_sfx_VolibearSkin04_VolibearRTransitionAttack_OnHit"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Volibear/Animations/Skin4"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin4.skl"
            SimpleSkin: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin4.skn"
            Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_TX_CM.dds"
            SkinScale: f32 = 1.02999997
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Poro"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Volibear_Base_Poro_TX_CM.dds"
                    Submesh: string = "Poro"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x433de8f4
                    mEndingJointName: hash = 0xbf3778ee
                    mDefaultMaskName: hash = 0x7136e1bc
                    mMaxBoneAngle: f32 = 50
                    mDampingValue: f32 = 15
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            ""
        }
        IconAvatar: string = "ASSETS/Characters/Volibear/HUD/Volibear_Circle_4.dds"
        mContextualActionData: link = "Characters/Volibear/CAC/Volibear_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Volibear/HUD/Volibear_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Volibear/HUD/Volibear_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Volibear/Skins/Skin4/Resources"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeA" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_L_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 1.79999995, 0, 0 }
                                { 1, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Max_L_SpikeA_Blend1"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 2, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_L_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.391025633, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0823529437, 0.145098045, 0.23137255, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0823529437, 0.145098045, 0.23137255, 0 }
                            { 0.0823529437, 0.145098045, 0.23137255, 1 }
                            { 0.0823529437, 0.145098045, 0.23137255, 1 }
                            { 0.0823529437, 0.145098045, 0.23137255, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_L_SpikeA_Blend3"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 1.79999995, 0, 0 }
                                { 1, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 8, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_L_SpikeA"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeA"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeB" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Max_R_SpikeA_Blend1"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 2, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 175, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568628, 0.211764708, 0.34117648, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_L_SpikeB"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeB"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeC" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Max_R_SpikeA_Blend1"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 1, -5 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -5, 187, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.699999988, 0.899999976 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568628, 0.211764708, 0.34117648, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_MAX_01.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_L_SpikeC"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeC"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeB" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Max_R_SpikeA_Blend1"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 2, -2, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, -5, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1.29999995, 0.899999976 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568628, 0.211764708, 0.34117648, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_R_SpikeB"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeB"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeC" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Max_R_SpikeA_Blend2"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -2, 5 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 7, -5, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.699999988, 0.899999976 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_Blend3"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568628, 0.211764708, 0.34117648, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 1 }
                            { 0.121568628, 0.211764708, 0.34117648, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_MAX_01.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_R_SpikeC"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeC"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeA" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Max_R_SpikeA_Blend1"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 8, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 31
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.79999995, 2 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0823529437, 0.145098045, 0.23137255, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0823529437, 0.145098045, 0.23137255, 0 }
                            { 0.0823529437, 0.145098045, 0.23137255, 1 }
                            { 0.0823529437, 0.145098045, 0.23137255, 1 }
                            { 0.0823529437, 0.145098045, 0.23137255, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_Add"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 32
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 8, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_R_SpikeA"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeA"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_Aura_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Avatar"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.0117647061, 0.0117647061, 0.600000024 }
                }
                Pass: i16 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.670588255, 0.176470593, 0.0117647061, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Mist.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.200000003, 0.200000003 }
                            }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_Aura_01"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_Aura_01"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeB" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.699999988
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -40, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBack"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.783623099
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.878710628
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { -1.70000005, 0, 0 }
                            { -0.230769232, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBackAdd"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.186788678
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0.282352954, 0.431372553, 0.521568656, 0.285714298 }
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.878710628
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { -1.70000005, 0, 0 }
                            { -0.230769232, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_L_SpikeB"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeB"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeC" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.600000024
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -50, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBack"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.783623099
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.875600219
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { -1.70000005, 0, 0 }
                            { -0.682692289, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.481287837
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.824359, 0.824359, 0.682692289 }
                            { 0.600000024, 0.600000024, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBackAdd"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.186788678
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0.282352954, 0.431372553, 0.521568656, 0.285714298 }
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.875600219
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { -1.70000005, 0, 0 }
                            { -0.682692289, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.481287837
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.824359, 0.824359, 0.682692289 }
                            { 0.600000024, 0.600000024, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_L_SpikeC"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeC"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeA" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.800000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -30, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBack"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.781798303
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.821167886
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { -1.5, 0, 0 }
                            { -0.115384616, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBackAdd"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.186788678
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0.282352954, 0.431372553, 0.521568656, 0.285714298 }
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.821167886
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { -1.5, 0, 0 }
                            { -0.115384616, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_L_SpikeA"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeA"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_Aura_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Avatar"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Pass: i16 = 3
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.0196078438, 0.313725501, 0.670588255, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Wisp_Mult.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.100000001, -0.100000001 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "GlowyBits"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                    0x6b77a8ca: embed = ValueColor {
                        ConstantValue: vec4 = { 0.00784313772, 0.164705887, 0.305882365, 1 }
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 0.00784313772, 0.164705887, 0.305882365, 1 }
                                { 0.00784313772, 0.164705887, 0.305882365, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0xbbd3e50a
                            0x3016733b
                            "BODY"
                            0x2004d744
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            0xbbd3e50a
                            0x3016733b
                            "BODY"
                            0x2004d744
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.00784313772, 0.164705887, 0.305882365, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.00776474783, 0.164705887, 0.305882365, 0 }
                            { 0.00784313772, 0.164705887, 0.305882365, 1 }
                            { 0.00784313772, 0.164705887, 0.305882365, 1 }
                            { 0.00784313772, 0.164705887, 0.305882365, 0 }
                        }
                    }
                }
                Pass: i16 = 8
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                1
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.200000003
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -7 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_gem_tex.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 0.100000001 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Avatar1"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Pass: i16 = 20
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                1
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.200000003
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.0196078438, 0.313725501, 0.670588255, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_Aura_01"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_Aura_01"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Idle_pawSpark" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "AddGlow"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 5, 0, -15 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.7400015, 1, 0.379995435 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.118738405
                            0.249428183
                            0.444979787
                            0.681495428
                            0.838589966
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.1190999, 1, 0 }
                            { 0, 0.260614336, 1, 0.0872337744 }
                            { 0, 0.416372597, 1, 0.300461501 }
                            { 0, 0.618118942, 1, 0.379995435 }
                            { 0, 0.524103165, 1, 0.326972812 }
                            { 0, 0.630589724, 1, 0.11684233 }
                            { 0, 0.7400015, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 200
                DepthBiasFactors: vec2 = { -1, 40 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Idle_Background.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "backBlend"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 5, 0, -15 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.220004573, 0.360006094, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0134328362
                            0.158035323
                            0.329046041
                            0.587882757
                            0.790470481
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.220004573, 0.360006094, 0 }
                            { 0, 0.220004573, 0.360006094, 0.349402934 }
                            { 0, 0.220004573, 0.360006094, 0.500007629 }
                            { 0, 0.220004573, 0.360006094, 0.500007629 }
                            { 0, 0.220004573, 0.360006094, 0.331330359 }
                            { 0, 0.220004573, 0.360006094, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 25, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/common_Aura_Self.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.375695735
                            1
                        }
                        Values: list[f32] = {
                            0
                            20
                            0
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "flatSpark"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.250980407, 0.764705896, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.250980407, 0.764705896, 1, 1 }
                            { 0.0885813162, 0.698731244, 1, 1 }
                            { 0.0521645509, 0.251903117, 0.725490212, 0 }
                        }
                    }
                }
                Pass: i16 = 60
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 1.29999995
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.0230946876
                                0.104323246
                                0.223877907
                                0.434656948
                                0.594522417
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.205476344
                                0.873024285
                                1.11428571
                                1.29999995
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Idle_impactErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { 0, -20 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 180, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_pawSpark_02.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Volibear_Skin04_Idle_pawSpark"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Idle_pawSpark"
        Flags: u16 = 204
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeA" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.800000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend1"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBack"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.783623099
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -1, 1, -1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.821167886
                            1
                        }
                        Values: list[vec3] = {
                            { -3, 0, -0 }
                            { 1.5, 0, -0 }
                            { 0.115384616, 0, -0 }
                            { -0, 0, -0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBackAdd"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.186788678
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0.282352954, 0.431372553, 0.521568656, 0.285714298 }
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -1, 1, -1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.821167886
                            1
                        }
                        Values: list[vec3] = {
                            { -3, 0, -0 }
                            { 1.5, 0, -0 }
                            { 0.115384616, 0, -0 }
                            { -0, 0, -0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_R_SpikeA"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeA"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeB" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.699999988
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBack"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.783623099
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -1, 1, -1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.878710628
                            1
                        }
                        Values: list[vec3] = {
                            { -3, 0, -0 }
                            { 1.70000005, 0, -0 }
                            { 0.230769232, 0, -0 }
                            { -0, 0, -0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBackAdd"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.186788678
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0.282352954, 0.431372553, 0.521568656, 0.285714298 }
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -1, 1, -1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.878710628
                            1
                        }
                        Values: list[vec3] = {
                            { -3, 0, -0 }
                            { 1.70000005, 0, -0 }
                            { 0.230769232, 0, -0 }
                            { -0, 0, -0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.789219439
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.933333337, 0.933333337, 0.730769217 }
                            { 0.899999976, 0.899999976, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_R_SpikeB"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeB"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeC" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.600000024
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBack"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.783623099
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -1, 1, -1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.875600219
                            1
                        }
                        Values: list[vec3] = {
                            { -3, 0, -0 }
                            { 1.70000005, 0, -0 }
                            { 0.682692289, 0, -0 }
                            { -0, 0, -0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.481287837
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.824359, 0.824359, 0.682692289 }
                            { 0.600000024, 0.600000024, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "snapBackAdd"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.186788678
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0.282352954, 0.431372553, 0.521568656, 0.285714298 }
                            { 0.282352954, 0.431372553, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ice_Errodes_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -1, 1, -1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.108399048
                            0.875600219
                            1
                        }
                        Values: list[vec3] = {
                            { -3, 0, -0 }
                            { 1.70000005, 0, -0 }
                            { 0.682692289, 0, -0 }
                            { -0, 0, -0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.481287837
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.824359, 0.824359, 0.682692289 }
                            { 0.600000024, 0.600000024, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_zeroStacks_R_SpikeC"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeC"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeB" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.334486723, 0.545098066, 0 }
                            { 0, 0.0653594807, 0.545098066, 0 }
                            { 0, 0.0882330537, 0.545098066, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.549019635, 0.654901981, 0.713725507, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.300000012
                    FresnelColor: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Mid_L_SpikeB_Spark"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_R_SpikeB"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeB"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeC" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.431372553, 0.521568656, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.431372553, 0.521568656, 1 }
                            { 0, 0.294348329, 0.521568656, 0 }
                            { 0, 0.0575163402, 0.521568656, 0 }
                            { 0, 0.0776450858, 0.521568656, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.549019635, 0.654901981, 0.713725507, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Mid_L_SpikeC_Spark"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.800000012, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_R_SpikeC"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeC"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeA" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.300000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.549019635, 0.654901981, 0.713725507, 1 }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.300000012
                    FresnelColor: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.200000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Mid_L_SpikeA_Spark"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 2, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend1"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.549019635, 0.654901981, 0.713725507, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.654781222
                            1
                        }
                        Values: list[vec4] = {
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.300000012
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            -0.0162074547
                            0.0073944875
                            0.603736937
                            0.95461911
                        }
                        Values: list[vec3] = {
                            { -2, 0, 0 }
                            { 1.5, 0, 0 }
                            { 0.15705128, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_Passive_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0540617742
                            0.156474814
                            0.329136699
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.490196079, 0.545098066, 0.346381962 }
                            { 0, 0.490196079, 0.545098066, 0.126050428 }
                            { 0, 0.490196079, 0.545098066, 0 }
                            { 0, 0.490196079, 0.545098066, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.300000012
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 180 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            -0.0162074547
                            0.0073944875
                            0.603736937
                            0.95461911
                        }
                        Values: list[vec3] = {
                            { -2, 0, 0 }
                            { 1.5, 0, 0 }
                            { 0.15705128, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_R_SpikeA"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeA"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Recall_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    0.699999988
                }
                Lifetime: option[f32] = {
                    11
                }
                EmitterName: string = "bodyAdd_A"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0151051581
                            0.0504885986
                            0.12214984
                            0.955795765
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.411764711, 0.725490212, 1, 1 }
                            { 0.0431372561, 0, 0.698039234, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Ashe_Base_ground_CrackNoise_mult.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 0.100000001 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 11
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "bodyBlend"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.0156862754, 0.333333343, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0151051581
                            0.955795765
                            1
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.0156862754, 0.333333343, 0 }
                            { 0.200000003, 0.0156862754, 0.333333343, 1 }
                            { 0.200000003, 0.0156862754, 0.333333343, 1 }
                            { 0.200000003, 0.0156862754, 0.333333343, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Recall_01"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Recall_01"
        Flags: u16 = 198
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeA" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.400000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.274509817, 0.329411775, 0.360784322, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.274509817, 0.329411775, 0.360784322, 0 }
                            { 0.274509817, 0.329411775, 0.360784322, 1 }
                            { 0.274509817, 0.329411775, 0.360784322, 1 }
                            { 0.274509817, 0.329411775, 0.360784322, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.600000024
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Mid_L_SpikeA_Spark"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 3, 0, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.79999995, 0.899999976, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend1"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.654781222
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.490196079, 0.545098066, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.300000012
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -10, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -0.600000024, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            -0.0162074547
                            0.0073944875
                            0.603736937
                            0.95461911
                        }
                        Values: list[vec3] = {
                            { 1.20000005, 0, 0 }
                            { -0.899999976, 0, 0 }
                            { -0.0942307711, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend2"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeA.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.549019635, 0.654901981, 0.713725507, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0470016189
                            0.142625615
                            0.327390611
                            1
                        }
                        Values: list[vec4] = {
                            { 0.549019635, 0.654901981, 0.713725507, 1 }
                            { 0.549019575, 0.654901922, 0.713725448, 0.514538586 }
                            { 0.549019575, 0.654901922, 0.713725448, 0.15126051 }
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                            { 0.549019635, 0.654901981, 0.713725507, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -10, 180, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { -0.600000024, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            -0.0162074547
                            0.0073944875
                            0.603736937
                            0.95461911
                        }
                        Values: list[vec3] = {
                            { 1.20000005, 0, 0 }
                            { -0.899999976, 0, 0 }
                            { -0.0942307711, 0, 0 }
                            { -0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_L_SpikeA"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeA"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeB" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.334486723, 0.545098066, 0 }
                            { 0, 0.0653594807, 0.545098066, 0 }
                            { 0, 0.0882330537, 0.545098066, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Mid_L"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeB.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.899999976, 0.699999988 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_L_SpikeB"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeB"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeC" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Max_R_SpikeA_AddFlash"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00200000009
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.334486723, 0.545098066, 0 }
                            { 0, 0.0653594807, 0.545098066, 0 }
                            { 0, 0.0882330537, 0.545098066, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Mid_L_SpikeA_Blend"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Passive_L_SpikeC.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.490196079, 0.545098066, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00499999989
                            0.99000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.490196079, 0.545098066, 0 }
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.490196079, 0.545098066, 1 }
                            { 0, 0.490196079, 0.545098066, 0 }
                        }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0, 0.880003035, 0.97999543, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -25, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_Ice_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "Mid_L_SpikeC_Spark"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_iceSpike_lightning_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -30, 180, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.5, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_runeWars_lightning_graphic.dds"
                NumFrames: u16 = 4
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 2, 1 }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_midStacks_L_SpikeC"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeC"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_chainLightning_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                    0.899999976
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.349999994
                        }
                    }
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterLinger: option[f32] = {}
                EmitterName: string = "lightning"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 110, 0 }
                            Dynamics: pointer = VfxAnimatedVector3fVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {}
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            0.899999976
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            2.5
                                            3
                                            3.5
                                        }
                                    }
                                    VfxProbabilityTableData {}
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[vec3] = {
                                    { 0, 110, 0 }
                                }
                            }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/common_alpha_12.dds"
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.184381783
                            0.325486183
                            0.687635601
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.393790841, 0.715359449, 1, 1 }
                            { 0.125925928, 0.447494566, 1, 1 }
                            { 0.0431372561, 0.121568628, 0.368627459, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ColorLookUpTypeY: u8 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 1.10000002
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.0230946876
                                0.09207277
                                0.30721271
                                0.639279306
                                0.990762115
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.599074662
                                0.979048967
                                1.10000002
                            }
                        }
                    }
                    ErosionSliceWidth: f32 = 0.899999976
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_impactErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    -1.5
                                    1.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0, 0 }
                            { 1.60000002, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Static_01.dds"
                FrameRate: f32 = 2
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 4, 1 }
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            0.208242953
                            0.388286322
                            0.700650752
                            1
                        }
                        Values: list[vec2] = {
                            { 0, 0 }
                            { 0, 0 }
                            { 0.186206892, 0 }
                            { 0.744827569, 0 }
                            { 1, 0 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1
                                    0.899999976
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterLinger: option[f32] = {}
                EmitterName: string = "lightning1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 110, 0 }
                            Dynamics: pointer = VfxAnimatedVector3fVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {}
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            0.899999976
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            2.5
                                            3
                                            3.5
                                        }
                                    }
                                    VfxProbabilityTableData {}
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[vec3] = {
                                    { 0, 110, 0 }
                                }
                            }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/common_alpha_12.dds"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.209994659, 0.579995394, 0.600000024 }
                }
                ColorLookUpTypeY: u8 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.095238097
                                0.322996169
                                0.874087572
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.117241383
                                0.903448284
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionSliceWidth: f32 = 1.79999995
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    -1.5
                                    1.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 2, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 1.20000005, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/common_color-bellcurve.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Mist.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 4 }
                    }
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_chainLightning_01"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_chainLightning_01"
        Flags: u16 = 198
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Q_aura" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "black"
                TranslationOverride: vec3 = { 0, -50, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/common_alpha_12.dds"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.164705887, 0.200000003, 0.384313732, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            -0.0103347898
                            0.765510678
                            0.983897924
                        }
                        Values: list[vec4] = {
                            { 0.164705887, 0.200000003, 0.384313732, 1 }
                            { 0.164705887, 0.200000003, 0.384313732, 1 }
                            { 0.164705887, 0.200000003, 0.384313732, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/common_ball32_02.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash"
                Importance: u8 = 2
                TranslationOverride: vec3 = { 0, -100, 0 }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 50 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/common_alpha_02.dds"
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Pass: i16 = -1
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_Flash_01.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "avatarFlash"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0496083535
                            0.122715406
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 0.470588237, 0.843137264, 1, 0.309803933 }
                            { 0, 0.0156862754, 1, 0.117647059 }
                            { 0.701960802, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_Passive_Glow_B.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.0299999993
                    FresnelColor: vec4 = { 0, 0.670588255, 0.956862748, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "avatarfresnel1"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.239215687, 0.31764707, 0.352941185, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            1
                        }
                        Values: list[vec4] = {
                            { 0.239215687, 0.31764707, 0.352941185, 1 }
                            { 0.239215687, 0.31764707, 0.352941185, 0.160006106 }
                            { 0.239215687, 0.31764707, 0.352941185, 0 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_Passive_Glow_B.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.454901963, 0.949019611, 0.956862748, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_Q_Underlit.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    4
                }
                Period: option[f32] = {
                    4
                }
                TimeActiveDuringPeriod: option[f32] = {
                    4
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_FlatBlend1"
                Disabled: bool = true
                TranslationOverride: vec3 = { 0, -50, 0 }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 150 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        ConstantValue: vec4 = { 0.121568628, 0.521568656, 0.717647076, 1 }
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.988913536
                            }
                            Values: list[vec4] = {
                                { 0.121568628, 0.521568656, 0.717647076, 1 }
                                { 0.121568628, 0.521568656, 0.717647076, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 800
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 300, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0414343365
                            0.679662347
                            0.988913536
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.101960786, 0.431372553, 0.596078455, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0962939486
                            0.814372182
                            0.993348122
                        }
                        Values: list[vec4] = {
                            { 0.101960786, 0.431372553, 0.596078455, 0 }
                            { 0.101960786, 0.431372553, 0.596078455, 1 }
                            { 0.101960786, 0.431372553, 0.596078455, 1 }
                            { 0.101960786, 0.431372553, 0.596078455, 0 }
                        }
                    }
                }
                Pass: i16 = 99
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.00416666688
                                0.0340848826
                                0.0686587319
                                0.212852359
                                0.329558581
                                0.448607117
                                0.73809278
                                0.89187187
                                1
                            }
                            Values: list[f32] = {
                                1
                                0.192660555
                                0
                                0
                                0.0964958817
                                0.251495808
                                0.771866262
                                0.938431442
                                1
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.0785597414
                                0.22585924
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.489130437
                                0.782608688
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.449999988
                    ErosionFeatherOut: f32 = 0.449999988
                    ErosionMapName: string = "ASSETS/Characters/Senna/Skins/Base/Particles/Senna_Base_AutoAttack_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.159671038
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Senna/Skins/Base/Particles/Senna_Base_E_mistTrailSoft.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 4, 1 }
                EmitterUvScrollRate: vec2 = { -2, 0 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    4
                }
                Period: option[f32] = {
                    4
                }
                TimeActiveDuringPeriod: option[f32] = {
                    4
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_VertAdd2"
                Disabled: bool = true
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 150 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.988913536
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 800
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 300, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0414343365
                            0.679662347
                            0.988913536
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.501960814 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.498935759
                            0.993348122
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.501960814 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.00416666688
                                0.0264975801
                                0.0878875479
                                0.198781326
                                0.330637991
                                0.510748208
                                0.664527297
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                0
                                0.146145105
                                0.401985377
                                0.704639375
                                0.871204555
                                1
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.0785597414
                                0.22585924
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.489130437
                                0.782608688
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.449999988
                    ErosionFeatherOut: f32 = 0.449999988
                    ErosionMapName: string = "ASSETS/Characters/Senna/Skins/Base/Particles/Senna_Base_AutoAttack_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.833765745
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Senna/Skins/Base/Particles/Senna_Base_E_mistTrailSoft.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 4, 1 }
                EmitterUvScrollRate: vec2 = { -3, 0 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "bodyAdd_A"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.024813896
                            0.781385243
                            0.854494631
                            0.931098104
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.309803933, 0.313725501, 0.482352942, 0.888888896 }
                            { 0.247058824, 0.262745112, 0.31764707, 0.57320261 }
                            { 0.108669974, 0.120434679, 0.167493507, 0 }
                        }
                    }
                }
                Pass: i16 = 42
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_R_Coif_01.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.00999999978, 0.5 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterLinger: option[f32] = {
                    0.25
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_Add"
                Disabled: bool = true
                TranslationOverride: vec3 = { 0, 80, 0 }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 150 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.988913536
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 40 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 1200
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0414343365
                            0.679662347
                            0.988913536
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.333333343, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.119657613
                            0.291924655
                            0.451600701
                            0.993348122
                        }
                        Values: list[vec4] = {
                            { 1, 0.333333343, 0, 0 }
                            { 1, 0.333333343, 0, 0 }
                            { 1, 0.333333343, 0, 1 }
                            { 0.400000006, 0.296732038, 0, 1 }
                            { 0.0196078438, 0.202614382, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 99
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.00416666688
                                0.0340848826
                                0.0686587319
                                0.212852359
                                0.329558581
                                0.448607117
                                0.73809278
                                0.89187187
                                1
                            }
                            Values: list[f32] = {
                                1
                                0.192660555
                                0
                                0
                                0.0964958817
                                0.251495808
                                0.771866262
                                0.938431442
                                1
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.163817286
                                0.227353469
                                0.444331706
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.485074639
                                0.931862414
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.600000024
                    ErosionFeatherOut: f32 = 0.600000024
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Q_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.159671038
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Q_RuneTrail_A.dds"
                EmitterUvScrollRate: vec2 = { -0.5, 0 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterLinger: option[f32] = {
                    0.25
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 40 }
                }
                EmitterName: string = "Trail_Blendo"
                Disabled: bool = true
                TranslationOverride: vec3 = { 0, 80, 0 }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 150 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        ConstantValue: vec4 = { 0.600000024, 0.600000024, 0.600000024, 1 }
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.988913536
                            }
                            Values: list[vec4] = {
                                { 0.600000024, 0.600000024, 0.600000024, 1 }
                                { 0.600000024, 0.600000024, 0.600000024, 0 }
                            }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 40 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 1200
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                        mMaxAddedPerFrame: i32 = 20
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0414343365
                            0.679662347
                            0.988913536
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.600000024, 0.600000024, 0.600000024, 0.400000006 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.187461659
                            0.548466384
                            0.993348122
                        }
                        Values: list[vec4] = {
                            { 0.600000024, 0.600000024, 0.600000024, 0 }
                            { 0.600000024, 0.599999964, 0.599999964, 0.400000006 }
                            { 0.600000024, 0.600000024, 0.600000024, 0.400000006 }
                            { 0.600000024, 0.600000024, 0.600000024, 0 }
                        }
                    }
                }
                Pass: i16 = 98
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.00416666688
                                0.0340848826
                                0.0686587319
                                0.212852359
                                0.329558581
                                0.448607117
                                0.73809278
                                0.89187187
                                1
                            }
                            Values: list[f32] = {
                                1
                                0.192660555
                                0
                                0
                                0.0964958817
                                0.251495808
                                0.771866262
                                0.938431442
                                1
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.163817286
                                0.227353469
                                0.444331706
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.485074639
                                0.931862414
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.600000024
                    ErosionFeatherOut: f32 = 0.600000024
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Q_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.159671038
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Q_RuneTrail_A.dds"
                EmitterUvScrollRate: vec2 = { -0.5, 0 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    4
                }
                Lifetime: option[f32] = {
                    4
                }
                EmitterName: string = "bodyAdd_A1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.282352954, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.203312889
                            0.42190668
                            0.626774848
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.282352954, 0, 1 }
                            { 1, 0.282352954, 0, 1 }
                            { 1, 0.282352954, 0, 0.440366983 }
                            { 1, 0.282352954, 0, 0.183486238 }
                            { 1, 0.282352954, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 42
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Q_aura"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Q_aura"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_R_Buf_Max" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 11.4499998
                }
                ParticleLinger: option[f32] = {
                    0.449999988
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "BodyBGDark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xd5977cbe
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.024813896
                            0.924242377
                            0.955334961
                            0.981518269
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.309803933, 0.313725501, 0.482352942, 0.963855445 }
                            { 0.247058824, 0.262745112, 0.31764707, 0.850980401 }
                            { 0.108669974, 0.120434679, 0.167493507, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { 1, 4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Ult_Clouds_A.dds"
                UvMode: u8 = 1
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.0500000007 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_TX_CM.dds"
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    12
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.0199999996, 5 }
                }
                EmitterName: string = "Darklow"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            0.5
                            0.5
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 250, 30 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.368627459, 0.419607848, 0.458823532, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.102908276
                            0.304250568
                            0.455700666
                            1
                        }
                        Values: list[vec4] = {
                            { 0.368627459, 0.419607848, 0.458823532, 0 }
                            { 0.368627459, 0.419607848, 0.458823532, 0.156626508 }
                            { 0.368627459, 0.419607848, 0.458823532, 0.759464204 }
                            { 0.368627459, 0.419607848, 0.458823532, 1 }
                            { 0.368627459, 0.419607848, 0.458823532, 1 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.249401912
                                0.330224723
                                0.595388055
                                0.72749579
                                0.998004675
                            }
                            Values: list[f32] = {
                                0
                                0.075630255
                                0.201680675
                                0.74640739
                                0.897292256
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                DoesCastShadow: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 120, 120 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Cas_Dust_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 3, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 12
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    12.5
                }
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "EndFlash"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0480526648
                            0.187859938
                            0.410504252
                            0.984782636
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.566265047 }
                            { 1, 1, 1, 0.258187443 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 43
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 12
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.800000012
                }
                Lifetime: option[f32] = {
                    12.5
                }
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "EndWisps"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 20 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            1
                            0
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0537598431
                            0.13113606
                            0.767000079
                            0.852826655
                            0.921222746
                            0.984782636
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.614457846 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.80865556 }
                            { 1, 1, 1, 0.234091043 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 44
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.12895377
                                0.540145993
                                0.739659369
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.0588235296
                                0.647058845
                                0.873949587
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Dissolve_Cloudy_01.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.00999999978
                    FresnelColor: vec4 = { 0, 0.669993162, 0.960006118, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.156780541
                            0.452400595
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.09635091, 1.09635091, 1.09635091 }
                            { 1.16987455, 1.16987455, 1.16987455 }
                            { 1.25, 1.25, 1.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Avatar_Blend_01.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                Lifetime: option[f32] = {
                    0.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "JumpFlat"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0.00230946881
                                0.988452673
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.149019614, 0.847058833, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0206718352
                            0.789024174
                            0.7985394
                            0.869903386
                            0.979328156
                        }
                        Values: list[vec4] = {
                            { 0.149019614, 0.847058833, 1, 1 }
                            { 0.149019614, 0.847058833, 1, 1 }
                            { 0.149019614, 0.847058833, 1, 0.481927723 }
                            { 0.149019614, 0.847058833, 1, 0.132530123 }
                            { 0.149019614, 0.847058833, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 98
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { 0, 0.819607854, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.899999976
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "LANDINGfLASH"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0480526648
                            0.187859938
                            0.410504252
                            0.984782636
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.566265047 }
                            { 1, 1, 1, 0.258187443 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                -0.00973236002
                                0.119221412
                                0.309002429
                                0.649635017
                                0.824817538
                                0.987834573
                            }
                            Values: list[f32] = {
                                0.0168067235
                                0.109243698
                                0.30252102
                                0.756302536
                                0.907563031
                                0.957983196
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Dissolve_Cloudy_01.dds"
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.899999976
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                ParticleLinger: option[f32] = {
                    1.20000005
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "LandRoarBlend"
                Disabled: bool = true
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 1 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -100, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear.skl"
                        mAnimationName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Animations/Volibear_Spell4_Ground_Pound_to_R.anm"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.179436862
                            0.478322983
                            0.58319819
                            0.907683313
                            0.951235175
                            0.984782636
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.99999994, 0.99999994, 0.99999994, 0.14683193 }
                            { 1, 1, 1, 0.841726601 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.824019074 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 400
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.504188299
                                0.595194101
                                0.666041255
                                0.868667901
                                0.917448401
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.0504679158
                                0.13636364
                                0.778409064
                                0.930767775
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_impactErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.00999999978
                    FresnelColor: vec4 = { 0, 0.669993162, 0.960006118, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 180, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -10, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.286427975
                            0.419047624
                            0.686562657
                            0.804657936
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.08691752, 1.08691752, 1.08691752 }
                            { 1.21590912, 1.21590912, 1.21590912 }
                            { 1.71590912, 1.71590912, 1.71590912 }
                            { 1.87097979, 1.87097979, 1.87097979 }
                            { 2, 2, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Ashe_Skin04_ground_CrackNoise_mult.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Avatar_Blend_01.dds"
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    12
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.0199999996, 5 }
                }
                EmitterName: string = "Lightop"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 450, 30 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.102908276
                            0.304250568
                            0.455700666
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.156626508 }
                            { 1, 1, 1, 0.759464204 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.249401912
                                0.330224723
                                0.595388055
                                0.72749579
                                0.998004675
                            }
                            Values: list[f32] = {
                                0
                                0.075630255
                                0.201680675
                                0.74640739
                                0.897292256
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_shield_ice_smoke.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 3, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Ashe_Skin04_ground_CrackNoise_mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.109999999, 0.100000001 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.109999999, 0.100000001 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.699999988
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.75
                        }
                    }
                }
                Lifetime: option[f32] = {
                    12
                }
                Period: option[f32] = {
                    12
                }
                TimeActiveDuringPeriod: option[f32] = {
                    12
                }
                EmitterName: string = "Masked_Static"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 100, 100, 100 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 300, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.450980395, 0.745098054, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.450980395, 0.745098054, 1, 1 }
                            { 0.288273752, 0.476278365, 0.639215708, 1 }
                            { 0.245828524, 0.406151474, 0.545098066, 1 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 2
                StencilRef: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.49000001
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 125, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 125, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.699999988, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_tar_flipbook.dds"
                FrameRate: f32 = 20
                NumFrames: u16 = 9
                StartFrame: u16 = 1
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 3, 3 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.800000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    12
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.00999999978, 6 }
                }
                EmitterName: string = "Shadow"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            0.5
                            0.5
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 0, 30 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0899977088, 0.100007631, 0.110002287, 0.700007617 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.159268931
                            0.574879229
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0899977088, 0.100007631, 0.110002287, 0 }
                            { 0.0899977088, 0.100007631, 0.110002287, 0.700007617 }
                            { 0.0899977088, 0.100007631, 0.110002287, 0.700007617 }
                            { 0.0899977088, 0.100007631, 0.110002287, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.535230577
                                0.8548522
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.827496231
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionSliceWidth: f32 = 1.70000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/common_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    12
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x6d78ac72
                        }
                    }
                }
                EmitterName: string = "StaticParent"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -15, 10 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.239770666
                            0.385681301
                            0.588914573
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 0, 0.768627465, 1, 0.991342008 }
                            { 0, 0.751902044, 1, 0.461130142 }
                            { 0, 0.62999922, 1, 0.171777949 }
                            { 0, 0.349019617, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                ColorLookUpTypeY: u8 = 3
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.0230946876
                                0.290875733
                                0.369488329
                                0.581794143
                                0.990762115
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.42696628
                                0.771535575
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Dissolve_Cloudy_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                FrameRate: f32 = 4
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 4, 1 }
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 0, 0.200000003 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            0.258660495
                            0.381062359
                            1
                        }
                        Values: list[vec2] = {
                            { 0, 0 }
                            { 0, 0 }
                            { 0, 0.200000003 }
                            { 0, 0.109363295 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.14999998
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Stencil_Mask"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0.00230946881
                                0.988452673
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDrawAlways: list[hash] = {
                            0xd5977cbe
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                }
                Pass: i16 = -1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.0490243956
                                0.117908008
                                0.878859878
                                0.942025065
                                1
                            }
                            Values: list[f32] = {
                                1.03311253
                                0.198412344
                                0
                                0
                                0.19157055
                                1.03311253
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Dissolve_Cloudy_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                StencilMode: u8 = 1
                StencilRef: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_skin5_R_color-hold.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 11.4499998
                }
                ParticleLinger: option[f32] = {
                    0.449999988
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "bodyAdd_A"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.486274511, 0.78039217, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.024813896
                            0.924242377
                            0.955334961
                            0.981518269
                            1
                        }
                        Values: list[vec4] = {
                            { 0.486274511, 0.78039217, 1, 0 }
                            { 0.486274511, 0.78039217, 1, 1 }
                            { 0.486274511, 0.78039217, 1, 1 }
                            { 0.150649756, 0.24482891, 0.482352942, 0.963855445 }
                            { 0.120138407, 0.20504421, 0.31764707, 0.850980401 }
                            { 0.0528434366, 0.0939862803, 0.167493507, 0 }
                        }
                    }
                }
                Pass: i16 = 42
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_impactErode.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 11.4499998
                }
                ParticleLinger: option[f32] = {
                    0.449999988
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "bodyBlend_A"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.024813896
                            0.924242377
                            0.955334961
                            0.981518269
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.309803933, 0.313725501, 0.482352942, 0.963855445 }
                            { 0.247058824, 0.262745112, 0.31764707, 0.850980401 }
                            { 0.108669974, 0.120434679, 0.167493507, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0.5
                    }
                    ErosionFeatherIn: f32 = 1
                    ErosionFeatherOut: f32 = 1
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Glow_B.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.611764729, 0.87843138, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Avatar_Blend_01.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 11.4499998
                }
                ParticleLinger: option[f32] = {
                    0.449999988
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "bodyFresnel_A"
                Disabled: bool = true
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xd5977cbe
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.024813896
                            0.924242377
                            0.955334961
                            0.981518269
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0, 0, 0 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                            { 0, 0, 0, 0.963855445 }
                            { 0, 0, 0, 0.850980401 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 43
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.5
                    ErosionFeatherOut: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Avatar_fresnelMask_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.611764729, 0.87843138, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -6 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 4, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 2.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    12
                }
                EmitterName: string = "innerLightning"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 20 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 40, 200, 40 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.600000024
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 40, 200, 40 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0235294122, 0.839215696, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0411943309
                            0.122950263
                            0.305344254
                            0.626744986
                            0.978873253
                        }
                        Values: list[vec4] = {
                            { 0.0235294122, 0.839215696, 1, 0 }
                            { 0.0235294122, 0.839215696, 1, 1 }
                            { 0.0235294122, 0.839215696, 1, 0.894098341 }
                            { 0.0235294122, 0.839215696, 1, 0.501633227 }
                            { 0.0235294122, 0.839215696, 1, 0.157599941 }
                            { 0.0235294122, 0.839215696, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.357817292
                                0.5593431
                                0.782511711
                                0.998004675
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.502709866
                                0.888888896
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionSliceWidth: f32 = 1.70000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 2
                StencilRef: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_shield_ice_smoke.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Ashe_Skin04_ground_CrackNoise_mult.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.109999999, 0.100000001 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.109999999, 0.100000001 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.899999976
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                ParticleLinger: option[f32] = {
                    1.20000005
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "landRoarAdd"
                Disabled: bool = true
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 1 }
                }
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -100, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear.skl"
                        mAnimationName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Animations/Volibear_Spell4_Ground_Pound_to_R.anm"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.104405805
                            0.294496894
                            0.399372101
                            0.907683313
                            0.951235175
                            0.984782636
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.0964722186 }
                            { 1, 1, 1, 0.884892106 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.824019074 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 401
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.496683598
                                0.56705147
                                0.624765456
                                0.771106958
                                0.84427768
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.0511363633
                                0.204545453
                                0.818181813
                                0.9421314
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_impactErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.00999999978
                    FresnelColor: vec4 = { 0, 0.669993162, 0.960006118, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 180, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -10, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.286427975
                            0.419047624
                            0.686562657
                            0.804657936
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.08691752, 1.08691752, 1.08691752 }
                            { 1.21590912, 1.21590912, 1.21590912 }
                            { 1.71590912, 1.71590912, 1.71590912 }
                            { 1.87097979, 1.87097979, 1.87097979 }
                            { 2, 2, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Ashe_Skin04_ground_CrackNoise_mult.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Avatar_Blend_01.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    12
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.0199999996, 5 }
                }
                EmitterName: string = "midMid"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 350, 30 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.43921569, 0.501960814, 0.549019635, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.102908276
                            0.304250568
                            0.455700666
                            1
                        }
                        Values: list[vec4] = {
                            { 0.43921569, 0.501960814, 0.549019635, 0 }
                            { 0.43921569, 0.501960814, 0.549019635, 0.156626508 }
                            { 0.43921569, 0.501960814, 0.549019635, 0.759464204 }
                            { 0.43921569, 0.501960814, 0.549019635, 1 }
                            { 0.43921569, 0.501960814, 0.549019635, 1 }
                        }
                    }
                }
                Pass: i16 = 29
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.249401912
                                0.330224723
                                0.595388055
                                0.72749579
                                0.998004675
                            }
                            Values: list[f32] = {
                                0
                                0.075630255
                                0.201680675
                                0.74640739
                                0.897292256
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 120, 120 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_shield_ice_smoke.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 3, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                Lifetime: option[f32] = {
                    0.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "startAddHands"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0.00230946881
                                0.988452673
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0206718352
                            0.0396430269
                            0.803296983
                            0.979328156
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.800000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    1.14999998
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "swirlblendo"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_transform_Wind_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.220004573, 0.11999695, 0.269993126, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0415704399
                            0.0704388022
                            0.867580175
                            0.95195514
                            1
                        }
                        Values: list[vec4] = {
                            { 0.220004573, 0.11999695, 0.269993126, 0 }
                            { 0.220004573, 0.11999695, 0.269993126, 0.4372361 }
                            { 0.220004573, 0.11999695, 0.269993126, 0.500007629 }
                            { 0.220004573, 0.11999695, 0.269993126, 0.500007629 }
                            { 0.220004573, 0.11999695, 0.269993126, 0.430446625 }
                            { 0.220004573, 0.11999695, 0.269993126, 0 }
                        }
                    }
                }
                Pass: i16 = 400
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -180, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 4, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Swipe_A.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexAddressModeBase: u8 = 2
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 0, -1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, -1 }
                        }
                    }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Mist.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 3 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -1.5 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.800000012
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    1.14999998
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "swirladdy"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_transform_Wind_01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.650980413, 0.909803927, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0415704399
                            0.0704388022
                            0.867580175
                            0.95195514
                            1
                        }
                        Values: list[vec4] = {
                            { 0.650980413, 0.909803927, 1, 0 }
                            { 0.650980413, 0.909803927, 1, 0.874458849 }
                            { 0.650980413, 0.909803927, 1, 1 }
                            { 0.650980413, 0.909803927, 1, 1 }
                            { 0.650980413, 0.909803927, 1, 0.860880136 }
                            { 0.650980413, 0.909803927, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 401
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -180, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 4, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Swipe_A.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexAddressModeBase: u8 = 2
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 0, -1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, -1 }
                        }
                    }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_R_Wisp_Mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1.5 }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    11.4499998
                }
                EmitterName: string = "SirenFlash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.0470588244, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.203312889
                            0.42190668
                            0.626774848
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.0470588244, 1, 1 }
                            { 0, 0.0470588244, 1, 1 }
                            { 0, 0.0470588244, 1, 0.440366983 }
                            { 0, 0.0470588244, 1, 0.183486238 }
                            { 0, 0.0470588244, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 250
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -7 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_R_Buf_Max"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_R_Buf_Max"
    }
    "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_Aura_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.0399999991, 5 }
                }
                EmitterName: string = "DarkAbove"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 20 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 40
                    Height: f32 = 25
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.37000075, 0.420004576, 0.459998488, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0984340012
                            0.482810736
                            1
                        }
                        Values: list[vec4] = {
                            { 0.37000075, 0.420004576, 0.459998488, 0 }
                            { 0.37000075, 0.420004576, 0.459998488, 0.577943385 }
                            { 0.37000075, 0.420004576, 0.459998488, 1 }
                            { 0.37000075, 0.420004576, 0.459998488, 1 }
                        }
                    }
                }
                Pass: i16 = 29
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.336353481
                                0.419168115
                                0.613982081
                                0.712234735
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.117647059
                                0.226890758
                                0.655462205
                                0.777076066
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1.20000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_shield_ice_smoke.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 3, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.600000024
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.0399999991, 10 }
                }
                EmitterName: string = "DarkGroundLayer"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 20 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 10
                    Height: f32 = 25
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.37000075, 0.420004576, 0.459998488, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.145413876
                            0.384376734
                            1
                        }
                        Values: list[vec4] = {
                            { 0.37000075, 0.420004576, 0.459998488, 0 }
                            { 0.37000075, 0.420004576, 0.459998488, 0.640108168 }
                            { 0.37000075, 0.420004576, 0.459998488, 1 }
                            { 0.37000075, 0.420004576, 0.459998488, 1 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.336353481
                                0.419168115
                                0.613982081
                                0.712234735
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.117647059
                                0.226890758
                                0.655462205
                                0.777076066
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1.20000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Cas_Dust_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 3, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.0399999991, 5 }
                }
                EmitterName: string = "LightBlend"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 20 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 20
                    Height: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.36845237
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.336353481
                                0.419168115
                                0.613982081
                                0.712234735
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.117647059
                                0.226890758
                                0.655462205
                                0.777076066
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1.20000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0, 0 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_shield_ice_smoke.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 3, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Ashe_Skin04_ground_CrackNoise_mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.109999999, 0.100000001 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.109999999, 0.100000001 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.699999988
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.75
                        }
                    }
                }
                EmitterName: string = "Masked_Static"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 20, 40, 20 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.600000024
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 20, 40, 20 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.450980395, 0.745098054, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.450980395, 0.745098054, 1, 1 }
                            { 0.288273752, 0.476278365, 0.639215708, 1 }
                            { 0.245828524, 0.406151474, 0.545098066, 1 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.49000001
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.653424621
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    0.65882355
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.699999988, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_tar_flipbook.dds"
                FrameRate: f32 = 20
                NumFrames: u16 = 9
                StartFrame: u16 = 1
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 3, 3 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                RateByVelocityFunction: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.00999999978, 6 }
                }
                EmitterName: string = "Shadow_"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 20 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.0809399486
                            0.509138405
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -150, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0899977088, 0.100007631, 0.110002287, 0.700007617 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.159268931
                            0.574879229
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0899977088, 0.100007631, 0.110002287, 0 }
                            { 0.0899977088, 0.100007631, 0.110002287, 0.700007617 }
                            { 0.0899977088, 0.100007631, 0.110002287, 0.700007617 }
                            { 0.0899977088, 0.100007631, 0.110002287, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.535230577
                                0.8548522
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.827496231
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionSliceWidth: f32 = 1.70000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/common_ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "innerLightning"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 20 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 20, 40, 20 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.600000024
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 20, 40, 20 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0235294122, 0.839215696, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0411943309
                            0.122950263
                            0.305344254
                            0.626744986
                            0.978873253
                        }
                        Values: list[vec4] = {
                            { 0.0235294122, 0.839215696, 1, 0 }
                            { 0.0235294122, 0.839215696, 1, 1 }
                            { 0.0235294122, 0.839215696, 1, 0.894098341 }
                            { 0.0235294122, 0.839215696, 1, 0.501633227 }
                            { 0.0235294122, 0.839215696, 1, 0.157599941 }
                            { 0.0235294122, 0.839215696, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.150000006
                                0.357817292
                                0.5593431
                                0.782511711
                                0.998004675
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.502709866
                                0.888888896
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.400000006
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionSliceWidth: f32 = 1.70000005
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 180, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 180, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_shield_ice_smoke.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Ashe_Skin04_ground_CrackNoise_mult.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.109999999, 0.100000001 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.109999999, 0.100000001 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Masked_Static1"
                Disabled: bool = true
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 10, 40, 10 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.600000024
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 10, 40, 10 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.737254918, 0.866666675, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.737254918, 0.866666675, 1, 1 }
                            { 0.471264899, 0.553986907, 0.639215708, 1 }
                            { 0.401876211, 0.472418308, 0.545098066, 1 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -45
                                    45
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.49000001
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 80 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, 80, 80 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_jacobsLadder.dds"
                FrameRate: f32 = 16
                NumFrames: u16 = 16
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 4, 4 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 99
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Avatar"
                Disabled: bool = true
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.329411775, 0.709803939, 1, 1 }
                }
                Pass: i16 = 20
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.5
                    ErosionFeatherOut: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 0, 1, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.0196078438, 0.313725501, 0.670588255, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/color-hold.DDS"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_impactErode.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.400000006, -0.400000006 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.400000006, -0.400000006 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "bodyGradBlend1"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    UseLingerScale: flag = true
                    0xb2dcc7dc: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            Times: list[f32] = {
                                0.00816326495
                                1
                            }
                            Values: list[vec3] = {
                                { 1, 0, 0 }
                                { 0.5, 0, 0 }
                            }
                        }
                    }
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0.00230946881
                                0.988452673
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.00999465957, 0.2399939, 0.319996953, 0.100007631 }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { -1, -2 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Skin04/Volibear_Skin04_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "bodyAdd_A"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.00392156886, 0.368627459, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.203312889
                            0.42190668
                            0.626774848
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.00392156886, 0.368627459, 1 }
                            { 0, 0.00392156886, 0.368627459, 1 }
                            { 0, 0.00392156886, 0.368627459, 0.440366983 }
                            { 0, 0.00392156886, 0.368627459, 0.183486238 }
                            { 0, 0.00392156886, 0.368627459, 0 }
                        }
                    }
                }
                Pass: i16 = 42
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 1 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.643137276, 0.690196097, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    6
                }
                Lifetime: option[f32] = {
                    6
                }
                EmitterName: string = "bodyAdd_A1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.00392156886, 0.239215687, 0.792156875, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.203312889
                            0.42190668
                            0.626774848
                            1
                        }
                        Values: list[vec4] = {
                            { 0.00392156886, 0.239215687, 0.792156875, 1 }
                            { 0.00392156886, 0.239215687, 0.792156875, 1 }
                            { 0.00392156886, 0.239215687, 0.792156875, 0.440366983 }
                            { 0.00392156886, 0.239215687, 0.792156875, 0.183486238 }
                            { 0.00392156886, 0.239215687, 0.792156875, 0 }
                        }
                    }
                }
                Pass: i16 = 42
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Volibear/Skins/Skin04/Particles/Volibear_Skin04_Passive_Glow_A.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 1 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.643137276, 0.690196097, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -4 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                Texture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/color-hold.DDS"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Volibear/Skins/Base/Particles/Volibear_Base_colorGrad.dds"
                    PaletteCount: i32 = 16
                }
            }
        }
        ParticleName: string = "Volibear_Skin04_Passive_maxStacks_Aura_01"
        ParticlePath: string = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_Aura_01"
    }
    0x6c5cb829 = GearSkinUpgrade {
        mGearData: pointer = GearData {
            mVfxResourceResolver: pointer = ResourceResolver {}
        }
    }
    0x7a6182ad = GearSkinUpgrade {
        mGearData: pointer = GearData {
            mVfxResourceResolver: pointer = ResourceResolver {}
        }
    }
    0x83810054 = GearSkinUpgrade {
        mGearData: pointer = GearData {
            mVfxResourceResolver: pointer = ResourceResolver {}
        }
    }
    0xedf63288 = GearSkinUpgrade {
        mGearData: pointer = GearData {
            mVfxResourceResolver: pointer = ResourceResolver {}
        }
    }
    "Characters/Volibear/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Volibear_R_attack_buf_L" = "Characters/Volibear/Skins/Skin0/Particles/Volibear_Base_R_attack_buf_L"
            "Volibear_R_attack_buf_R" = "Characters/Volibear/Skins/Skin0/Particles/Volibear_Base_R_attack_buf_R"
            0x9302b6d3 = 0x6dea0f58
            0xbabd2161 = 0xe24cb79e
            0xdeb570a5 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_R_Buf_Max"
            0x339465c4 = 0x3f47ddf7
            0x5d587cca = 0xd0f73971
            0x3426454d = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_Aura_01"
            0x86cad419 = 0x765705b2
            0x255cc173 = 0xd976c74e
            0xeeb9b013 = 0x5c9f5368
            0x430a78d7 = 0x0de16d06
            0xefccc0de = 0x0de16d06
            0x26e4bfc3 = 0x273787e6
            0x19a7d548 = 0xc7c6fb55
            0x5175695e = 0x04674c7b
            0x79ea8ec0 = 0xcb5f78a9
            0xca178bf5 = 0x242f98ca
            0x2076dd33 = 0x3634da14
            0xcfe5ced8 = 0x363e7583
            0x34a4196b = 0x0f36fb08
            0x7e2af041 = 0x2c6094d6
            0x4c352fd2 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeA"
            0x4b352e3f = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeB"
            0x4a352cac = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_L_SpikeC"
            0xe36387f0 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeA"
            0xe6638ca9 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeB"
            0xe5638b16 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_R_SpikeC"
            0xcfdc69a6 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeA"
            0xcedc6813 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeB"
            0xcddc6680 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_L_SpikeC"
            0x01ab2a3c = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeA"
            0x04ab2ef5 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeB"
            0x03ab2d62 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_maxStacks_R_SpikeC"
            0x95bf28e2 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeA"
            0x94bf274f = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeB"
            0x93bf25bc = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_L_SpikeC"
            0x2e517920 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeA"
            0x31517dd9 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeB"
            0x30517c46 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_R_SpikeC"
            0x178c0831 = 0xfd7ce94e
            0x04fe08a9 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_midStacks_Aura_01"
            0x04719679 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_zeroStacks_Aura_01"
            0x2cd330c5 = 0xc2e77732
            0xd6565e3e = 0x41081dd7
            0x46d2dfd3 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Q_aura"
            0x6d78ac72 = 0x01b543d4
            0xd2c8fa6f = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Passive_chainLightning_01"
            0xbe6a7615 = 0xdb467fc7
            0x9852d67e = 0x8a1a93d3
            0x4543e999 = 0x83d9bf05
            0xead3c256 = 0x74978bae
            0xacf17fa8 = 0x95d9db5b
            0x338f637d = 0x57b754e2
            0xb9c9d361 = 0x1d1519e0
            0x243e81b6 = 0x80ff550f
            0xac47b4f2 = 0xe49dbc07
            0xc65b4dee = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Idle_pawSpark"
            0x4a8e6c32 = 0x16cff8eb
            0x19f2b094 = 0xa603ad29
            0xd68d8ea4 = 0xc0376651
            0x3190c9e3 = 0x9ba0d874
            0xb64e604f = 0x4a3bda72
            0x34aeb891 = 0xe69ee834
            0x631db25c = 0xfc426561
            0x173ad995 = 0xf94260a8
            0x8aa39859 = 0xf7783e08
            0xf26df310 = 0x56c9ec3d
            0x54310ad9 = 0x2cd288c6
            0xdd587971 = 0x1d040de6
            0xf475415d = 0x87a4fc6c
            0xf7bec269 = "Characters/Volibear/Skins/Skin4/Particles/Volibear_Skin04_Recall_01"
            0x1877a055 = 0xe88e5370
            0x9291ddb9 = 0xf1012f1a
            0xed60495a = 0x5a8dc989
            0xf39d67a6 = 0x0202ef69
            0x772825b8 = 0x88bc34a9
            0x1571890e = 0x3e65c86d
            0xf7c7b804 = 0xbcfaf072
            0x7cedf3f7 = 0x68d1f77c
            0x14b4d573 = 0x0a179cc6
            0xbeba5d20 = 0x724af32f
            0xc8cfc575 = 0xd649ba80
            0xbd1b28fe = 0xfcf7707f
            0xdaebc7e8 = 0x74eec27d
            0x59e92b92 = 0x91c59ec5
            0xc66563b6 = 0xe3911b53
            0x69331747 = 0x5d549f5c
        }
    }
}
