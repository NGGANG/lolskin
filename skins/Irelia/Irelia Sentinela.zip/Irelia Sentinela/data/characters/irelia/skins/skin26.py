#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Irelia/Animations/Skin26.bin"
    "DATA/Characters/Irelia/Irelia.bin"
    "DATA/Irelia_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin4_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Irelia_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35.bin"
}
entries: map[hash,embed] = {
    "Characters/Irelia/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "IreliaSkin26"
        MetaDataTags: string = "gender:female,faction:ionia,race:human,skinline:sentinels"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Irelia/Skins/Skin26/IreliaLoadScreen_26.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Irelia/Skins/Skin26/IreliaLoadscreen_26_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Irelia"
                "IreliaSkin26"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Irelia_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Irelia/Skins/Base/Irelia_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Irelia/Skins/Base/Irelia_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Irelia/Skins/Base/Irelia_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Irelia_AllyPing3DGank"
                        "Play_vo_Irelia_AttackChampion2D"
                        "Play_vo_Irelia_BuyItem2D1038"
                        "Play_vo_Irelia_BuyItem2D3078"
                        "Play_vo_Irelia_BuyItem2D3153"
                        "Play_vo_Irelia_BuyItem2D3748"
                        "Play_vo_Irelia_Death3D"
                        "Play_vo_Irelia_FirstMove2D"
                        "Play_vo_Irelia_IreliaBasicAttack2_cast3D"
                        "Play_vo_Irelia_IreliaBasicAttack_cast3D"
                        "Play_vo_Irelia_IreliaCritAttack_cast3D"
                        "Play_vo_Irelia_IreliaE2_cast3D"
                        "Play_vo_Irelia_IreliaE_cast3D"
                        "Play_vo_Irelia_IreliaQ_cast3D"
                        "Play_vo_Irelia_IreliaQ_OnHit_fail"
                        "Play_vo_Irelia_IreliaR_cast3D"
                        "Play_vo_Irelia_IreliaW2_OnCast"
                        "Play_vo_Irelia_IreliaW_cast3D"
                        "Play_vo_Irelia_Joke3DGeneral"
                        "Play_vo_Irelia_JokeResponse3D"
                        "Play_vo_Irelia_KillChampion3D"
                        "Play_vo_Irelia_KillChampion3DGank"
                        "Play_vo_Irelia_KillChampion3DNoxus"
                        "Play_vo_Irelia_Laugh3DGeneral"
                        "Play_vo_Irelia_MoveOrder2D"
                        "Play_vo_Irelia_MoveOrder2DLong"
                        "Play_vo_Irelia_Recall3D"
                        "Play_vo_Irelia_Respawn2D"
                        "Play_vo_Irelia_Taunt3DAhri"
                        "Play_vo_Irelia_Taunt3DAkali"
                        "Play_vo_Irelia_Taunt3DAurelionSol"
                        "Play_vo_Irelia_Taunt3DBard"
                        "Play_vo_Irelia_Taunt3DBraum"
                        "Play_vo_Irelia_Taunt3DFiora"
                        "Play_vo_Irelia_Taunt3DGaren"
                        "Play_vo_Irelia_Taunt3DGeneral"
                        "Play_vo_Irelia_Taunt3DIonianLoners"
                        "Play_vo_Irelia_Taunt3DIonianVastaya"
                        "Play_vo_Irelia_Taunt3DIonianVillians"
                        "Play_vo_Irelia_Taunt3DIvern"
                        "Play_vo_Irelia_Taunt3DJanna"
                        "Play_vo_Irelia_Taunt3DKarma"
                        "Play_vo_Irelia_Taunt3DKinkou"
                        "Play_vo_Irelia_Taunt3DNoxus"
                        "Play_vo_Irelia_Taunt3DOrianna"
                        "Play_vo_Irelia_Taunt3DRiven"
                        "Play_vo_Irelia_Taunt3DRyze"
                        "Play_vo_Irelia_Taunt3DSinged"
                        "Play_vo_Irelia_Taunt3DSivir"
                        "Play_vo_Irelia_Taunt3DSkarner"
                        "Play_vo_Irelia_Taunt3DSwain"
                        "Play_vo_Irelia_Taunt3DXinZhao"
                        "Play_vo_Irelia_TauntResponse3D"
                        "Play_vo_Irelia_TeamFightSurvive2D"
                        "Play_vo_Irelia_TeamRally3D"
                        "Play_vo_Irelia_UseItem2DWard"
                        "Reset_Playlist_vo_Irelia_IreliaQ_OnCast_Max"
                        "Stop_vo_Irelia_IreliaW_OnCast"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Irelia_Skin26_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Irelia/Skins/Skin26/Irelia_Skin26_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Irelia/Skins/Skin26/Irelia_Skin26_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_IreliaSkin26_Dance3D_loop"
                        "Play_sfx_IreliaSkin26_Death3D_buffactivate"
                        "Play_sfx_IreliaSkin26_Idle_attack1_armsV2_to_idle"
                        "Play_sfx_IreliaSkin26_Idle_attack1_kick_to_idle"
                        "Play_sfx_IreliaSkin26_Idle_attack1_to_idle"
                        "Play_sfx_IreliaSkin26_Idle_homeguard_in"
                        "Play_sfx_IreliaSkin26_Idle_in_subtle_a"
                        "Play_sfx_IreliaSkin26_Idle_in_subtle_b"
                        "Play_sfx_IreliaSkin26_IreliaBasicAttack2_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaBasicAttack2_OnHit"
                        "Play_sfx_IreliaSkin26_IreliaBasicAttack_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaBasicAttack_OnHit"
                        "Play_sfx_IreliaSkin26_IreliaCritAttack_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaCritAttack_OnHit"
                        "Play_sfx_IreliaSkin26_IreliaE2_buffactivate"
                        "Play_sfx_IreliaSkin26_IreliaE_foley"
                        "Play_sfx_IreliaSkin26_IreliaE_missile_stop"
                        "Play_sfx_IreliaSkin26_IreliaEMissile_OnMissileCast"
                        "Play_sfx_IreliaSkin26_IreliaEMissile_OnMissileLaunch"
                        "Play_sfx_IreliaSkin26_IreliaESecondary_hit"
                        "Play_sfx_IreliaSkin26_IreliaESecondary_hit_minion"
                        "Play_sfx_IreliaSkin26_IreliaESecondary_OnMissileCast"
                        "Play_sfx_IreliaSkin26_IreliaESecondary_sparkles"
                        "Play_sfx_IreliaSkin26_IreliaP_Max_OnBuffActivate"
                        "Play_sfx_IreliaSkin26_IreliaP_max_sparkles"
                        "Play_sfx_IreliaSkin26_IreliaP_sparkles"
                        "Play_sfx_IreliaSkin26_IreliaQ_hit"
                        "Play_sfx_IreliaSkin26_IreliaQ_Hit_reset"
                        "Play_sfx_IreliaSkin26_IreliaQ_missilelaunch"
                        "Play_sfx_IreliaSkin26_IreliaQ_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaR2_hit"
                        "Play_sfx_IreliaSkin26_IreliaR2_OnBuffActivate"
                        "Play_sfx_IreliaSkin26_IreliaR_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaR_OnHit_champ"
                        "Play_sfx_IreliaSkin26_IreliaR_OnHit_minion"
                        "Play_sfx_IreliaSkin26_IreliaR_onmissilelaunch"
                        "Play_sfx_IreliaSkin26_IreliaW2_hit"
                        "Play_sfx_IreliaSkin26_IreliaW2_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaW_OnCast"
                        "Play_sfx_IreliaSkin26_IreliaWCharged_cast"
                        "Play_sfx_IreliaSkin26_IreliaWDefence_block_enemy"
                        "Play_sfx_IreliaSkin26_IreliaWDefence_block_self"
                        "Play_sfx_IreliaSkin26_Joke3D_buffactivate"
                        "Play_sfx_IreliaSkin26_Recall3D_buffactivate"
                        "Play_sfx_IreliaSkin26_Taunt3D_buffactivate"
                        "Play_sfx_IreliaSkin26_Winddown3D_buffactivate"
                        "Stop_sfx_IreliaSkin26_Dance3D_loop"
                        "Stop_sfx_IreliaSkin26_IreliaR_onmissilelaunch"
                        "Stop_sfx_IreliaSkin26_Joke3D_buffactivate"
                        "Stop_sfx_IreliaSkin26_Recall3D_buffactivate"
                        "Stop_sfx_IreliaSkin26_Taunt3D_buffactivate"
                        "Switch_IreliaSkin26_P_01"
                        "Switch_IreliaSkin26_P_02"
                        "Switch_IreliaSkin26_P_03"
                        "Switch_IreliaSkin26_P_04"
                        "Switch_IreliaSkin26_P_Max"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Irelia/Animations/Skin26"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26.skl"
            SimpleSkin: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26.skn"
            Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_TX_CM.dds"
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "RecallRock"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Irelia/Skins/Skin26/Materials/Irelia_Blades_Passive_inst"
                    Submesh: string = "blades"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Recall_TX_CM.dds"
                    Submesh: string = "RecallRock"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Irelia/Skins/Skin26/Materials/HairGlow_inst"
                    Submesh: string = "Body_MAT"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x5346efd1
                    mEndingJointName: hash = 0x5246ee3e
                    mMaxBoneAngle: f32 = 70
                    mDampingValue: f32 = 20
                    mVelMultiplier: f32 = -1.29999995
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x506fbcc3
                    mEndingJointName: hash = 0x4f6fbb30
                    mMaxBoneAngle: f32 = 50
                    mDampingValue: f32 = 15
                    mVelMultiplier: f32 = -2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xc949c7fe
                    mEndingJointName: hash = 0xca49c991
                    mMaxBoneAngle: f32 = 30
                    mVelMultiplier: f32 = -5
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Blades"
        }
        IconAvatar: string = "ASSETS/Characters/Irelia/HUD/Irelia_Circle_26.dds"
        mContextualActionData: link = "Characters/Irelia/CAC/Irelia_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Irelia/HUD/Irelia_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Irelia/HUD/Irelia_Square_0.dds"
        }
        GodrayFxBone: string = ""
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Irelia/Skins/Skin26/Resources"
    }
    "Characters/Irelia/Skins/Skin26/Materials/Irelia_Blades_Passive_inst" = StaticMaterialDef {
        Name: string = "Characters/Irelia/Skins/Skin26/Materials/Irelia_Blades_Passive_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Shared/Materials/StepsMask.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color1"
                Value: vec4 = { 0.34117648, 0.223529413, 0.286274523, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel1_Bias"
                Value: vec4 = { -0.409999996, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel1_Size"
                Value: vec4 = { 3.96075249, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Num_Steps"
                Value: vec4 = { 3, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "stepValue"
                Value: vec4 = { -3, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.574999988, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.0745098069, 0, 0.666666687, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ENV_Map_Contribution"
                Value: vec4 = { 0.699999988, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color2"
                Value: vec4 = { 0.321568638, 0.788235307, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ENV_Fresnel_Masking"
                Value: vec4 = { 20.8008385, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Reflection_Tint"
                Value: vec4 = { 0.70588237, 0.666666687, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel2_Size"
                Value: vec4 = { 2.4408474, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel2_Bias"
                Value: vec4 = { -0.375, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_FRESNEL_MASK"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Glow_TextureSteps"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "stepValue"
                    Driver: pointer = RemapFloatMaterialDriver {
                        mDriver: pointer = BuffCounterDynamicMaterialFloatDriver {
                            mScriptName: string = "IreliaPassiveStacks"
                        }
                        mMaxValue: f32 = 3
                        mOutputMinValue: f32 = -3
                        mOutputMaxValue: f32 = 0
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Fresnel_Color2"
                    Driver: pointer = ColorGraphMaterialDriver {
                        Driver: pointer = FloatComparisonMaterialDriver {
                            mOperator: u32 = 2
                            mValueA: pointer = BuffCounterDynamicMaterialFloatDriver {
                                mScriptName: string = "IreliaPassiveStacks"
                            }
                            mValueB: pointer = FloatLiteralMaterialDriver {
                                mValue: f32 = 4
                            }
                        }
                        Colors: embed = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0.00441014348
                                1
                            }
                            Values: list[vec4] = {
                                { 0.57439059, 0.657550514, 1, 1 }
                                { 0.284482747, 0.284482747, 0.611400127, 1 }
                            }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Bloom_Color"
                    Driver: pointer = ColorGraphMaterialDriver {
                        Driver: pointer = FloatComparisonMaterialDriver {
                            mOperator: u32 = 2
                            mValueA: pointer = BuffCounterDynamicMaterialFloatDriver {
                                mScriptName: string = "IreliaPassiveStacks"
                            }
                            mValueB: pointer = FloatLiteralMaterialDriver {
                                mValue: f32 = 4
                            }
                        }
                        Colors: embed = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.995589852
                            }
                            Values: list[vec4] = {
                                { 0.268421054, 0.126315787, 0, 1 }
                                { 1, 0.620689631, 0, 1 }
                            }
                        }
                    }
                }
            }
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Diffuse_Texture"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = FloatComparisonMaterialDriver {
                                mOperator: u32 = 4
                                mValueA: pointer = BuffCounterDynamicMaterialFloatDriver {
                                    mScriptName: string = "IreliaPassiveStacks"
                                }
                                mValueB: pointer = FloatLiteralMaterialDriver {
                                    mValue: f32 = 3
                                }
                            }
                            TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
                        }
                    }
                }
            }
        }
    }
    "Characters/Irelia/Skins/Skin26/Materials/HairGlow_inst" = StaticMaterialDef {
        Name: string = "Characters/Irelia/Skins/Skin26/Materials/HairGlow_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "AlphaMask_Fresnel"
                TextureName: string = "ASSETS/Shared/Materials/white.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_01"
                TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_P_HairGlow1.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask"
                TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_P_HairGlow1.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_02"
                TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_P_HairGlow1.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_03"
                TextureName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_P_HairGlow1.dds"
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Texture_UV_Scale01"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 1, 0.839215696, 0.654901981, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Panning_Noise_Color"
                Value: vec4 = { 1, 0.87843138, 0.725490212, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollTexture_Control01"
                Value: vec4 = { 0, -0.25, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Texture_UV_Scale02"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollTexture_Control02"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Texture_UV_Scale03"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollTexture_Control03"
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomIntensity"
                Value: vec4 = { 1.42499995, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "INVERT_FRESNEL"
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_DIFFUSE_ALPHA"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/MultiMask_Panner_Fresnel"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Panning_Noise_Color"
                    Driver: pointer = ColorGraphMaterialDriver {
                        Driver: pointer = RemapFloatMaterialDriver {
                            mDriver: pointer = BuffCounterDynamicMaterialFloatDriver {
                                mScriptName: string = "IreliaPassiveStacks"
                            }
                            mMaxValue: f32 = 4
                        }
                        Colors: embed = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.482520342
                                1
                            }
                            Values: list[vec4] = {
                                { 0, 0, 0, 1 }
                                { 0, 0, 0, 1 }
                                { 0.947368443, 0.75686276, 0.474509805, 1 }
                            }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Fresnel_Color"
                    Driver: pointer = ColorGraphMaterialDriver {
                        Driver: pointer = RemapFloatMaterialDriver {
                            mDriver: pointer = BuffCounterDynamicMaterialFloatDriver {
                                mScriptName: string = "IreliaPassiveStacks"
                            }
                            mMaxValue: f32 = 4
                        }
                        Colors: embed = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.277235806
                                1
                            }
                            Values: list[vec4] = {
                                { 0, 0, 0, 1 }
                                { 0, 0, 0, 1 }
                                { 1, 0.75686276, 0.474509805, 1 }
                            }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Fresnel_Size"
                    Driver: pointer = RemapFloatMaterialDriver {
                        mDriver: pointer = BuffCounterDynamicMaterialFloatDriver {
                            mScriptName: string = "IreliaPassiveStacks"
                        }
                        mMaxValue: f32 = 5
                        mOutputMaxValue: f32 = 0.25
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "BloomIntensity"
                    Driver: pointer = RemapFloatMaterialDriver {
                        mDriver: pointer = BuffCounterDynamicMaterialFloatDriver {
                            mScriptName: string = "IreliaPassiveStacks"
                        }
                        mMaxValue: f32 = 3
                    }
                }
            }
        }
    }
    "Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BurstLight"
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.780407012 }
                            { 1, 1, 1, 1 }
                            { 0.576470613, 0.482352942, 0.376470596, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 310, 310, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.743799984
                            0.931861997
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.193910033, 0.193910033, 0.193907201 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Flash_1.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Weapon_Rainbow_Shine.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Center_light"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.11999695 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0 }
                            { 1, 0.882352948, 0.454901963, 0.11999695 }
                            { 0.352941185, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                AlphaRef: u8 = 0
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 211, 51, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.600000024, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Glow_Bright.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "shadow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.870588243, 0.870588243, 0.870588243, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.075815998
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.337254912, 0.254901975, 0.156862751, 0 }
                            { 0.250980407, 0.215686277, 0.13333334, 1 }
                            { 0.435294122, 0.388235301, 0.290196091, 0.603921592 }
                            { 0.203921571, 0.168627456, 0.125490203, 0 }
                        }
                    }
                }
                Pass: i16 = -33
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 283.200012, 378, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 3, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Glow_Bright.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cast_glow1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -100, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 3, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 40, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.639993906 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 0.940001547, 1 }
                            { 0.937254906, 1, 0.717647076, 1 }
                            { 0.952941179, 0.80392158, 0.53725493, 1 }
                            { 0.420004576, 0.0200045779, 0.0200045779, 1 }
                        }
                    }
                }
                Pass: i16 = -100
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.300000012
                                1.29999995
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Warwick_Skin26_Temp_R_DeflectionRipples.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0, 0 }
                            { 2, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_blade_swirl2.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ConeBurst"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Slayer_Transform_Beat3_upswirl.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.400000006, 0.100000001, 0.400000006 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 5, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Slayer_Transform_Beat4_groundflash.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -6 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ConeBurst1"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Slayer_Transform_Beat3_upswirl.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.450003803 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 0.650980413, 0.635294139, 0.403921574, 1 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -40, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.400000006, 0.300000012, 0.400000006 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.29999995, 1, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Ass_trans_ground_mesh.dds"
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.200000003 }
                }
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 0, -1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec2] = {
                            { 0, -9 }
                            { 0, -1 }
                            { 0, -1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "mesh_dustup"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.5, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Slayer_Transform_groundpulse.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.968627453, 0.768627465, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.968627453, 0.768627465, 0 }
                            { 1, 0.968627453, 0.768627465, 0.949996173 }
                            { 0.650980413, 0.6153633, 0.355678588, 0.309803933 }
                            { 0.164705887, 0.098762013, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsRotationEnabled: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    3609
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                            { 0, 1, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 1, 0.600000024 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.100000001, 0, 0.100000001 }
                            { 0.800000012, 1, 0.800000012 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_assassin_transform_ground_swirl_mult.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.5, -1 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldAttractionDefinitions: list[embed] = {
                        VfxFieldAttractionDefinitionData {
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 500
                            }
                        }
                    }
                }
                EmitterName: string = "_center"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -160, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 2, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                            { 1, 1.29999995, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_left"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 0, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, -170, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0.899999976, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                            { 1, 2, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_right"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 0, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -20, -170, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -500, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0.899999976, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                        }
                        Values: list[vec3] = {
                            { 1, 0, 1 }
                            { 1, 2, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_right5"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1200, 0, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -160, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.400000006, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_right1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1200, 0, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -160, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -500, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.400000006, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_left2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -200, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 8, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -50, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.600000024, 0.800000012 }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_right2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 8, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 50, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.600000024, 0.800000012 }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_left7"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -200, 200, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 8, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -125, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.5, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_child"
                        }
                    }
                }
                EmitterName: string = "_right6"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 8, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 125, -200, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Temp_R_Block_mult.dds"
                }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.600000024, 0.5, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Glow1"
                Importance: u8 = 2
                0xf50b1a41: pointer = 0xf4e37e07 {
                    KeywordsExcluded: list[string] = {
                        "VelkozSkin01"
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -250, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.956862748, 0.482352942, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -15
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 300, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 300, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Mis_glow_lines.dds"
            }
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.449999988
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_R_Mis_End_child"
                        }
                    }
                    ChildEmitOnDeath: bool = true
                }
                EmitterName: string = "Child_burst"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -200, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cast_glow3"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 7, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.579995394 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 0.940001547, 1 }
                            { 0.937254906, 1, 0.717647076, 1 }
                            { 0.952941179, 0.80392158, 0.53725493, 1 }
                            { 0.420004576, 0.0200045779, 0.0200045779, 1 }
                        }
                    }
                }
                Pass: i16 = -100
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.200000003
                                1.29999995
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Warwick_Skin26_Temp_R_DeflectionRipples.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0, 0 }
                            { 1.20000005, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_blade_swirl2.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Glow2"
                Importance: u8 = 2
                0xf50b1a41: pointer = 0xf4e37e07 {
                    KeywordsExcluded: list[string] = {
                        "VelkozSkin01"
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -200, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 10, -180, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 10, -180, 0 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.400000006 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 0.949019611, 0.650980413, 0 }
                        }
                    }
                }
                Pass: i16 = -15
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 250, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.899999976
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 250, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 0.800000012, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 0.800000012, 0 }
                            { 1.60000002, 0.800000012, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Light_Beam.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_Weapon_Rainbow_Shine.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.25, 0.25 }
                    }
                }
            }
        }
        VisibilityRadius: f32 = 500
        ParticleName: string = "Irelia_Skin26_R_Mis"
        ParticlePath: string = "Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Mis"
        Flags: u16 = 199
    }
    "Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Blades" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Middle_blade"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 90, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.200000003
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.600000024 }
                        }
                    }
                }
                Pass: i16 = 5
                MiscRenderFlags: u8 = 1
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                            { 0, 5, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1.39999998, 1.20000005 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1.20000005, 1.20000005 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0299999993
                            0.0500000007
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.20000005, 1.55999994, 1.20000005 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            4
                            3
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "Large_beam_glow"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -100, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveRay {}
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.900007606, 0.650003791, 0.639993906 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.900007606, 0.650003791, 0 }
                            { 0.701960802, 0.900007606, 0.570983768, 0.639993906 }
                            { 0.125490203, 0, 0.412943602, 0 }
                        }
                    }
                }
                Pass: i16 = 12
                CensorModulateValue: vec4 = { 0, 0, 0, 1 }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec3] = {
                            { 50, 300, 0 }
                            { 50, 300, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 3, 1 }
                            { 3, 1, 1 }
                            { 5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Spotlight.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.9000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_E_Blades_Child_Glow"
                        }
                    }
                }
                EmitterName: string = "left_blade"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                        }
                        Values: list[vec3] = {
                            { 0, 5, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                            { -30, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 30, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.200000003
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.360006094 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                            { 0, 5, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.970000029
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.9000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Irelia_E_Blades_Child_Glow"
                        }
                    }
                }
                EmitterName: string = "right_blade"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                        }
                        Values: list[vec3] = {
                            { 0, 5, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { -50, 0, 0 }
                            { 30, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -30, 80, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Weapon.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.200000003
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.360006094 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -90, 0 }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                            { 0, 5, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.970000029
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Irelia_Skin26_Blades_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Bright_flash"
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.933333337, 0.600000024, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.933333337, 0.600000024, 1 }
                            { 1, 0.933333337, 0.600000024, 1 }
                        }
                    }
                }
                Pass: i16 = 12
                CensorModulateValue: vec4 = { 0, 0, 0, 1 }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 70, 0 }
                }
                DirectionVelocityScale: f32 = 0.0250000004
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 0, 0 }
                            { 0.300000012, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Spotlight.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BurstLight"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 70, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.780407012 }
                            { 1, 0.870588243, 0.643137276, 1 }
                            { 0.427450985, 0.352941185, 0.321568638, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 110, 310, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.743799984
                            0.931861997
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.193910033, 0.193910033, 0.193907201 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Flash_1.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    4
                }
                EmitterName: string = "Dark_circle"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 500, 0 }
                            { 0, -100, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.282352954, 0.168627456, 0.0941176489, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.282352954, 0.168627456, 0.0941176489, 0 }
                            { 0.282352954, 0.168627456, 0.0941176489, 1 }
                            { 0.282352954, 0.138275281, 0.0367063843, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 1.20000005, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ray_flash"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -100, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 0.730006874, 0.289997697 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 0.730006874, 0.289997697 }
                            { 0.968627453, 1, 0.438004136, 0.289997697 }
                            { 0.792156875, 0.501960814, 0.223296225, 0.289997697 }
                        }
                    }
                }
                Pass: i16 = 12
                CensorModulateValue: vec4 = { 0, 0, 0, 1 }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 500, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 0 }
                            { 0, 1, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Spotlight.dds"
            }
        }
        ParticleName: string = "Irelia_Skin26_E_Blades"
        ParticlePath: string = "Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Blades"
        SoundOnCreateDefault: string = "Play_sfx_Irelia_IreliaE_missile_stop"
    }
    "Characters/Irelia/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Irelia_emote_death_sound" = 0x37177d64
            "Irelia_Q_tar" = 0xbd56b1aa
            "Irelia_Q_Dash" = 0x86c3fe1f
            "Irelia_E_Mis_02" = 0x056406ad
            "Irelia_E_Beam_Warning_Sparks" = 0x5f32b8fa
            "Irelia_Q_heal" = 0x96dab551
            "Irelia_E_Blades" = "Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_E_Blades"
            0x5e32a062 = 0x9e0cda50
            0x1e79e656 = 0xbe5cfc53
            0x29f0eed8 = 0x3375ad47
            "Irelia_E_Team_Indicator" = 0x8d177478
            "Irelia_E_Beam" = 0x9f166b68
            "Irelia_R_Wall_Hit" = 0x2ee71e6a
            "Irelia_W_Hit" = 0x5959aca6
            "Irelia_R_Mis" = "Characters/Irelia/Skins/Skin26/Particles/Irelia_Skin26_R_Mis"
            "Irelia_W_Swipe" = 0x8a6150dd
            "Irelia_Q_Mark" = 0x9075bcf6
            "Irelia_E_Mis_01" = 0x026401f4
            "Irelia_BA_Far_swipe_01" = 0x07f42125
            "Irelia_BA_Far_swipe_02" = 0x04f41c6c
            "Irelia_BA_Hit" = 0x4f657644
            "Irelia_BA_Hit_02" = 0xe9075243
            "Irelia_BA_Hit_Crit" = 0xe1d19381
            0xf5889176 = 0x33410844
            0x62ebbfd6 = 0x684ab3d4
            "Irelia_W_DR" = 0x7d451207
            "Irelia_W_Block" = 0x2f7c9206
            0x4fbcffc4 = 0x1c48adf8
            0xeed84822 = 0x65b89968
            "Irelia_P_Hit_02" = 0xb93aa012
            0xecd844fc = 0xdc53367d
            "Irelia_P_Hit_04" = 0xb33a96a0
            0x19c4bd3c = 0x8eb42041
            "Irelia_E_Blades_Child_Glow" = 0xdeea55d3
            "Irelia_BA_Far_swipe_03" = 0x05f41dff
            "Irelia_BA_Close_01" = 0x86b51205
            "Irelia_BA_Close_02" = 0x83b50d4c
            "Irelia_BA_Crit_swipe" = 0x0ef05fce
            "Irelia_E_cas" = 0xd3a2b344
            "Irelia_W_FullPower" = 0xf8d60d71
            "Irelia_Q_Mark_SelfOnly" = 0xd658a257
            "Irelia_Q_Proc" = 0x8ff60b4b
            0xd17cc36f = 0x03931b17
            "Irelia_E_cas_02" = 0x469f3143
            "Irelia_E_Mis_02_Child" = 0xe2aa1774
            "Irelia_P_Far_swipe_02" = 0x419ce925
            "Irelia_P_Far_swipe_03" = 0x409ce792
            "Irelia_P_Close_01" = 0xda47bae0
            "Irelia_P_Far_swipe_01" = 0x3e9ce46c
            "Irelia_P_Close_02" = 0xdd47bf99
            "Irelia_P_Hit_Shields" = 0xe21e940a
            "Irelia_R_cas" = 0x42516cc5
            "Irelia_E_hit_Avatar" = 0x18f745bc
            "Irelia_W_Swipe_Empowered" = 0x745e782c
            "Irelia_R_groundlines" = 0x6a099d8a
            0xf38f40e1 = 0x5df82d8d
            "Irelia_W_Block_child" = 0xbdfc6013
            "Irelia_R_Mis_child" = 0x87fc3abe
            "Irelia_R_Mis_End_child" = 0x3ea1b194
            "Irelia_R_Hit_Aoe" = 0x3fd538cd
            "Irelia_E_Team_Indicator_Enemy" = 0x26c155cb
            "Irelia_E_Beam_Enemy" = 0xb0d4c8fb
            "Irelia_E_Beam_Warning_Sparks_Enemy" = 0xe2e1853d
            "Irelia_E_Hit_minion" = 0xd422644b
            "Irelia_R_Wall_Bladeglow_Enemy" = 0x039cc34b
            "Irelia_Q_tar_enemy" = 0xf3ea166d
            0xef440838 = 0x26573ddf
            0x255b925b = 0x9e7264f6
            0x90b85bce = 0x3aecabaf
            0x8fb85a3b = 0x3becad42
            0x8eb858a8 = 0x3cecaed5
            0xc96c8c46 = 0xd4b93e31
            0x57dd663a = 0x8e4913af
            0xa476f8d7 = 0xe30d6842
            0xe48dc601 = 0x057d7c84
            0x2bfbb43c = 0x4f02584d
            0x680a5803 = 0x07e94ed6
            0xbceb351f = 0x1e14f47a
            0xafc75cc2 = 0x366f38ed
            0x4f97786c = 0xd4e1d905
        }
    }
}
