#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Zoe/Zoe.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin9.bin"
    "DATA/Characters/Zoe/Animations/Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin9.bin"
    "DATA/Zoe_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Zoe/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 2
        ChampionSkinName: string = "ZoeSkin12"
        SkinParent: i32 = 9
        MetaDataTags: string = "faction:mttargon,gender:female,race:aspect,thememusic:starguardian2019,skinline:starguardian"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Zoe/Skins/Skin09/ZoeLoadScreen_9.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Zoe/Skins/Skin09/ZoeLoadscreen_9_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Zoe"
                "ZoeSkin09"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Zoe_Skin09_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Zoe/Skins/Skin09/Zoe_Skin09_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Zoe/Skins/Skin09/Zoe_Skin09_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Zoe/Skins/Skin09/Zoe_Skin09_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_ZoeSkin09_Attack2DAurelionSol"
                        "Play_vo_ZoeSkin09_Attack2DEzreal"
                        "Play_vo_ZoeSkin09_Attack2DFemale"
                        "Play_vo_ZoeSkin09_Attack2DGeneral"
                        "Play_vo_ZoeSkin09_Attack2DLux"
                        "Play_vo_ZoeSkin09_Attack2DYordle"
                        "Play_vo_ZoeSkin09_Dance3DGeneral"
                        "Play_vo_ZoeSkin09_Death3D"
                        "Play_vo_ZoeSkin09_FirstEncounter3DEzreal"
                        "Play_vo_ZoeSkin09_FirstEncounter3DLux"
                        "Play_vo_ZoeSkin09_Joke3DGeneral"
                        "Play_vo_ZoeSkin09_Kill3DAurelionSol"
                        "Play_vo_ZoeSkin09_Kill3DEzreal"
                        "Play_vo_ZoeSkin09_Kill3DGeneral"
                        "Play_vo_ZoeSkin09_Kill3DLux"
                        "Play_vo_ZoeSkin09_Laugh3DGeneral"
                        "Play_vo_ZoeSkin09_Move2DFirstEnemyAurelionSol"
                        "Play_vo_ZoeSkin09_Move2DFirstEnemyEzreal"
                        "Play_vo_ZoeSkin09_Move2DLong"
                        "Play_vo_ZoeSkin09_Move2DStandard"
                        "Play_vo_ZoeSkin09_Recall3DGeneral"
                        "Play_vo_ZoeSkin09_Taunt3DGeneral"
                        "Play_vo_ZoeSkin09_TauntResponse3DGeneral"
                        "Play_vo_ZoeSkin09_ZoeBasicAttack2_cast3D"
                        "Play_vo_ZoeSkin09_ZoeBasicAttack3_cast3D"
                        "Play_vo_ZoeSkin09_ZoeBasicAttack_cast3D"
                        "Play_vo_ZoeSkin09_ZoeCritAttack_cast3D"
                        "Play_vo_ZoeSkin09_ZoeE_enemytrapped"
                        "Play_vo_ZoeSkin09_ZoeE_OnCast"
                        "Play_vo_ZoeSkin09_ZoeQ_nearmiss"
                        "Play_vo_ZoeSkin09_ZoeQ_OnCast"
                        "Play_vo_ZoeSkin09_ZoeQMis2_big_hit"
                        "Play_vo_ZoeSkin09_ZoeQrecast_OnCast"
                        "Play_vo_ZoeSkin09_ZoeR_OnCast"
                        "Play_vo_ZoeSkin09_ZoeWVisualMissile_OnHit"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Zoe_Skin09_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Zoe/Skins/Skin09/Zoe_Skin09_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Zoe/Skins/Skin09/Zoe_Skin09_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate"
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate_familiar"
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate_ground_light_01"
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate_ground_light_02"
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate_ground_light_03"
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate_ground_light_04"
                        "Play_sfx_ZoeSkin09_Dance3D_buffactivate_stage"
                        "Play_sfx_ZoeSkin09_Death3D_buffactivate"
                        "Play_sfx_ZoeSkin09_Homeguard3D_buffactivate"
                        "Play_sfx_ZoeSkin09_Homeguard3D_buffdeactivate"
                        "Play_sfx_ZoeSkin09_Homeguard3D_familiar_swim_01"
                        "Play_sfx_ZoeSkin09_Homeguard3D_familiar_swim_02"
                        "Play_sfx_ZoeSkin09_Homeguard3D_loop"
                        "Play_sfx_ZoeSkin09_Homeguard3D_loop2"
                        "Play_sfx_ZoeSkin09_Homeguard3D_zoe_swim_01"
                        "Play_sfx_ZoeSkin09_Homeguard3D_zoe_swim_02"
                        "Play_sfx_ZoeSkin09_Idle3D_jumprope_single"
                        "Play_sfx_ZoeSkin09_Idle3D_yoyo_double"
                        "Play_sfx_ZoeSkin09_Idle3D_yoyo_single"
                        "Play_sfx_ZoeSkin09_Idle3D_yoyo_single_run"
                        "Play_sfx_ZoeSkin09_Idle3D_yoyo_trick"
                        "Play_sfx_ZoeSkin09_Joke3D_buffactivate"
                        "Play_sfx_ZoeSkin09_Laugh3D_buffactivate"
                        "Play_sfx_ZoeSkin09_Recall3D_leadin"
                        "Play_sfx_ZoeSkin09_Recall3D_winddown"
                        "Play_sfx_ZoeSkin09_Respawn3D_buffactivate"
                        "Play_sfx_ZoeSkin09_Taunt3D_buffactivate"
                        "Play_sfx_ZoeSkin09_TauntGameStart3D_buffactivate"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack2_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack2_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack2_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack3_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack3_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack3_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttack_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttackSpecial_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeBasicAttackSpecial_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeCritAttack_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeCritAttack_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeE_MusicParameter_Off"
                        "Play_sfx_ZoeSkin09_ZoeE_MusicParameter_On"
                        "Play_sfx_ZoeSkin09_ZoeE_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeE_OnMissileCast"
                        "Play_sfx_ZoeSkin09_ZoeEB_bounce"
                        "Play_sfx_ZoeSkin09_ZoeEB_pop"
                        "Play_sfx_ZoeSkin09_ZoeEMisAudio_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeESleepCountDownSlow_buffactivate"
                        "Play_sfx_ZoeSkin09_ZoeESleepCountDownSlow_hit"
                        "Play_sfx_ZoeSkin09_ZoeESleepStun_buffactivate"
                        "Play_sfx_ZoeSkin09_ZoeESleepStun_OnBuffDeactivate"
                        "Play_sfx_ZoeSkin09_ZoeQ_mis_linger"
                        "Play_sfx_ZoeSkin09_ZoeQ_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeQMis2_big_hit"
                        "Play_sfx_ZoeSkin09_ZoeQMis2_big_hit_self"
                        "Play_sfx_ZoeSkin09_ZoeQMis2_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeQMis2SleepCombo_big_hit"
                        "Play_sfx_ZoeSkin09_ZoeQMis2SleepCombo_big_hit_self"
                        "Play_sfx_ZoeSkin09_ZoeQMis2SleepCombo_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeQMis2Warning_missilecast_self"
                        "Play_sfx_ZoeSkin09_ZoeQMis2Warning_OnMissileCast"
                        "Play_sfx_ZoeSkin09_ZoeQMis2Warning_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeQMis2WarningSleepCombo_missilecast_self"
                        "Play_sfx_ZoeSkin09_ZoeQMis2WarningSleepCombo_OnMissileCast"
                        "Play_sfx_ZoeSkin09_ZoeQMis2WarningSleepCombo_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeQMissile_missilecast_self"
                        "Play_sfx_ZoeSkin09_ZoeQMissile_OnHit"
                        "Play_sfx_ZoeSkin09_ZoeQMissile_OnMissileCast"
                        "Play_sfx_ZoeSkin09_ZoeQMissile_OnMissileLaunch"
                        "Play_sfx_ZoeSkin09_ZoeR_buffonactivate"
                        "Play_sfx_ZoeSkin09_ZoeR_cast_self"
                        "Play_sfx_ZoeSkin09_ZoeR_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeR_vocalization"
                        "Play_sfx_ZoeSkin09_ZoeR_vocalization_lick"
                        "Play_sfx_ZoeSkin09_ZoeW_balloonpop"
                        "Play_sfx_ZoeSkin09_ZoeW_orb_hit"
                        "Play_sfx_ZoeSkin09_ZoeW_orb_missilelaunch"
                        "Play_sfx_ZoeSkin09_ZoeW_spellorbland"
                        "Play_sfx_ZoeSkin09_ZoeWPassive_OnCast"
                        "Play_sfx_ZoeSkin09_ZoeWVisualMissile_OnMissileCast"
                        "Play_sfx_ZoeSkin09W_disablebypass"
                        "Play_sfx_ZoeSkin09W_enablebypass"
                        "Stop_sfx_ZoeSkin09_Homeguard3D_buffactivate"
                        "Stop_sfx_ZoeSkin09_Homeguard3D_loop"
                        "Stop_sfx_ZoeSkin09_Homeguard3D_loop2"
                        "Stop_sfx_ZoeSkin09_ZoeEMis_OnMissileLaunch"
                        "Stop_sfx_ZoeSkin09_ZoeQMis2Warning_OnMissileLaunch"
                        "Stop_sfx_ZoeSkin09_ZoeQMissile_OnMissileLaunch"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Zoe/Animations/Skin9"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Zoe/Skins/Skin09/Zoe_Skin09.skl"
            SimpleSkin: string = "ASSETS/Characters/Zoe/Skins/Skin09/Zoe_Skin09.skn"
            Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_TX_CM.dds"
            SelfIllumination: f32 = 0.699999988
            Material: link = "Characters/Zoe/Skins/Skin12/Materials/Zoe_Skin_inst"
            BoundingSphereRadius: option[f32] = {
                220
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Zoe_Base_Yoyo_Mat Zoe_Base_Headphones_Mat Zoe_Base_Jumprope_Mat Zoe_Base_TennisRac_Mat Zoe_Base_IceCream_Mat Recall_Mat Familiar_Mat"
            SubmeshRenderOrder: string = "Zoe_Base_Mat Recall_Mat Hair_VFX_Mat"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zoe/Skins/Skin12/Materials/HairMaterial_01"
                    Submesh: string = "Zoe_Base_Hair_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xdaf3281e
                    Submesh: string = "Zoe_Base_Jumprope_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xd6d97fee
                    Submesh: string = "Zoe_Base_Yoyo_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zoe/Skins/Skin12/Materials/Zoe_Crystal_Hair_inst"
                    Submesh: string = "Hair_VFX_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_Recall_TX_CM.dds"
                    Submesh: string = "Recall_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Zoe/Skins/Skin12/Materials/Zoe_Familiar_inst"
                    Submesh: string = "Familiar_Mat"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x093d460a
                    mEndingJointName: hash = 0x7c374505
                    mMaxBoneAngle: f32 = 90
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xf63fc669
                    mEndingJointName: hash = 0x351ff327
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x8438572e
                    mEndingJointName: hash = 0xb693d2da
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x7b360a6c
                    mEndingJointName: hash = 0x478d7c5b
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x0b2e9e57
                    mEndingJointName: hash = 0xbe84d85e
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x0e30e1a7
                    mEndingJointName: hash = 0xef176ed5
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x0f3daf2d
                    mEndingJointName: hash = 0xb05769f0
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x7733c589
                    mEndingJointName: hash = 0xe8ef0e34
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x60ca72e5
                    mEndingJointName: hash = 0xad49d69b
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x7424b646
                    mEndingJointName: hash = 0xddce34a2
                    mMaxBoneAngle: f32 = 100
                    mVelMultiplier: f32 = 0
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Zoe_Idle_Hair_Sparkles_head"
                BoneName: string = "C_Hair1"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Zoe_Idle_Hair_sparkles"
                BoneName: string = "C_Hair3"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = 0xfaf1b739
                BoneName: string = "C_Hair5"
            }
        }
        ExtraCharacterPreloads: list[string] = {
            "ZoeOrbs"
        }
        IconAvatar: string = "ASSETS/Characters/Zoe/HUD/Zoe_Circle_9.dds"
        mContextualActionData: link = "Characters/Zoe/CAC/Zoe_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Zoe/HUD/Zoe_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Zoe/HUD/Zoe_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = 0xa58e58af
            }
        }
        mResourceResolver: link = "Characters/Zoe/Skins/Skin12/Resources"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles_head" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Star_Glow_add1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 10, 1, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.220004573 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.100000001
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.549019635, 0.752941191, 1, 0 }
                            { 0.701960802, 0.580392182, 1, 0.220004573 }
                            { 0.325490206, 0, 0.407843143, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 10
                    DeltaIn: f32 = 10
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 90, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 1, 0 }
                            { 1.5, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Glow.DDS"
            }
        }
        ParticleName: string = "Zoe_Skin12_Idle_Hair_sparkles_head"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles_head"
        Flags: u16 = 198
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                            Frequency: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            VelocityDelta: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "downspores1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -40, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -40, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -5, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 23, 0, 23 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0862745121, 0.0470588244, 0.117647059, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.850980401, 0.745098054, 0.427450985, 0.43921569 }
                            { 0.635294139, 0.262745112, 0.262745112, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                DepthBiasFactors: vec2 = { -1, -5 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 10, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 12, 12 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 12, 12 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Star_Glow_add"
                Importance: u8 = 3
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -5, 1, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.619607866, 0.145098045, 0.701960802, 0 }
                            { 0.333333343, 0.690196097, 1, 0.800000012 }
                            { 0.282352954, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 10
                    DeltaIn: f32 = 10
                }
                DepthBiasFactors: vec2 = { -1, -6 }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 70, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 1, 0 }
                            { 1, 1, 1 }
                            { 1.5, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Emote_portal_tex.dds"
                    TexDivMult: vec2 = { 0.5, 0.5 }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                            Frequency: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            VelocityDelta: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "downspores2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -40, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -40, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -5, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 23, 0, 23 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.768627465, 0.941176474, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.850980401, 0.745098054, 0.427450985, 0.43921569 }
                            { 0.635294139, 0.262745112, 0.262745112, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                DepthBiasFactors: vec2 = { -1, -5 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 10, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 12, 12 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 12, 12 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Zoe_Skin12_Idle_Hair_sparkles"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles"
        Flags: u16 = 198
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles_tip" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 35
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                            Frequency: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            VelocityDelta: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "downspores1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -5, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 23, 0, 23 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.733333349, 0.709803939, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { -1, -5 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 10, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 12, 12 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 12, 12 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Star_Glow_add1"
                Importance: u8 = 3
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -5, 1, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.466666669, 0.258823544, 0.701960802, 0 }
                            { 0.674509823, 0.788235307, 1, 1 }
                            { 0.282352954, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 10
                    DeltaIn: f32 = 10
                }
                DepthBiasFactors: vec2 = { -1, -6 }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 70, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.300000012, 1, 0 }
                            { 1, 1, 1 }
                            { 1.5, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Emote_portal_tex.dds"
                    TexDivMult: vec2 = { 0.5, 0.5 }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 35
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                            Frequency: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            VelocityDelta: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "downspores2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -5, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 23, 0, 23 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0705882385, 0.0392156877, 0.0823529437, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.850980401, 0.850980401, 0.850980401, 0.43921569 }
                            { 0.635294139, 0.635294139, 0.635294139, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { -1, -5 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 10, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 12, 12 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 12, 12 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 35
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 1000
                            }
                            Frequency: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            VelocityDelta: embed = ValueFloat {
                                ConstantValue: f32 = 10
                            }
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "downspores3"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -5, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 23, 0, 23 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0666666701, 0.0352941193, 0.0784313753, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.941176474 }
                            { 0.635294139, 0.635294139, 0.635294139, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaRef: u8 = 0
                DepthBiasFactors: vec2 = { -1, -5 }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 10, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 8, 12, 12 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 8, 12, 12 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.25, 0.25, 0.25 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Zoe_Skin12_Idle_Hair_sparkles_tip"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles_tip"
        Flags: u16 = 198
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_1" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ConfusedLines"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Pass: i16 = 12
                DepthBiasFactors: vec2 = { -1, -14 }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 60, 60 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Z_Familiar_Face_01.dds"
            }
        }
        ParticleName: string = "Zoe_Skin12_Yoyo_Familiar_Child_1"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_1"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_3" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ConfusedLines"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Pass: i16 = 12
                DepthBiasFactors: vec2 = { -1, -14 }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 60, 60 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Z_Familiar_Face_03.dds"
            }
        }
        ParticleName: string = "Zoe_Skin12_Yoyo_Familiar_Child_3"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_3"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_2" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ConfusedLines"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Pass: i16 = 12
                DepthBiasFactors: vec2 = { -1, -14 }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 60, 60 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Z_Familiar_Face_02.dds"
            }
        }
        ParticleName: string = "Zoe_Skin12_Yoyo_Familiar_Child_2"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_2"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_4" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ConfusedLines"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Pass: i16 = 12
                DepthBiasFactors: vec2 = { -1, -14 }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 60, 60 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Z_Familiar_Face_04.dds"
            }
        }
        ParticleName: string = "Zoe_Skin12_Yoyo_Familiar_Child_4"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_4"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis_cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cas_flash1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.172549024, 0.141176477, 0.498039216, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.172549024, 0.141176477, 0.498039216, 1 }
                            { 0.172549024, 0.115709342, 0.193356395, 1 }
                        }
                    }
                }
                Pass: i16 = -1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 110, 100, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0.5, 0.5, 1 }
                            { 0, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Glow.DDS"
            }
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cas_flash2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.90196079, 0.725490212, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.90196079, 0.725490212, 1 }
                            { 0.619607866, 0.484582841, 0.517800868, 1 }
                            { 0.184313729, 0.205151871, 0.460899651, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 110, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.5, 0.5, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Glow.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ears"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Ears.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.730006874, 0.730006874, 0.730006874, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.200000003
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 0.200000003, 1.5 }
                            { 0.600000024, 2, 0.600000024 }
                            { 0.200000003, 1.5, 0.200000003 }
                            { 1, 1, 1 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1, 2, 1 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "EyeMeshGlow"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Head.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.200000003
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 0.200000003, 1.5 }
                            { 0.600000024, 2, 0.600000024 }
                            { 0.200000003, 1.5, 0.200000003 }
                            { 1, 1, 1 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1, 2, 1 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Additive.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Head"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Head.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.730006874, 0.730006874, 0.730006874, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0.200000003, 2 }
                            { 0.600000024, 2, 0.600000024 }
                            { 0.200000003, 1.5, 0.200000003 }
                            { 1, 1, 1 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1, 2, 1 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Head1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Head.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MeshRenderFlags: u8 = 0
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.150000006
                    FresnelColor: vec4 = { 1, 0.34117648, 0.968627453, 0 }
                }
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0.200000003, 2 }
                            { 0.600000024, 2, 0.600000024 }
                            { 0.200000003, 1.5, 0.200000003 }
                            { 1, 1, 1 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1, 2, 1 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ears1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Ears.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MeshRenderFlags: u8 = 0
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.150000006
                    FresnelColor: vec4 = { 1, 0.34117648, 0.968627453, 0 }
                }
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0.200000003, 2 }
                            { 0.600000024, 2, 0.600000024 }
                            { 0.200000003, 1.5, 0.200000003 }
                            { 1, 1, 1 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1, 2, 1 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cas_flash3"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1000, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.300007641 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.160784319, 0.960784316, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.160784319, 0.960784316, 1 }
                            { 0.619607866, 0.0863821581, 0.685736239, 1 }
                            { 0.184313729, 0.036570549, 0.61038065, 0 }
                        }
                    }
                }
                Pass: i16 = 99
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.5, 0.5, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Glow.DDS"
            }
        }
        VisibilityRadius: f32 = 550
        ParticleName: string = "Zoe_Skin12_E_mis_cas"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis_cas"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis_child" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "MainMesh"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.skl"
                        mAnimationName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.anm"
                    }
                }
                BlendMode: u8 = 1
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.5, 2.5, 2.5 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bright_glow"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 4, 0 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1750, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -600, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -600, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.300000012
                            0.5
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0, 30, 0 }
                            { 0, 0, 0 }
                            { 0, 15, 0 }
                            { 0, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0117647061, 0.274509817, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0117647061, 0.263531089, 0.62999922, 0 }
                            { 0.00392156886, 0, 1, 1 }
                            { 0.00350634381, 0, 0.713725507, 0 }
                        }
                    }
                }
                Pass: i16 = -100
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 50, 2 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.400000006
                            0.699999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1.60000002, 0.200000003, 1.60000002 }
                            { 1, 1, 1 }
                            { 1.29999995, 0.800000012, 1.29999995 }
                            { 0.800000012, 1.10000002, 0.800000012 }
                            { 1, 1, 1 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "YellowLight"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 4, 0 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1600, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -600, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -600, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.509803951, 0.0823529437, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.713725507, 0.713725507, 0.713725507, 1 }
                        }
                    }
                }
                Pass: i16 = 5
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 100, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0.400000006, 2, 2 }
                            { 0.25, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_flash_01.dds"
            }
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "dark_background"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 4, 0 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1800, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -600, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -600, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.80392158, 0.0823529437, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.956862748, 0.627451003, 1 }
                            { 0.411764711, 0.101960786, 0.635294139, 1 }
                        }
                    }
                }
                Pass: i16 = -1
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 80, 2.20000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.600000024
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 0.200000003, 1.5 }
                            { 0.600000024, 2, 0.600000024 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1, 2, 1 }
                            { 0, 0, 0 }
                            { 2, 2, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.899999976
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "leadingedge_Balloon2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 4, 0 }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1750, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -600, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -600, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0800030529, 0.0800030529, 0.0800030529, 0.37000075 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.956862748, 0.627451003, 1 }
                            { 0.34117648, 0.407843143, 1, 1 }
                            { 0.690196097, 0.635294139, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -100
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 70, 2.20000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.200000003
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.899999976
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 1.5, 0.200000003, 1.5 }
                            { 0.600000024, 2, 0.600000024 }
                            { 0.200000003, 1.5, 0.200000003 }
                            { 1, 1, 1 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1.20000005, 0.600000024, 1.20000005 }
                            { 1.10000002, 0.800000012, 1.10000002 }
                            { 1, 2, 1 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                            { 0.600000024, 0.600000024, 0.600000024 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.699999988
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "stars_POOF"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 500, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Radius: f32 = 20
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.141176477, 0.00784313772, 0.254901975, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0235294122, 0.0980392173, 0.274509817, 0 }
                            { 0.423529416, 0.101960786, 0.478431374, 0.933333337 }
                            { 0.321568638, 0.0941176489, 1, 1 }
                            { 0.129411995, 0, 0.196078002, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ColorLookUpScales: vec2 = { 0.699999988, 1 }
                ColorLookUpOffsets: vec2 = { 0.300000012, 1 }
                MiscRenderFlags: u8 = 1
                StencilRef: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 20, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 20, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 2, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Eye_ADD"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.skl"
                        mAnimationName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.anm"
                    }
                }
                BlendMode: u8 = 4
                Pass: i16 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.5, 2.5, 2.5 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Additive.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "FakeFresnel"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 14, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.skl"
                        mAnimationName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Animated.anm"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.941176474, 0.117647059, 1, 1 }
                }
                Pass: i16 = -1
                MeshRenderFlags: u8 = 0
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.5999999, 2.5, 2.5999999 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Alpha.dds"
            }
        }
        ParticleName: string = "Zoe_Skin12_E_mis_child"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis_child"
        SoundOnCreateDefault: string = "Play_sfx_ZoeSkin09_ZoeEB_bounce"
        Flags: u16 = 197
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Emote_Yoyo_Familiar_1" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Zoe_Skin09_Yoyo_Familiar_Child_1"
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = "Zoe_Skin09_Yoyo_Familiar_Child_2"
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = "Zoe_Skin09_Yoyo_Familiar_Child_3"
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = "Zoe_Skin09_Yoyo_Familiar_Child_4"
                        }
                    }
                    ChildrenProbability: embed = ValueFloat {
                        ConstantValue: f32 = 1
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        5
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                1
                            }
                        }
                    }
                }
                EmitterName: string = "ConfusedLines"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0 }
                }
                Pass: i16 = 12
                DepthBiasFactors: vec2 = { -1, -40 }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 60, 60 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Z_Familiar_Face_01.dds"
            }
        }
        ParticleName: string = "Zoe_Skin12_Emote_Yoyo_Familiar_1"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Emote_Yoyo_Familiar_1"
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Q2_cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "mesh_swipe"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_cas_mesh.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.866666675, 0.380392164, 1, 1 }
                            { 0.400000006, 0.0980392173, 1, 1 }
                            { 0.411764711, 0.101960786, 0.635294139, 1 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0.800000012, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_cas_paddle.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -3 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.5 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.720000029
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Zoe_W_Child_Star"
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "C_tennisrac2"
                    }
                }
                EmitterName: string = "Anim_Paddle1"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 8 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Familiar_Paddle_Animation.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Familiar_Paddle_Animation.skl"
                        mAnimationName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Familiar_Paddle_Animation.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.75
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.435294122, 0.435294122, 0.435294122, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 5
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    0.5
                }
                IsSingleParticle: flag = true
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "Bokeh_Dots"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 55, 300, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 55, 300, 50 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.800000012
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Bokeh_Color.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.200000018 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.200000018 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.568627, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0.568627, 0 }
                            { 1, 0, 0.568627, 1 }
                            { 1, 0, 0.568627, 0 }
                        }
                    }
                }
                Pass: i16 = 15
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 6, 6 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 6, 6 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Bokeh_Dots_4x4.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BrightSpark"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.699999988
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.5
                            0.699999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0, 0, 0 }
                            { 0, 0, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                                0.899999976
                                1
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                                { 0, 0, 0 }
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            0
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                        { 0, 0, 1.00000012 }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/DefaultColorOverlifetime.dds"
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.400000006
                            0.5
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.537254989, 0.0901959985, 0.796078026, 1 }
                            { 0.0745100006, 0.113724999, 0.796078026, 1 }
                            { 0.0941179991, 0.745097995, 0.925490022, 1 }
                            { 0.066666998, 0.925490022, 0.784313977, 1 }
                            { 1, 0.878431022, 0.25097999, 1 }
                            { 0.992156982, 0, 0.298038989, 1 }
                        }
                    }
                }
                Pass: i16 = 51
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 50, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 50, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.150000006, 0.100000001 }
                            { 1.29999995, 1.29999995, 1.5 }
                            { 0.5, 0.5, 0.200000003 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Sparkles02.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 3
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    0.899999976
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Constil_ring"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.839993894, 0, 1, 0.7400015 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 60, 40 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0450000018
                            0.0949999988
                            0.125
                            0.5
                            0.850000024
                            0.930000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0.5, 0 }
                            { 0.550000012, 0.5, 0.550000012 }
                            { 0.474999994, 0.5, 0.474999994 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.600000024, 0.5, 0.600000024 }
                            { 0, 0.5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_R_Circle.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    0.899999976
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Constil_ring1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349996179, 0.409994662, 1, 0.409994662 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 60, 40 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0450000018
                            0.0949999988
                            0.125
                            0.5
                            0.850000024
                            0.930000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0.5, 0 }
                            { 0.550000012, 0.5, 0.550000012 }
                            { 0.474999994, 0.5, 0.474999994 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.600000024, 0.5, 0.600000024 }
                            { 0, 0.5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_R_Circle_Blur.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Distort_PINCH"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Distortion_Map.dds"
                BlendMode: u8 = 1
                Pass: i16 = 2
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeY: u8 = 3
                ColorLookUpOffsets: vec2 = { 0.300000012, 0 }
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.00499999989
                    DistortionMode: u8 = 3
                    NormalMapTexture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Distortion.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 400, 400 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.349999994, 0.349999994, 0.349999994 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Aura_Self.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "MESH_darkbottom"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_R_portal_mesh_topring.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.209994659, 0.0899977088, 0.459998488, 0.439993888 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.209994659, 0.0899977088, 0.459998488, 0 }
                            { 0.209994659, 0.0899977088, 0.459998488, 0.439993888 }
                            { 0.209994659, 0.0899977088, 0.459998488, 0.439993888 }
                            { 0.209994659, 0.0899977088, 0.459998488, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                IsUniformScale: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/DefaultColorOverlifetime.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                IsSingleParticle: flag = true
                EmitterName: string = "vortex_cap"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_vortex_cap.scb"
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0 }
                }
                Pass: i16 = -10
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 1
                StencilRef: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.349999994, 1.39999998, 1.39999998 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0450000018
                            0.0949999988
                            0.125
                            0.5
                            0.850000024
                            0.930000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0.5, 0 }
                            { 0.550000012, 0.5, 0.550000012 }
                            { 0.474999994, 0.5, 0.474999994 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.600000024, 0.5, 0.600000024 }
                            { 0, 0.5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Emote_portal_cover_BLACK.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                IsSingleParticle: flag = true
                EmitterName: string = "vortex_lines"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_R_portal_mesh_exit.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.345098048, 0.286274523, 0.443137258, 0.721568644 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.772549033, 0.772549033, 0.772549033, 0 }
                            { 0.509803951, 0.509803951, 0.509803951, 1 }
                            { 1, 1, 1, 1 }
                            { 0.729411781, 0.729411781, 0.729411781, 1 }
                            { 0.137254909, 0.137254909, 0.137254909, 0 }
                        }
                    }
                }
                Pass: i16 = -8
                MiscRenderFlags: u8 = 1
                StencilMode: u8 = 2
                StencilRef: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.899999976, 0.5, 0.899999976 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0450000018
                            0.0949999988
                            0.125
                            0.5
                            0.850000024
                            0.930000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0.5, 0 }
                            { 0.550000012, 0.5, 0.550000012 }
                            { 0.474999994, 0.5, 0.474999994 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.5, 0.5, 0.5 }
                            { 0.600000024, 0.5, 0.600000024 }
                            { 0, 0.5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Checkers.dds"
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 1, -3 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec2] = {
                            { 0.300000012, 3 }
                            { 0, -0 }
                            { -0.300000012, -3 }
                        }
                    }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 1 }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 45
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Zoe_W_Child_Star"
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "C_tennisrac2"
                    }
                }
                EmitterName: string = "Anim_Paddle_FlashFrame"
                Importance: u8 = 2
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 8 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Familiar_Paddle_Animation.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Familiar_Paddle_Animation.skl"
                        mAnimationName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Q_Familiar_Paddle_Animation.anm"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.819607854, 0.686274529, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.819607854, 0.686274529, 1, 1 }
                            { 0.819607854, 0.686274529, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.5
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 150
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/CloudyTile01.dds"
            }
        }
        VisibilityRadius: f32 = 500
        ParticleName: string = "Zoe_Skin12_Q2_cas"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Q2_cas"
        Flags: u16 = 205
    }
    "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "TRAIL"
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 10 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 2000, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.552941203, 0.0431372561, 1, 0.741176486 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec4] = {
                            { 0.552941203, 0.0431372561, 1, 0 }
                            { 0.552941203, 0.0431372561, 1, 0.741176486 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.250003815, 0, 0.37000075, 0 }
                            { 0.411764711, 0.101960786, 0.635294139, 1 }
                            { 0.669993162, 0.669993162, 1, 0.710002303 }
                            { 0.349019617, 0.41568628, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 100, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.400000006, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Temp_Pv3_Warwick_Skin09_E_ScentMult.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "leadingedge_Balloon"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.689997733 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.850980401, 0.592156887, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.850980401, 0.592156887, 1, 1 }
                            { 0.4104729, 0.297239512, 0.666666687, 1 }
                            { 0.570151031, 0.4441154, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 2 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_cas_paddle.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.60000002
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cas_flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.333333343, 0.376470596, 1, 0.65882355 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333333343, 0.360230684, 0.627451003, 0.65882355 }
                            { 0.20653595, 0.202260673, 0.713725507, 0.65882355 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0.600000024, 0, 0 }
                            { 1, 1, 1 }
                            { 2, 2, 2 }
                            { 0, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_flash_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cas_flash1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.592156887, 0.0941176489, 1, 0.490196079 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.592156887, 0.0941176489, 1, 0.490196079 }
                            { 0.366905034, 0.0505651683, 0.713725507, 0.490196079 }
                            { 0.376193762, 0.0151326414, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 250, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            0.949999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.5, 0.5, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "TRAIL1"
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 20, 10 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 2000, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.23137255, 0.0666666701, 0.298039228, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                        }
                        Values: list[vec4] = {
                            { 0.23137255, 0.0666666701, 0.298039228, 1 }
                            { 0.23137255, 0.0666666701, 0.298039228, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.250003815, 0, 0.37000075, 0 }
                            { 0.411764711, 0.101960786, 0.635294139, 1 }
                            { 0.669993162, 0.669993162, 1, 0.710002303 }
                            { 0.349019617, 0.41568628, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 0, 0 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_SmallStarTrail.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "leadingedge_Balloon1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.540001512 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.623529434, 0.192156866, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.980000019
                            1
                        }
                        Values: list[vec4] = {
                            { 0.623529434, 0.192156866, 1, 1 }
                            { 0.623529434, 0.192156866, 1, 1 }
                            { 0.623529434, 0.192156866, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 100
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 125, 1.70000005 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.200000003
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.29999995, 0.800000012 }
                            { 1, 1.20000005, 0.899999976 }
                            { 1.20000005, 1, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_mis_circle.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Head"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Head.scb"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.733333349, 0.733333349, 0.733333349, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Tentacles"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -10, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Tentacles.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1.20000005, 0 }
                            { 1.5, 0.800000012, 1.5 }
                            { 0.699999988, 1.20000005, 0.699999988 }
                            { 1.5, 0.800000012, 1.5 }
                            { 0.699999988, 1.20000005, 0.699999988 }
                            { 1.5, 0.800000012, 1.5 }
                            { 0.699999988, 1.20000005, 0.699999988 }
                            { 1.5, 0.800000012, 1.5 }
                            { 0.699999988, 1.20000005, 0.699999988 }
                            { 1.5, 0.800000012, 1.5 }
                            { 0.699999988, 1.20000005, 0.699999988 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "EyeMeshGlow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Head.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Additive.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ears"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Ears.scb"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.733333349, 0.733333349, 0.733333349, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dress_Front"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Dress_Front.scb"
                    }
                }
                BlendMode: u8 = 3
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 7
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1.20000005, 1.20000005 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1.20000005, 0 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dress_Back"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Dress_Back.scb"
                    }
                }
                BlendMode: u8 = 3
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1.20000005, 1.20000005 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1.20000005, 0 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                            { 1.20000005, 0.959999979, 1.20000005 }
                            { 1.08000004, 1.20000005, 1.08000004 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_Familiar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "TRAIL2"
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 25, 10, 33 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 500, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.823529422, 0.172549024, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 0.90196079, 0.701960802, 1 }
                            { 1, 0.501960814, 0.145098045, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 0, 0 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_SmallStarTrail.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "EyeGlow"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 25, 0, 33 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.669993162, 0.110002287, 0.710002303 }
                }
                Pass: i16 = 330
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 0, 0 }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_ImpactGlow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ears1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 4, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Ears.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.20784314, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3.0999999, 3, 3.0999999 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/DefaultColorOverlifetime.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Head1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 4, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_E_Familiar_Projectile_Head.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.886274517, 0, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 5
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3.0999999, 3, 3.0999999 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                            0.600000024
                            0.699999988
                            0.800000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                            { 1, 0.800000012, 1 }
                            { 0.899999976, 1, 0.899999976 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/DefaultColorOverlifetime.dds"
            }
        }
        VisibilityRadius: f32 = 550
        ParticleName: string = "Zoe_Skin12_E_mis"
        ParticlePath: string = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis"
    }
    "Characters/Zoe/Skins/Skin12/Materials/Zoe_Crystal_Hair_inst" = StaticMaterialDef {
        Name: string = "Characters/Zoe/Skins/Skin12/Materials/Zoe_Crystal_Hair_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_TailMask.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_FresnelGradient_1.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_Hair_VFX_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "ScreenSpace_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Bokeh_Color.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "ScreenSpace_Lines_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Emote_portal_tex.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Twinkles_Mask"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_beam_01.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Twinkly_Gradient"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_SS_Boxes_Gradient.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "MainColor"
                Value: vec4 = { 0, 0.0588235296, 0.13333334, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ColorIntensity"
                Value: vec4 = { 1.93499994, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 2, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "RainbowIntensity"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Parallax_Tiling"
                Value: vec4 = { 4, 2, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_ScrollSpeed"
                Value: vec4 = { 1.25, 0.25, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Lines_Tiling"
                Value: vec4 = { 33, 20, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_Boxes_Sin_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Lines_Intensity"
                Value: vec4 = { 5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Lines_Color"
                Value: vec4 = { 0.0117647061, 0.70588237, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_Blend_Multiplier"
                Value: vec4 = { 0.605000019, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "GradientFresnel_Intensity"
                Value: vec4 = { 3.25, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Bias"
                Value: vec4 = { 0.0900000036, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveMask_Value"
                Value: vec4 = { 0.0350000001, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveMaskColor"
                Value: vec4 = { 1, 0, 0.984313726, 1 }
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Ahri_Popstar_Crystal_Twinkly"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {}
    }
    "Characters/Zoe/Skins/Skin12/Materials/Zoe_Familiar_inst" = StaticMaterialDef {
        Name: string = "Characters/Zoe/Skins/Skin12/Materials/Zoe_Familiar_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_Familiar_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "SS_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_beam_01.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask1"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Familiar_Material_Mask_1.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask2"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Familiar_Material_Mask_2.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "SS_Scale"
                Value: vec4 = { 5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_rate"
                Value: vec4 = { -0.0299999993, 0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Color"
                Value: vec4 = { 1, 0.0941176489, 0.909803927, 0.729411781 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Blue_Scale"
                Value: vec4 = { 6, 6, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Blue_Rate"
                Value: vec4 = { 0.354999989, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomIntensity"
                Value: vec4 = { 2.8499999, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 1.20000005, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dodge_Bias"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Darkstar"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {}
    }
    "Characters/Zoe/Skins/Skin12/Materials/Zoe_Skin_inst" = StaticMaterialDef {
        Name: string = "Characters/Zoe/Skins/Skin12/Materials/Zoe_Skin_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "SS_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_beam_01.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask1"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Material_Mask_1.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask2"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Particles/Zoe_Skin09_Material_Mask_2.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "SS_Scale"
                Value: vec4 = { 10, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_rate"
                Value: vec4 = { -0.0299999993, 0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Color"
                Value: vec4 = { 0.145098045, 0.0745098069, 0.180392161, 0.729411781 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Blue_Scale"
                Value: vec4 = { 10, 10, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Blue_Rate"
                Value: vec4 = { 0.354999989, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomIntensity"
                Value: vec4 = { 2.8499999, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 0.800000012, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dodge_Bias"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Darkstar"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {}
    }
    "Characters/Zoe/Skins/Skin12/Materials/HairMaterial_01" = StaticMaterialDef {
        Name: string = "Characters/Zoe/Skins/Skin12/Materials/HairMaterial_01"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_Hair_TX_CM.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "ScreenSpace_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Hair_nightsky.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin09/Zoe_Skin09_hair_material.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Characters/Zoe/Skins/Skin12/Zoe_Skin12_Mat_fresnel.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "SS_Scale"
                Value: vec4 = { 11, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_ScrollSpeed"
                Value: vec4 = { 0, 0.100000001, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SS_Blend_Multiplier"
                Value: vec4 = { 1.75999999, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 64, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Bias"
                Value: vec4 = { -0.294999987, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/MaskedGradientFresnel_ScreenSpaceBlend"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
    "Characters/Zoe/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x316bd310 = 0x21c99e34
            "Zoe_BA_mis" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_BA_mis"
            "Zoe_BA_tar" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_BA_tar"
            "Zoe_P_buf" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_P_buf"
            "Zoe_Q_mis_02" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Q2_mis"
            "Zoe_Q2_mis_warning" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Q2_mis_warning"
            "Zoe_Q2_mis_warning_self" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Q2_mis_warning_self"
            "Zoe_Q_mis_01" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Q_mis_01"
            0x7b67335d = 0x00f69ad8
            "Zoe_Taunt" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Taunt"
            "Zoe_W_pickup" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_pickup"
            0x5754f3f2 = 0x249edccb
            "Zoe_E_AoE" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_AoE"
            "Zoe_E_Ring" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_Ring"
            "Zoe_E_Ring_Enemy" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_Ring_Enemy"
            "Zoe_Q_Tar" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Q_Tar"
            "Zoe_R_portal_entrance" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_R_portal_entrance"
            0x77e7b73a = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Barrier"
            0xac7f794e = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Cleanse"
            0x65f289f6 = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Ignite"
            0xda78681b = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Exhaust"
            0xa658a3e3 = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Flash"
            0x7265c64e = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Ghost"
            0x17b5de49 = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Heal"
            0x773822f5 = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Smite"
            0xb91991d4 = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Teleport"
            "Zoe_E_land" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_land"
            "Zoe_W_P_cas" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_P_cas"
            "Zoe_Base_W_P_buf" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_P_buf"
            "Zoe_R_portal_exit" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_R_portal_exit"
            0x0ab51601 = 0x91f3d6fa
            0x4a466ac7 = 0x59e1342c
            0x32615fe1 = 0x7cb4dd5c
            "Zoe_E_mis" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis"
            "Zoe_Base_W_P_Minion" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_P_Minion"
            0x6859baa7 = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_minion_balloonstring"
            0x4b331ad7 = 0x5d8c0f29
            "Zoe_E_mis_child" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis_child"
            "Zoe_Q_Mis_Linger" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Q_Mis_Linger"
            "Zoe_W_P_Mis" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_P_Mis"
            "Zoe_W_Child_Star" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_Child_Star"
            "Zoe_W_P_buf_child_1" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_P_buf_child_1"
            "Zoe_W_P_buf_child_2" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_P_buf_child_2"
            "Zoe_W_P_buf_child_3" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_P_buf_child_3"
            "Zoe_E_Tar" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_Tar"
            "Zoe_E_mis_cas" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_E_mis_cas"
            0x60a9fdd6 = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Q2_cas"
            "Zoe_Idle_Hair_sparkles" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles"
            "Zoe_W_P_minion_balloon" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_minion_balloon"
            "Zoe_W_PickUp_TEMPLATE" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_PickUp_TEMPLATE"
            "Zoe_W_SS_IronStylus" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_IronStylus"
            "Zoe_W_SS_ItemRedemption" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_ItemRedemption"
            "Zoe_W_SS_ItemSoFBoltSpellBase" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_ItemSoFBoltSpellBase"
            "Zoe_W_SS_S5_SummonerSmitePlayerGanker" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_S5_SummonerSmitePlayerGanker"
            "Zoe_W_SS_ShurelyasCrest" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_ShurelyasCrest"
            "Zoe_W_SS_YoumusBlade" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_YoumusBlade"
            "Zoe_W_SS_ZhonyasHourglass" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_ZhonyasHourglass"
            "Zoe_Q_Cas" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Q_Cas"
            "Zoe_Q_Mis_01_end_child" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Q_Mis_01_end_child"
            "Zoe_Emote_SkippingRope" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_SkippingRope"
            "Zoe_Emote_SkippingRope_sparkles" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_SkippingRope_sparkles"
            "Zoe_Emote_SkippingRope_trail" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_SkippingRope_trail"
            "Zoe_Emote_Yoyo_idle1" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Yoyo_idle1"
            "Zoe_Emote_Yoyo_string_stars" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Yoyo_string_stars"
            "Zoe_Emote_Yoyo_string_spin" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Yoyo_string_spin"
            "Zoe_Emote_Yoyo" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Yoyo"
            "Zoe_E_Aoe_Child_sparkles" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_Aoe_Child_sparkles"
            "Zoe_Emote_Jumprope_star" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Jumprope_star"
            "Zoe_Emote_jumprope_connector" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_jumprope_connector"
            "Zoe_Emote_Jumprope_star_long" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Jumprope_star_long"
            "Zoe_Emote_jumprope_connector_long" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_jumprope_connector_long"
            "Zoe_Emote_SkippingRope_trail_long" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_SkippingRope_trail_long"
            "Zoe_Emote_SkippingRope_sparkles_long" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_SkippingRope_sparkles_long"
            "Zoe_W_tar" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_W_tar"
            "Zoe_Emote_Yoyo_string_spin_long" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Yoyo_string_spin_long"
            "Zoe_Emote_Yoyo_avatar_long" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Yoyo_avatar_long"
            "Zoe_Emote_Yoyo_string_stars_long" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Yoyo_string_stars_long"
            "Zoe_Emote_string_stars_rev" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_string_stars_rev"
            "Zoe_Emote_Jumprope_star_intro" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Jumprope_star_intro"
            "Zoe_Emote_jumprope_connector_intro" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_jumprope_connector_intro"
            0x78672ea4 = 0x7da15574
            "Zoe_Q_Cas_Paddle" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Q_Cas_Paddle"
            "Zoe_Q_Cas_child_paddlesparkle" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Q_Cas_child_paddlesparkle"
            "Zoe_E_child_timer" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_E_child_timer"
            "Zoe_R_Body_Avatar" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_R_Body_Avatar"
            "Zoe_R_Enter_Sparkles_Child" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_R_Enter_Sparkles_Child"
            "Zoe_Emote_Recall_Gum_toss" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Recall_Gum_toss"
            "Zoe_Emote_Recall_Gum_bubble" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Recall_Gum_bubble"
            "Zoe_Emote_Recall_gum_child" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Recall_gum_child"
            "Zoe_Emote_Recall_Gum_bubble_child" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Recall_Gum_bubble_child"
            "Zoe_Emote_Recall_Portal" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Recall_Portal"
            0xe09b1651 = 0x0dab57c0
            0xfaf1b739 = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles_tip"
            "Zoe_Idle_Hair_Sparkles_head" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Idle_Hair_sparkles_head"
            "Zoe_Emote_Death" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Death"
            "Zoe_Emote_Death_bodyglow" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Death_bodyglow"
            "Zoe_E_Cas" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_Cas"
            "Zoe_E_Mis_direct_hit" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_E_Mis_direct_hit"
            "Zoe_Emote_Recall_Portal_Winddown" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_Emote_Recall_Portal_Winddown"
            "Zoe_W_SS_SummonerMana" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_SummonerMana"
            "Zoe_W_SS_RanduinsOmen" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_RanduinsOmen"
            "Zoe_W_SS_ItemRighteousGlory" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_ItemRighteousGlory"
            "Zoe_W_Minion_balloonstring_child" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_Minion_balloonstring_child"
            "Zoe_Emote_Death_Avatar" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_Emote_Death_Avatar"
            "Zoe_BA_tar_crit" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_BA_tar_crit"
            "Zoe_BA_cas_crit" = "Characters/Zoe/Skins/Skin9/Particles/Zoe_Skin09_BA_cas_crit"
            0x47128b4c = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_Predator"
            "Zoe_W_SS_SummonerSnowball" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_SS_SummonerSnowball"
            "Zoe_E_tar_sleep_BREAK" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_E_tar_sleep_BREAK"
            "Zoe_W_OrbLand_Sound" = "Characters/Zoe/Skins/Skin0/Particles/Zoe_Base_W_OrbLand_Sound"
            0xe0482c85 = 0x1c7304f4
            0xff8b518b = 0x716f2c4e
            0xfc883972 = 0xd3071f4f
            0x807ebf70 = 0x7039f4f5
            0x9b417911 = 0xa0d1cb84
            0x5f7cf9fc = 0x38d894c9
            0x0272433b = 0x1976eac6
            0x3b10a702 = 0x3848c59f
            0x566c392a = 0xdb64fa83
            0xdf3f28f8 = 0xdc4c7757
            0x9e819484 = 0xf0f405b5
            0xfeab5703 = 0x7fda587a
            0xca63a451 = 0xcba03130
            0xf9693a68 = 0xd0c082bb
            0x0976ea6b = 0xce0414d2
            0x4f867213 = 0xb491c2ce
            0x14234505 = 0x0068162e
            0xf142a987 = 0x66a6cc06
            0x612c8783 = 0x4a9f3900
            0x4693e5a9 = 0x5474ccaa
            0x6a5be390 = 0xa326e761
            0x1b5b3855 = 0x3fdfff46
            0x0f993af0 = 0x44b1142d
            0x65cc57ed = 0xae62bc7a
            0xa4f9d0cf = 0x3b2fe8cc
            0x630f92a9 = 0x0314fa76
            0x903cddaa = 0xf719b23f
            0x1c84df97 = 0xb1c649ba
            0x653fc56c = 0x3f330575
            0x90a610cc = 0x21811479
            0xe5fd39d3 = 0x181c2daa
            0x232735fd = 0xb7266c5c
            0xd38e9d50 = 0xb77f5309
            0xa8de7392 = 0xec999078
            0x63be95a9 = 0x0122cdd7
            0x60e53c2f = 0xb6feba95
            0xa3f70fec = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Emote_Yoyo_Familiar_1"
            "Zoe_Skin09_Yoyo_Familiar_Child_1" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_1"
            "Zoe_Skin09_Yoyo_Familiar_Child_2" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_2"
            "Zoe_Skin09_Yoyo_Familiar_Child_3" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_3"
            "Zoe_Skin09_Yoyo_Familiar_Child_4" = "Characters/Zoe/Skins/Skin12/Particles/Zoe_Skin12_Yoyo_Familiar_Child_4"
            0x07ff4af6 = 0x589cbac0
            0x1c8e63f3 = 0x359bb7d1
            0xd5cb38b6 = 0x4aea319c
            0xac9bd220 = 0x1a2bc81a
            0xf7533c2e = 0x82926a8c
            0xf6533a9b = 0x85926f45
            0xf5533908 = 0x84926db2
            0xfc53440d = 0x7f9265d3
            0xfb53427a = 0x7e926440
            0xfa5340e7 = 0x819268f9
            0x71b856b0 = 0xa2d39756
            0xfc9c8f6a = 0x2ab31c78
            0x809ba707 = 0xeda86521
            0x3577d4a9 = 0x66c7cdc3
            0xdacb5343 = 0x2d05d8f1
            0x47ba0f95 = 0xc9a59b13
            0xe7fca46d = 0xa8aba1cf
            0xc8c037df = 0x16481019
            0xedfda884 = 0x1e67c5aa
            0x8d46e53f = 0xef073f95
            0x5ae00bc9 = 0x68b26fdf
            0x689c6fe3 = 0xb5c7a9d1
            0x75f59873 = 0x10a490c1
            0x76f59a06 = 0x0da48c08
            0x77f59b99 = 0x0ea48d9b
            0x78f59d2c = 0x13a4957a
            0x7c4182ef = 0x99e53591
            0xff1f10b3 = 0xb8a031c5
            0x4ed2d818 = 0x4514b892
            0x403d4b3a = 0x25f78d6c
            0x7531c3a4 = 0x9d53ba2a
            0x474cee39 = 0x3f13db73
            0x83079dd8 = 0x32ea1ade
            0xbf6736dd = 0x98140b1f
        }
    }
}
