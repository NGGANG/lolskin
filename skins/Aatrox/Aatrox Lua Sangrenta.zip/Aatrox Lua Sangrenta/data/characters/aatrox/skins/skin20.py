#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Aatrox_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Aatrox/Aatrox.bin"
    "DATA/Aatrox_Skins_Skin20_Skins_Skin7_Skins_Skin8.bin"
    "DATA/Characters/Aatrox/Animations/Skin20.bin"
    "DATA/Aatrox_Skins_Skin0_Skins_Skin2_Skins_Skin20_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
    "DATA/Aatrox_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin2_Skins_Skin20_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Aatrox_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin20_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
    "DATA/Aatrox_Skins_Skin0_Skins_Skin2_Skins_Skin20_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
    "DATA/Aatrox_Skins_Skin20_Skins_Skin8.bin"
}
entries: map[hash,embed] = {
"Characters/Aatrox/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "AatroxSkin20"
        MetaDataTags: string = "gender:male,race:darkin,element:dark,skinline:bloodmoon"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Aatrox/Skins/Skin20/AatroxLoadScreen_20.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Aatrox"
                "AatroxSkin07"
                "AatroxSkin08"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Aatrox_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Aatrox/Skins/Base/Aatrox_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Aatrox/Skins/Base/Aatrox_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Aatrox/Skins/Base/Aatrox_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Aatrox_AatroxE_cast3D"
                        "Play_vo_Aatrox_AatroxQ_OnCast"
                        "Play_vo_Aatrox_AatroxR_cast3D"
                        "Play_vo_Aatrox_AatroxRRevive_OnBuffCast"
                        "Play_vo_Aatrox_AatroxW_cast3D"
                        "Play_vo_Aatrox_Attack2DGeneral"
                        "Play_vo_Aatrox_Attack2DPantheon"
                        "Play_vo_Aatrox_Attack2DTryndamere"
                        "Play_vo_Aatrox_Attack2DZoe"
                        "Play_vo_Aatrox_Death3D"
                        "Play_vo_Aatrox_FirstEncounter3DAkali"
                        "Play_vo_Aatrox_FirstEncounter3DAnivia"
                        "Play_vo_Aatrox_FirstEncounter3DCamille"
                        "Play_vo_Aatrox_FirstEncounter3DDarius"
                        "Play_vo_Aatrox_FirstEncounter3DFiora"
                        "Play_vo_Aatrox_FirstEncounter3DGalio"
                        "Play_vo_Aatrox_FirstEncounter3DGangplank"
                        "Play_vo_Aatrox_FirstEncounter3DGaren"
                        "Play_vo_Aatrox_FirstEncounter3DGeneral"
                        "Play_vo_Aatrox_FirstEncounter3DIllaoi"
                        "Play_vo_Aatrox_FirstEncounter3DJax"
                        "Play_vo_Aatrox_FirstEncounter3DKaisa"
                        "Play_vo_Aatrox_FirstEncounter3DKayle"
                        "Play_vo_Aatrox_FirstEncounter3DKayn"
                        "Play_vo_Aatrox_FirstEncounter3DKennen"
                        "Play_vo_Aatrox_FirstEncounter3DKled"
                        "Play_vo_Aatrox_FirstEncounter3DMalphite"
                        "Play_vo_Aatrox_FirstEncounter3DMaokai"
                        "Play_vo_Aatrox_FirstEncounter3DMorgana"
                        "Play_vo_Aatrox_FirstEncounter3DMundo"
                        "Play_vo_Aatrox_FirstEncounter3DNasus"
                        "Play_vo_Aatrox_FirstEncounter3DNautilus"
                        "Play_vo_Aatrox_FirstEncounter3DOrnn"
                        "Play_vo_Aatrox_FirstEncounter3DPantheon"
                        "Play_vo_Aatrox_FirstEncounter3DQuinn"
                        "Play_vo_Aatrox_FirstEncounter3DRenekton"
                        "Play_vo_Aatrox_FirstEncounter3DRiven"
                        "Play_vo_Aatrox_FirstEncounter3DRumble"
                        "Play_vo_Aatrox_FirstEncounter3DShen"
                        "Play_vo_Aatrox_FirstEncounter3DSion"
                        "Play_vo_Aatrox_FirstEncounter3DTargon"
                        "Play_vo_Aatrox_FirstEncounter3DTaric"
                        "Play_vo_Aatrox_FirstEncounter3DTeemo"
                        "Play_vo_Aatrox_FirstEncounter3DTrundle"
                        "Play_vo_Aatrox_FirstEncounter3DTryndamere"
                        "Play_vo_Aatrox_FirstEncounter3DVarus"
                        "Play_vo_Aatrox_FirstEncounter3DVoid"
                        "Play_vo_Aatrox_FirstEncounter3DYorick"
                        "Play_vo_Aatrox_FirstEncounter3DZoe"
                        "Play_vo_Aatrox_Joke3DGeneral"
                        "Play_vo_Aatrox_Kill3DAatrox"
                        "Play_vo_Aatrox_Kill3DAnivia"
                        "Play_vo_Aatrox_Kill3DCamille"
                        "Play_vo_Aatrox_Kill3DDarius"
                        "Play_vo_Aatrox_Kill3DFiora"
                        "Play_vo_Aatrox_Kill3DGangplank"
                        "Play_vo_Aatrox_Kill3DGaren"
                        "Play_vo_Aatrox_Kill3DGeneral"
                        "Play_vo_Aatrox_Kill3DIllaoi"
                        "Play_vo_Aatrox_Kill3DKaisa"
                        "Play_vo_Aatrox_Kill3DKayle"
                        "Play_vo_Aatrox_Kill3DKayn"
                        "Play_vo_Aatrox_Kill3DKled"
                        "Play_vo_Aatrox_Kill3DMalphite"
                        "Play_vo_Aatrox_Kill3DMaokai"
                        "Play_vo_Aatrox_Kill3DMorgana"
                        "Play_vo_Aatrox_Kill3DNasus"
                        "Play_vo_Aatrox_Kill3DNautilus"
                        "Play_vo_Aatrox_Kill3DOrnn"
                        "Play_vo_Aatrox_Kill3DPantheon"
                        "Play_vo_Aatrox_Kill3DRiven"
                        "Play_vo_Aatrox_Kill3DShen"
                        "Play_vo_Aatrox_Kill3DSion"
                        "Play_vo_Aatrox_Kill3DTaric"
                        "Play_vo_Aatrox_Kill3DTeemo"
                        "Play_vo_Aatrox_Kill3DTryndamere"
                        "Play_vo_Aatrox_Kill3DVarus"
                        "Play_vo_Aatrox_Kill3DZoe"
                        "Play_vo_Aatrox_Laugh3DGeneral"
                        "Play_vo_Aatrox_MasteryResponse3DGeneral"
                        "Play_vo_Aatrox_Move2DFirstPantheon"
                        "Play_vo_Aatrox_Move2DLong"
                        "Play_vo_Aatrox_Move2DRReady"
                        "Play_vo_Aatrox_Move2DStandard"
                        "Play_vo_Aatrox_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Aatrox_Skin07_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Aatrox/Skins/Skin07/Aatrox_Skin07_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Aatrox/Skins/Skin07/Aatrox_Skin07_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_AatroxSkin07_AatroxBasicAttack2_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxBasicAttack2_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxBasicAttack3_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxBasicAttack3_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxBasicAttack_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxBasicAttack_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxCritAttack_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxCritAttack_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxE_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxPassiveAttack_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxPassiveAttack_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxPassiveDebuff_OnBuffActivate"
                        "Play_sfx_AatroxSkin07_AatroxPassiveDebuff_OnBuffDeactivate"
                        "Play_sfx_AatroxSkin07_AatroxPassiveReady_OnBuffActivate"
                        "Play_sfx_AatroxSkin07_AatroxQ1_OnCast_all"
                        "Play_sfx_AatroxSkin07_AatroxQ1_OnHit_miss"
                        "Play_sfx_AatroxSkin07_AatroxQ1_OnHit_normal_all"
                        "Play_sfx_AatroxSkin07_AatroxQ1_OnHit_normal_player"
                        "Play_sfx_AatroxSkin07_AatroxQ1_OnHit_sweetspot_all"
                        "Play_sfx_AatroxSkin07_AatroxQ1_OnHit_sweetspot_player"
                        "Play_sfx_AatroxSkin07_AatroxQ2_OnCast_all"
                        "Play_sfx_AatroxSkin07_AatroxQ2_OnHit_miss"
                        "Play_sfx_AatroxSkin07_AatroxQ2_OnHit_normal_all"
                        "Play_sfx_AatroxSkin07_AatroxQ2_OnHit_normal_player"
                        "Play_sfx_AatroxSkin07_AatroxQ2_OnHit_sweetspot_all"
                        "Play_sfx_AatroxSkin07_AatroxQ2_OnHit_sweetspot_player"
                        "Play_sfx_AatroxSkin07_AatroxQ3_OnCast_all"
                        "Play_sfx_AatroxSkin07_AatroxQ3_OnHit_miss"
                        "Play_sfx_AatroxSkin07_AatroxQ3_OnHit_normal_all"
                        "Play_sfx_AatroxSkin07_AatroxQ3_OnHit_normal_player"
                        "Play_sfx_AatroxSkin07_AatroxQ3_OnHit_sweetspot_all"
                        "Play_sfx_AatroxSkin07_AatroxQ3_OnHit_sweetspot_player"
                        "Play_sfx_AatroxSkin07_AatroxR_buffdeactivate"
                        "Play_sfx_AatroxSkin07_AatroxR_OnBuffActivate_all"
                        "Play_sfx_AatroxSkin07_AatroxR_OnBuffActivate_player"
                        "Play_sfx_AatroxSkin07_AatroxRAttack1_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxRAttack1_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxRAttack2_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxRAttack2_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxRRevive_all"
                        "Play_sfx_AatroxSkin07_AatroxRRevive_player"
                        "Play_sfx_AatroxSkin07_AatroxW_OnCast"
                        "Play_sfx_AatroxSkin07_AatroxW_OnHit"
                        "Play_sfx_AatroxSkin07_AatroxW_OnMissileCast"
                        "Play_sfx_AatroxSkin07_AatroxW_OnMissileLaunch"
                        "Play_sfx_AatroxSkin07_AatroxWBump_OnBuffActivate"
                        "Play_sfx_AatroxSkin07_AatroxWChains_OnBuffActivate"
                        "Play_sfx_AatroxSkin07_AatroxWChains_OnBuffDeactivate"
                        "Play_sfx_AatroxSkin07_Dance3D_In_buffactivate"
                        "Play_sfx_AatroxSkin07_Dance3D_loop_buffactivate"
                        "Play_sfx_AatroxSkin07_Death3D_cast"
                        "Play_sfx_AatroxSkin07_Joke3D_buffactivate"
                        "Play_sfx_AatroxSkin07_Recall3D_buffactivate"
                        "Play_sfx_AatroxSkin07_Respawn3D_buffactivate"
                        "Play_sfx_AatroxSkin07_Taunt3D_buffactivate"
                        "Play_sfx_AatroxSkin07_Winddown3D_buffactivate"
                        "Set_Switch_Aatrox_R_Active"
                        "Set_Switch_Aatrox_R_Inactive"
                        "Stop_sfx_AatroxSkin07_AatroxW_OnMissileLaunch"
                        "Stop_sfx_AatroxSkin07_AatroxWBump_OnBuffActivate"
                        "Stop_sfx_AatroxSkin07_AatroxWChains_OnBuffActivate"
                        "Stop_sfx_AatroxSkin07_Dance3D_In_buffactivate"
                        "Stop_sfx_AatroxSkin07_Joke3D_buffactivate"
                        "Stop_sfx_AatroxSkin07_Recall3D_buffactivate"
                        "Stop_sfx_AatroxSkin07_Respawn3D_buffactivate"
                        "Stop_sfx_AatroxSkin07_Taunt3D_buffactivate"
                        "Stop_sfx_AatroxSkin07_Winddown3D_buffactivate"
                        "Switch_Aatrox_Footsteps_Brush"
                        "Switch_Aatrox_Footsteps_Dirt"
                        "Switch_Aatrox_Footsteps_Stone"
                        "Switch_Aatrox_Footsteps_Water"
                    }
                }
                BankUnit {
                    Name: string = "Aatrox_Skin08_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Aatrox/Skins/Skin08/Aatrox_Skin08_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Aatrox/Skins/Skin08/Aatrox_Skin08_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_AatroxSkin08_AatroxQ1_OnCast_all"
                        "Play_sfx_AatroxSkin08_AatroxQ1_OnHit_sweetspot_all"
                        "Play_sfx_AatroxSkin08_AatroxQ1_OnHit_sweetspot_player"
                        "Play_sfx_AatroxSkin08_AatroxQ2_OnCast_all"
                        "Play_sfx_AatroxSkin08_AatroxQ2_OnHit_sweetspot_all"
                        "Play_sfx_AatroxSkin08_AatroxQ2_OnHit_sweetspot_player"
                        "Play_sfx_AatroxSkin08_AatroxQ3_OnCast_all"
                        "Play_sfx_AatroxSkin08_AatroxQ3_OnHit_sweetspot_all"
                        "Play_sfx_AatroxSkin08_AatroxQ3_OnHit_sweetspot_player"
                        "Play_sfx_AatroxSkin08_AatroxR_buffdeactivate"
                        "Play_sfx_AatroxSkin08_AatroxR_OnBuffActivate_all"
                        "Play_sfx_AatroxSkin08_AatroxR_OnBuffActivate_player"
                        "Play_sfx_AatroxSkin08_AatroxRRevive_all"
                        "Play_sfx_AatroxSkin08_AatroxRRevive_player"
                        "Play_sfx_AatroxSkin08_AatroxW_OnHit"
                        "Play_sfx_AatroxSkin08_AatroxW_OnMissileLaunch"
                        "Stop_sfx_AatroxSkin08_AatroxW_OnMissileLaunch"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = 0x17064d41
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20.skl"
            SimpleSkin: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20.skn"
            Texture: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_TX_CM.dds"
            SkinScale: f32 = 1.09000003
            SelfIllumination: f32 = 0.699999988
            BrushAlphaOverride: f32 = 0.550000012
            OverrideBoundingBox: option[vec3] = {
                { 130, 250, 130 }
            }
            Material: link = 0x5403626e
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Wings Masks_MAT"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_TX_CM.dds"
                    Submesh: string = "Banner"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x56869e92
                    Submesh: string = "Sword"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x45939031
                    Submesh: string = "Wings"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x269c8576
                    Submesh: string = "Shadow"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Masks_TX_CM.dds"
                    Submesh: string = "Masks_MAT"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x5403626e
                    Submesh: string = "Spikes"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xf9416f36
                    mEndingJointName: hash = 0x92f23d35
                    mDefaultMaskName: hash = "Empty"
                    mMaxBoneAngle: f32 = 150
                    mVelMultiplier: f32 = 0
                    mFrequency: f32 = 5
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x30bbc6f4
                    mEndingJointName: hash = 0x4efad75c
                    mDefaultMaskName: hash = "Empty"
                    mMaxBoneAngle: f32 = 150
                    mVelMultiplier: f32 = 0
                    mFrequency: f32 = 5
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "BaseBuffPose"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Aatrox_Z_IdleSparkles"
                BoneName: string = "C_Buffbone_Glb_Chest_Loc"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Aatrox_Z_IdleGlow"
                BoneName: string = "R_Buffbone_Glb_Hand_Loc"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Aatrox_Z_EyeGlow"
                BoneName: string = "C_Buffbone_Glb_Head_Loc"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Aatrox/HUD/Aatrox_Circle_8.dds"
        mContextualActionData: link = "Characters/Aatrox/CAC/Aatrox_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Aatrox/HUD/Aatrox_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Aatrox/HUD/Aatrox_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/51"
                mLoadingScreenAnchor: u32 = 1
            }
        }
        mResourceResolver: link = 0x9442d190
        0x87b1d303: list2[pointer] = {
            0x67ac9672 {
                0x43c8c7b1: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = "Characters/Aatrox/Spells/AatroxPassiveAbility/AatroxPassiveReady"
                }
                0x071f3c1d: list2[embed] = {
                    0x00fa43e4 {
                        BoneName: string = "Weapon_Heart"
                        EffectKey: hash = "Aatrox_P_Ready"
                    }
                }
            }
        }
    }
    0x269c8576 = StaticMaterialDef {
        Name: string = "Characters/Aatrox/Skins/Skin20/Materials/Skin08_Ult_Inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Shadow_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Shared/Materials/Aatrox_BaseMask.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Shared/Materials/Gradient_test_01.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_SmoothStep"
                Value: vec4 = { 0, 0.400000006, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Bias"
                Value: vec4 = { -1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Pulse_Rate"
                Value: vec4 = { 0.300000012, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Pulse_Max"
                Value: vec4 = { 0.600000024, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Gradient_Sharpness"
                Value: vec4 = { 0.00999999978, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Sharpness"
                Value: vec4 = { 0.100000001, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Pulse_Offset"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Aatrox_VFXBase"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Alpha"
                    Driver: pointer = MaxMaterialDriver {
                        mDrivers: list[pointer] = {
                            LerpMaterialDriver {
                                mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                                    mScriptName: string = "AatroxR"
                                }
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                            LerpMaterialDriver {
                                mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "ULT_out_to_passive_idle"
                                    }
                                }
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                            LerpMaterialDriver {
                                mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        0x6bddf209
                                    }
                                }
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                            LerpMaterialDriver {
                                mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        0x18fa64cb
                                    }
                                }
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                        }
                    }
                }
            }
        }
    }
    0x45939031 = StaticMaterialDef {
        Name: string = "Characters/Aatrox/Skins/Skin20/Materials/Wings_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Shadow_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin07/Particles/Aatrox_Skin07_R_wing_mask.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin08/Particles/Aatrox_Skin08_WingsTransformGradient.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Mask_Intensity"
                Value: vec4 = { 0.917500019, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 2, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scrolling_Scale"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scrolling_Rate"
                Value: vec4 = { 0, 0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Color"
                Value: vec4 = { 0.850980401, 0.588235319, 0.215686277, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Bias"
                Value: vec4 = { 0.785000026, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_SmoothStep"
                Value: vec4 = { 0, 0.5, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Gradient_Sharpness"
                Value: vec4 = { 4, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Sharpness"
                Value: vec4 = { 0.00100000005, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_COLORDODGE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_ADDATIVE"
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_LERP"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_DISSOLVE"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Scrolling_ColorDodge_Masked"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Dissolve_Bias"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = HasBuffDynamicMaterialBoolDriver {
                                    mScriptName: string = "AatroxRFX"
                                }
                                mValue: pointer = LerpMaterialDriver {
                                    mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                                        mScriptName: string = "AatroxRFX"
                                        0xff80df7a: f32 = 1
                                    }
                                    mOnValue: f32 = -1
                                    mOffValue: f32 = 1
                                    mTurnOnTimeSec: f32 = 2
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = HasBuffDynamicMaterialBoolDriver {
                                    mScriptName: string = "AatroxRReviveMaterialOverride"
                                }
                                mValue: pointer = LerpMaterialDriver {
                                    mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                                        mScriptName: string = "AatroxRReviveMaterialOverride"
                                    }
                                    mOffValue: f32 = -0.180000007
                                    mTurnOnTimeSec: f32 = 6
                                    mTurnOffTimeSec: f32 = 0
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        0x909068b6
                                    }
                                }
                                mValue: pointer = LerpMaterialDriver {
                                    mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                        mAnimationNames: list[hash] = {
                                            0x909068b6
                                        }
                                    }
                                    mOnValue: f32 = -1
                                    mOffValue: f32 = 1
                                    mTurnOnTimeSec: f32 = 0.200000003
                                    mTurnOffTimeSec: f32 = 0.200000003
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "Taunt"
                                    }
                                }
                                mValue: pointer = LerpMaterialDriver {
                                    mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                        mAnimationNames: list[hash] = {
                                            "Taunt"
                                        }
                                    }
                                    mOnValue: f32 = -1
                                    mOffValue: f32 = 1
                                    mTurnOnTimeSec: f32 = 0.200000003
                                    mTurnOffTimeSec: f32 = 0.200000003
                                }
                            }
                        }
                        mDefaultValue: pointer = FloatLiteralMaterialDriver {
                            mValue: f32 = 1
                        }
                    }
                }
            }
        }
    }
    0x5403626e = StaticMaterialDef {
        Name: string = "Characters/Aatrox/Skins/Skin20/Materials/Aatrox_Skin08_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Base/Particles/Aatrox_Base_R_body_mask.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin08/Particles/Aatrox_Skin08_WingsTransformGradient.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_SmoothStep"
                Value: vec4 = { 0, 0.150000006, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Bias"
                Value: vec4 = { -0.200000003, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Pulse_Rate"
                Value: vec4 = { 3, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Pulse_Max"
                Value: vec4 = { 0.400000006, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Gradient_Sharpness"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Sharpness"
                Value: vec4 = { 0.00100000005, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 10, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Pulse_Offset"
                Value: vec4 = { 0.300000012, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Aatrox_VFXBase"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Dissolve_Bias"
                    Driver: pointer = MaxMaterialDriver {
                        mDrivers: list[pointer] = {
                            FloatGraphMaterialDriver {
                                Driver: pointer = LerpMaterialDriver {
                                    mBoolDriver: pointer = IsDeadDynamicMaterialBoolDriver {}
                                    mTurnOnTimeSec: f32 = 4
                                    mTurnOffTimeSec: f32 = 0
                                }
                                Graph: embed = VfxAnimatedFloatVariableData {
                                    Times: list[f32] = {
                                        0.00171930937
                                        0.216738746
                                        0.766768217
                                        1.00488436
                                    }
                                    Values: list[f32] = {
                                        -0.22144419
                                        0.260138661
                                        0.752247512
                                        0.86541003
                                    }
                                }
                            }
                            FloatGraphMaterialDriver {
                                Driver: pointer = LerpMaterialDriver {
                                    mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                        mAnimationNames: list[hash] = {
                                            "Passive_Death"
                                        }
                                    }
                                    mTurnOnTimeSec: f32 = 3
                                }
                                Graph: embed = VfxAnimatedFloatVariableData {
                                    Times: list[f32] = {
                                        0.00321787666
                                        0.381477386
                                        0.997775316
                                    }
                                    Values: list[f32] = {
                                        -0.225780264
                                        0.583815038
                                        0.994219661
                                    }
                                }
                            }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Pulse_Rate"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "AatroxR"
                        }
                        mOnValue: f32 = 5
                        mTurnOnTimeSec: f32 = 0
                        mTurnOffTimeSec: f32 = 0
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Alpha"
                    Driver: pointer = MinMaterialDriver {
                        mDrivers: list[pointer] = {
                            LerpMaterialDriver {
                                mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                                    mScriptName: string = "AatroxR"
                                }
                                mOnValue: f32 = 0
                                mOffValue: f32 = 1
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                            LerpMaterialDriver {
                                mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        "ULT_out_to_passive_idle"
                                    }
                                }
                                mOnValue: f32 = 0
                                mOffValue: f32 = 1
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                            LerpMaterialDriver {
                                mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        0x6bddf209
                                    }
                                }
                                mOnValue: f32 = 0
                                mOffValue: f32 = 1
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                            LerpMaterialDriver {
                                mBoolDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                                    mAnimationNames: list[hash] = {
                                        0x18fa64cb
                                    }
                                }
                                mOnValue: f32 = 0
                                mOffValue: f32 = 1
                                mTurnOnTimeSec: f32 = 0
                                mTurnOffTimeSec: f32 = 0
                            }
                        }
                    }
                }
            }
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Diffuse_Texture"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = HasBuffDynamicMaterialBoolDriver {
                                mScriptName: string = "AatroxR"
                            }
                            TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin08/Aatrox_Prestige_Shadow_TX_CM.dds"
                        }
                    }
                }
            }
        }
    }
    0x56869e92 = StaticMaterialDef {
        Name: string = "Characters/Aatrox/Skins/Skin20/Materials/Sword_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Sword_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_P_Sword_Mask.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Gradient.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Mask_Intensity"
                Value: vec4 = { 0.792500019, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 10, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scrolling_Scale"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scrolling_Rate"
                Value: vec4 = { 0, -0.300000012, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Color"
                Value: vec4 = { 1, 0.372549027, 0.164705887, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Bias"
                Value: vec4 = { -1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_SmoothStep"
                Value: vec4 = { 0, 0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Gradient_Sharpness"
                Value: vec4 = { 0.400000006, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Sharpness"
                Value: vec4 = { 0.00100000005, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_COLORDODGE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_ADDATIVE"
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_LERP"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_DISSOLVE"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Scrolling_ColorDodge_Masked"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Mask_Intensity"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "AatroxPassiveReady"
                        }
                        mOnValue: f32 = 0.75
                        mTurnOffTimeSec: f32 = 0.200000003
                    }
                }
            }
        }
    }
    0x82c6835b = StaticMaterialDef {
        Name: string = "Characters/Aatrox/Skins/Skin20/Materials/SwordSwap_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Sword_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_P_Sword_Mask.dds"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Gradient_Texture"
                TextureName: string = "ASSETS/Characters/Aatrox/Skins/Skin20/Aatrox_Skin20_Gradient.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Mask_Intensity"
                Value: vec4 = { 0.792500019, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 10, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scrolling_Scale"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scrolling_Rate"
                Value: vec4 = { 0, -0.300000012, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Color"
                Value: vec4 = { 1, 0.372549027, 0.164705887, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_Bias"
                Value: vec4 = { -1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Dissolve_SmoothStep"
                Value: vec4 = { 0, 0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Gradient_Sharpness"
                Value: vec4 = { 0.400000006, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Sharpness"
                Value: vec4 = { 0.00100000005, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_COLORDODGE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_ADDATIVE"
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_LERP"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_DISSOLVE"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Scrolling_ColorDodge_Masked"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Mask_Intensity"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "AatroxPassiveReady"
                        }
                        mOnValue: f32 = 0.75
                        mTurnOffTimeSec: f32 = 0.200000003
                    }
                }
            }
        }
    }
    0x6a73c249 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Basic3"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -75, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.164705887, 0, 0.400000006 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                DepthBiasFactors: vec2 = { -1, -30 }
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 75, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 75, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.600000024, 0.25, 2.5 }
                            { 1, 1, 1 }
                            { 0.600000024, 0.25, 0.25 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Aatrox/Skins/Skin08/Particles/Aatrox_Skin08_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "BroadLargeGlow"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -50, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -50, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.280003041, 0.280003041, 0.280003041, 0.650003791 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.698039234, 0.20784314, 0 }
                            { 0.874509811, 0.517647088, 0.156862751, 1 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                DepthBiasFactors: vec2 = { 1, 3 }
                ParticleIsLocalOrientation: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 50, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 0 }
                            { 0, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Aatrox/Skins/Skin07/Particles/Aatrox_Skin07_P_hit_splash.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                EmitterName: string = "Basic4"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 1.00000012, 0, 0 }
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 10, 0 }
                }
                Texture: string = "ASSETS/Shared/Particles/disc32.DDS"
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        SubMeshName: option[string] = {
                            "Sword"
                        }
                        Material: link = 0x82c6835b
                    }
                }
            }
        }
        ParticleName: string = "Aatrox_Skin20_P_Ready"
        ParticlePath: string = "Characters/Aatrox/Skins/Skin20/Particles/Aatrox_Skin20_P_Ready"
    }
"Characters/Aatrox/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Aatrox_Q_Indicator_01" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Indicator_01"
            0x4c250437 = "Characters/Kayn/Skins/Skin0/Particles/Kayn_Base_Primary_R_tar_child"
            "Aatrox_Q_cas1" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_cas1"
            "Aatrox_Q_cas3" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_cas3"
            "Aatrox_Q_cas2" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_cas2"
            "Aatrox_AA_Trail_01" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Trail_01"
            "Aatrox_AA_Trail_03" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Trail_03"
            "Aatrox_AA_Trail_02" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Trail_02"
            0x57532b4b = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Hit_Tar01"
            0x58532cde = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Hit_Tar02"
            "Aatrox_W_mis" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_mis"
            "Aatrox_W_Beam_Tar" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Beam_Tar"
            "Aatrox_W_Core" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Core"
            "Aatrox_Q_Indicator_02" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Indicator_02"
            "Aatrox_Q_Indicator_03" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Indicator_03"
            "Aatrox_E_Dash" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_E_Dash"
            "Aatrox_E_Active_buff" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_E_Active_buff"
            "Aatrox_Q_Trail_01" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Trail_01"
            "Aatrox_Q_Trail_02" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Trail_02"
            "Aatrox_Q_Trail_03" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Trail_03"
            "Aatrox_Q_Indicator_01_Ally" = "Characters/Aatrox/Skins/Skin7/Particles/Aatrox_Skin07_Q_Indicator_01_Ally"
            "Aatrox_Q_Indicator_02_Ally" = "Characters/Aatrox/Skins/Skin7/Particles/Aatrox_Skin07_Q_Indicator_02_Ally"
            "Aatrox_Q_Indicator_03_Ally" = "Characters/Aatrox/Skins/Skin7/Particles/Aatrox_Skin07_Q_Indicator_03_Ally"
            "Aatrox_P_Ready" = 0x6a73c249
            "Aatrox_R_Fear" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_Fear"
            "Aatrox_P_Activate" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_P_Activate"
            "Aatrox_E_Heal" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_E_Heal"
            "Aatrox_Death_ambers" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Death_ambers"
            "Aatrox_R_Attack_01" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_Attack_01"
            "Aatrox_P_Hit_Tar" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_P_Hit_Tar"
            "Aatrox_R_Attack_02" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_Attack_02"
            "Aatrox_W_Cas" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Cas"
            "Aatrox_E_Dash_trail" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_E_Dash_trail"
            "Aatrox_E_Dash2" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_E_Dash2"
            "Aatrox_W_Hand_glow_cas" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Hand_glow_cas"
            "Aatrox_Q_Hit_Tar" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Hit_Tar"
            "Aatrox_Q_Sweet_hit_tar" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Q_Sweet_hit_tar"
            "Aatrox_W_Core_Area" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Core_Area"
            "Aatrox_P_Attack_trail" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_P_Attack_trail"
            "Aatrox_R_Revive_end" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_Revive_end"
            "Aatrox_E_Buf_Sword" = 0x00000000
            "Aatrox_Passive_Sheathe_Sword" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Passive_Sheathe_Sword"
            "Aatrox_R_Revive_Duration" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_Revive_Duration"
            "Aatrox_R_Revive_Diration_Sword" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_Revive_Diration_Sword"
            "Aatrox_R_SpeedBuff" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_R_SpeedBuff"
            "Aatrox_P_Debuff" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_P_Debuff"
            "Aatrox_Recall_Ground" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Recall_Ground"
            "Aatrox_Recall_Beam" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Recall_Beam"
            "Aatrox_Recall_Weapon_glow" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Recall_Weapon_glow"
            "Aatrox_Recall_Hand_glow" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Recall_Hand_glow"
            "Aatrox_W_Core_End" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Core_End"
            "Aatrox_W_Beam_Tar_Break" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Beam_Tar_Break"
            "Aatrox_W_Hit_Tar" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Hit_Tar"
            "Aatrox_W_Beam_Tar_Pull" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_W_Beam_Tar_Pull"
            "Aatrox_AA_Crit_Hit_Tar" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Crit_Hit_Tar"
            "Aatrox_AA_Crit_Trail" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_AA_Crit_Trail"
            "Aatrox_Dance_Ground" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Dance_Ground"
            "Aatrox_Taunt_Ground" = "Characters/Aatrox/Skins/Skin0/Particles/Aatrox_Base_Taunt_Ground"
            0x5b2b3b83 = "Maps/Particles/SRX/Base/SRX_Audio_Hextech_Storm_loop"
            0x2c43403d = 0x69af6630
            0x20bae730 = 0x36d5d42b
            "Aatrox_Z_FloorSlash" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_FloorSlash"
            "Aatrox_Z_FloorSlashDirt" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_FloorSlashDirt"
            "Aatrox_Z_RecallMaskTrails" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_RecallMaskTrails"
            "Aatrox_Z_RecallBuff" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_RecallBuff"
            "Aatrox_Z_RecallHits" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_RecallHits"
            "Aatrox_Z_DianaMaskGlow" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_DianaMaskGlow"
            "Aatrox_Z_EyeGlow" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_EyeGlow"
            "Aatrox_Z_IdleSparkles" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_IdleSparkles"
            "Aatrox_Z_IdleGlow" = "Characters/Aatrox/Skins/Skin8/Particles/Aatrox_Skin08_Z_IdleGlow"
        }
    }
}
