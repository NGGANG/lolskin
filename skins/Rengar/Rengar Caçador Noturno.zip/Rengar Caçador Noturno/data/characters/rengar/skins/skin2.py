#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Rengar/Animations/Skin2.bin"
    "DATA/Characters/Rengar/Rengar.bin"
    "DATA/Rengar_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Rengar/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "rengarSkin02"
        MetaDataTags: string = "gender:male,race:vastaya,faction:ixtal,skinline:legacy,appearance:feline,"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Rengar/Skins/Skin02/RengarLoadScreen_2.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Rengar"
                "RengarSkin02"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Rengar_Skin02_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Rengar/Skins/Skin02/Rengar_Skin02_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Rengar/Skins/Skin02/Rengar_Skin02_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_RengarSkin02_Recall3D_buffactivate"
                    }
                }
                BankUnit {
                    Name: string = "Rengar_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Rengar/Skins/Base/Rengar_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Rengar/Skins/Base/Rengar_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    Name: string = "Rengar_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Rengar/Skins/Base/Rengar_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Rengar/Skins/Base/Rengar_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Rengar/Skins/Base/Rengar_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Rengar_Attack2DGeneral"
                        "Play_vo_Rengar_Death3D"
                        "Play_vo_Rengar_FirstEncounter3DKhazix"
                        "Play_vo_Rengar_Joke3DGeneral"
                        "Play_vo_Rengar_Laugh3DGeneral"
                        "Play_vo_Rengar_Move2DStandard"
                        "Play_vo_Rengar_RengarBasicAttack2_cast3D"
                        "Play_vo_Rengar_RengarBasicAttack3_cast3D"
                        "Play_vo_Rengar_RengarBasicAttack_cast3D"
                        "Play_vo_Rengar_RengarBonetoothStack1"
                        "Play_vo_Rengar_RengarBonetoothStack2"
                        "Play_vo_Rengar_RengarBonetoothStack3"
                        "Play_vo_Rengar_RengarBonetoothStack4"
                        "Play_vo_Rengar_RengarBonetoothStack5"
                        "Play_vo_Rengar_RengarCritAttack_cast3D"
                        "Play_vo_Rengar_RengarE_cast3D"
                        "Play_vo_Rengar_RengarEEmp_cast3D"
                        "Play_vo_Rengar_RengarQ_cast3D"
                        "Play_vo_Rengar_RengarQEmp_cast3D"
                        "Play_vo_Rengar_RengarR_cast3D"
                        "Play_vo_Rengar_RengarW_cast3D"
                        "Play_vo_Rengar_RengarWEmp_cast3D"
                        "Play_vo_Rengar_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Rengar/Animations/Skin2"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Rengar/Skins/Skin02/rengar_Skin02.skl"
            SimpleSkin: string = "ASSETS/Characters/Rengar/Skins/Skin02/rengar_Skin02.skn"
            Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/rengar_Skin02_TX_CM.dds"
            SkinScale: f32 = 0.949999988
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 180, 250, 180 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Hood"
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x49c3f916
                    mEndingJointName: hash = 0x4dc3ff62
                    mDefaultMaskName: hash = 0xef7cfc3b
                    mVelMultiplier: f32 = 1
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IconAvatar: string = "ASSETS/Characters/Rengar/HUD/Rengar_Circle_2.dds"
        mContextualActionData: link = "Characters/Rengar/CAC/Rengar_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Rengar/HUD/Rengar_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Rengar/HUD/Rengar_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/29"
            }
        }
        mResourceResolver: link = "Characters/Rengar/Skins/Skin2/Resources"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA3_Cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashSkin02"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 120 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.5 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashAdd"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 120 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 0, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.5 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Rengar_Skin02_BA3_Cas"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA3_Cas"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA1_Cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashSkin02"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 110, 80, 50 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, -120, -10 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.5 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashAdd"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 110, 80, 50 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                AlphaRef: u8 = 255
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, -120, -10 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.5 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Rengar_Skin02_BA1_Cas"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA1_Cas"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Secondary_Target" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.239999995
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                EmitterName: string = "dArK_bg"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 130, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.211765006, 0.105881996, 0.647059023, 1 }
                            { 0.258823991, 0.0470589995, 0.329412013, 0 }
                        }
                    }
                }
                Pass: i16 = 70
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 80, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1.70000005, 1 }
                            { 2, 2, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_skin02_R_glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Eye_back"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 130, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.101960793, 0.0823529437, 0.388235331, 1 }
                }
                Pass: i16 = -5
                ColorLookUpTypeY: u8 = 3
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 120, 0 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_base_z_mult.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_R_tar_vision_eye_glow.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "groundshadow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.121568635, 0.141176477, 0.325490206, 1 }
                }
                Pass: i16 = -11
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 120, 10 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_base_z_alpha_circle.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_R_Secondary_Target"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Secondary_Target"
        Flags: u16 = 197
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Claw" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Rengar_Q_Buf_Blade_Child"
                        }
                    }
                }
                EmitterName: string = "Blue_Flames_Parent"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -5
                                        90
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -20
                                        -20
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 1, 1 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 0 }
                }
                Pass: i16 = -40
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Blade_Mesh_Flame_Dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Buf_Claw_Flame.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.294117987, 0.294117987, 0.294117987, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.294117987, 0.294117987, 0.294117987, 0 }
                            { 0.294117987, 0.294117987, 0.294117987, 0.800000012 }
                            { 0.294117987, 0.294117987, 0.294117987, 0 }
                        }
                    }
                }
                Pass: i16 = 20
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Buf_Blade_Flame_2x2.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.150000006, 0.25 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { -0.150000006, 0.25 }
                        }
                    }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 4, 4 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "powerFlareBurst"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.313724995, 0.850979984, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.313724995, 0.850979984, 1, 0.800000012 }
                            { 0.313724995, 0.850979984, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_flareblue.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Buf_Claw"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Claw"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_C_Cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashSkin02"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -47, 120, 150 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_C_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 190, 180 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    -0.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 190, 180 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashAdd"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -47, 120, 150 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_C_WeaponTrail.sco"
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 190, 180 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    -0.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 190, 180 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Rengar_Skin02_C_Cas"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_C_Cas"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade_Max" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Rengar_Q_Buf_Blade_Child"
                        }
                    }
                }
                EmitterName: string = "Blue_Flames_Parent"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 1, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        60
                                        130
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 1, 0 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Pass: i16 = 40
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cross1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 60, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0235290006, 0.043136999, 0.141176, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0235290006, 0.043136999, 0.141176, 0 }
                            { 0.0235290006, 0.043136999, 0.141176, 0.800000012 }
                            { 0.0235290006, 0.043136999, 0.141176, 0.800000012 }
                            { 0.0235290006, 0.043136999, 0.141176, 0 }
                        }
                    }
                }
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 120, 50 }
                }
                Texture: string = "ASSETS/Shared/Particles/Items/Item_HextechRevolver_Cyan_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cross2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 60, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0235290006, 0.043136999, 0.141176, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0235290006, 0.043136999, 0.141176, 0 }
                            { 0.0235290006, 0.043136999, 0.141176, 0.800000012 }
                            { 0.0235290006, 0.043136999, 0.141176, 0.800000012 }
                            { 0.0235290006, 0.043136999, 0.141176, 0 }
                        }
                    }
                }
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 120, 50 }
                }
                Texture: string = "ASSETS/Shared/Particles/Items/Item_HextechRevolver_Cyan_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Blade_Mesh_Flame"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 75, -2.5 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Buf_Blade_Flame.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.474510014, 0.956862986, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.474510014, 0.956862986, 1, 0 }
                            { 0.474510014, 0.956862986, 1, 1 }
                            { 0.474510014, 0.956862986, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                DepthBiasFactors: vec2 = { -1, -2 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.10000002, 1.10000002, 1.10000002 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_EmBuf_Highlight.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.500100017
                                    0.500199974
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -0.5
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.500100017
                                    0.500199974
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -0.400000006
                                    0.400000006
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0.5, 1 }
                        }
                    }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "powerFlareBurst"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.333332986, 1, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 1, 1, 0.800000012 }
                            { 0.333332986, 1, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/FlareBlue.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "powerFlare"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.333332986, 1, 1, 0.494118005 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 1, 1, 0 }
                            { 0.333332986, 1, 1, 0.494118005 }
                            { 0.333332986, 1, 1, 0.494118005 }
                            { 0.333332986, 1, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/FlareBlue.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Buf_Blade_Max"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade_Max"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Max_Mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Net"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Max_Net.sco"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 10
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -600, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 165, 165, 165 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Net.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 13
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "trail_add"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.699999988 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.699999988 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 9
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 20, 360 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 10 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 110, 110, 110 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola_Add.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "trail_dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 20, 360 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 10 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola_Add.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_E_Max_Mis"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Max_Mis"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Buf" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            20
                            40
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "Stealth_Swirls"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 150, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Sphere.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                ColorLookUpTypeY: u8 = 3
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, -90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, -90, 90 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 8, 8, 8 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_Cas.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.25, 0.100000001 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    10
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    10
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            25
                            50
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "Stealth_Swirls_Add"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -100 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 150, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Sphere.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB_add.dds"
                ColorLookUpTypeY: u8 = 3
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { -1, -1, -1, -1 }
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, -90, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, -90, 90 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 8, 8, 8 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_Cas.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.25, 0.100000001 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    10
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    10
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "base_Hunter"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0, 0.615686297, 1, 1 }
                            { 0, 0.779995441, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 100
                ColorLookUpTypeY: u8 = 3
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionMapName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_AlphaSlice.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.02999997, 1.02999997, 1.02999997 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.10000002, 1.10000002, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_cas_avatar.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "base_Hunter1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_TransRamp.dds"
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0700000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.615686297, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0, 0.620004594, 1, 1 }
                            { 0, 0.620004594, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 9
                ColorLookUpTypeY: u8 = 3
                AlphaRef: u8 = 0
                ColorRenderFlags: u8 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.300000012
                                1
                            }
                            Values: list[f32] = {
                                1
                                0.200000003
                                -1
                            }
                        }
                    }
                    LingerErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0.5
                    }
                    ErosionFeatherIn: f32 = 0.5
                    ErosionSliceWidth: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_cas_avatar.dds"
                }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.02999997, 1.02999997, 1.02999997 }
                }
                Texture: string = "ASSETS/Shared/Particles/3161common_color-hold.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_R_Buf"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Buf"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Buf" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10
                }
                EmitterName: string = "base"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            0.5
                            -1.5
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Shared/Particles/arrow01.scb"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.10000002, 1.10000002, 1.10000002 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Avatar.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Max_Buf"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Buf"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Max_Tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.75
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Net"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00600000005
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Net.sco"
                    }
                }
                BlendMode: u8 = 1
                DoesCastShadow: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 80, 150 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Net.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_E_Max_Tar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Max_Tar"
        OverrideScaleCap: option[f32] = {
            500
        }
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Roar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    0.649999976
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Skin02"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -90, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -250, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 600, 600 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.340000004
                            0.550000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_ShoutRing.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    10.6499996
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Skin02_Ult"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -90, 0, 1 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 600, 600 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.340000004
                            0.550000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Max_ShoutRing.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "ShellRing"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.800000012, 0.800000012, 0.800000012, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.800000012, 0.800000012, 0.800000012, 0 }
                            { 0.800000012, 0.800000012, 0.800000012, 1 }
                            { 0.800000012, 0.800000012, 0.800000012, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 475, 475, 475 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Ring.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    10.6000004
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "GroundRing"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_GroundRing_Geo.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.699999988, 0.699999988, 0.699999988, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec4] = {
                            { 0.699999988, 0.699999988, 0.699999988, 0 }
                            { 0.699999988, 0.699999988, 0.699999988, 1 }
                            { 0.699999988, 0.699999988, 0.699999988, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.70000005, 0.5, 1.70000005 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_GroundRing_Sub.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1.75 }
                }
                TexDiv: vec2 = { 0.699999988, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ShellDistort"
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Rampdown_RGBA.DDS"
                BlendMode: u8 = 1
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.100000001
                    NormalMapTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Distortion_NormalMap.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 450, 450, 450 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Distortion.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "ShellRing_ULT"
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB_add.dds"
                Pass: i16 = 50
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 650, 650, 650 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Max_Ring.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "ShellRing_ULT_Add"
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Add_RGB.dds"
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 650, 650, 650 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Max_Ring.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "Model_Flash"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            0.5
                            -1.5
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Shared/Particles/arrow01.scb"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.10000002, 1.10000002, 1.10000002 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                            { 1.39999998, 1.39999998, 1.39999998 }
                            { 1.5, 1.5, 1.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Avatar.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Max_Roar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Roar"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_AS_Buf" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "powerFlare"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.325489998, 1, 1, 0.298038989 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.325489998, 1, 1, 0 }
                            { 0.325489998, 1, 1, 0.298038989 }
                            { 0.325489998, 1, 1, 0.298038989 }
                            { 0.325489998, 1, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_flareblue.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    10.1000004
                }
                EmitterName: string = "ASTrail"
                Importance: u8 = 2
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 800, 0, 0 }
                        }
                        mSmoothingMode: u8 = 1
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.00392200006, 0.450980008, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.00392200006, 0.450980008, 1, 0 }
                            { 0.00392200006, 0.450980008, 1, 1 }
                            { 0.00392200006, 0.275893807, 0.168626994, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 100, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_AS_Buf"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_AS_Buf"
        SoundOnCreateDefault: string = "Play_sfx_Rengar_RengarQ_buffactivate"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Emp_Buf2" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    100
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Gold_Caustics"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.113724999, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                AlphaRef: u8 = 121
                ParticleIsLocalOrientation: flag = true
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.02999997, 1.02999997, 1.02999997 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_EmBuf_Highlight.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.400000006, 0.600000024 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 0.25, 0.25 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    100
                }
                IsSingleParticle: flag = true
                EmitterName: string = "red_pulse1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.211764723, 0, 0.388235331, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.02999997, 1.02999997, 1.02999997 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_W_Swirl_Mask.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.400000006, 0.600000024 }
                }
                TexDiv: vec2 = { 0.25, 0.25 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_W_VerticalStreak_Mask.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 0.100000001 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    0.400000006
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "Avatar"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, -200, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500001013
                                    1
                                }
                                KeyValues: list[f32] = {
                                    2
                                    2
                                    -2
                                    -2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.200000003
                                    0.200001001
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -1
                                    -3
                                    -5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 10, -200, 10 }
                            { 20, -200, 20 }
                            { 50, -200, 50 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Shared/Particles/arrow01.scb"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_skin02_W_EmBuf_ColorText.dds"
                BlendMode: u8 = 4
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeY: u8 = 1
                SliceTechniqueRange: f32 = 0.150000006
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 90 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.85000002, 1.85000002, 1.85000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Particles/global_ss_cleanse_alphaslice.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Emp_Buf2"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Emp_Buf2"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "cursebandages"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 20, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00700000022
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00700000022
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Wrap.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 1, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 30, 1, 30 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 20, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 20, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 0.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.5, 0.5, 0.5 }
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 0.5, 0, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Wrap.dds"
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 0 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Bola"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 20, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00749999983
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00749999983
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DoesCastShadow: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, -1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { 0, -40, 0 }
                            { 0, -0, 0 }
                            { 0, -0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.800000012, 0.800000012, 0.800000012 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_E_Tar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Tar"
        OverrideScaleCap: option[f32] = {
            375
        }
        SoundOnCreateDefault: string = "Play_sfx_Rengar_RengarE_hit"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Buf_Enhanced_Ring" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 66
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                Lifetime: option[f32] = {
                    100000
                }
                EmitterName: string = "Ring_FX"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 750, 0, 0 }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_W_Heal_Spark_RGBA.DDS"
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.426337063, 1, 0.380392164 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 20, 5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 10, 5, 1 }
                            { 30, 5, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_P_Shafts.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_DarkstarMode_LanternPullTetherThresh_Skin05_W_Einstein_01_mult.dds"
                    TexDivMult: vec2 = { 4, 4 }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                0x538effa4: flag = true
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                Lifetime: option[f32] = {
                    100000
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring_FX1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 750, 0, 0 }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_W_Heal_Spark_RGBA.DDS"
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.168551162, 0.766781092, 1, 0.470588237 }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 20, 5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.23888889
                            1
                        }
                        Values: list[vec3] = {
                            { 10, 5, 1 }
                            { 24.641304, 5, 1 }
                            { 30, 5, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_P_Shafts.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_Void_Ring.sco"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.506202817, 0.76050967, 1, 1 }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ColorRenderFlags: u8 = 1
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 750, 800, 800 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_P_CloudTxt06_1.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 0 }
                }
                TexDiv: vec2 = { 0.600000024, 0.300000012 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Ring1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_Void_Ring.sco"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.209994659 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.142046228, 0.597055018, 1, 1 }
                }
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                ColorRenderFlags: u8 = 1
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 750, 800, 800 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_P_CloudTxt06_1.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "HARD_EDGE"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_NewRing.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.190005347, 0.666422546, 1, 1 }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 11, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/3026_Items_Noise_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 0 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0.25 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/3026_Items_Noise_02.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 5, 0.25 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0.0799999982, 0.119999997 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.0799999982, 0.119999997 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "HARD_EDGE1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_NewRing.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.190005347, 0.618356586, 1, 0.309803933 }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 11, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_P_CloudTxt06_1.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 0 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0.25 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                EmitterName: string = "HARD_EDGE2"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_NewRing_02.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.0482490286, 0.119905397, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.600000024
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.400000006 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 101
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 11, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25555557
                            0.566666663
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.461956531, 0.253926694, 0.253926694 }
                            { 0.845652163, 1, 1 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/3026_Items_Noise_02.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 0.25 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/3026_Items_Noise_02.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 5, 0.25 }
                    }
                    0x22c3cf3e: embed = IntegratedValueVector2 {
                        ConstantValue: vec2 = { 0.0799999982, 0.119999997 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.0799999982, 0.119999997 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Rengar_Skin02_P_Buf_Enhanced_Ring"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Buf_Enhanced_Ring"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Bola"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Mis_Bola.sco"
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = 10
                DoesCastShadow: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 800, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 130, 130 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 12
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "trail_add"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 20, 360 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 10 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 75, 75 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola_Add.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "trail_dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 360 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 20, 360 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 10 }
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 75, 75 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_E_Bola_Add.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_E_Mis"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Mis"
        SoundOnCreateDefault: string = "Play_sfx_Rengar_RengarE_missilelaunch"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Slash1"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 80 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Rengar_Base_Q_Slash.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.215685993, 0.215685993, 0.647059023, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.215685993, 0.215685993, 0.647059023, 1 }
                            { 0, 0.215685993, 0.647059023, 1 }
                            { 0, 0, 0.647059023, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 200, 200 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Slash_New.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.79999995 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_HA_PoroRay_Mult.dds"
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.135000005
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.38499999
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashBase"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 100, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin08/Particles/Rengar_Skin08_Z_WeaponTrail_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.294117987, 0.294117987, 0.294117987, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.226067021, 0.294117987, 1 }
                            { 0, 0.151095763, 0.294117987, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 70 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin08/Particles/Rengar_Skin08_AA_Trail_00.dds"
                FrameRate: f32 = 24
                NumFrames: u16 = 5
                TexDiv: vec2 = { 1, 5 }
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Cas"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Cas"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Claw_Max" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Rengar_Q_Buf_Blade_Child"
                        }
                    }
                }
                EmitterName: string = "Blue_Flames_Parent"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -5
                                        90
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -20
                                        -20
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 1, 1 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 0 }
                }
                Pass: i16 = 40
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Blade_Mesh_Flame"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Buf_Claw_Flame.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.333332986, 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.333332986, 1, 1, 0 }
                            { 0.333332986, 1, 1, 1 }
                            { 0.333332986, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                DepthBiasFactors: vec2 = { -1, -2 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.04999995, 1.04999995, 1.04999995 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_EmBuf_Highlight.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.5, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.500100017
                                    0.500199974
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -0.5
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.500100017
                                    0.500199974
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -0.400000006
                                    0.400000006
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0.5, 1 }
                        }
                    }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "powerFlareBurst"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.313724995, 0.850979984, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.313724995, 0.850979984, 1, 0.800000012 }
                            { 0.313724995, 0.850979984, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/FlareBlue.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "powerFlare"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.400000006, 0.741176009, 1, 0.498039007 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.400000006, 0.741176009, 1, 0 }
                            { 0.400000006, 0.741176009, 1, 0.498039007 }
                            { 0.400000006, 0.741176009, 1, 0.498039007 }
                            { 0.400000006, 0.741176009, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 10, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Shared/Particles/FlareBlue.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cross1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0196080003, 0.0392160006, 0.137254998, 0.500007987 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0196080003, 0.0392160006, 0.137254998, 0 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0.500007987 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0.500007987 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0 }
                        }
                    }
                }
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 120, 50 }
                }
                Texture: string = "ASSETS/Shared/Particles/Items/Item_HextechRevolver_Cyan_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 8
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "cross2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0196080003, 0.0392160006, 0.137254998, 0.500007987 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0196080003, 0.0392160006, 0.137254998, 0 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0.500007987 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0.500007987 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0 }
                        }
                    }
                }
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 120, 50 }
                }
                Texture: string = "ASSETS/Shared/Particles/Items/Item_HextechRevolver_Cyan_Glow.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Buf_Claw_Max"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Claw_Max"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Cas_Max" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Slash1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 80 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Rengar_Base_Q_Slash.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.952941, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.952941, 1, 1 }
                            { 0, 0.952941, 1, 1 }
                            { 0, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 200, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.25
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 200, 200 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Slash_New.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.79999995 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Particles/HA_PoroRay_Mult.dds"
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.135000005
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                Lifetime: option[f32] = {
                    0.38499999
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashBase"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 100, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin08/Particles/Rengar_Skin08_Z_WeaponTrail_01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.768626988, 1, 1 }
                            { 0, 0.513724983, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 70 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin08/Particles/Rengar_Skin08_AA_Trail_00.dds"
                FrameRate: f32 = 24
                NumFrames: u16 = 5
                TexDiv: vec2 = { 1, 5 }
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Cas_Max"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Cas_Max"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    10.6499996
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Skin02"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -90, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -250, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.340000004
                            0.550000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_ShoutRing.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Tar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Tar"
    }
    "Characters/Rengar/Skins/Skin2/Particles/rengar_skin02_recall_start_sound" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    10
                }
                EmitterName: string = "empty"
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_Black.dds"
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_Black.dds"
            }
        }
        ParticleName: string = "rengar_skin02_recall_start_sound"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/rengar_skin02_recall_start_sound"
        Flags: u16 = 164
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Max_Tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.3999996
                }
                Lifetime: option[f32] = {
                    0.150000006
                }
                EmitterName: string = "SlashSkin2"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.223528996, 0.341176003, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.223528996, 0.341176003, 1, 1 }
                            { 0.223528996, 0.341176003, 1, 1 }
                            { 0.223528996, 0.341176003, 1, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 90, -90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 180, 90, -90 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 50, 100 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Slash_New.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1.79999995 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.400000006 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                Lifetime: option[f32] = {
                    0.150000006
                }
                EmitterName: string = "SlashAdd1"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.650979996, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.650979996, 1, 1 }
                            { 0, 0.650979996, 1, 1 }
                            { 0, 0.650979996, 1, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 90, -90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 180, 90, -90 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Slash_New.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1.79999995 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.400000006 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0196080003, 0.0392160006, 0.137254998, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0196080003, 0.0392160006, 0.137254998, 1 }
                            { 0.0196080003, 0.0392160006, 0.137254998, 0 }
                        }
                    }
                }
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 350, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/common_Kalista_Skin01_P_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "powerFlare"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.423528999, 0.643136978, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.423528999, 0.643136978, 1, 1 }
                            { 0.423528999, 0.643136978, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_flareblue.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    0.150000006
                }
                EmitterName: string = "Basic"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 2200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 2200, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 5, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 10, 10 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 10, 10 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 100, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Shafts.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Max_Tar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Max_Tar"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Leap_Grass" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Grass_01"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 300, 1000 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 300, 1000 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -500, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -500, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 100, 90, 40 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 100, 90, 40 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 300, 300 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 22, 22, 22 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 22, 22, 22 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_P_Leap_Grass.dds"
                NumFrames: u16 = 8
                TexDiv: vec2 = { 4, 2 }
            }
        }
        ParticleName: string = "Rengar_Skin02_P_Leap_Grass"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Leap_Grass"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Primary_Target_Enhanced" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                EmitterName: string = "Smoke_heart"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 50, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.113724999, 0.113724999, 0.113724999, 0 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0.400000006
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                0.400000006
                                1
                            }
                            Values: list[f32] = {
                                0.800000012
                                0.400000006
                                1.60000002
                                2.79999995
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.5
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/common_test_texture_mult.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 0.699999988 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 40, 0.699999988 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 1 }
                            { 1, 1, 1 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_Heart.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_skin02_r_heart_mult.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "background_smoke"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 120, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.349019617, 0.686274529, 0.854902029, 0.466666698 }
                }
                Pass: i16 = -11
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 200, 10 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_base_z_mult.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                }
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_base_z_alpha_circle.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.620004594, 0.910002291, 0.360006094 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.620004594, 0.910002291, 0 }
                            { 0, 0.620004594, 0.910002291, 0.360006094 }
                            { 0, 0.620004594, 0.910002291, 0 }
                        }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -6 }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                Texture: string = "ASSETS/Shared/Particles/3161color-hold.SRT_DURIAN_2024.dds"
                NumFrames: u16 = 4
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.400000006, 0.200000003 }
                }
            }
        }
        ParticleName: string = "Rengar_Skin02_R_Primary_Target_Enhanced"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Primary_Target_Enhanced"
        SoundPersistentDefault: string = "Play_sfx_Rengar_RengarR_buffactivateheartbeat"
        Flags: u16 = 213
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Roar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    0.649999976
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Skin02"
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -90, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -250, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 600, 600, 600 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.340000004
                            0.550000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_ShoutRing.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "ShellRing"
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 475, 475, 475 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Ring.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                }
                ParticleLinger: option[f32] = {
                    10.6000004
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "GroundRing"
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_GroundRing_Geo.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.699999988, 0.699999988, 0.699999988, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec4] = {
                            { 0.699999988, 0.699999988, 0.699999988, 0 }
                            { 0.699999988, 0.699999988, 0.699999988, 1 }
                            { 0.699999988, 0.699999988, 0.699999988, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.70000005, 0.5, 1.70000005 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_GroundRing_Sub.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1.75 }
                }
                TexDiv: vec2 = { 0.699999988, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ShellDistort"
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Rampdown_RGBA.DDS"
                BlendMode: u8 = 1
                Pass: i16 = 100
                MeshRenderFlags: u8 = 0
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.0399999991
                    NormalMapTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Distortion_NormalMap.dds"
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 500, 500 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_Distortion.DDS"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Roar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Roar"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade_Child" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Blue_Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -10, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.517647028, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.517647028, 1, 1 }
                            { 0, 0.517647028, 1, 1 }
                            { 0, 0, 1, 0.200000003 }
                            { 0, 0, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -40
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 35, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.500010014
                                    0.500020027
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                    -1.5
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 35, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 1, 0 }
                            { 3.5, 3, 0 }
                            { 4, 6, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Flames_add_4x4.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                EmitterName: string = "Blue_Glow_Sub"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -10, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 2
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.75 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -50
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 25, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.500010014
                                    0.500020027
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                    -1.5
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 25, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                            { 4, 3, 0 }
                            { 5, 6, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Flames_sub_4x4.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Buf_Blade_Child"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade_Child"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Strike" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0700000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.07000005
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Swipe1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_mesh_swipes_02.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.5
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 2
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.300000012, 1 }
                            { 1, 1, 1 }
                            { 0, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_swipe_tex.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -2.79999995, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                }
                TexDiv: vec2 = { 1, 1.5 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.170000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.3999996
                }
                Lifetime: option[f32] = {
                    1.16999996
                }
                IsSingleParticle: flag = true
                EmitterName: string = "bottom_dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 300 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.725490212 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 260, 120, 0 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_skin02_Q_ground_swipe.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.100000001
                }
                Lifetime: option[f32] = {
                    1.14999998
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Bright_glow"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 500 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 60, 300 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 0.666666985, 1, 1, 0 }
                            { 0.133332998, 0.160784006, 0.666666985, 0.811765015 }
                            { 0.219607994, 0.129411995, 0.403921992, 0.474510014 }
                            { 0.254902005, 0.149020001, 0.329412013, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 100, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 0 }
                            { 2, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Yorick_Base_R_Aura_self.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0700000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 6
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.39999998
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    0.899999976
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    0.300000012
                                    0.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.39999998
                        }
                    }
                }
                Lifetime: option[f32] = {
                    1.07000005
                }
                IsSingleParticle: flag = true
                EmitterName: string = "mesh_Sparkles_right"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 3000 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 12 }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 50, 20, 150 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 200 }
                }
                BlendMode: u8 = 5
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.250980407 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.36470601, 0, 0, 1 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 15, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 15, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 3, 1 }
                            { 0.300000012, 2, 1 }
                            { 0.150000006, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Shafts.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Strike"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Strike"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA2_Cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashSkin02"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -150, 120, 100 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 150, 185 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.5 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "SlashAdd"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -150, 120, 100 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 150, 190 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1.5, 1.5 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -2.5 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
        }
        ParticleName: string = "Rengar_Skin02_BA2_Cas"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA2_Cas"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Heal" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 75
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    3
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    0.25
                }
                EmitterName: string = "healspark"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 3, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 3, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 800, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 800, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 1, 3 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 60, 25, 60 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.5
                                        0.50999999
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        -0.5
                                        0.5
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.5
                                        0.50999999
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        -0.5
                                        0.5
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 60, 25, 60 }
                            }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Heal_Spark_RGBA.DDS"
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 25, 25 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0.100000001, 0.100000001, 0.100000001 }
                            { 0.300000012, 0.300000012, 0.300000012 }
                            { 1, 10, 1 }
                            { 0.300000012, 0.300000012, 0.300000012 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Heal_Spark.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Heal"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Heal"
        SoundOnCreateDefault: string = "Play_sfx_Rengar_RengarWBuff_buffactivate"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.3999996
                }
                Lifetime: option[f32] = {
                    0.150000006
                }
                EmitterName: string = "SlashSkin02"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0784310028, 0.113724999, 0.345097989, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0784310028, 0.113724999, 0.345097989, 1 }
                            { 0.0784310028, 0.113724999, 0.345097989, 1 }
                            { 0.0784310028, 0.113724999, 0.345097989, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 90, -90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 180, 90, -90 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 50, 100 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Slash_New.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1.79999995 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.400000006 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    10.5
                }
                Lifetime: option[f32] = {
                    0.150000006
                }
                EmitterName: string = "SlashAdd"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_WeaponTrail.sco"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.149020001, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.149020001, 1, 1 }
                            { 0, 0.149020001, 1, 1 }
                            { 0, 0.149020001, 1, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 90, -90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 180, 90, -90 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 50, 100 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_Q_Slash_New.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1.79999995 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -0.400000006 }
                }
                TexDiv: vec2 = { 4, 1 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "powerFlare"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.423528999, 0.643136978, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.423528999, 0.643136978, 1, 1 }
                            { 0.423528999, 0.643136978, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_flareblue.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Tar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Tar"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Primary_Target" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "eyes"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 130, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.435294002 }
                        }
                    }
                }
                Pass: i16 = 100
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 70, 0 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_tar_vision_eye.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "dark_eyes_pulse"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 26, 26, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 26, 26, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 130, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.168626994, 0.0705880001, 0.239216, 1 }
                            { 0.058823999, 0.058823999, 0.129411995, 0.505882025 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 90
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 70, 0 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_Base_R_tar_vision_eye_pulse.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "yellow_eye_glow_pulse"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 130, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 0.882353008, 0.717647016, 0 }
                        }
                    }
                }
                Pass: i16 = 102
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 65, 65, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 1, 1 }
                            { 1.20000005, 1.39999998, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_tar_vision_eye_glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "yellow_eye_glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 124, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0705882385, 0.101960793, 0.239215702, 0.713725507 }
                }
                Pass: i16 = 90
                MiscRenderFlags: u8 = 1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 100, 1 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_R_tar_vision_eye_glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.75
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            4
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1.5
                }
                EmitterName: string = "Smoke_AE"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0.400000006
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1000, 200, 1000 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    -1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1000, 200, 1000 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 13, 2, 13 }
                }
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 50, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -50
                                    50
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    4
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -50
                                    50
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 50, 1 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.113724999, 0.113724999, 0.113724999, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0.5
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                0.400000006
                                1
                            }
                            Values: list[f32] = {
                                1
                                0.5
                                1
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.5
                    ErosionSliceWidth: f32 = 10
                    ErosionMapName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/common_test_texture_mult.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -60
                                    60
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 50, 0.699999988 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 50, 0.699999988 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 2, 4, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_skin02_R_smoke_dust.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "wisp"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -30, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.333332986, 0.498039007, 0 }
                            { 0, 0.478430986, 0.701960981, 1 }
                            { 0, 0, 0.231372997, 0 }
                        }
                    }
                }
                Pass: i16 = -500
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 90 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, -230, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    6
                                    10
                                    13
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, -230, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.600000024, 2, 1 }
                            { 1, 2, 1 }
                            { 1.20000005, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_skin02_R_glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "groundshadow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -70, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.00784313772, 0.117647067, 0.239215702, 0.549019635 }
                }
                Pass: i16 = -11
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 120, 10 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Rengar_base_z_alpha_circle.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wisp1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 100, 0 }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.388235331, 1, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.666666985, 0.333332986, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 200
                AlphaRef: u8 = 0
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 90, 8 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 2, 0.600000024, 1 }
                            { 2, 1, 1 }
                            { 2, 1.20000005, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/Talon_base_w_mis_02_spark.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_R_Primary_Target"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Primary_Target"
        Flags: u16 = 197
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                ParticleLinger: option[f32] = {
                    10.6499996
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Skin02"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -90, 0, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -250, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.340000004
                            0.550000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0.699999988, 0.699999988, 0.699999988 }
                            { 0.899999976, 0.899999976, 0.899999976 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_ShoutRing.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 32
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterLinger: option[f32] = {}
                EmitterName: string = "Zap"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 2, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        30
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 2, 0 }
                            }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveRay {}
                ParticleColorTexture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Z_RGB.dds"
                BlendMode: u8 = 2
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 65, 40, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.649999976
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 65, 40, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 4, 0, 0 }
                            { 4, 3, 0 }
                            { 0, 5.5, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_W_Barbs.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_W_Max_Tar"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Tar"
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Rengar_Q_Buf_Blade_Child"
                        }
                    }
                }
                EmitterName: string = "Blue_Flames_Parent"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 1, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        60
                                        130
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 1, 0 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                Pass: i16 = -40
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Blade_Mesh_Flame_Dark1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 75, -2.5 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Buf_Blade_Flame.sco"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.294117987, 0.294117987, 0.294117987, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.294117987, 0.294117987, 0.294117987, 0 }
                            { 0.294117987, 0.294117987, 0.294117987, 0.800000012 }
                            { 0.294117987, 0.294117987, 0.294117987, 0 }
                        }
                    }
                }
                Pass: i16 = 20
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.10000002, 1.10000002, 1.10000002 }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_Q_Buf_Blade_Flame_2x2.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.150000006, 0.25 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { -0.150000006, 0.25 }
                        }
                    }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
                TexDiv: vec2 = { 4, 4 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterName: string = "powerFlareBurst"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.313724995, 0.850979984, 1, 0.800000012 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.313724995, 0.850979984, 1, 0.800000012 }
                            { 0.313724995, 0.850979984, 1, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Base/Particles/common_flareblue.dds"
            }
        }
        ParticleName: string = "Rengar_Skin02_Q_Buf_Blade"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade"
        Flags: u16 = 198
    }
    "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Buf_Max" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 45
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "ShadowWispsVert"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -0.75, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -0.75, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[f32] = {
                            1
                            0.600000024
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 5, 0, 0 }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 2
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -50
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 75, 75, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 75, 75, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_shadowwisps_sub_4x4.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                EmitterName: string = "ShadowWispsAdd"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -0.75, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -0.75, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[f32] = {
                            1
                            0.600000024
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 5, 0, 0 }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -30
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 85, 75, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 85, 75, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Rengar/Skins/Skin02/Particles/Rengar_Skin02_shadowwisps_add_4x4.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
            }
        }
        ParticleName: string = "Rengar_Skin02_P_Buf_Max"
        ParticlePath: string = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Buf_Max"
        SoundOnCreateDefault: string = "Play_sfx_Rengar_RengarPEmp_buffactivate"
    }
    "Characters/Rengar/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Rengar_BA1_Cas" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA1_Cas"
            "Rengar_BA2_Cas" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA2_Cas"
            "Rengar_BA3_Cas" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_BA3_Cas"
            "Rengar_BA_tar_01" = "Characters/Rengar/Skins/Skin0/Particles/Rengar_Base_BA_tar_01"
            "Rengar_BA_tar_crit_01" = "Characters/Rengar/Skins/Skin0/Particles/Rengar_Base_BA_tar_crit_01"
            "Rengar_C_Cas" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_C_Cas"
            "Rengar_E_Max_Mis" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Max_Mis"
            "Rengar_E_Max_Tar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Max_Tar"
            "Rengar_E_Mis" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Mis"
            "Rengar_E_Tar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_E_Tar"
            0x12c0cd20 = 0x44ea4b4e
            "Rengar_P_Buf_Enhanced_Ring" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Buf_Enhanced_Ring"
            "Rengar_P_Leap_Grass" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Leap_Grass"
            0x4b2693bb = 0xd8b8f649
            0x7042df7a = 0xfa63b080
            "Rengar_Q_AS_Buf" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_AS_Buf"
            "Rengar_Q_Buf_Blade" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade"
            "Rengar_Q_Buf_Blade_Max" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade_Max"
            "Rengar_Q_Buf_Claw" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Claw"
            "Rengar_Q_Buf_Claw_Max" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Claw_Max"
            "Rengar_Q_Cas" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Cas"
            "Rengar_Q_Cas_Max" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Cas_Max"
            "Rengar_Q_Max_Tar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Max_Tar"
            "Rengar_Q_Strike" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Strike"
            "Rengar_Q_Tar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Tar"
            0xe03e0048 = 0xb444f1b6
            "Rengar_R_Buf" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Buf"
            "Rengar_R_Primary_Target" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Primary_Target"
            "Rengar_R_Primary_Target_Enhanced" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Primary_Target_Enhanced"
            "Rengar_R_Secondary_Target" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_R_Secondary_Target"
            0xb6e54f46 = 0xe7cb0d58
            0x6a8d8a6c = 0x991c6796
            "Rengar_W_Emp_Buf2" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Emp_Buf2"
            "Rengar_W_Heal" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Heal"
            "Rengar_W_Max_Buf" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Buf"
            "Rengar_W_Max_Roar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Roar"
            "Rengar_W_Max_Tar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Max_Tar"
            "Rengar_W_Roar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Roar"
            "Rengar_W_Tar" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_W_Tar"
            0xd04d91f2 = 0x03bf08e1
            0xfed74afb = 0x7bb4caa0
            0x63e95512 = 0xf0337669
            0xddb01ae4 = 0x46aaf2c7
            0xcc4fc42d = 0xecb0305e
            0x769e3c03 = 0xc5fd329c
            0xbe6b790d = 0xd9542556
            "Rengar_P_Buf_Max" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_P_Buf_Max"
            0xcdc6293f = 0xa60f0d10
            "Rengar_Q_Buf_Blade_Child" = "Characters/Rengar/Skins/Skin2/Particles/Rengar_Skin02_Q_Buf_Blade_Child"
            0xc0b74aaf = "Characters/Rengar/Skins/Skin2/Particles/rengar_skin02_recall_start_sound"
        }
    }
}
