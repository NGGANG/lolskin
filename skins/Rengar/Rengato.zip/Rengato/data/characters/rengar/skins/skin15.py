#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Rengar_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Rengar/Rengar.bin"
    "DATA/Characters/Rengar/Animations/Skin15.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3.bin"
    "DATA/Rengar_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin3_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Rengar_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22.bin"
}
entries: map[hash,embed] = {
    "Characters/Rengar/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "RengarSkin15"
        MetaDataTags: string = "gender:male,race:vastaya,faction:ixtal,appearance:feline,"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Rengar/Skins/Skin15/RengarLoadScreen_15.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Rengar/Skins/Skin15/RengarLoadscreen_15_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Rengar"
                "RengarSkin15"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Rengar_Skin15_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Rengar/Skins/Skin15/Rengar_Skin15_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Rengar/Skins/Skin15/Rengar_Skin15_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_RengarSkin15_Dance3D_buffactivate"
                        "Play_sfx_RengarSkin15_Death3D_cast"
                        "Play_sfx_RengarSkin15_Joke3D_buffactivate"
                        "Play_sfx_RengarSkin15_Laugh3D_buffactivate"
                        "Play_sfx_RengarSkin15_Recall3D_buffactivate"
                        "Play_sfx_RengarSkin15_RengarBasicAttack2_OnCast"
                        "Play_sfx_RengarSkin15_RengarBasicAttack2_OnHit"
                        "Play_sfx_RengarSkin15_RengarBasicAttack3_OnCast"
                        "Play_sfx_RengarSkin15_RengarBasicAttack3_OnHit"
                        "Play_sfx_RengarSkin15_RengarBasicAttack_OnCast"
                        "Play_sfx_RengarSkin15_RengarBasicAttack_OnHit"
                        "Play_sfx_RengarSkin15_RengarCritAttack_OnCast"
                        "Play_sfx_RengarSkin15_RengarCritAttack_OnHit"
                        "Play_sfx_RengarSkin15_RengarE_hit"
                        "Play_sfx_RengarSkin15_RengarE_missilelaunch"
                        "Play_sfx_RengarSkin15_RengarE_OnCast"
                        "Play_sfx_RengarSkin15_RengarEEmp_OnCast"
                        "Play_sfx_RengarSkin15_RengarEEmpmis_OnHit"
                        "Play_sfx_RengarSkin15_RengarEEmpmis_OnMissileLaunch"
                        "Play_sfx_RengarSkin15_RengarP_cast"
                        "Play_sfx_RengarSkin15_RengarP_leaphit"
                        "Play_sfx_RengarSkin15_RengarPEmp_buffactivate"
                        "Play_sfx_RengarSkin15_RengarQ_buffactivate"
                        "Play_sfx_RengarSkin15_RengarQ_OnBuffDeactivate"
                        "Play_sfx_RengarSkin15_RengarQ_OnCast"
                        "Play_sfx_RengarSkin15_RengarQAttack_OnCast"
                        "Play_sfx_RengarSkin15_RengarQAttack_OnHit"
                        "Play_sfx_RengarSkin15_RengarQEmp_OnBuffDeactivate"
                        "Play_sfx_RengarSkin15_RengarQEmp_OnCast"
                        "Play_sfx_RengarSkin15_RengarQEmpAttack_OnCast"
                        "Play_sfx_RengarSkin15_RengarQEmpAttack_OnHit"
                        "Play_sfx_RengarSkin15_RengarR_buffactivateheartbeat"
                        "Play_sfx_RengarSkin15_RengarR_buffactivateheartbeat_stop"
                        "Play_sfx_RengarSkin15_RengarR_OnBuffDeactivate"
                        "Play_sfx_RengarSkin15_RengarR_OnCast"
                        "Play_sfx_RengarSkin15_RengarRpassivebuff_OnBuffDeactivate"
                        "Play_sfx_RengarSkin15_RengarRSecondaryTarget_end"
                        "Play_sfx_RengarSkin15_RengarRSecondaryTarget_start"
                        "Play_sfx_RengarSkin15_RengarRstealth_end"
                        "Play_sfx_RengarSkin15_RengarRstealth_start"
                        "Play_sfx_RengarSkin15_RengarW_OnCast"
                        "Play_sfx_RengarSkin15_RengarWBuff_buffactivate"
                        "Play_sfx_RengarSkin15_RengarWEmp_OnCast"
                        "Play_sfx_RengarSkin15_Taunt3D_buffactivate"
                        "Play_sfx_RengarSkin15_Winddown3D_buffactivate"
                        "Stop_sfx_RengarSkin15_RengarQ_buffactivate"
                    }
                }
                BankUnit {
                    Name: string = "Rengar_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Rengar/Skins/Base/Rengar_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Rengar/Skins/Base/Rengar_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Rengar/Skins/Base/Rengar_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Rengar_Attack2DGeneral"
                        "Play_vo_Rengar_Death3D"
                        "Play_vo_Rengar_FirstEncounter3DKhazix"
                        "Play_vo_Rengar_Joke3DGeneral"
                        "Play_vo_Rengar_Laugh3DGeneral"
                        "Play_vo_Rengar_Move2DStandard"
                        "Play_vo_Rengar_RengarBasicAttack2_cast3D"
                        "Play_vo_Rengar_RengarBasicAttack3_cast3D"
                        "Play_vo_Rengar_RengarBasicAttack_cast3D"
                        "Play_vo_Rengar_RengarBonetoothStack1"
                        "Play_vo_Rengar_RengarBonetoothStack2"
                        "Play_vo_Rengar_RengarBonetoothStack3"
                        "Play_vo_Rengar_RengarBonetoothStack4"
                        "Play_vo_Rengar_RengarBonetoothStack5"
                        "Play_vo_Rengar_RengarCritAttack_cast3D"
                        "Play_vo_Rengar_RengarE_cast3D"
                        "Play_vo_Rengar_RengarEEmp_cast3D"
                        "Play_vo_Rengar_RengarQ_cast3D"
                        "Play_vo_Rengar_RengarQEmp_cast3D"
                        "Play_vo_Rengar_RengarR_cast3D"
                        "Play_vo_Rengar_RengarW_cast3D"
                        "Play_vo_Rengar_RengarWEmp_cast3D"
                        "Play_vo_Rengar_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Rengar/Animations/Skin15"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Rengar/Skins/Skin15/Rengar_Skin15.skl"
            SimpleSkin: string = "ASSETS/Characters/Rengar/Skins/Skin15/Rengar_Skin15.skn"
            Texture: string = "ASSETS/Characters/Rengar/Skins/Skin15/Rengar_Skin15_TX_CM.dds"
            SkinScale: f32 = 0.899999976
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 180, 250, 180 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Box_Mat bongos"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Rengar/Skins/Skin15/Rengar_Skin15_Recall_TX_CM.dds"
                    Submesh: string = "Box_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Rengar/Skins/Skin15/Rengar_Skin15_Bongo_TX_CM.dds"
                    Submesh: string = "bongos"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x49c3f916
                    mEndingJointName: hash = 0x4dc3ff62
                    mDefaultMaskName: hash = 0xef7cfc3b
                    mVelMultiplier: f32 = 1
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Rengar_Z_Idle"
                BoneName: string = "C_Buffbone_Glb_Chest_Loc"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Rengar/HUD/Rengar_Circle_15.dds"
        mContextualActionData: link = "Characters/Rengar/CAC/Rengar_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Rengar/HUD/Rengar_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Rengar/HUD/Rengar_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Rengar/Skins/Skin15/Resources"
    }
    "Characters/Rengar/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Rengar_BA1_Cas" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_BA1_Cas"
            "Rengar_BA2_Cas" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_BA2_Cas"
            "Rengar_BA3_Cas" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_BA3_Cas"
            "Rengar_BA_tar_01" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_BA_tar_01"
            "Rengar_BA_tar_crit_01" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_BA_tar_crit_01"
            "Rengar_C_Cas" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_C_Cas"
            "Rengar_E_Max_Mis" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_E_Max_Mis"
            "Rengar_E_Max_Tar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_E_Max_Tar"
            "Rengar_E_Mis" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_E_Mis"
            "Rengar_E_Tar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_E_Tar"
            0x12c0cd20 = 0x44ea4b4e
            "Rengar_P_Buf_Enhanced_Ring" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_P_Buf_Enhanced_Ring"
            "Rengar_P_Leap_Grass" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_P_Leap_Grass"
            0x4b2693bb = 0xd8b8f649
            0x7042df7a = 0xfa63b080
            "Rengar_Q_AS_Buf" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_AS_Buf"
            "Rengar_Q_Buf_Blade" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Buf_Blade"
            "Rengar_Q_Buf_Blade_Max" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Buf_Blade_Max"
            "Rengar_Q_Buf_Claw" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Buf_Claw"
            "Rengar_Q_Buf_Claw_Max" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Buf_Claw_Max"
            "Rengar_Q_Cas" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Cas"
            "Rengar_Q_Cas_Max" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Cas_Max"
            "Rengar_Q_Max_Tar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Max_Tar"
            "Rengar_Q_Strike" = "Characters/Rengar/Skins/Skin0/Particles/Rengar_Base_Q_Strike"
            "Rengar_Q_Tar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Q_Tar"
            0xe03e0048 = 0xb444f1b6
            "Rengar_R_Buf" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_R_Buf"
            "Rengar_R_Primary_Target" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_R_Primary_Target"
            "Rengar_R_Primary_Target_Enhanced" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_R_Primary_Target_Enhanced"
            "Rengar_R_Secondary_Target" = "Characters/Rengar/Skins/Skin0/Particles/Rengar_Base_R_Secondary_Target"
            0xb6e54f46 = 0xe7cb0d58
            0x6a8d8a6c = 0x991c6796
            "Rengar_W_Emp_Buf2" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_W_Emp_Buf2"
            "Rengar_W_Heal" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_W_Heal"
            "Rengar_W_Max_Buf" = "Characters/Rengar/Skins/Skin0/Particles/Rengar_Base_W_Max_Buf"
            "Rengar_W_Max_Roar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_W_Max_Roar"
            "Rengar_W_Max_Tar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_W_Max_Tar"
            "Rengar_W_Roar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_W_Roar"
            "Rengar_W_Tar" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_W_Tar"
            0xd04d91f2 = 0x03bf08e1
            0xfed74afb = 0x7bb4caa0
            0x63e95512 = 0xf0337669
            0xddb01ae4 = 0x46aaf2c7
            0xcc4fc42d = 0xecb0305e
            0x769e3c03 = 0xc5fd329c
            0xbe6b790d = 0xd9542556
            "Rengar_P_Buf_Max" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_P_Buf_Max_New"
            0xcdc6293f = 0xa60f0d10
            "Rengar_Z_RecallBoxStars" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Z_RecallBoxStars"
            "Rengar_Z_Heart" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Z_Heart"
            "Rengar_Z_Idle" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_Z_Idle"
            "Rengar_R_Leap" = "Characters/Rengar/Skins/Skin15/Particles/Rengar_Skin15_R_Leap"
        }
    }
}
