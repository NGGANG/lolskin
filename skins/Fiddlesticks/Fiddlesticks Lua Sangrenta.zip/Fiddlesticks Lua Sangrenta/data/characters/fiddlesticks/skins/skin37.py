#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/FiddleSticks/FiddleSticks.bin"
    "DATA/Characters/FiddleSticks/Animations/Skin37.bin"
    "DATA/FiddleSticks_Skins_Skin0_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin3_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
    "DATA/FiddleSticks_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin5_Skins_Skin9.bin"
    "DATA/FiddleSticks_Skins_Skin0_Skins_Skin1_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin3_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
    "DATA/FiddleSticks_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45.bin"
}
entries: map[hash,embed] = {
    "Characters/FiddleSticks/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "FiddleSticksSkin37"
        MetaDataTags: string = "race:demon,element:dark,skinline:bloodmoon"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticksLoadScreen_37.SKINS_FiddleSticks_Skin37.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "FiddleSticks"
                "FiddlesticksSkin37"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Fiddlesticks_Skin37_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_FiddlesticksSkin37_Dance3D_into"
                        "Play_sfx_FiddlesticksSkin37_Dance3D_loop"
                        "Play_sfx_FiddlesticksSkin37_Death3D_buffactivate"
                        "Play_sfx_FiddlesticksSkin37_Death3D_effigies"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack2_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack2_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack2_OnMissileLaunch"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack_OnMissileLaunch"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttackMelee2_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttackMelee2_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttackMelee_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksBasicAttackMelee_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksCritAttack_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksCritAttack_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksCritAttack_OnMissileLaunch"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksCritAttackMelee_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksCritAttackMelee_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksE_cast_self"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksE_hit_regular"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksE_hit_slowed"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksE_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksPassive_lvl6_sweeper"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksPassive_OnBuffActivate"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksQ_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksQ_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksQmissilefear_OnHit"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksQmissilefear_OnMissileLaunch"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksQmissilenofear_OnMissileLaunch"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksQpassiveterrify_OnBuffActivate"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksR_cast_self"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksR_OnBuffActivate"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksR_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksR_run"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksScarecrowEffigy_OnHitLocation"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksW_finaltick"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksW_OnCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksWcosmeticmissilebig_OnMissileCast"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksWdrain_OnBuffActivate"
                        "Play_sfx_FiddlesticksSkin37_FiddlesticksWdrain_OnBuffDeactivate"
                        "Play_sfx_FiddlesticksSkin37_Idle_IdleIn_A"
                        "Play_sfx_FiddlesticksSkin37_Idle_IdleIn_B"
                        "Play_sfx_FiddlesticksSkin37_Idle_IdleIn_C"
                        "Play_sfx_FiddlesticksSkin37_Idle_loop"
                        "Play_sfx_FiddlesticksSkin37_Joke3D_buffactivate"
                        "Play_sfx_FiddlesticksSkin37_Laugh3D_buffactivate"
                        "Play_sfx_FiddlesticksSkin37_Recall3D_winddown"
                        "Play_sfx_FiddlesticksSkin37_Recall_leadin"
                        "Play_sfx_FiddlesticksSkin37_Respawn3D_buffactivate"
                        "Play_sfx_FiddlesticksSkin37_Taunt3D_buffactivate"
                        "Stop_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack2_OnMissileLaunch"
                        "Stop_sfx_FiddlesticksSkin37_FiddlesticksBasicAttack_OnMissileLaunch"
                        "Stop_sfx_FiddlesticksSkin37_FiddlesticksCritAttack_OnMissileLaunch"
                        "Stop_sfx_FiddlesticksSkin37_FiddlesticksQmissilefear_OnMissileLaunch"
                        "Stop_sfx_FiddlesticksSkin37_FiddlesticksQmissilenofear_OnMissileLaunch"
                        "Stop_sfx_FiddlesticksSkin37_FiddlesticksQpassiveterrify_OnBuffActivate"
                    }
                }
                BankUnit {
                    Name: string = "Fiddlesticks_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Fiddlesticks/Skins/Base/Fiddlesticks_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Fiddlesticks/Skins/Base/Fiddlesticks_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Fiddlesticks/Skins/Base/Fiddlesticks_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Fiddlesticks_Attack2DGeneral"
                        "Play_vo_Fiddlesticks_Death3D"
                        "Play_vo_Fiddlesticks_FiddlesticksBasicAttack2_cast3D"
                        "Play_vo_Fiddlesticks_FiddlesticksBasicAttack_cast3D"
                        "Play_vo_Fiddlesticks_FiddlesticksCritAttack_cast3D"
                        "Play_vo_Fiddlesticks_FiddlesticksE_cast3D"
                        "Play_vo_Fiddlesticks_FiddlesticksR_cast3D"
                        "Play_vo_Fiddlesticks_FirstEncounter3DAnnie"
                        "Play_vo_Fiddlesticks_FirstEncounter3DDemacia"
                        "Play_vo_Fiddlesticks_FirstEncounter3DEvelynn"
                        "Play_vo_Fiddlesticks_FirstEncounter3DGaren"
                        "Play_vo_Fiddlesticks_FirstEncounter3DJinx"
                        "Play_vo_Fiddlesticks_FirstEncounter3DKindred"
                        "Play_vo_Fiddlesticks_FirstEncounter3DLux"
                        "Play_vo_Fiddlesticks_FirstEncounter3DMissFortune"
                        "Play_vo_Fiddlesticks_FirstEncounter3DNocturne"
                        "Play_vo_Fiddlesticks_FirstEncounter3DNunu"
                        "Play_vo_Fiddlesticks_FirstEncounter3DRiven"
                        "Play_vo_Fiddlesticks_FirstEncounter3DSoraka"
                        "Play_vo_Fiddlesticks_FirstEncounter3DSwain"
                        "Play_vo_Fiddlesticks_FirstEncounter3DSylas"
                        "Play_vo_Fiddlesticks_FirstEncounter3DTahmKench"
                        "Play_vo_Fiddlesticks_FirstEncounter3DVayne"
                        "Play_vo_Fiddlesticks_FirstEncounter3DYasuo"
                        "Play_vo_Fiddlesticks_Joke3DGeneral"
                        "Play_vo_Fiddlesticks_JokeResponse3DGeneral"
                        "Play_vo_Fiddlesticks_Kill3DAnnie"
                        "Play_vo_Fiddlesticks_Kill3DEvelynn"
                        "Play_vo_Fiddlesticks_Kill3DGaren"
                        "Play_vo_Fiddlesticks_Kill3DGeneral"
                        "Play_vo_Fiddlesticks_Kill3DJinx"
                        "Play_vo_Fiddlesticks_Kill3DKindred"
                        "Play_vo_Fiddlesticks_Kill3DLux"
                        "Play_vo_Fiddlesticks_Kill3DMissFortune"
                        "Play_vo_Fiddlesticks_Kill3DNocturne"
                        "Play_vo_Fiddlesticks_Kill3DNunu"
                        "Play_vo_Fiddlesticks_Kill3DPenta"
                        "Play_vo_Fiddlesticks_Kill3DRiven"
                        "Play_vo_Fiddlesticks_Kill3DSoraka"
                        "Play_vo_Fiddlesticks_Kill3DSwain"
                        "Play_vo_Fiddlesticks_Kill3DSylas"
                        "Play_vo_Fiddlesticks_Kill3DTahmKench"
                        "Play_vo_Fiddlesticks_Kill3DVayne"
                        "Play_vo_Fiddlesticks_Kill3DYasuo"
                        "Play_vo_Fiddlesticks_Laugh3DGeneral"
                        "Play_vo_Fiddlesticks_Move2DFirst"
                        "Play_vo_Fiddlesticks_Move2DLong"
                        "Play_vo_Fiddlesticks_Move2DStandard"
                        "Play_vo_Fiddlesticks_Recall3DGeneral"
                        "Play_vo_Fiddlesticks_Respawn2DGeneral"
                        "Play_vo_Fiddlesticks_Spell3DPCast"
                        "Play_vo_Fiddlesticks_Taunt3DGeneral"
                        "Play_vo_Fiddlesticks_TauntResponse3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = 0x44c89fe5
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37.SKINS_FiddleSticks_Skin37.skl"
            SimpleSkin: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37.SKINS_FiddleSticks_Skin37.skn"
            Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 140, 300, 140 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "L_Demon_Arm Lantern Tongue R_Demon_Arm Recall"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x896f9ad9
                    Submesh: string = "Weapon"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                    Submesh: string = "R_Demon_Arm"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                    Submesh: string = "L_Demon_Arm"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                    Submesh: string = "Tongue"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                    Submesh: string = "Lantern"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Ghost_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                    Submesh: string = "Recall"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xbd42da01
                    mEndingJointName: hash = "R_Hand"
                    mDefaultMaskName: hash = 0x52541a39
                    mMaxBoneAngle: f32 = 50
                    mDampingValue: f32 = 0
                    mVelMultiplier: f32 = 0
                    mFrequency: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x840b6ffb
                    mEndingJointName: hash = 0xdabe2b5d
                    mDefaultMaskName: hash = 0x52541a39
                    mMaxBoneAngle: f32 = 50
                    mDampingValue: f32 = 0
                    mVelMultiplier: f32 = 0
                    mFrequency: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x8c0eead8
                    mEndingJointName: hash = 0xc291927e
                    mDefaultMaskName: hash = 0x52541a39
                    mMaxBoneAngle: f32 = 110
                    mDampingValue: f32 = 0
                    mVelMultiplier: f32 = 0
                    mFrequency: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xbc88194a
                    mEndingJointName: hash = 0xa069fc10
                    mDefaultMaskName: hash = 0x52541a39
                    mMaxBoneAngle: f32 = 110
                    mDampingValue: f32 = 0
                    mVelMultiplier: f32 = 0
                    mFrequency: f32 = 1
                }
            }
        }
        ArmorMaterial: string = "Wood"
        DefaultAnimations: list[string] = {
            "extras"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = 0x621d7b68
                BoneName: string = "C_Buffbone_Glb_Chest_Loc"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = 0xbc450d0a
                BoneName: string = "Buffbone_Glb_Weapon_1"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = 0xebc4f0f9
                BoneName: string = "C_Buffbone_Glb_Eye_Loc"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Fiddlesticks/HUD/FiddleSticks_Circle_37.SKINS_FiddleSticks_Skin37.dds"
        mContextualActionData: link = "Characters/FiddleSticks/CAC/FiddleSticks_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Fiddlesticks/HUD/FiddleSticks_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Fiddlesticks/HUD/FiddleSticks_Square.dds"
        }
        EmoteBuffbone: string = ""
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = 0xaa7eba20
    }
    0x495a29c5 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Opacity Override"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {}
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0, 0, 0.220004573 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.220004573, 0, 0, 1 }
                }
                Pass: i16 = 4
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0.454901963, 0.149019614, 0.164705887, 0 }
                    Fresnel: f32 = 0.00100000005
                    FresnelColor: vec4 = { 0.454901963, 0.149019614, 0.164705887, 0 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_Black.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Main2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.229999244, 0, 0.0399938971, 0.400000006 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 3
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                2
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.340000004
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Death_Eye_Scrolling.SKINS_FiddleSticks_Skin37.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.0500000007
                    FresnelColor: vec4 = { 0.200000003, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.25
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "outer edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.137254909, 0.0156862754, 0.00392156886, 0.34117648 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.649999976
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.137254909, 0.0156862754, 0.00392156886, 0.34117648 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.0980392173, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                MeshRenderFlags: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Z_Einstein_01_mult.SKINS_FiddleSticks_Skin37.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.01499999, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.970000029
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1.01499999, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_color-hold.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "weapon additive"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "weapon"
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.2399939, 0.00999465957, 0.00999465957, 0.400000006 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 8
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.340000004
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Death_Eye_Scrolling.SKINS_FiddleSticks_Skin37.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_Weapon_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "weapon alpha"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "weapon"
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0200045779, 0, 0.0500038154, 0.450003803 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 9
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.340000004
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Death_Eye_Scrolling.SKINS_FiddleSticks_Skin37.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0.356862754, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_Weapon_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.75
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[f32] = {
                            0
                            30
                            60
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.0500000007
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "additive"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.400000006, 0 }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 400, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 400, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 4, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 4, 4, 3 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 200, 100, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 100, 50 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 80, 100, 80 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 80, 100, 80 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00300000003
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 0.450003803 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 0.450003803 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.179995418, 0.179995418, 0.179995418, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                AlphaRef: u8 = 0
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 18, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 18, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.5, 1.5, 1.5 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/Lulu_Skin37_GlowGrid_02.SKINS_FiddleSticks_Skin37.dds"
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.75
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[f32] = {
                            0
                            30
                            60
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.0500000007
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            3
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "dark"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.400000006, 0 }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 200, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 4, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 4, 4, 3 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 150, 100, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 100, 200 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 80, 100, 80 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 80, 100, 80 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00300000003
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.149996191, 0.0800030529, 0.310002297, 0.549996197 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.149996191, 0.0800030529, 0.310002297, 0.549996197 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.179995418, 0.179995418, 0.179995418, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                AlphaRef: u8 = 0
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.5, 1.5, 1.5 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_Petal_Amber.SKINS_FiddleSticks_Skin37.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Main3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.770000756, 0.0399938971, 0.0399938971, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 7
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                2
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.340000004
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Death_Eye_Scrolling.SKINS_FiddleSticks_Skin37.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.200000003, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.860000014
                }
                EmitterName: string = "distorion"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Emote_Mark_distort_RGBA.SKINS_FiddleSticks_Skin37.dds"
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.0800030529 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.300007641 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.300007641 }
                            { 1, 1, 1, 0.300007641 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 20
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.00300000003
                    NormalMapTexture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Emote_glow_distort.SKINS_FiddleSticks_Skin37.dds"
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 300, 300 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1.39999998, 1.39999998, 1.39999998 }
                            { 1.70000005, 1.70000005, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_color-hold.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.75
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[f32] = {
                            0
                            30
                            60
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.0500000007
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "additive1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.400000006, 0 }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 4, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 4, 4, 3 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 200, 100, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 100, 50 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 80, 100, 80 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 80, 100, 80 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00300000003
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.117647059, 0.13333334, 0.690196097 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0.179995418, 0.179995418, 0.179995418, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                AlphaRef: u8 = 0
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 12, 10, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 12, 10, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.600000024
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.5, 1.5, 1.5 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_Petal_Amber.SKINS_FiddleSticks_Skin37.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 13
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.25
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterName: string = "Dustring"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 4, 3 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 4, 4, 3 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 150, 30, 200 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 30, 200 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, 30, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 30, 0 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.149019614, 0.0784313753, 0.305882365, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.149019614, 0.0784313753, 0.305882365, 0 }
                            { 0.149019614, 0.0784313753, 0.305882365, 1 }
                            { 0.149019614, 0.0784313753, 0.305882365, 1 }
                            { 0.149019614, 0.0784313753, 0.305882365, 0 }
                        }
                    }
                }
                Pass: i16 = 500
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Q_SmokeErode.SKINS_FiddleSticks_Skin37.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 60, 1.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 60, 1.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 2, 2, 2 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Base_fog_norm.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Z_Einstein_01_mult.SKINS_FiddleSticks_Skin37.dds"
                    TexDivMult: vec2 = { 4, 4 }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.800000012
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.400000006
                                        0.600000024
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 1 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            10
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.75
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Rocks"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 1600, -300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 30, 1600, -300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 6, 3 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -900, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -900, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 60
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.129411772, 0.0627451017, 0.0156862754, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.129411772, 0.0627451017, 0.0156862754, 1 }
                            { 0.128396764, 0.0627451017, 0.00793540943, 1 }
                            { 0.0999769345, 0.00221453281, 0.000738177623, 0 }
                        }
                    }
                }
                Pass: i16 = 111
                DepthBiasFactors: vec2 = { -1, -30 }
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 0 }
                }
                DirectionVelocityScale: f32 = 0.00200000009
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 150, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.25
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 15, 150, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Emote_Rocks_2X2.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 3.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Main4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.160006106, 0.100007631, 0.300007641, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 8
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                2
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.340000004
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Death_Eye_Scrolling.SKINS_FiddleSticks_Skin37.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.0399999991
                    FresnelColor: vec4 = { 0.368627459, 0.286274523, 0.568627477, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
        }
        ParticleName: string = "FiddleSticks_Skin37_Emote_Effigy_Death_Dissolve"
        ParticlePath: string = "Characters/FiddleSticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Emote_Effigy_Death_Dissolve"
        Flags: u16 = 198
    }
    0x65b9dadd = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.150000006
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 80
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                EmitterName: string = "aditive trail1"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -22, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 200, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0.0156862754, 0 }
                            { 0.890196085, 0.0274509806, 0.141176477, 1 }
                            { 1, 0.168627456, 0.419607848, 0 }
                        }
                    }
                }
                Pass: i16 = 14
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 9, 9 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1.29999995, 1.29999995, 1.29999995 }
                            { 0.200000003, 0.200000003, 0.200000003 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_FlameTrail.SKINS_FiddleSticks_Skin37.DDS"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                EmitterName: string = "Sparkles_Blue"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 20, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 5
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -15, 0, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.490196079, 0.125490203, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.990005314, 0.990005314, 0.990005314, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.990005314, 0.990005314, 0.990005314, 1 }
                            { 0.990005314, 0.990005314, 0.990005314, 1 }
                            { 0.990005314, 0.990005314, 0.990005314, 0 }
                        }
                    }
                }
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 15
                }
                0xcb13aff1: f32 = -60
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 16, 16, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.5
                            0.699999988
                            0.899999976
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1, 1, 1 }
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/Lulu_Skin37_GlowGrid_02.SKINS_FiddleSticks_Skin37.dds"
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Inner_Light2"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -10, 0, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.890196085, 0.0392156877, 0.0509803928, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.890196085, 0.0392156877, 0.0509803928, 0 }
                            { 0.890196085, 0.0392156877, 0.0509803928, 1 }
                            { 0.890196085, 0.0392156877, 0.0509803928, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                DepthBiasFactors: vec2 = { 1, 35 }
                ParticleIsLocalOrientation: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 30, 40, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/Fiddlesticks_Base_E_SoftMult.SKINS_FiddleSticks_Skin37.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                EmitterName: string = "Inner_Light6"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -15, 0, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.110002287, 0.0299992375, 0.349996179, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.110002287, 0.0299992375, 0.349996179, 0 }
                            { 0.110002287, 0.0299992375, 0.349996179, 0.500007629 }
                            { 0.110002287, 0.0299992375, 0.349996179, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 20
                }
                DepthBiasFactors: vec2 = { 1, 35 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0xa86c592f
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.960784316, 0.0470588244, 0.243137255, 0.360784322 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 5
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.00499999989
                    FresnelColor: vec4 = { 0.890196085, 0.321568638, 0.0549019612, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -3 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_W_Range_Indicator.SKINS_FiddleSticks_Skin37.dds"
                    0x38123c47: flag = true
                }
            }
        }
        ParticleName: string = "FiddleSticks_Skin37_P_Idle_Lantern_Glow"
        ParticlePath: string = "Characters/FiddleSticks/Skins/Skin37/Particles/FiddleSticks_Skin37_P_Idle_Lantern_Glow"
    }
    0x8efa1fad = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    12
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "alpha back drop"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.223529413, 0.141176477, 0.290196091, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.223529413, 0.141176477, 0.290196091, 0 }
                            { 0.223529413, 0.141176477, 0.290196091, 0.160006106 }
                            { 0.223529413, 0.141176477, 0.290196091, 1 }
                            { 0.223529413, 0.141176477, 0.290196091, 1 }
                        }
                    }
                }
                Pass: i16 = 2
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                }
                                KeyValues: list[f32] = {
                                    90
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 230, 150, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 230, 150, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0306469928
                            0.0658342764
                            0.103291713
                            0.139046535
                            0.184449494
                            0.311010212
                            0.357548237
                            0.399545968
                            0.440408617
                            0.481271297
                            0.646140754
                            0.681328058
                            0.711975038
                            0.742622018
                            0.772133946
                            0.785244048
                            0.799375713
                            0.817536891
                            0.860669672
                            0.879965961
                            0.894721925
                            0.908342779
                            0.931044281
                            0.954880834
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.00502515, 1, 1 }
                            { 0.854271352, 1, 1 }
                            { 1.33668339, 1, 1 }
                            { 0.711055279, 1, 1 }
                            { 1.00251257, 1, 1 }
                            { 1.02010047, 1, 1 }
                            { 0.869346738, 1, 1 }
                            { 1.25628138, 1, 1 }
                            { 0.718592942, 1, 1 }
                            { 1.02010047, 1, 1 }
                            { 1.01633167, 1, 1 }
                            { 1.24246228, 1, 1 }
                            { 0.757537663, 1, 1 }
                            { 1.01130652, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.1909548, 1, 1 }
                            { 0.712311566, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.0037688, 1, 1 }
                            { 0.928391933, 1, 1 }
                            { 1.19472361, 1, 1 }
                            { 0.657035172, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.0138191, 1, 1 }
                            { 0, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.39999998
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1.49000001
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.0500000007
                }
                ParticleLinger: option[f32] = {
                    12
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash ring"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.34117648, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.34117648, 0, 0, 0 }
                            { 0.34117648, 0, 0, 1 }
                            { 0.34117648, 0, 0, 0 }
                            { 0.34117648, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                }
                                KeyValues: list[f32] = {
                                    90
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 150, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_R_Shadow_Ring.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.449999988
                            0.800000012
                        }
                        Values: list[f32] = {
                            0
                            10
                            20
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "dark blobs"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.360784322, 0.552941203, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.149019614, 0, 0, 1 }
                            { 0.200000003, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                2
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.25
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Ray_Erode.SKINS_FiddleSticks_Skin37.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsDirectionOriented: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 40, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    4
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 40, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 2 }
                            { 1, 1.5, 0.449999988 }
                            { 1, 1, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_W_Tar_Streaks.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 2
                TexDiv: vec2 = { 2, 1 }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 180
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.449999988
                            0.800000012
                        }
                        Values: list[f32] = {
                            0
                            15
                            30
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "slow streaks"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.23137255, 0.137254909, 0.376470596, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.713725507, 0.713725507, 0.713725507, 1 }
                            { 0.392156869, 0.392156869, 0.392156869, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                2
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.25
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Ray_Erode.SKINS_FiddleSticks_Skin37.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsDirectionOriented: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 40, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    4
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 40, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 2 }
                            { 1, 1.5, 0.449999988 }
                            { 1, 1, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_W_Throw_Sparks.SKINS_FiddleSticks_Skin37.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Grain_Mult.SKINS_FiddleSticks_Skin37.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 30 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.800000012
                        }
                        Values: list[f32] = {
                            0
                            10
                            20
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "fast streaks"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.235294119, 0.145098045, 0.337254912, 0.349019617 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.729411781, 0.729411781, 0.729411781, 1 }
                            { 0.490196079, 0.490196079, 0.490196079, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                ParticleIsLocalOrientation: flag = true
                IsDirectionOriented: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 40, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    4
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 40, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 2 }
                            { 1, 1.5, 0.449999988 }
                            { 1, 1, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_W_Throw_Sparks.SKINS_FiddleSticks_Skin37.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Grain_Mult.SKINS_FiddleSticks_Skin37.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 30 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    12
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "inner glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.890196085, 0.243137255, 0.254901975, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.890196085, 0.243137255, 0.254901975, 0 }
                            { 0.890196085, 0.243137255, 0.254901975, 0.0500038154 }
                            { 0.890196085, 0.243137255, 0.254901975, 1 }
                            { 0.890196085, 0.243137255, 0.254901975, 0 }
                        }
                    }
                }
                Pass: i16 = 3
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                }
                                KeyValues: list[f32] = {
                                    90
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 155, 150, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 155, 150, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0306469928
                            0.0658342764
                            0.103291713
                            0.139046535
                            0.184449494
                            0.311010212
                            0.357548237
                            0.399545968
                            0.440408617
                            0.481271297
                            0.646140754
                            0.681328058
                            0.711975038
                            0.742622018
                            0.772133946
                            0.785244048
                            0.799375713
                            0.817536891
                            0.860669672
                            0.879965961
                            0.894721925
                            0.908342779
                            0.931044281
                            0.954880834
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.00502515, 1, 1 }
                            { 0.854271352, 1, 1 }
                            { 1.33668339, 1, 1 }
                            { 0.711055279, 1, 1 }
                            { 1.00251257, 1, 1 }
                            { 1.02010047, 1, 1 }
                            { 0.869346738, 1, 1 }
                            { 1.25628138, 1, 1 }
                            { 0.718592942, 1, 1 }
                            { 1.02010047, 1, 1 }
                            { 1.01633167, 1, 1 }
                            { 1.24246228, 1, 1 }
                            { 0.757537663, 1, 1 }
                            { 1.01130652, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.1909548, 1, 1 }
                            { 0.712311566, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.0037688, 1, 1 }
                            { 0.928391933, 1, 1 }
                            { 1.19472361, 1, 1 }
                            { 0.657035172, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.0138191, 1, 1 }
                            { 0, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.79999995
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "avatar dark"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.376470596, 0.0196078438, 0.101960786, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.502270162
                            0.602724195
                            0.734392762
                            1
                        }
                        Values: list[vec4] = {
                            { 0.945098042, 0.945098042, 0.945098042, 0 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.228813559 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.576271176 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.779661 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.779661 }
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                        }
                    }
                }
                Pass: i16 = 4
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.00300000003
                    FresnelColor: vec4 = { 0.388235301, 0, 0.0117647061, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -3 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    12
                }
                Lifetime: option[f32] = {
                    5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "small pulse"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.890196085, 0.305882365, 0.31764707, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.949999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.890196085, 0.305882365, 0.31764707, 0 }
                            { 0.890196085, 0.305882365, 0.31764707, 0.0500038154 }
                            { 0.890196085, 0.305882365, 0.31764707, 1 }
                            { 0.890196085, 0.305882365, 0.31764707, 0 }
                        }
                    }
                }
                Pass: i16 = 50
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                }
                                KeyValues: list[f32] = {
                                    90
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 150, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 150, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0306469928
                            0.0658342764
                            0.103291713
                            0.139046535
                            0.184449494
                            0.311010212
                            0.357548237
                            0.399545968
                            0.440408617
                            0.481271297
                            0.646140754
                            0.681328058
                            0.711975038
                            0.742622018
                            0.772133946
                            0.785244048
                            0.799375713
                            0.817536891
                            0.860669672
                            0.879965961
                            0.894721925
                            0.908342779
                            0.931044281
                            0.954880834
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1.00502515, 1, 1 }
                            { 0.854271352, 1, 1 }
                            { 1.33668339, 1, 1 }
                            { 0.711055279, 1, 1 }
                            { 1.00251257, 1, 1 }
                            { 1.02010047, 1, 1 }
                            { 0.869346738, 1, 1 }
                            { 1.25628138, 1, 1 }
                            { 0.718592942, 1, 1 }
                            { 1.02010047, 1, 1 }
                            { 1.01633167, 1, 1 }
                            { 1.24246228, 1, 1 }
                            { 0.757537663, 1, 1 }
                            { 1.01130652, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.1909548, 1, 1 }
                            { 0.712311566, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.0037688, 1, 1 }
                            { 0.928391933, 1, 1 }
                            { 1.19472361, 1, 1 }
                            { 0.657035172, 1, 1 }
                            { 1.00879395, 1, 1 }
                            { 1.0138191, 1, 1 }
                            { 0, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.35000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.850000024
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.75
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "back"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 200, 300 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 7, 5, 7 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Radius: f32 = 50
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.600000024 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.129411772, 0.164705887, 0.286274523, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.129411772, 0.164705887, 0.286274523, 0 }
                            { 0.129411772, 0.164705887, 0.286274523, 1 }
                            { 0.129411772, 0.164705887, 0.286274523, 1 }
                            { 0.129411772, 0.164705887, 0.286274523, 0 }
                        }
                    }
                }
                Pass: i16 = -20
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Q_SmokeErode.SKINS_FiddleSticks_Skin37.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 60, 1.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 60, 1.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 2, 2, 2 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Base_fog_norm.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.39999998
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "bubble"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x6b77a8ca: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 1, 1, 0.97999543 }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_alpha_12.SKINS_FiddleSticks_Skin37.dds"
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0.149996191, 0.700007617 }
                            { 1, 0, 0.149019614, 1 }
                            { 0.379995435, 0, 0.76000613, 0.700007617 }
                            { 0.376470596, 0, 0.75686276, 0 }
                        }
                    }
                }
                Pass: i16 = 999
                MeshRenderFlags: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionSliceWidth: f32 = 0.600000024
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_ground_pool_erosion.SKINS_FiddleSticks_Skin37.dds"
                }
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 230, 10, 10 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_decal.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.35000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "bubble1"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 30, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_alpha_12.SKINS_FiddleSticks_Skin37.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.0235294122, 0.235294119, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 10, 10 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.35000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BlueSparks"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 1000, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 1000, 300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 5, 3 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 50
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.670588255, 0.00784313772, 0.305882365, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.550000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 0.454901963, 0.956862748, 1, 1 }
                            { 0, 0.768627465, 1, 0.298039228 }
                            { 0, 0.298039228, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                DirectionVelocityScale: f32 = 0.00100000005
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.349999994
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 25, 50, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_Petal_Amber.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.35000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BlueSparks1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 1000, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 1000, 300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 5, 3 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 50
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 30, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.179995418, 0.659998477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.550000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -5
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                DirectionVelocityScale: f32 = 0.00100000005
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 25, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.349999994
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 25, 50, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_Petal_Amber.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.35000002
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "bubble2"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_alpha_12.SKINS_FiddleSticks_Skin37.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0.31764707, 1 }
                }
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 35, 35 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 2, 2, 2 }
                            { 5, 5, 5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/Q2_tar.SKINS_FiddleSticks_Skin37.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 28
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.850000024
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            0.594999969
                            0.850000024
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                EmitterLinger: option[f32] = {
                    4.5
                }
                EmitterName: string = "SandDust"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 2, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 2, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 200, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 250, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.850000024
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 250, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.289997697, 0.100007631, 0.149996191, 0.600000024 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 50, 20 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1.5, 1 }
                            { 1.5, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_fire_absorb.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.39999998
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Sand_Burst"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1100, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1100, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.400000006 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.31764707, 0.43921569, 0.619607866, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0399999991
                            0.0500000007
                            1
                        }
                        Values: list[vec4] = {
                            { 0.31764707, 0.43921569, 0.619607866, 0 }
                            { 0.31764707, 0.43921569, 0.619607866, 0 }
                            { 0.31764707, 0.43921569, 0.619607866, 1 }
                            { 0.31764707, 0.43921569, 0.619607866, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -100, 160, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500100017
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -100, 160, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 3, 0.200000003, 1 }
                            { 1, 0.800000012, 1 }
                            { 0.5, 0.800000012, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_fire_absorb.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.39999998
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "Sand_Comet"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 8000, 0 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -1000, 0 }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.482352972 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.909803927, 0.239215687, 0.396078438, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.909803927, 0.239215687, 0.396078438, 1 }
                            { 0.909803927, 0.239215687, 0.396078438, 1 }
                            { 0.909803927, 0.239215687, 0.396078438, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 1000, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 150, 1000, 0 }
                            { 75, 1000, 0 }
                            { 15, 1000, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_Ray_01.SKINS_FiddleSticks_Skin37.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Z_Einstein_01_mult.SKINS_FiddleSticks_Skin37.dds"
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[f32] = {
                            3
                            30
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    10.75
                }
                Lifetime: option[f32] = {
                    1.20000005
                }
                EmitterLinger: option[f32] = {
                    4.5
                }
                EmitterName: string = "Volume_inner"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0, 4500, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 250, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.349999994
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        0.800000012
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -30
                                        30
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 150, 250, 1 }
                                { 1, 250, 1 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.400000006 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.545098066, 0.152941182, 0.290196091, 0.600000024 }
                }
                Pass: i16 = 3
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 650, -700 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 650, -700 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 1 }
                            { 0, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_fire_absorb.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 180
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.25
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[f32] = {
                            1.5
                            15
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.75
                }
                ParticleLinger: option[f32] = {
                    10.75
                }
                Lifetime: option[f32] = {
                    1.20000005
                }
                EmitterLinger: option[f32] = {
                    4.5
                }
                EmitterName: string = "Volume_innerADD"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 0, 4500, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 500, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.349999994
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        0.800000012
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -30
                                        30
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[vec3] = {
                                { 100, 500, 1 }
                                { 1, 500, 1 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveRay {}
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.700007617 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.866666675, 0.192156866, 0.262745112, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                        }
                        Values: list[vec4] = {
                            { 0.866666675, 0.192156866, 0.262745112, 0 }
                            { 0.866666675, 0.192156866, 0.262745112, 1 }
                        }
                    }
                }
                Pass: i16 = 3
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 850, -800 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 850, -800 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 2, 1 }
                            { 0, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_fire_absorb.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 180
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.29999995
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    12
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BlueSparks2"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 1000, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 1000, 300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 5, 3 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 50
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 30, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.23137255, 0.152941182, 0.458823532, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.550000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                DirectionVelocityScale: f32 = 0.00100000005
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 23, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.349999994
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 23, 50, 50 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_Feathers.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    2
                }
                EmitterName: string = "BlueSparks4"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 1000, 250 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 1000, 250 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 5, 3 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 50
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 30, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.266666681, 0.176470593, 0.458823532, 0.800000012 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.550000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -4
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 0, 0 }
                        }
                    }
                }
                DirectionVelocityScale: f32 = 0.00100000005
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 23, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.349999994
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 23, 50, 50 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_Feathers.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.20000005
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 25
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.20000005
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.20000005
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    12
                }
                Lifetime: option[f32] = {
                    2
                }
                IsSingleParticle: flag = true
                EmitterName: string = "BlueSparks5"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 100, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 300, 100, 300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.20000005, 1, 2.20000005 }
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 100
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 100, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.190005347, 0.110002287, 0.289997697, 0.450003803 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.550000012
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.600000024
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Q_SmokeErode.SKINS_FiddleSticks_Skin37.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                DirectionVelocityScale: f32 = 0.00100000005
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, 50, 50 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Base_fog_norm.SKINS_FiddleSticks_Skin37.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
            }
        }
        ParticleName: string = "FiddleSticks_Skin37_R_Channel_Chest"
        ParticlePath: string = "Characters/FiddleSticks/Skins/Skin37/Particles/FiddleSticks_Skin37_R_Channel_Chest"
    }
    0xa186910c = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    0.100000001
                }
                EmitterName: string = "Avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0xd8f49a02
                            0x1b1f3c08
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.960006118, 0.0500038154, 0.2399939, 0.149996191 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 5
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.00499999989
                    FresnelColor: vec4 = { 0.890196085, 0, 0, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -3 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Z_Einstein_01_mult.SKINS_FiddleSticks_Skin37.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 10, 4 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 0.300000012 }
                    }
                }
            }
        }
        ParticleName: string = "FiddleSticks_Skin37_Idle_Demon_Arm_Fresnel"
        ParticlePath: string = "Characters/FiddleSticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Idle_Demon_Arm_Fresnel"
        Flags: u16 = 197
    }
    0xd793a415 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Main1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.940001547, 0.179995418, 0.190005347, 0.600000024 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.111188002, 0.111188002, 0.111188002, 0.270588249 }
                            { 0, 0, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 6
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.850000024
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                EmitterName: string = "outer edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.489997715, 0.170000762, 0.179995418, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 0.0980392173, 0, 0, 0 }
                        }
                    }
                }
                MeshRenderFlags: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.349999994
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.25
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/Fiddlesticks_Base_E_SoftMult.SKINS_FiddleSticks_Skin37.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.01499999, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.970000029
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1.01499999, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_color-hold.SKINS_FiddleSticks_Skin37.dds"
                UvMode: u8 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, -1 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 5 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "weapon additive"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "weapon"
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.964705884, 0.0313725509, 0.152941182, 0.188235298 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.269993126 }
                            { 0.945098042, 0.945098042, 0.945098042, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_Weapon_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "weapon alpha"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "weapon"
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.179995418, 0.100007631, 0.37000075, 0.700007617 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.269993126 }
                            { 0.945098042, 0.945098042, 0.945098042, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0.356862754, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_Weapon_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Main3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.269993126, 0.059998475, 0.11999695, 0.700007617 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.349999994
                            0.850000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 1 }
                            { 0.945098042, 0.945098042, 0.945098042, 0.269993126 }
                            { 0.945098042, 0.945098042, 0.945098042, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.200000003, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.400000006, 0.330006868, 0.960006118, 0.400000006 }
                }
                Pass: i16 = 9
                ColorLookUpTypeX: u8 = 3
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 0 }
                    Fresnel: f32 = 0.00999999978
                    FresnelColor: vec4 = { 0.330006868, 0.330006868, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                0xcb13aff1: f32 = -40
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00999999, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_purple_avata.SKINS_FiddleSticks_Skin37.tex"
                NumFrames: u16 = 4
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = -1
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Main4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.160006106, 0.100007631, 0.300007641, 0.700007617 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.945098042, 0.945098042, 0.945098042, 1 }
                }
                Pass: i16 = 8
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.617480159
                                1
                            }
                            Values: list[f32] = {
                                0
                                0.294117659
                                2
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.200000003
                    ErosionFeatherOut: f32 = 0.340000004
                    ErosionMapName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Death_Eye_Scrolling.SKINS_FiddleSticks_Skin37.dds"
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnel: f32 = 0
                    ReflectionFresnelColor: vec4 = { 1, 0, 0, 1 }
                    Fresnel: f32 = 0.0399999991
                    FresnelColor: vec4 = { 0.368627459, 0.286274523, 0.568627477, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/FiddleSticks_Skin37_Body_TX_CM.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.850000024
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.25
                }
                EmitterName: string = "outer edge1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            "Tongue"
                            0xa86c592f
                            0xd8f49a02
                            0x1b1f3c08
                        }
                    }
                }
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0, 0, 0.200000003 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.220004573, 0, 0, 1 }
                }
                Pass: i16 = 3
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionFresnelColor: vec4 = { 0.454901963, 0.149019614, 0.164705887, 0 }
                    Fresnel: f32 = 0.00100000005
                    FresnelColor: vec4 = { 0.454901963, 0.149019614, 0.164705887, 0 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_Black.SKINS_FiddleSticks_Skin37.dds"
            }
        }
        ParticleName: string = "FiddleSticks_Skin37_P_Effigy_Body"
        ParticlePath: string = "Characters/FiddleSticks/Skins/Skin37/Particles/FiddleSticks_Skin37_P_Effigy_Body"
    }
    0xfb5efa55 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.200000003
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    0.649999976
                }
                EmitterName: string = "Core"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -5, 2, -8 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.889997721, 0.0399938971, 0.269993126, 0.500007629 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 0, 0, 1 }
                            { 1, 0.529411972, 0.717647016, 1 }
                        }
                    }
                }
                Pass: i16 = 2001
                0xcb13aff1: f32 = -1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 30, 30 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1.29999995, 1.29999995, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/FiddleSticks_Skin37_3026_Items_ball32_02.SKINS_FiddleSticks_Skin37.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterLinger: option[f32] = {
                    1
                }
                Period: option[f32] = {
                    3
                }
                TimeActiveDuringPeriod: option[f32] = {
                    3
                }
                EmitterName: string = "trail"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1, 1, 0.300000012 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { -0, 1, 45 }
                            { -150, 1, 37.5 }
                            { -0, 1, 30 }
                            { 200, 1, 37.5 }
                            { -0, 1, 45 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                0x3bf0b4ed: pointer = 0xee39916f {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -5, 2, -8 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 1000, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.360784322, 0.360784322, 0.360784322, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 0.360784322, 0.360784322, 0.360784322, 0 }
                            { 0.360784322, 0, 0.191003472, 0.600000024 }
                            { 0.32116878, 0.0155632449, 0.0976239964, 0.298039228 }
                            { 0.189588636, 0.0382006913, 0.0636678189, 0 }
                        }
                    }
                }
                Pass: i16 = 1999
                0xcb13aff1: f32 = -60
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -130, -20 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.5, 0, 0 }
                            { 0.300000012, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_color-bellcurve.SKINS_FiddleSticks_Skin37.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 0.100000001 }
                        }
                    }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterLinger: option[f32] = {
                    1
                }
                Period: option[f32] = {
                    3
                }
                TimeActiveDuringPeriod: option[f32] = {
                    3
                }
                EmitterName: string = "trail4"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -1, 1, 0.300000012 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec3] = {
                            { -0, 1, 45 }
                            { -150, 1, 37.5 }
                            { -0, 1, 30 }
                            { 200, 1, 37.5 }
                            { -0, 1, 45 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                0x3bf0b4ed: pointer = 0xee39916f {}
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -5, 2, -8 }
                }
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mCutoff: f32 = 500
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 1000, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.600000024
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 0, 0.529411793, 0.600000024 }
                            { 0.890196085, 0.0431372561, 0.270588249, 0.298039228 }
                            { 0.525490224, 0.105882354, 0.176470593, 0 }
                        }
                    }
                }
                Pass: i16 = 2000
                0xcb13aff1: f32 = -60
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -130, -20 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 0.5, 0, 0 }
                            { 0.300000012, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/common_color-bellcurve.SKINS_FiddleSticks_Skin37.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 0.100000001 }
                        }
                    }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
            }
        }
        ParticleName: string = "FiddleSticks_Skin37_Idle_eye_glow"
        ParticlePath: string = "Characters/FiddleSticks/Skins/Skin37/Particles/FiddleSticks_Skin37_Idle_eye_glow"
    }
    0x896f9ad9 = StaticMaterialDef {
        Name: string = "Characters/FiddleSticks/Skins/Skin37/Materials/Bloom_Weapon_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Fiddlesticks_Skin37_Weapon_TX_CM.SKINS_FiddleSticks_Skin37.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture_red"
                TextureName: string = "ASSETS/Characters/Fiddlesticks/Skins/Skin37/Particles/mask_sythe.SKINS_FiddleSticks_Skin37.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 1, 0.0470588244, 0.223529413, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "USE_ALPHA"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Diffuse_Bloom"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Mask_Texture_red"
                }
            }
        }
    }
    "Characters/FiddleSticks/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "FiddleSticks_BasicAttack_tar" = 0x2230d14b
            0x5e198eb9 = 0x8efa1fad
            0x136ce45a = 0xee22c09e
            0x71755033 = 0x0b101c7f
            0x5c1914f2 = 0x48de8f2e
            0xfe9f5e1d = 0x09170ed5
            0x8d79bfda = 0x70cdc80e
            "FiddleSticks_Terrify_cas" = 0x9be79978
            0x76d53e22 = 0x8b355ad6
            "FiddleSticks_W_indicator_ring" = 0x72847651
            0xc03dac2b = 0x894816c8
            0xfb424438 = 0xb5aaba94
            0xc529563a = 0xe61500ae
            0x0fb10364 = 0x5bd003a2
            0xc22c0b13 = 0x8d3c632f
            0x31a9a9c9 = 0x8d40aead
            0xff8d54cd = 0x67fe68e9
            0x82cf4f31 = 0xd793a415
            0x8d1cf0ee = 0xdfc2c48a
            0xe2d0a8e5 = 0x2991d651
            0xb50a1884 = 0x86ac80a0
            0x14273389 = 0xe2f34c4d
            0x94150219 = 0x2a1e4935
            0x95c2a6e1 = 0x65b9dadd
            0x5465aebf = 0x05e3afb3
            0xdfcbae36 = 0x4326958a
            0x07d96864 = 0xa26be1d0
            0x5af495ff = 0x46488db3
            0xeb780ed6 = 0x53bae26a
            0x8ef46d46 = 0x81eea8b2
            0x1b8493d7 = 0x731d114b
            0x865e58a0 = 0x03223b14
            0x4ba2fd3e = 0xe6dea7aa
            0x6515cca1 = 0x18134b85
            0x00aa4a7f = 0x2b4ae9b3
            0x18bc1bcc = 0xbfe08918
            0x6115615e = 0xd47582ca
            0x8807e708 = 0x55b8a7cc
            0xcd2bb2b4 = 0x86088e78
            0xaf3992df = 0x05e89d9b
            0x39141c42 = 0x0c039dd6
            0xd6f3427a = 0xc109525e
            0xde009ea5 = 0xd66b5ae1
            0xbfcdb999 = 0x7a7b3e0d
            0x8fe99f68 = 0x4636daac
            0x51b0eb80 = 0x83262044
            0xaec9e547 = 0x69ba97cb
            0xf0ea8b5d = 0x65c5fe21
            0x4f8212e1 = 0x495a29c5
            0x621d7b68 = 0xa186910c
            0xbc450d0a = 0x1d83fd5e
            0xf35834fd = 0x5820e871
            0xe5a4bfe7 = 0x9bd94e7b
            0x0244c85a = 0xb369fa26
            0x005495b0 = 0xab863d74
            0x8302e596 = 0xa9c0f14a
            0x24bb95b8 = 0x92f41c14
            0xe3dfa10f = 0x064ce3a1
            0x511a3315 = 0xab5f0ef1
            0x4957c032 = 0xe0345816
            0xe42b1a21 = 0x8fbf82a5
            0xc05f2923 = 0x0015c03f
            0x90120dac = 0x0b6f43c8
            0x643887c2 = 0x49374afe
            0xa609478c = 0x2c84b368
            0xb1e96447 = 0x0e6f53ab
            0x237950e6 = 0x39194092
            0xb66f3a79 = 0x327d6e9d
            0x1db150ee = 0x445b553a
            0x4152420d = 0xdedaab71
            0x298e78f3 = 0x0cfb511f
            0xfc1336a8 = 0x218f079c
            0xebc4f0f9 = 0xfb5efa55
            0x40c277ed = 0x1de1d859
            0xce22af54 = 0x7287abb8
            0x6fed6dbc = 0xe972e378
            0x9d7348b3 = 0xbc5af2c7
        }
    }
}
