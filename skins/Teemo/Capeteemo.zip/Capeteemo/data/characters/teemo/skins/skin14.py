#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Characters/Teemo/Teemo.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin4_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Teemo/Animations/Skin14.bin"
    "DATA/Teemo_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin4_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin2_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin26_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin6_Skins_Skin8.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin2_Skins_Skin26_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin9.bin"
    "DATA/Teemo_Skins_Skin14_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36.bin"
}
entries: map[hash,embed] = {
    "Characters/Teemo/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "LilDevilTeemo"
        MetaDataTags: string = "faction:bandlecity,race:yordle,gender:male,skinline:demonic"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Teemo/Skins/Skin14/teemoLoadScreen_14.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Teemo"
                "TeemoSkin14"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Teemo_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Teemo/Skins/Base/Teemo_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Teemo/Skins/Base/Teemo_Base_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_Teemo_BantamTrap_boom"
                        "Play_sfx_Teemo_BantamTrap_bounce"
                        "Play_sfx_Teemo_BantamTrap_OnBuffActivate"
                        "Play_sfx_Teemo_BantamTrap_OnCast"
                        "Play_sfx_Teemo_BlindingDart_OnCast"
                        "Play_sfx_Teemo_BlindingDart_OnHit"
                        "Play_sfx_Teemo_BlindingDart_OnMissileLaunch"
                        "Play_sfx_Teemo_MoveQuick_OnBuffActivate"
                        "Play_sfx_Teemo_MoveQuick_OnBuffDeactivate"
                        "Play_sfx_Teemo_MoveQuick_OnCast"
                        "Play_sfx_Teemo_TeemoBasicAttack2_OnCast"
                        "Play_sfx_Teemo_TeemoBasicAttack2_OnHit"
                        "Play_sfx_Teemo_TeemoBasicAttack2_OnMissileLaunch"
                        "Play_sfx_Teemo_TeemoBasicAttack_OnCast"
                        "Play_sfx_Teemo_TeemoBasicAttack_OnHit"
                        "Play_sfx_Teemo_TeemoBasicAttack_OnMissileLaunch"
                        "Play_sfx_Teemo_TeemoCritAttack_OnCast"
                        "Play_sfx_Teemo_TeemoCritAttack_OnHit"
                        "Play_sfx_Teemo_TeemoCritAttack_OnMissileLaunch"
                        "Play_sfx_Teemo_TeemoRCast_mis"
                        "Play_sfx_Teemo_TeemoRCast_OnCast"
                        "Play_sfx_Teemo_ToxicShotAttack_OnCast"
                        "Play_sfx_Teemo_ToxicShotAttack_OnHit"
                        "Play_sfx_Teemo_ToxicShotAttack_OnMissileLaunch"
                        "Stop_sfx_Teemo_MoveQuick_OnBuffActivate"
                        "Stop_sfx_Teemo_TeemoRCast_mis"
                    }
                }
                BankUnit {
                    Name: string = "Teemo_Skin14_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Teemo/Skins/Skin14/Teemo_Skin14_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Teemo/Skins/Skin14/Teemo_Skin14_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_TeemoSkin14_BantamTrap_boom"
                        "Play_sfx_TeemoSkin14_BantamTrap_bounce"
                        "Play_sfx_TeemoSkin14_BantamTrap_OnBuffActivate"
                        "Play_sfx_TeemoSkin14_BantamTrap_OnCast"
                        "Play_sfx_TeemoSkin14_BlindingDart_OnCast"
                        "Play_sfx_TeemoSkin14_BlindingDart_OnHit"
                        "Play_sfx_TeemoSkin14_BlindingDart_OnMissileLaunch"
                        "Play_sfx_TeemoSkin14_CamouflageStealth_OnBuffActivate"
                        "Play_sfx_TeemoSkin14_CamouflageStealth_OnBuffDeactivate"
                        "Play_sfx_TeemoSkin14_Death3D_cast"
                        "Play_sfx_TeemoSkin14_MoveQuick_OnBuffActivate"
                        "Play_sfx_TeemoSkin14_MoveQuick_OnBuffDeactivate"
                        "Play_sfx_TeemoSkin14_MoveQuick_OnCast"
                        "Play_sfx_TeemoSkin14_Recall_leadin"
                        "Play_sfx_TeemoSkin14_TeemoBasicAttack2_OnCast"
                        "Play_sfx_TeemoSkin14_TeemoBasicAttack2_OnHit"
                        "Play_sfx_TeemoSkin14_TeemoBasicAttack2_OnMissileLaunch"
                        "Play_sfx_TeemoSkin14_TeemoBasicAttack_OnCast"
                        "Play_sfx_TeemoSkin14_TeemoBasicAttack_OnHit"
                        "Play_sfx_TeemoSkin14_TeemoBasicAttack_OnMissileLaunch"
                        "Play_sfx_TeemoSkin14_TeemoCritAttack_OnCast"
                        "Play_sfx_TeemoSkin14_TeemoCritAttack_OnHit"
                        "Play_sfx_TeemoSkin14_TeemoCritAttack_OnMissileLaunch"
                        "Play_sfx_TeemoSkin14_TeemoRCast_mis"
                        "Play_sfx_TeemoSkin14_TeemoRCast_OnCast"
                        "Play_sfx_TeemoSkin14_ToxicShotAttack_OnCast"
                        "Play_sfx_TeemoSkin14_ToxicShotAttack_OnHit"
                        "Play_sfx_TeemoSkin14_ToxicShotAttack_OnMissileLaunch"
                        "Stop_sfx_TeemoSkin14_MoveQuick_OnBuffActivate"
                        "Stop_sfx_TeemoSkin14_Recall_leadin"
                        "Stop_sfx_TeemoSkin14_TeemoRCast_mis"
                    }
                }
                BankUnit {
                    Name: string = "Teemo_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Teemo/Skins/Base/Teemo_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Teemo/Skins/Base/Teemo_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Teemo/Skins/Base/Teemo_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Teemo_Attack2DGeneral"
                        "Play_vo_Teemo_Death3D"
                        "Play_vo_Teemo_Joke3DGeneral"
                        "Play_vo_Teemo_Laugh3DGeneral"
                        "Play_vo_Teemo_Move2DStandard"
                        "Play_vo_Teemo_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Teemo/Animations/Skin14"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Teemo/Skins/Skin14/Teemo_Skin14.skl"
            SimpleSkin: string = "ASSETS/Characters/Teemo/Skins/Skin14/Teemo_Skin14.skn"
            Texture: string = "ASSETS/Characters/Teemo/Skins/Skin14/teemo_skin14_TX_CM.dds"
            SkinScale: f32 = 1.60000002
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Evil"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Teemo/Skins/Skin14/teemo_skin14_evilface_TX_CM.dds"
                    Submesh: string = "Evil"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Teemo_I_FlameCrown"
                BoneName: string = "Crown"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Teemo/HUD/Teemo_Circle_14.dds"
        mContextualActionData: link = "Characters/Teemo/CAC/Teemo_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Teemo/HUD/Teemo_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Teemo/HUD/Teemo_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/11"
            }
        }
        mResourceResolver: link = "Characters/Teemo/Skins/Skin14/Resources"
    }
    "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_I_FlameCrown" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 75
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                EmitterName: string = "Fire_Add"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 75, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 75, 50 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 5
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.21960786 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.63529402, 0, 0 }
                            { 0.666666985, 0.043136999, 0, 1 }
                            { 0.619607985, 0.258823991, 0, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.0250000004, 0.0250000004, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_E_Fire.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Flare2"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.100000001
                                    0.100000001
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 20, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.56078434 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.400000006, 0, 0 }
                            { 1, 0.533333004, 0, 1 }
                            { 0.345097989, 0, 0.44313699, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 90 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                }
                Texture: string = "ASSETS/Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_R_LensFlare.dds"
            }
        }
        ParticleName: string = "Teemo_Skin14_I_FlameCrown"
        ParticlePath: string = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_I_FlameCrown"
    }
    "Characters/Teemo/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x5422624c = 0x19953824
            "Teemo_BA_cas" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_BA_cas"
            "Teemo_BA_mis" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_BA_mis"
            "Teemo_BA_tar" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_BA_tar"
            "Teemo_E_cas" = 0x00000000
            "Teemo_E_mis" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_E_mis"
            0x738da1cd = 0xfd0bec1e
            "Teemo_E_Poison" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_E_Poison"
            "Teemo_E_Tar" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_E_Tar"
            "Teemo_P_Buf" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_P_Buf"
            "Teemo_P_cas" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_P_cas"
            "Teemo_Q_cas" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_Q_cas"
            "Teemo_Q_debuf" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_Q_debuf"
            "Teemo_Q_mis" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_Q_mis"
            "Teemo_Q_tar" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_Q_tar"
            0x55115da9 = 0x1d61467a
            0x6497e97f = 0x35e88eae
            0xf5460bfd = 0xd01123e2
            "Teemo_R_GroundImpact_Dust" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_R_GroundImpact_Dust"
            "Teemo_R_Mis" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_R_mis"
            "Teemo_R_Mis_Bounce" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_R_Mis_Bounce"
            "Teemo_R_Mis_Short" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_R_mis_short"
            "Teemo_R_tar" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_R_tar"
            "Teemo_W_buf" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_W_buf"
            "Teemo_W_buf2" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_W_buf2"
            "Teemo_W_Buf_Weapon" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_W_Buf_Weapon"
            "Teemo_R_Debuff" = "Characters/Teemo/Skins/Skin0/Particles/Teemo_Base_R_Debuff"
            0x6ecc5fac = 0x00000000
            0x5507ff8c = 0x00000000
            "Teemo_death_Portal" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_death_Portal"
            "Teemo_I_FlameCrown" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_I_FlameCrown"
            "Teemo_recall_Portal" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_recall_Portal"
            "Teemo_recall_VFX" = "Characters/Teemo/Skins/Skin14/Particles/Teemo_Skin14_recall_VFX"
        }
    }
}
