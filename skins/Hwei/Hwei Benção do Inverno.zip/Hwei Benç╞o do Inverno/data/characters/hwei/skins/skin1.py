#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Hwei_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Hwei/Hwei.bin"
    "DATA/Hwei_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Hwei/Animations/Skin1.bin"
    "DATA/Hwei_Skins_Skin1_Skins_Skin10_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    0x06c3ba8c = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "HweiSkin01"
        MetaDataTags: string = "faction:ionia,gender:male,race:human,skinline:winterblessed"
        SkinUpgradeData: embed = SkinUpgradeData {
            mGearSkinUpgrades: list[link] = {
                0x7da93a36
                0x7ca938a3
                0x7ba93710
                0xdfdcf380
            }
        }
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Hwei/Skins/Skin1/HweiLoadScreen_1.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Hwei/Skins/Skin1/HweiLoadScreen_1_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Hwei"
                "HweiSkin01"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Hwei_Skin01_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Hwei/Skins/Skin01/Hwei_Skin01_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Hwei/Skins/Skin01/Hwei_Skin01_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_HweiSkin01_Dance3D_intro_buffactivate"
                        "Play_sfx_HweiSkin01_Dance3D_look_buffactivate"
                        "Play_sfx_HweiSkin01_Dance3D_loop1_buffactivate"
                        "Play_sfx_HweiSkin01_Dance3D_loop2_buffactivate"
                        "Play_sfx_HweiSkin01_Dance3D_paint_fast_buffactivate"
                        "Play_sfx_HweiSkin01_Dance3D_paint_slow_buffactivate"
                        "Play_sfx_HweiSkin01_Death3D_cast"
                        "Play_sfx_HweiSkin01_HweiBasicAttack2_OnCast"
                        "Play_sfx_HweiSkin01_HweiBasicAttack2_OnHit"
                        "Play_sfx_HweiSkin01_HweiBasicAttack2_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiBasicAttack_OnCast"
                        "Play_sfx_HweiSkin01_HweiBasicAttack_OnHit"
                        "Play_sfx_HweiSkin01_HweiBasicAttack_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiCritAttack2_OnCast"
                        "Play_sfx_HweiSkin01_HweiCritAttack2_OnHit"
                        "Play_sfx_HweiSkin01_HweiCritAttack2_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiCritAttack_OnCast"
                        "Play_sfx_HweiSkin01_HweiCritAttack_OnHit"
                        "Play_sfx_HweiSkin01_HweiCritAttack_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiE_cast"
                        "Play_sfx_HweiSkin01_HweiEE_AoE_buffactivate"
                        "Play_sfx_HweiSkin01_HweiEE_hit"
                        "Play_sfx_HweiSkin01_HweiEE_OnCast"
                        "Play_sfx_HweiSkin01_HweiEQ_missile_end"
                        "Play_sfx_HweiSkin01_HweiEQ_OnCast"
                        "Play_sfx_HweiSkin01_HweiEQ_OnHit"
                        "Play_sfx_HweiSkin01_HweiEQ_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiEW_AoE_buffactivate"
                        "Play_sfx_HweiSkin01_HweiEW_AoE_buffdeactivate"
                        "Play_sfx_HweiSkin01_HweiEW_hit"
                        "Play_sfx_HweiSkin01_HweiEW_OnCast"
                        "Play_sfx_HweiSkin01_HweiEW_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiEW_target_warning"
                        "Play_sfx_HweiSkin01_HweiP_explosion_buffactivate"
                        "Play_sfx_HweiSkin01_HweiP_explosion_warning_buffactivate"
                        "Play_sfx_HweiSkin01_HweiP_mark_buffactivate"
                        "Play_sfx_HweiSkin01_HweiQ_cast"
                        "Play_sfx_HweiSkin01_HweiQE_lava_explode"
                        "Play_sfx_HweiSkin01_HweiQE_OnCast"
                        "Play_sfx_HweiSkin01_HweiQETell_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiQQ_explosion"
                        "Play_sfx_HweiSkin01_HweiQQ_OnCast"
                        "Play_sfx_HweiSkin01_HweiQQ_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiQW_AoE_explode"
                        "Play_sfx_HweiSkin01_HweiQW_AoE_warning"
                        "Play_sfx_HweiSkin01_HweiQW_OnCast"
                        "Play_sfx_HweiSkin01_HweiR_AoE_grow_buffactivate"
                        "Play_sfx_HweiSkin01_HweiR_AoE_shatter_buffactivate"
                        "Play_sfx_HweiSkin01_HweiR_OnCast"
                        "Play_sfx_HweiSkin01_HweiR_OnHit"
                        "Play_sfx_HweiSkin01_HweiR_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiW_cast"
                        "Play_sfx_HweiSkin01_HweiWashBrush_cast"
                        "Play_sfx_HweiSkin01_HweiWE_empowered_damage_hit"
                        "Play_sfx_HweiSkin01_HweiWE_OnCast"
                        "Play_sfx_HweiSkin01_HweiWEBuffCounter_OnBuffActivate"
                        "Play_sfx_HweiSkin01_HweiWEBuffCounter_OnBuffDeactivate"
                        "Play_sfx_HweiSkin01_HweiWQ_AoE_buffactivate_loop"
                        "Play_sfx_HweiSkin01_HweiWQ_OnCast"
                        "Play_sfx_HweiSkin01_HweiWQ_OnMissileLaunch"
                        "Play_sfx_HweiSkin01_HweiWQMoveSpeed_OnBuffActivate"
                        "Play_sfx_HweiSkin01_HweiWW_AoE_buffactivate"
                        "Play_sfx_HweiSkin01_HweiWW_OnCast"
                        "Play_sfx_HweiSkin01_HweiWWShield_OnBuffActivate"
                        "Play_sfx_HweiSkin01_HweiWWShield_OnBuffDeactivate"
                        "Play_sfx_HweiSkin01_Joke3D_buffactivate"
                        "Play_sfx_HweiSkin01_Laugh3D_buffactivate"
                        "Play_sfx_HweiSkin01_Recall3D_buffactivate"
                        "Play_sfx_HweiSkin01_Respawn3D_buffactivate"
                        "Play_sfx_HweiSkin01_Taunt3D_buffactivate"
                        "Play_sfx_HweiSkin01_Winddown3D_buffactivate"
                        "Stop_sfx_HweiSkin01_Dance3D_intro_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiBasicAttack2_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiBasicAttack_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiCritAttack2_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiCritAttack_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiEQ_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiEW_AoE_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiEW_hit"
                        "Stop_sfx_HweiSkin01_HweiEW_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiEW_target_warning"
                        "Stop_sfx_HweiSkin01_HweiP_explosion_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiP_explosion_warning_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiP_mark_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiQETell_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiQQ_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiR_AoE_grow_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiR_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiWE_empowered_damage_hit"
                        "Stop_sfx_HweiSkin01_HweiWEBuffCounter_OnBuffActivate"
                        "Stop_sfx_HweiSkin01_HweiWQ_AoE_buffactivate_loop"
                        "Stop_sfx_HweiSkin01_HweiWQ_OnMissileLaunch"
                        "Stop_sfx_HweiSkin01_HweiWQMoveSpeed_OnBuffActivate"
                        "Stop_sfx_HweiSkin01_HweiWW_AoE_buffactivate"
                        "Stop_sfx_HweiSkin01_HweiWWShield_OnBuffActivate"
                    }
                }
                BankUnit {
                    Name: string = "Hwei_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Hwei/Skins/Base/Hwei_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Hwei/Skins/Base/Hwei_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Hwei/Skins/Base/Hwei_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Hwei_Assist3DJhin"
                        "Play_vo_Hwei_Attack2DGeneral"
                        "Play_vo_Hwei_Death3D"
                        "Play_vo_Hwei_FirstEncounter3DAhri"
                        "Play_vo_Hwei_FirstEncounter3DAkali"
                        "Play_vo_Hwei_FirstEncounter3DGeneral"
                        "Play_vo_Hwei_FirstEncounter3DIonia"
                        "Play_vo_Hwei_FirstEncounter3DIrelia"
                        "Play_vo_Hwei_FirstEncounter3DJhin"
                        "Play_vo_Hwei_FirstEncounter3DKarma"
                        "Play_vo_Hwei_FirstEncounter3DKayn"
                        "Play_vo_Hwei_FirstEncounter3DKennen"
                        "Play_vo_Hwei_FirstEncounter3DLeeSin"
                        "Play_vo_Hwei_FirstEncounter3DMasterYi"
                        "Play_vo_Hwei_FirstEncounter3DSett"
                        "Play_vo_Hwei_FirstEncounter3DShen"
                        "Play_vo_Hwei_FirstEncounter3DSona"
                        "Play_vo_Hwei_FirstEncounter3DSyndra"
                        "Play_vo_Hwei_FirstEncounter3DVex"
                        "Play_vo_Hwei_FirstEncounter3DYasuo"
                        "Play_vo_Hwei_FirstEncounter3DYone"
                        "Play_vo_Hwei_FirstEncounter3DZed"
                        "Play_vo_Hwei_HweiBasicAttack2_cast3D"
                        "Play_vo_Hwei_HweiBasicAttack_cast3D"
                        "Play_vo_Hwei_HweiCritAttack_cast3D"
                        "Play_vo_Hwei_HweiEE_cast3D"
                        "Play_vo_Hwei_HweiEQ_cast3D"
                        "Play_vo_Hwei_HweiQE_cast3D"
                        "Play_vo_Hwei_HweiQQ_cast3D"
                        "Play_vo_Hwei_HweiR_cast3D"
                        "Play_vo_Hwei_HweiWQ_cast3D"
                        "Play_vo_Hwei_HweiWW_cast3D"
                        "Play_vo_Hwei_Joke3DGeneral"
                        "Play_vo_Hwei_JokeResponse3DGeneral"
                        "Play_vo_Hwei_Kill3DAhri"
                        "Play_vo_Hwei_Kill3DAkali"
                        "Play_vo_Hwei_Kill3DFirst"
                        "Play_vo_Hwei_Kill3DGeneral"
                        "Play_vo_Hwei_Kill3DJhin"
                        "Play_vo_Hwei_Kill3DKayn"
                        "Play_vo_Hwei_Kill3DMasterYi"
                        "Play_vo_Hwei_Kill3DPenta"
                        "Play_vo_Hwei_Kill3DQW"
                        "Play_vo_Hwei_Kill3DShen"
                        "Play_vo_Hwei_Kill3DZed"
                        "Play_vo_Hwei_Laugh3DGeneral"
                        "Play_vo_Hwei_Move2DFirst"
                        "Play_vo_Hwei_Move2DFirstDark"
                        "Play_vo_Hwei_Move2DFirstDarkJhin"
                        "Play_vo_Hwei_Move2DFirstLight"
                        "Play_vo_Hwei_Move2DFirstLightJhin"
                        "Play_vo_Hwei_Move2DLong"
                        "Play_vo_Hwei_Move2DStandard"
                        "Play_vo_Hwei_Recall3DGeneral"
                        "Play_vo_Hwei_Respawn2DGeneral"
                        "Play_vo_Hwei_Spell2DRRankOne"
                        "Play_vo_Hwei_Spell2DRRankOneJhin"
                        "Play_vo_Hwei_Spell2DRRankTwo"
                        "Play_vo_Hwei_Spell2DRRankTwoJhin"
                        "Play_vo_Hwei_Spell3DEWRoot"
                        "Play_vo_Hwei_Taunt3DGeneral"
                        "Play_vo_Hwei_TauntResponse3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = 0x292c8b32
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Hwei/Skins/Skin01/Hwei_Skin01.skl"
            SimpleSkin: string = "ASSETS/Characters/Hwei/Skins/Skin01/Hwei_Skin01.skn"
            Texture: string = "ASSETS/Characters/Hwei/Skins/Skin01/Hwei_Skin01_TX_CM.dds"
            SkinScale: f32 = 1.14999998
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Smear Brush_Smear"
            SubmeshRenderOrder: string = "Hair Body PaletteA"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xf23bc20b
                    Submesh: string = "PaletteA"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Hwei/Skins/Skin01/Hwei_Skin01_Weapon_TX_CM.dds"
                    Submesh: string = "Brush"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x0a11887c
                    mEndingJointName: hash = 0xdabe2b5d
                    mDefaultMaskName: hash = 0x97dc0b10
                    0xa4e3d433: bool = true
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x6d229b3a
                    mEndingJointName: hash = "R_Hand"
                    mDefaultMaskName: hash = 0x97dc0b10
                    0xa4e3d433: bool = true
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xd8d53e31
                    mEndingJointName: hash = 0x24d6afad
                    mDefaultMaskName: hash = 0x97dc0b10
                    0xa4e3d433: bool = true
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xc4fef487
                    mEndingJointName: hash = 0x11eef1bf
                    mDefaultMaskName: hash = 0x97dc0b10
                    0xa4e3d433: bool = true
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xb57019db
                    mEndingJointName: hash = 0x873c1eb3
                    mDefaultMaskName: hash = 0x97dc0b10
                    0xa4e3d433: bool = true
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xfa2b91c9
                    mEndingJointName: hash = 0xc1ab9955
                    mDefaultMaskName: hash = 0x97dc0b10
                    0xa4e3d433: bool = true
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x8538c866
                    mEndingJointName: hash = 0x8338c540
                    mDefaultMaskName: hash = 0x97dc0b10
                    mMaxBoneAngle: f32 = 40
                    0xa4e3d433: bool = true
                }
                0xcc9e24e1 {
                    Name: hash = 0x828712ad
                    Joint: hash = 0x71349f51
                    DefaultOn: bool = false
                    0x028ff849: f32 = 3
                    DoRotation: bool = true
                    MaxAngle: f32 = 15
                    MaxDistance: f32 = 10
                }
                0xcc9e24e1 {
                    Name: hash = 0x8187111a
                    Joint: hash = 0xa73b74e2
                    DefaultOn: bool = false
                    0x028ff849: f32 = 3
                    Damping: f32 = 10
                    DoRotation: bool = true
                    MaxAngle: f32 = 15
                    MaxDistance: f32 = 10
                }
                0xcc9e24e1 {
                    Name: hash = 0x7f870df4
                    Joint: hash = 0xaf9746d0
                    DefaultOn: bool = false
                    0x028ff849: f32 = 3
                    DoRotation: bool = true
                    MaxAngle: f32 = 30
                    MaxDistance: f32 = 10
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Additive_Pallet_BuffBone_Offset"
        }
        IconAvatar: string = "ASSETS/Characters/Hwei/HUD/Hwei_Circle_1.dds"
        mContextualActionData: link = 0xe49defb1
        IconCircle: option[string] = {
            "ASSETS/Characters/Hwei/HUD/Hwei_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Hwei/HUD/Hwei_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/9"
            }
        }
        mResourceResolver: link = 0xa7a79ef5
        0x87b1d303: list2[pointer] = {
            0x67ac9672 {
                0x43c8c7b1: pointer = NotMaterialDriver {
                    mDriver: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                        mAnimationNames: list[hash] = {
                            "Recall"
                        }
                    }
                }
                0x071f3c1d: list2[embed] = {
                    0x00fa43e4 {
                        BoneName: string = "BUFFBONE_GLB_Layout_LOC"
                        EffectKey: hash = 0xbbeaa03b
                    }
                }
            }
        }
    }
    0x4dc527ee = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x36f8aabb = 0xb4eb4cd7
            0x18d77379 = 0xa75109bd
            0x241fd967 = 0x1461260b
            0xbe531a5a = 0xc063ae56
            0xb0f19984 = 0xf5f2da08
            0x1bc21e46 = 0x02169f0a
            0x893aa144 = 0xc59962f8
            0x3483b89a = 0x64f05d8e
            0xa7a2b3fa = 0x442a668e
            0x503d05bf = 0x16d9e213
            0x1ec917c8 = 0x2e1622ac
            0xfd20551a = 0x4677f8b6
            0xed0529be = 0xfbb79b22
            0x1b4bcd5e = 0xa1882eaa
            0xb6ec04b7 = 0xdee5b603
            0x7792deec = 0x64cf0378
            0xc8eb2b6e = 0x317fbc22
            0xa59d4d10 = 0xc7f57254
            0x45dba0a5 = 0xcf82fb41
            0x2d6b4c12 = 0x6e5a88b6
            0x26517137 = 0x0c5678db
            0x8d5d7925 = 0x4929bb41
            0xe4f27b47 = 0xc0430ea3
            0x0990c2cf = 0x4ca78fa7
            0x973d5a8a = 0x84a0ef36
            0x67161b35 = 0xccdf4901
            0x23495448 = 0x72eb5b3c
            0x2ec51c08 = 0xefd2a714
            0xf7a6ffbe = 0xdb334fca
            0x415ca5f2 = 0xc480cd7e
            0x0a34566d = 0xc3a8a0e1
            0xbc3579c6 = 0x3b7fc0ea
            0xc140f3f0 = 0xd39ef514
            0x9211462c = 0x9b78e3f0
            0xbbeaa03b = 0xafb0e8df
            0xe27b7a76 = 0x98365302
            0xfa7234bb = 0xc185d25f
            0x0aa147ba = 0xe8712c16
            0x228df3a3 = 0x446c497f
            0xdd7a4dd2 = 0x02302a96
            0xb81ec971 = 0xf5f0769d
            0x51e4ca4c = 0x47a11fc8
            0x385742b0 = 0x5e7306b4
            0xe94de03e = 0xb487c202
            0x15e6e79b = 0x26870293
            0x36306592 = 0x1bf918a6
            0x5e231c72 = 0xe314a916
            0xbc327fdc = 0xf4e5fb90
            0xfba36d61 = 0x63453add
            0xc54f0a3c = 0x441ce410
            0x47b4be88 = 0xf717fe90
            0xbf1cd093 = 0x5993da07
            0x1a106750 = 0xf3ba61ec
            0xb977af56 = 0x9e3455f2
            0x94bfc392 = 0xd6fcd406
            0xc3c3d9c6 = 0x8d411e42
            0xb17501ff = 0xa3344cb7
            0x92629a00 = 0x9b1a6f3c
            0x369ae18a = 0xe653cd1e
            0xa2462aec = 0xf0bb86f0
            0x7d138c91 = 0xe6afdc4d
            0x099b6727 = 0x9ab0679b
            0x6a7bf3bd = 0xdb9e4d91
            0x1ff3ab14 = 0x7b7d2f50
            0x0c0f72be = 0xda1beeca
            0xb7cdeee5 = 0x496ccb61
            0xb0054d7f = 0x4b33a207
            0x6b40d0f6 = 0x2417492e
            0x18a755de = 0x386badb6
            0xecac44ca = 0x523a9a82
            0x22cc217d = 0x99a064e5
            0xb7c598c7 = 0xeb69d7f3
            0xf6633a49 = 0x156c98b5
        }
    }
    0xf23bc20b = StaticMaterialDef {
        Name: string = "Characters/Hwei/Skins/Skin1/Materials/Hwei_Skin01_PBR_VFX_Palette"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Hwei/Skins/Skin01/Hwei_Skin01_Weapon_TX_CM.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_Texture"
                TextureName: string = "ASSETS/Characters/Hwei/Skins/Skin01/Particles/Hwei_Skin01_Foundation_Palette_RGBPack.tex"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "EmissionR_DistortionG_Texture"
                TextureName: string = "ASSETS/Shared/Materials/black.Skarner_Rework.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "RMA_Texture"
                TextureName: string = "ASSETS/Shared/Materials/white.dds"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "ScreenSpaceTex"
                TextureName: string = "ASSETS/Characters/Hwei/Skins/Skin01/Particles/Hwei_Skin01_Foundation_Palette_SS_Snow.tex"
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "ScreenSpace_Mask"
                TextureName: string = "ASSETS/Characters/Hwei/Skins/Skin01/Particles/Hwei_Skin01_Foundation_Palette_RMATXT.tex"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Exclude_Mask_from_TintColor_Value"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScreenSpaceTex_UV_Scroll_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "RMA_Value"
                Value: vec4 = { 1, 0, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Outline_Color"
                Value: vec4 = { 0, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Outline_Control"
                Value: vec4 = { 0.300000012, 0.800000012, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "OutlineBlendValue"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_UV_Tile"
                Value: vec4 = { 2, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_UV_Scroll_Speed"
                Value: vec4 = { -0.200000003, 0.100000001, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_UV_Tile"
                Value: vec4 = { 2, 2, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_UV_Scroll_Speed"
                Value: vec4 = { -0.200000003, 0.100000001, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_B_UV_Tile"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_B_UV_Scroll_Speed"
            }
            StaticMaterialShaderParamDef {
                Name: string = "TintColor"
                Value: vec4 = { 0.729411781, 0.729411781, 0.729411781, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveValue"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveEdgePowObjSize"
                Value: vec4 = { 10, 500, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveEdgeColor"
                Value: vec4 = { 0, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveStrengthLength"
                Value: vec4 = { 0.100000001, 5, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DeformWaveController"
                Value: vec4 = { 0.5, 0.5, 0.5, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DeformWaveStrength"
                Value: vec4 = { 0.200000003, 0.200000003, 0.300000012, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_R_Tint"
                Value: vec4 = { 0.200000003, 0.300000012, 0.300000012, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_G_Tint"
                Value: vec4 = { 0.300000012, 0.300000012, 0.300000012, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_MaskStrength"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "BloomPow_RGB"
                Value: vec4 = { 0.100000001, 0.100000001, 0.100000001, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "EdgeBloomColor_RGB"
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveLocationOffset"
            }
            StaticMaterialShaderParamDef {
                Name: string = "EmissionColor"
                Value: vec4 = { 0, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DistortionStrength"
                Value: vec4 = { 0.100000001, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveDirNoiseA"
                Value: vec4 = { 1, 1, 4, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "DissolveWaveDirNoiseB"
                Value: vec4 = { 1, 1, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "All_Additive_Strength"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScreenSpace_Mask_Strength"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScreenSpaceTex_UV_Tile"
                Value: vec4 = { 8, 8, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "VFX_ScrollTex_Simple_Strength"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelOutlineOnly_Color"
                Value: vec4 = { 1, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelOutlineOnly_BaseColor"
                Value: vec4 = { 0, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelOutlineOnly_Control"
                Value: vec4 = { 0.100000001, 1, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "EXCLUDE_MASK_FROM_TINTCOLOR"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCREENSPACETEX_SCROLL"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_ALPHA_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_G_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_R_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "DEFORM_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "TWO_D_DEFORM_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "OUTLINE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "BLOOM_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "DISTORTION_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ALL_ADDITIVE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_SIMPLE_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCREENSPACE_TEX_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "FRESNEL_OUTLINE_ONLY"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "VFX_SCROLLTEX_SIMPLE_MASK_ON"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = 0x6747a207
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Outline_Color"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = HasGearDynamicMaterialBoolDriver {}
                                mValue: pointer = 0xf4c0192d {
                                    Value: vec4 = { 0, 0.5, 1, 1 }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 1
                                }
                                mValue: pointer = 0xf4c0192d {
                                    Value: vec4 = { 0, 1, 0.5, 0 }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 2
                                }
                                mValue: pointer = 0xf4c0192d {
                                    Value: vec4 = { 0.5, 0.100000001, 1, 0 }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 3
                                }
                                mValue: pointer = 0xf4c0192d {
                                    Value: vec4 = { 0.5, 0.699999988, 1, 1 }
                                }
                            }
                        }
                        mDefaultValue: pointer = 0xf4c0192d {
                            Value: vec4 = { 0.5, 0.699999988, 1, 1 }
                        }
                    }
                }
            }
        }
    }
}
