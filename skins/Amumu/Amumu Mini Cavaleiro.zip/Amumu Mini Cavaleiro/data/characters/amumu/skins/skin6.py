#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Amumu/Amumu.bin"
    "DATA/Amumu_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin4_Skins_Skin5_Skins_Skin6.bin"
    "DATA/Amumu_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7.bin"
    "DATA/Characters/Amumu/Animations/Skin6.bin"
    "DATA/Amumu_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6.bin"
    "DATA/Amumu_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Amumu_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Amumu_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Amumu/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "KnightAmumu"
        MetaDataTags: string = "faction:shurima,gender:male"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Amumu/Skins/Skin06/AmumuLoadScreen_6.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Amumu"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Amumu_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Amumu/Skins/Base/Amumu_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Amumu/Skins/Base/Amumu_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Amumu/Skins/Base/Amumu_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Amumu_AmumuBasicAttack2_cast3D"
                        "Play_vo_Amumu_AmumuBasicAttack_cast3D"
                        "Play_vo_Amumu_AmumuCritAttack_cast3D"
                        "Play_vo_Amumu_Attack2DGeneral"
                        "Play_vo_Amumu_BandageToss_cast3D"
                        "Play_vo_Amumu_Death3D"
                        "Play_vo_Amumu_Joke3DGeneral"
                        "Play_vo_Amumu_Laugh3DGeneral"
                        "Play_vo_Amumu_Move2DStandard"
                        "Play_vo_Amumu_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Amumu_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Amumu/Skins/Base/Amumu_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Amumu/Skins/Base/Amumu_Base_SFX_events.bnk"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Amumu/Animations/Skin6"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Amumu/Skins/Skin06/amumu_knight.skl"
            SimpleSkin: string = "ASSETS/Characters/Amumu/Skins/Skin06/amumu_knight.skn"
            Texture: string = "ASSETS/Characters/Amumu/Skins/Skin06/amumu_knight_TX_CM.dds"
            SkinScale: f32 = 1.79999995
            SelfIllumination: f32 = 1
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Idle1_BOW"
        }
        IconAvatar: string = "ASSETS/Characters/Amumu/HUD/Amumu_Circle_6.dds"
        mContextualActionData: link = "Characters/Amumu/CAC/Amumu_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Amumu/HUD/Amumu_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Amumu/HUD/Amumu_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/29"
            }
        }
        mResourceResolver: link = "Characters/Amumu/Skins/Skin6/Resources"
    }
    "Characters/Amumu/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Amumu_BA_Dust" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_BA_Dust"
            "Amumu_BA_tar" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_BA_tar"
            "Amumu_BA_tar_crit" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_BA_tar_crit"
            "Amumu_E_Tantrum_cas" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_E_Tantrum_cas"
            "Amumu_E_Tantrum_Tar" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_E_Tantrum_Tar"
            "Amumu_P_Shred_Hit" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_P_Shred_Hit"
            "Amumu_P_Shred_Maintain" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_P_Shred_Maintain"
            "Amumu_Q_beam" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_Q_beam"
            "Amumu_Q_beam_01" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_Q_beam_01"
            "Amumu_Q_Fly" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_Q_Fly"
            "Amumu_Q_mis" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_Q_mis"
            "Amumu_Q_Tar" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_Q_Tar"
            "Amumu_R_buf_tar_01" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_R_buf_tar_01"
            "Amumu_R_cas_01" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_R_cas_01"
            "Amumu_R_CurseBandages_cas" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_R_CurseBandages_cas"
            "Amumu_R_CurseBandages_Tar" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_R_CurseBandages_Tar"
            "Amumu_W_Despairpool_tar" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_W_Despairpool_tar"
            "Amumu_W_Despair_Buf" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_W_Despair_buf"
            "Amumu_W_NB_AOE_01" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_W_NB_AOE_01"
            "Amumu_W_tar" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_W_tar"
            "Amumu_R_Body_Cas" = "Characters/Amumu/Skins/Skin0/Particles/Amumu_Base_R_Body_Cas"
        }
    }
}
