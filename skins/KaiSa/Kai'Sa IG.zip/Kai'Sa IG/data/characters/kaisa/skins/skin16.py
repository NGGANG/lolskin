#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Kaisa/Kaisa.bin"
    "DATA/Kaisa_Skins_Root_Skins_Skin0_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin48_Skins_Skin49_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin68.bin"
    "DATA/Characters/Kaisa/Animations/Skin16.bin"
    "DATA/Kaisa_Skins_Skin16_Skins_Skin58.bin"
}
entries: map[hash,embed] = {
    "Characters/Kaisa/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "KaisaSkin16"
        MetaDataTags: string = "faction:void,gender:female,race:human"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Kaisa/Skins/Skin16/KaisaLoadScreen_16.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Kaisa/Skins/Skin16/KaisaLoadscreen_16_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Kaisa"
                "KaisaSkin16"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Kaisa_Skin16_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_KaisaSkin16_Dance3D"
                        "Play_sfx_KaisaSkin16_Death3D"
                        "Play_sfx_KaisaSkin16_Helmet_cast"
                        "Play_sfx_KaisaSkin16_Helmet_deactivate"
                        "Play_sfx_KaisaSkin16_idle1_buffactivate"
                        "Play_sfx_KaisaSkin16_idle2_buffactivate"
                        "Play_sfx_KaisaSkin16_Joke3D"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack2_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack2_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack2_OnMissileCast"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack2_OnMissileLaunch"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack3_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack3_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack3_OnMissileCast"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack3_OnMissileLaunch"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack_OnMissileCast"
                        "Play_sfx_KaisaSkin16_KaisaBasicAttack_OnMissileLaunch"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack2_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack2_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack2_OnMissileLaunch"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack3_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack3_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack3_OnMissileLaunch"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaCritAttack_OnMissileLaunch"
                        "Play_sfx_KaisaSkin16_KaisaE_OnBuffDeactivate"
                        "Play_sfx_KaisaSkin16_KaisaE_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaEAttack2_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaEAttack2_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaEAttack3_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaEAttack3_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaEAttack4_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaEAttack4_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaEAttack5_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaEAttack5_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaEAttack_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaEAttack_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaEAttackSpeed_buffdeactivate"
                        "Play_sfx_KaisaSkin16_KaisaEAttackSpeed_OnBuffDeactivate"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack2_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack2_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack3_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack3_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack4_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack4_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack5_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack5_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaECritAttack_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaEvolveOthers_cast"
                        "Play_sfx_KaisaSkin16_KaisaEvolveSelf_cast"
                        "Play_sfx_KaisaSkin16_KaisaPassiveAttack_cast"
                        "Play_sfx_KaisaSkin16_KaisaPassiveAttack_hit"
                        "Play_sfx_KaisaSkin16_KaisaPassiveMarker_OnBuffDeactivate"
                        "Play_sfx_KaisaSkin16_KaisaPassiveStack4_buffactivate"
                        "Play_sfx_KaisaSkin16_KaisaPassiveStack_buffactivate"
                        "Play_sfx_KaisaSkin16_KaisaQ_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaQLeftMissile1_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQLeftMissile2_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQLeftMissile3_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQLeftMissile4_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQLeftMissile5_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQLeftMissile6_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQRightMissile1_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQRightMissile2_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQRightMissile3_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQRightMissile4_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQRightMissile5_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaQRightMissile6_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaR_land"
                        "Play_sfx_KaisaSkin16_KaisaR_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaRDashCas_cast"
                        "Play_sfx_KaisaSkin16_KaisaRReadyBeam_cast"
                        "Play_sfx_KaisaSkin16_KaisaRShield_cast"
                        "Play_sfx_KaisaSkin16_KaisaRShield_OnBuffActivate"
                        "Play_sfx_KaisaSkin16_KaisaRShield_OnBuffDeactivate"
                        "Play_sfx_KaisaSkin16_KaisaRTarget_buffactivate"
                        "Play_sfx_KaisaSkin16_KaisaW_OnCast"
                        "Play_sfx_KaisaSkin16_KaisaW_OnHit"
                        "Play_sfx_KaisaSkin16_KaisaW_OnMissileCast"
                        "Play_sfx_KaisaSkin16_Recall_leadin"
                        "Play_sfx_KaisaSkin16_Recall_winddown"
                        "Play_sfx_KaisaSkin16_Revive3D"
                        "Play_sfx_KaisaSkin16_Taunt3D"
                        "Stop_sfx_KaisaSkin16_Joke3D"
                        "Stop_sfx_KaisaSkin16_KaisaBasicAttack2_OnMissileCast"
                        "Stop_sfx_KaisaSkin16_KaisaBasicAttack2_OnMissileLaunch"
                        "Stop_sfx_KaisaSkin16_KaisaBasicAttack3_OnMissileCast"
                        "Stop_sfx_KaisaSkin16_KaisaBasicAttack3_OnMissileLaunch"
                        "Stop_sfx_KaisaSkin16_KaisaBasicAttack_OnMissileCast"
                        "Stop_sfx_KaisaSkin16_KaisaBasicAttack_OnMissileLaunch"
                        "Stop_sfx_KaisaSkin16_KaisaCritAttack2_OnMissileLaunch"
                        "Stop_sfx_KaisaSkin16_KaisaCritAttack3_OnMissileLaunch"
                        "Stop_sfx_KaisaSkin16_KaisaCritAttack_OnMissileLaunch"
                        "Stop_sfx_KaisaSkin16_KaisaPassiveAttack_cast"
                        "Stop_sfx_KaisaSkin16_Revive3D"
                        "Stop_sfx_KaisaSkin16_Taunt3D"
                        "Switch_CHAMP_578_Basic"
                        "Switch_CHAMP_578_Crit"
                        "Switch_CHAMP_578_Evolve"
                        "Switch_CHAMP_578_Far"
                        "Switch_CHAMP_578_Near"
                        "Switch_CHAMP_578_NonCrit"
                    }
                }
                BankUnit {
                    Name: string = "Kaisa_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kaisa/Skins/Base/Kaisa_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kaisa/Skins/Base/Kaisa_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Kaisa/Skins/Base/Kaisa_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Kaisa_Attack2DBaron"
                        "Play_vo_Kaisa_Attack2DGeneral"
                        "Play_vo_Kaisa_Attack2DJax"
                        "Play_vo_Kaisa_Attack2DJinx"
                        "Play_vo_Kaisa_Attack2DKassadin"
                        "Play_vo_Kaisa_Attack2DKhazix"
                        "Play_vo_Kaisa_Attack2DKogmaw"
                        "Play_vo_Kaisa_Attack2DMalzahar"
                        "Play_vo_Kaisa_Attack2DMissFortune"
                        "Play_vo_Kaisa_Attack2DVoid"
                        "Play_vo_Kaisa_Death3D"
                        "Play_vo_Kaisa_Joke3DGeneral"
                        "Play_vo_Kaisa_KaisaBasicAttack2_cast3D"
                        "Play_vo_Kaisa_KaisaBasicAttack3_cast3D"
                        "Play_vo_Kaisa_KaisaBasicAttack_cast3D"
                        "Play_vo_Kaisa_KaisaCritAttack2_cast3D"
                        "Play_vo_Kaisa_KaisaCritAttack3_cast3D"
                        "Play_vo_Kaisa_KaisaCritAttack_cast3D"
                        "Play_vo_Kaisa_KaisaE_cast3D"
                        "Play_vo_Kaisa_KaisaEAttack2_cast3D"
                        "Play_vo_Kaisa_KaisaEAttack3_cast3D"
                        "Play_vo_Kaisa_KaisaEAttack4_cast3D"
                        "Play_vo_Kaisa_KaisaEAttack5_cast3D"
                        "Play_vo_Kaisa_KaisaEAttack_cast3D"
                        "Play_vo_Kaisa_KaisaECritAttack2_cast3D"
                        "Play_vo_Kaisa_KaisaECritAttack3_cast3D"
                        "Play_vo_Kaisa_KaisaECritAttack4_cast3D"
                        "Play_vo_Kaisa_KaisaECritAttack5_cast3D"
                        "Play_vo_Kaisa_KaisaECritAttack_cast3D"
                        "Play_vo_Kaisa_KaisaEEvolved_cast3D"
                        "Play_vo_Kaisa_KaisaPAttack_cast3D"
                        "Play_vo_Kaisa_KaisaQ_cast3D"
                        "Play_vo_Kaisa_KaisaQEvolved_cast3D"
                        "Play_vo_Kaisa_KaisaR_cast3D"
                        "Play_vo_Kaisa_KaisaW_cast3D"
                        "Play_vo_Kaisa_KaisaW_hit3D"
                        "Play_vo_Kaisa_KaisaW_miss3D"
                        "Play_vo_Kaisa_KaisaWEvolved_cast3D"
                        "Play_vo_Kaisa_Kill3DCount_01"
                        "Play_vo_Kaisa_Kill3DCount_02"
                        "Play_vo_Kaisa_Kill3DCount_03"
                        "Play_vo_Kaisa_Kill3DCount_04"
                        "Play_vo_Kaisa_Kill3DCount_05"
                        "Play_vo_Kaisa_Kill3DCount_06"
                        "Play_vo_Kaisa_Kill3DCount_07"
                        "Play_vo_Kaisa_Kill3DCount_08"
                        "Play_vo_Kaisa_Kill3DCount_09"
                        "Play_vo_Kaisa_Kill3DCount_10"
                        "Play_vo_Kaisa_Kill3DCount_11"
                        "Play_vo_Kaisa_Kill3DCount_12"
                        "Play_vo_Kaisa_Kill3DCount_13"
                        "Play_vo_Kaisa_Kill3DCount_14"
                        "Play_vo_Kaisa_Kill3DCount_15"
                        "Play_vo_Kaisa_Kill3DCount_16"
                        "Play_vo_Kaisa_Kill3DCount_17"
                        "Play_vo_Kaisa_Kill3DCount_18"
                        "Play_vo_Kaisa_Kill3DCount_19"
                        "Play_vo_Kaisa_Kill3DCount_20"
                        "Play_vo_Kaisa_Kill3DCount_21"
                        "Play_vo_Kaisa_Kill3DCount_22"
                        "Play_vo_Kaisa_Kill3DCount_23"
                        "Play_vo_Kaisa_Kill3DCount_24"
                        "Play_vo_Kaisa_Kill3DCount_25"
                        "Play_vo_Kaisa_Kill3DCount_26"
                        "Play_vo_Kaisa_Kill3DDouble"
                        "Play_vo_Kaisa_Kill3DMalzahar"
                        "Play_vo_Kaisa_Kill3DTurret"
                        "Play_vo_Kaisa_Laugh3DGeneral"
                        "Play_vo_Kaisa_Move2DFirst"
                        "Play_vo_Kaisa_Move2DFirstEnemyVoid"
                        "Play_vo_Kaisa_Move2DFirstKassadin"
                        "Play_vo_Kaisa_Move2DLong"
                        "Play_vo_Kaisa_Move2DStandard"
                        "Play_vo_Kaisa_Ping3DEnemyMissing"
                        "Play_vo_Kaisa_Recall3DGeneral"
                        "Play_vo_Kaisa_Recall3DSupport"
                        "Play_vo_Kaisa_Receive3DHeal"
                        "Play_vo_Kaisa_Receive3DHealHoneyfruit"
                        "Play_vo_Kaisa_Receive3DShield"
                        "Play_vo_Kaisa_Respawn2DGeneral"
                        "Play_vo_Kaisa_Spell3DWKill"
                        "Play_vo_Kaisa_Taunt3DGeneral"
                        "Play_vo_Kaisa_UseItem2DWard"
                        "Stop_vo_Kaisa_Joke3DGeneral"
                        "Stop_vo_Kaisa_Laugh3DGeneral"
                        "Stop_vo_Kaisa_Taunt3DGeneral"
                        "Switch_CHAMP_578_Off"
                        "Switch_CHAMP_578_On"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Kaisa/Animations/Skin16"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16.skl"
            SimpleSkin: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16.skn"
            Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_TX_CM.dds"
            SkinScale: f32 = 1.10000002
            SelfIllumination: f32 = 0.699999988
            BrushAlphaOverride: f32 = 0.400000006
            OverrideBoundingBox: option[vec3] = {
                { 155, 225, 155 }
            }
            InitialSubmeshToHide: string = "Kaisa_Helmet_Mat, Kaisa_Base_Frog_Mat, Kaisa_Pistols_Mat, Kaisa_Q2_Mat, Kaisa_Base_VoidFrog_Mat, Wings, Kaisa_Skin16_Recall_MAT"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_Frog_TX_CM.dds"
                    Submesh: string = "Kaisa_Base_Frog_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_Joke_FrogVoid_TX_CM.dds"
                    Submesh: string = "Kaisa_Base_VoidFrog_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_Recall_TX_CM.dds"
                    Submesh: string = "Wings"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_Recall_TX_CM.dds"
                    Submesh: string = "Kaisa_Skin16_Recall_MAT"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_TX_CM.dds"
                    Submesh: string = "Kaisa_Skin16_EngineWings_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Kaisa/Skins/Skin16/Materials/FresnelAlpha_inst"
                    Submesh: string = "Kaisa_Helmet_Mat"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Kaisa/Skins/Skin16/Materials/FresnelAlpha_Guns_inst"
                    Submesh: string = "Kaisa_Pistols_Mat"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Buffbones"
            "idle1_BACKUP"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Kaisa_Idle_engine"
                BoneName: string = "R_Buffbone_Engine"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Kaisa_Idle_engine"
                BoneName: string = "L_Buffbone_Engine"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Kaisa/HUD/Kaisa_Circle_16.dds"
        mContextualActionData: link = "Characters/Kaisa/CAC/Kaisa"
        IconCircle: option[string] = {
            "ASSETS/Characters/Kaisa/HUD/Kaisa_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Kaisa/HUD/Kaisa_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/54"
                mLoadingScreenAnchor: u32 = 1
            }
        }
        mResourceResolver: link = "Characters/Kaisa/Skins/Skin16/Resources"
        0x87b1d303: list2[pointer] = {
            0x67ac9672 {
                0x43c8c7b1: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = "Characters/Kaisa/Spells/KaisaQAbility/KaisaQEvolved"
                }
                0xa826e328: list2[hash] = {
                    0x8a3d498b
                }
                0xfd949819: list2[hash] = {
                    0x255fe762
                }
            }
        }
    }
    "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mask_off" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x247951bd
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0588235296, 0.0784313753, 0.113725491, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0588235296, 0.0784313753, 0.113725491, 0 }
                            { 0.0588235296, 0.0784313753, 0.113725491, 1 }
                            { 0.0341407135, 0.0498269908, 0.113725491, 0.20784314 }
                            { 0.00230680499, 0.00553633226, 0.0566397533, 0 }
                        }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00999999, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/color-hold.dds"
                NumFrames: u16 = 0
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.39999998
                }
                Lifetime: option[f32] = {
                    1.39999998
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x247951bd
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.494117647, 0.800000012, 1, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.541176498, 0.78039217, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.541176498, 0.78039217, 1, 1 }
                            { 0.541176498, 0.78039217, 1, 1 }
                            { 0.541176498, 0.78039217, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionMapTexture: string = "ASSETS/Shared/Particles/Generic_Grey_Cubemap.SRT_DURIAN_2024.dds"
                    ReflectionOpacityDirect: f32 = -4
                    ReflectionOpacityGlancing: f32 = 5
                    ReflectionFresnel: f32 = 0.100000001
                    ReflectionFresnelColor: vec4 = { 0.368627459, 0.737254918, 0.964705884, 1 }
                    FresnelColor: vec4 = { 0.58431375, 0.968627453, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1.01999998, 1.01999998 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    0.200000003
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "electric1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x247951bd
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.286274523, 0.407843143, 0.556862772, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.286274523, 0.407843143, 0.556862772, 1 }
                            { 0.286274523, 0.407843143, 0.556862772, 1 }
                            { 0.00673587061, 0.0367858522, 0.185620919, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                DepthBiasFactors: vec2 = { -1, -3 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1.01999998, 1.01999998 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_PlasmaShapes.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 3, 3 }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
            }
        }
        ParticleName: string = "Kaisa_Skin16_R_mask_off"
        ParticlePath: string = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mask_off"
        SoundOnCreateDefault: string = "Play_sfx_Kaisa_Helmet_deactivate"
    }
    "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Death_dissorve" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 7
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.75
                }
                Lifetime: option[f32] = {
                    2.5
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {
                    FieldNoiseDefinitions: list[embed] = {
                        VfxFieldNoiseDefinitionData {
                            Position: embed = ValueVector3 {
                                ConstantValue: vec3 = { 0, 150, 0 }
                            }
                            Radius: embed = ValueFloat {
                                ConstantValue: f32 = 2000
                            }
                            Frequency: embed = ValueFloat {
                                ConstantValue: f32 = 50
                            }
                            VelocityDelta: embed = ValueFloat {
                                ConstantValue: f32 = 5
                            }
                            AxisFraction: vec3 = { 1, 1, 1 }
                        }
                    }
                }
                EmitterName: string = "bits_alphablend"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -2
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 100, 100 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -3
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -150, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 90, 50, 90 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 75, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.384313732, 0.384313732, 0.384313732, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.126826167, 0.165254608, 0.234429315, 0 }
                            { 0.126826167, 0.165254608, 0.234429315, 1 }
                            { 0.0753556341, 0.0979623199, 0.147697046, 1 }
                            { 0.0192171521, 0.0230582375, 0.0422753878, 0 }
                        }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    300
                                    -300
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    300
                                    -300
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 13, 13 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.800000012
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.800000012
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 60, 13, 13 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Dagger_Feathers_sharpen.dds"
                NumFrames: u16 = 4
                StartFrame: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.899999976
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLinger: option[f32] = {
                    5
                }
                Lifetime: option[f32] = {
                    1.10000002
                }
                EmitterName: string = "Glow_alpha"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 1, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0862745121, 0.101960786, 0.180392161, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.699999988
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0862745121, 0.101960786, 0.180392161, 0 }
                            { 0.0862745121, 0.101960786, 0.180392161, 1 }
                            { 0.0862745121, 0.101960786, 0.180392161, 1 }
                            { 0.0862745121, 0.101960786, 0.180392161, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 300, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 210, 210, 210 }
                            { 300, 300, 300 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Base_R_circle.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar_Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionSliceWidth: f32 = 1.79999995
                    ErosionMapName: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Base_Death_dissorve.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.01499999, 1.01499999, 1.01499999 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "goldRiple_avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.411764711, 0.533333361, 0.768627465, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 0.411764711, 0.533333361, 0.768627465, 1 }
                            { 0.411764711, 0.533333361, 0.768627465, 1 }
                            { 0.411764711, 0.533333361, 0.768627465, 1 }
                        }
                    }
                }
                Pass: i16 = -1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.0500000007
                                1.04999995
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1.79999995
                    ErosionMapName: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Base_Death_dissorve.dds"
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.01499999, 1.01499999, 1.01499999 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/color-hold.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Base_E_light_wall_mult.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 0.5 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 1.5
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    3.5
                }
                EmitterName: string = "groundglow"
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Flags: u8 = 1
                    Radius: f32 = 35
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.34117648, 0.419607848, 0.666666687, 0.400000006 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.34117648, 0.419607848, 0.666666687, 0 }
                            { 0.34117648, 0.419607848, 0.666666687, 0.400000006 }
                            { 0.116401382, 0.159615532, 0.371241838, 0.0909803957 }
                            { 0.041476354, 0.0658208355, 0.180392161, 0 }
                        }
                    }
                }
                Pass: i16 = -30
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.150000006
                                0.600000024
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1.89999998
                    ErosionMapName: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Base_R_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 400, 400, 400 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 400, 400, 400 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Base_R_circle.dds"
            }
        }
        VisibilityRadius: f32 = 1000
        ParticleName: string = "Kaisa_Skin16_Death_dissorve"
        ParticlePath: string = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Death_dissorve"
        Flags: u16 = 199
    }
    "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mask_on" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Avatar"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x247951bd
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0588235296, 0.0784313753, 0.113725491, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0588235296, 0.0784313753, 0.113725491, 0 }
                            { 0.0588235296, 0.0784313753, 0.113725491, 1 }
                            { 0.0341407135, 0.0498269908, 0.113725491, 0.20784314 }
                            { 0.00230680499, 0.00553633226, 0.0566397533, 0 }
                        }
                    }
                }
                DepthBiasFactors: vec2 = { -1, -2 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00999999, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/color-hold.dds"
                NumFrames: u16 = 0
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1, 1 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.200000003, 0.200000003 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    0.200000003
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "electric"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x247951bd
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.286274523, 0.407843143, 0.556862772, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.286274523, 0.407843143, 0.556862772, 1 }
                            { 0.286274523, 0.407843143, 0.556862772, 1 }
                            { 0.00673587061, 0.0367858522, 0.185620919, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                DepthBiasFactors: vec2 = { -1, -3 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1.01999998, 1.01999998 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_PlasmaShapes.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 0.100000001 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 0, 1 }
                        }
                    }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 3, 3 }
                }
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.39999998
                }
                Lifetime: option[f32] = {
                    1.39999998
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x247951bd
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.494117647, 0.800000012, 1, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.541176498, 0.78039217, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.541176498, 0.78039217, 1, 1 }
                            { 0.541176498, 0.78039217, 1, 1 }
                            { 0.541176498, 0.78039217, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MeshRenderFlags: u8 = 0
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionMapTexture: string = "ASSETS/Shared/Particles/Generic_Grey_Cubemap.SRT_DURIAN_2024.dds"
                    ReflectionOpacityDirect: f32 = -4
                    ReflectionOpacityGlancing: f32 = 5
                    ReflectionFresnel: f32 = 0.100000001
                    ReflectionFresnelColor: vec4 = { 0.368627459, 0.737254918, 0.964705884, 1 }
                    FresnelColor: vec4 = { 0.58431375, 0.968627453, 1, 1 }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1.01999998, 1.01999998 }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/color-hold.dds"
            }
        }
        ParticleName: string = "Kaisa_Skin16_R_mask_on"
        ParticlePath: string = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mask_on"
        SoundOnCreateDefault: string = "Play_sfx_Kaisa_Helmet_cast"
    }
    "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Idle_engine" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "Basic"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -15, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.580392182, 0.70588237, 1, 0.290196091 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec4] = {
                            { 0.24126105, 0.368166089, 0.749019623, 0 }
                            { 0.191188008, 0.254671276, 0.643137276, 0.290196091 }
                            { 0.0796616673, 0.113494806, 0.254901975, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 35, 35 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 35, 35 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_SoftCircle.dds"
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Kaisa/Skins/Base/Particles/Kaisa_Skin01_W_gradient_rgb.dds"
                    PalleteSrcMixColor: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 6, 0, 0 }
                    }
                    PaletteCount: i32 = 8
                }
            }
        }
        ParticleName: string = "Kaisa_Skin16_Idle_engine"
        ParticlePath: string = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Idle_engine"
        Flags: u16 = 192
    }
    "Characters/Kaisa/Skins/Skin16/Materials/FresnelAlpha_Guns_inst" = StaticMaterialDef {
        Name: string = "Characters/Kaisa/Skins/Skin16/Materials/FresnelAlpha_Guns_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_Guns_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_TX_GunScroll.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Noise_Scale"
                Value: vec4 = { 0.600000024, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scroll_Speed"
                Value: vec4 = { 0.0700000003, -0.0299999993, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Addative_Color"
                Value: vec4 = { 0.0666666701, 0.203921571, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_color"
                Value: vec4 = { 0.109803922, 0.376470596, 1, 1 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "OVERLAY_ADDATIVE"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/ScrollingUVs_Simple"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
    "Characters/Kaisa/Skins/Skin16/Materials/FresnelAlpha_inst" = StaticMaterialDef {
        Name: string = "Characters/Kaisa/Skins/Skin16/Materials/FresnelAlpha_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Kaisa/Skins/Skin16/Kaisa_Skin16_Guns_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask_Texture"
                TextureName: string = "ASSETS/Characters/Swain/Skins/Skin04/Swain_Skin04_TX_ArmMask.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 0.0352941193, 0.0549019612, 0.176470593, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Size"
                Value: vec4 = { 15.3600397, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Bias"
                Value: vec4 = { 0.140000001, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 2.72829986, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
                Value: vec4 = { 0.855000019, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Diffuse_Alpha_Override"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 1.72500002, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Noise_Scale"
                Value: vec4 = { 10, 2, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.160784319, 0.0235294122, 0.349019617, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Noise_ScrollSpeed"
                Value: vec4 = { 0.0500000007, -0.300000012, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Override"
                Value: vec4 = { 1, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "INVERT_FRESNEL"
            }
            StaticMaterialSwitchDef {
                Name: string = "USE_ADDITIONAL_MASKING"
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/FresnelAlpha_Scrolling"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "FresnelColor_Bias"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = IsDeadDynamicMaterialBoolDriver {}
                        mTurnOnTimeSec: f32 = 4
                        mTurnOffTimeSec: f32 = 2
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Bloom_Intensity"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = IsDeadDynamicMaterialBoolDriver {}
                        mOnValue: f32 = 0
                        mOffValue: f32 = 1.70000005
                        mTurnOnTimeSec: f32 = 4
                        mTurnOffTimeSec: f32 = 2
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Alpha_Override"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = IsDeadDynamicMaterialBoolDriver {}
                        mOnValue: f32 = 0
                        mOffValue: f32 = 1
                        mTurnOnTimeSec: f32 = 4
                    }
                }
            }
        }
    }
    "Characters/Kaisa/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Kaisa_AA_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_AA_tar"
            "Kaisa_AA_tar_Crit" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_AA_tar_Crit"
            0xb01e27d0 = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_attack_mis"
            "Kaisa_BA6_mis" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_BA6_mis"
            "Kaisa_BAPlasma_mis" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_BAPlasma_mis"
            "Kaisa_E_active" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_active"
            "Kaisa_E_HandBuff" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_HandBuff"
            "Kaisa_E_stealth_activate" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_stealth_activate"
            "Kaisa_E_warp01" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_warp01"
            "Kaisa_P_Max_hit_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_Max_hit_tar"
            "Kaisa_P_stack_01" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_stack_01"
            "Kaisa_P_stack_02" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_stack_02"
            "Kaisa_P_stack_03" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_stack_03"
            "Kaisa_P_stack_05" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_stack_05"
            "Kaisa_P_stack_Max" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_stack_Max"
            "Kaisa_Q_Flashbang_Mis" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Q_Flashbang_Mis"
            "Kaisa_Q_Tracker_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Q_Tracker_tar"
            "Kaisa_R_DashCas" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_DashCas"
            "Kaisa_R_DashTrail" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_DashTrail"
            "Kaisa_R_Shield_Buf" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_Shield_Buf"
            "Kaisa_R_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_tar"
            "Kaisa_R_Target_activate" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_Target_activate"
            "Kaisa_R_Target_Ring" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_Target_Ring"
            "Kaisa_W_cas" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_cas"
            "Kaisa_W_mis" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_mis"
            "Kaisa_W_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_tar"
            "Kaisa_W_Tar_Champ" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_Tar_Champ"
            "Kaisa_W_vision_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_vision_tar"
            "Kaisa_R_ready_beam" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_ready_beam"
            "Kaisa_w_mis_child" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_w_mis_child"
            "Kaisa_E_Attack_steam" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_Attack_steam"
            "Kaisa_Q_cas" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Q_cas"
            0x9602c658 = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_beam_electricity"
            "Kaisa_Idle_engine" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Idle_engine"
            "Kaisa_R_shield_end" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_shield_end"
            "Kaisa_R_Destination" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_Destination"
            "Kaisa_E_End_weapon" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_End_weapon"
            "Kaisa_R_Dash_Start" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_Dash_Start"
            "Kaisa_E_stealth_ready" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_stealth_ready"
            "Kaisa_REcall_cas" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_REcall_cas"
            "Kaisa_Recall_Wing" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Recall_Wing"
            "Kaisa_R_indicator_range" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_indicator_range"
            "Kaisa_R_mark_tar" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mark_tar"
            "Kaisa_Death_dissorve" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Death_dissorve"
            0x0d618b08 = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Revive_cas"
            "Kaisa_W_evolved_mis" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_evolved_mis"
            "Kaisa_W_Evolved_mis_child" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_Evolved_mis_child"
            "Kaisa_R_mask_on" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mask_on"
            "Kaisa_R_mask_off" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_R_mask_off"
            "Kaisa_Joke_engine" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Joke_engine"
            "Kaisa_Joke_frog" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Joke_frog"
            "Kaisa_joke_frog_land" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_joke_frog_land"
            "Kaisa_Q_Tracker_tar_minion" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Q_Tracker_tar_minion"
            "Kaisa_Q_Tracker_tar_iso" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Q_Tracker_tar_iso"
            0xba2cd2ce = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_W_Evolved_Tar_Champ"
            "Kaisa_P_stack_full" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_P_stack_full"
            "Kaisa_AA_Hand_Glow" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_AA_Hand_Glow"
            0x7e49c2d8 = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_AA_tar"
            0x66511a5c = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_AA_tar"
            "Kaisa_E_Wings" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_Wings"
            "Kaisa_E_Wings2" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_Wings2"
            "Kaisa_E_HaloGuns" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_E_HaloGuns"
            "Kaisa_Recall_FingerSnap" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Recall_FingerSnap"
            "Kaisa_Recall_TrophyGlow" = "Characters/Kaisa/Skins/Skin16/Particles/Kaisa_Skin16_Recall_TrophyGlow"
        }
    }
}
