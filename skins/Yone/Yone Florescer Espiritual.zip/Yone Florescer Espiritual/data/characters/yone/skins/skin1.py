#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Yone/Yone.bin"
    "DATA/Characters/Yone/Animations/Skin1.bin"
    "DATA/Yone_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yone_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin2_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin56_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yone_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yone_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yone_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yone_Skins_Skin0_Skins_Skin1_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yone_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Yone/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "YoneSkin01"
        MetaDataTags: string = "gender:male,faction:ionia,race:human,skinline:spiritblossom,subfaction:kanmei"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Yone/Skins/Skin01/YoneLoadScreen_1.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Yone/Skins/Skin01/YoneLoadscreen_1_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Yone"
                "YoneSkin01"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Yone_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yone/Skins/Base/Yone_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yone/Skins/Base/Yone_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yone/Skins/Base/Yone_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Yone_Attack2DGeneral"
                        "Play_vo_Yone_Death3D"
                        "Play_vo_Yone_FirstEncounter3DAhri"
                        "Play_vo_Yone_FirstEncounter3DAnnie"
                        "Play_vo_Yone_FirstEncounter3DEvelynn"
                        "Play_vo_Yone_FirstEncounter3DFiddlesticks"
                        "Play_vo_Yone_FirstEncounter3DGeneral"
                        "Play_vo_Yone_FirstEncounter3DKindred"
                        "Play_vo_Yone_FirstEncounter3DKled"
                        "Play_vo_Yone_FirstEncounter3DLillia"
                        "Play_vo_Yone_FirstEncounter3DNocturne"
                        "Play_vo_Yone_FirstEncounter3DRiven"
                        "Play_vo_Yone_FirstEncounter3DShen"
                        "Play_vo_Yone_FirstEncounter3DSwain"
                        "Play_vo_Yone_FirstEncounter3DTahmKench"
                        "Play_vo_Yone_FirstEncounter3DTaliyah"
                        "Play_vo_Yone_FirstEncounter3DYasuo"
                        "Play_vo_Yone_FirstEncounter3DYordle"
                        "Play_vo_Yone_Joke3DGeneral_in"
                        "Play_vo_Yone_Joke3DGeneral_loop"
                        "Play_vo_Yone_Kill3DGeneral"
                        "Play_vo_Yone_Kill3DPenta"
                        "Play_vo_Yone_Laugh3DGeneral"
                        "Play_vo_Yone_Move2DFirst"
                        "Play_vo_Yone_Move2DLong"
                        "Play_vo_Yone_Move2DStandard"
                        "Play_vo_Yone_Recall3DGeneral"
                        "Play_vo_Yone_Respawn2DGeneral"
                        "Play_vo_Yone_Spell3DEEnd"
                        "Play_vo_Yone_Taunt3DGeneral"
                        "Play_vo_Yone_YoneBasicAttack2_cast3D"
                        "Play_vo_Yone_YoneBasicAttack3_cast3D"
                        "Play_vo_Yone_YoneBasicAttack4_cast3D"
                        "Play_vo_Yone_YoneBasicAttack5_cast3D"
                        "Play_vo_Yone_YoneBasicAttack6_cast3D"
                        "Play_vo_Yone_YoneBasicAttack_cast3D"
                        "Play_vo_Yone_YoneCritAttack2_cast3D"
                        "Play_vo_Yone_YoneCritAttack3_cast3D"
                        "Play_vo_Yone_YoneCritAttack4_cast3D"
                        "Play_vo_Yone_YoneCritAttack5_cast3D"
                        "Play_vo_Yone_YoneCritAttack_cast3D"
                        "Play_vo_Yone_YoneE_cast3D"
                        "Play_vo_Yone_YoneQ3_cast3D"
                        "Play_vo_Yone_YoneQ_cast3D"
                        "Play_vo_Yone_YoneR_cast3D"
                        "Play_vo_Yone_YoneW_cast3D"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Yone_Skin01_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yone/Skins/Skin01/Yone_Skin01_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yone/Skins/Skin01/Yone_Skin01_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_YoneSkin01_Dance3D_in"
                        "Play_sfx_YoneSkin01_Dance3D_loop"
                        "Play_sfx_YoneSkin01_Death3D_buffactivate"
                        "Play_sfx_YoneSkin01_Homeguard_In_buffactivate"
                        "Play_sfx_YoneSkin01_Homeguard_Out_buffactivate"
                        "Play_sfx_YoneSkin01_Homeguard_Run_buffactivate"
                        "Play_sfx_YoneSkin01_Idle13D_buffactivate"
                        "Play_sfx_YoneSkin01_Idle3D_sheath_buffactivate"
                        "Play_sfx_YoneSkin01_Idle3D_spell4_toidle"
                        "Play_sfx_YoneSkin01_Idle3D_spell4_towalk"
                        "Play_sfx_YoneSkin01_Joke3D_buffactivate"
                        "Play_sfx_YoneSkin01_Laugh3D_buffactivate"
                        "Play_sfx_YoneSkin01_Recall3D_buffactivate"
                        "Play_sfx_YoneSkin01_Recall3D_winddown"
                        "Play_sfx_YoneSkin01_Respawn3D_buffactivate"
                        "Play_sfx_YoneSkin01_Taunt3D_buffactivate"
                        "Play_sfx_YoneSkin01_Taunt3D_buffactivate_loop"
                        "Play_sfx_YoneSkin01_YoneBasicAttack2_OnCast"
                        "Play_sfx_YoneSkin01_YoneBasicAttack2_OnHit"
                        "Play_sfx_YoneSkin01_YoneBasicAttack2_swipe"
                        "Play_sfx_YoneSkin01_YoneBasicAttack3_OnCast"
                        "Play_sfx_YoneSkin01_YoneBasicAttack3_OnHit"
                        "Play_sfx_YoneSkin01_YoneBasicAttack4_OnCast"
                        "Play_sfx_YoneSkin01_YoneBasicAttack4_OnHit"
                        "Play_sfx_YoneSkin01_YoneBasicAttack4_swipe"
                        "Play_sfx_YoneSkin01_YoneBasicAttack_OnCast"
                        "Play_sfx_YoneSkin01_YoneBasicAttack_OnHit"
                        "Play_sfx_YoneSkin01_YoneCritAttack2_OnCast"
                        "Play_sfx_YoneSkin01_YoneCritAttack2_OnHit"
                        "Play_sfx_YoneSkin01_YoneCritAttack3_OnCast"
                        "Play_sfx_YoneSkin01_YoneCritAttack3_OnHit"
                        "Play_sfx_YoneSkin01_YoneCritAttack4_OnCast"
                        "Play_sfx_YoneSkin01_YoneCritAttack4_OnHit"
                        "Play_sfx_YoneSkin01_YoneCritAttack_OnCast"
                        "Play_sfx_YoneSkin01_YoneCritAttack_OnHit"
                        "Play_sfx_YoneSkin01_YoneE_beam_buffactivate"
                        "Play_sfx_YoneSkin01_YoneE_cast"
                        "Play_sfx_YoneSkin01_YoneE_deactivate"
                        "Play_sfx_YoneSkin01_YoneE_hit"
                        "Play_sfx_YoneSkin01_YoneE_mark_buffactivate"
                        "Play_sfx_YoneSkin01_YoneE_return_cast"
                        "Play_sfx_YoneSkin01_YoneE_sheath"
                        "Play_sfx_YoneSkin01_YoneE_warning_cast"
                        "Play_sfx_YoneSkin01_YonePShield_buffactivate"
                        "Play_sfx_YoneSkin01_YoneQ3_hit"
                        "Play_sfx_YoneSkin01_YoneQ3_OnCast"
                        "Play_sfx_YoneSkin01_YoneQ3Ready_OnBuffActivate"
                        "Play_sfx_YoneSkin01_YoneQ_hit"
                        "Play_sfx_YoneSkin01_YoneQ_OnCast"
                        "Play_sfx_YoneSkin01_YoneR_cast_dash"
                        "Play_sfx_YoneSkin01_YoneR_hit_initial"
                        "Play_sfx_YoneSkin01_YoneR_hit_residual"
                        "Play_sfx_YoneSkin01_YoneR_OnCast"
                        "Play_sfx_YoneSkin01_YoneW_hit"
                        "Play_sfx_YoneSkin01_YoneW_OnBuffDeactivate"
                        "Play_sfx_YoneSkin01_YoneW_OnCast"
                        "Stop_sfx_YoneSkin01_Respawn3D_buffactivate"
                        "Stop_sfx_YoneSkin01_YoneQ3Ready_OnBuffActivate"
                    }
                }
                BankUnit {
                    Name: string = "Yone_Skin01_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yone/Skins/Skin01/Yone_Skin01_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yone/Skins/Skin01/Yone_Skin01_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yone/Skins/Skin01/Yone_Skin01_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_YoneSkin01_Move2DFirst"
                        "Play_vo_YoneSkin01_YoneR_cast3D"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Yone/Animations/Skin1"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin1.skl"
            SimpleSkin: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin1.skn"
            Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_TX_CM.dds"
            SkinScale: f32 = 0.930000007
            SelfIllumination: f32 = 0.699999988
            BrushAlphaOverride: f32 = 0.5
            OverrideBoundingBox: option[vec3] = {
                { 230, 180, 230 }
            }
            InitialSubmeshToHide: string = "Bow_Smear, Fish, Sushi, Azakana,Instrument,Flower,Recall_GhostKatana,Recall_Mask,Recall_Sword"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Weapon_Trail_TX_CM.dds"
                    Submesh: string = "Weapon_Trail"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Streak_Demon_TX_CM.dds"
                    Submesh: string = "GhostKatana_Smear"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Streak_Steel_TX_CM.dds"
                    Submesh: string = "Katana_Smear"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_Swords_TX_CM.dds"
                    Submesh: string = "Katana"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_Swords_TX_CM.dds"
                    Submesh: string = "GhostKatana"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Streak_Steel_TX_CM.dds"
                    Submesh: string = "Bow_Smear"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Base/Yone_Base_Props_TX_CM.dds"
                    Submesh: string = "Fish"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Base/Yone_Base_Props_TX_CM.dds"
                    Submesh: string = "Instrument"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Base/Yone_Base_Props_TX_CM.dds"
                    Submesh: string = "Sushi"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Base/Yone_Base_Recall_TX_CM.dds"
                    Submesh: string = "Azakana"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Yone/Skins/Skin1/Materials/Diffuse_Tint_inst"
                    Submesh: string = "Skirt_Inner"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_SpiritFlower_TX_CM.dds"
                    Submesh: string = "Flower"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_Recall_TX_CM.dds"
                    Submesh: string = "Recall_Mask"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_Recall_TX_CM.dds"
                    Submesh: string = "Recall_GhostKatana"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_Recall_TX_CM.dds"
                    Submesh: string = "Recall_Sword"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_Swords_TX_CM.dds"
                    Submesh: string = "Sheath"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x633c9818
                    mEndingJointName: hash = 0x683c9ff7
                    mDefaultMaskName: hash = 0x7136e1bc
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x0a11887c
                    mEndingJointName: hash = 0xdabe2b5d
                    mDefaultMaskName: hash = 0x7136e1bc
                    mDampingValue: f32 = 15
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x6d229b3a
                    mEndingJointName: hash = "R_Hand"
                    mDefaultMaskName: hash = 0x7136e1bc
                    mMaxBoneAngle: f32 = 90
                    mDampingValue: f32 = 0.5
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x62e0a85f
                    mEndingJointName: hash = 0x63e0a9f2
                    mDefaultMaskName: hash = 0x7136e1bc
                    mMaxBoneAngle: f32 = 55
                    mDampingValue: f32 = 15
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xd0a0997e
                    mEndingJointName: hash = 0xcfa097eb
                    mDefaultMaskName: hash = 0x7136e1bc
                    mMaxBoneAngle: f32 = 55
                    mDampingValue: f32 = 15
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xd80a6dc5
                    mEndingJointName: hash = 0xd50a690c
                    mDefaultMaskName: hash = 0x7136e1bc
                    mMaxBoneAngle: f32 = 55
                    mDampingValue: f32 = 15
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xa97035a4
                    mEndingJointName: hash = 0xac703a5d
                    mDefaultMaskName: hash = 0x7136e1bc
                    mMaxBoneAngle: f32 = 55
                    mDampingValue: f32 = 15
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Mask"
            "BottleFix_Skin01"
        }
        IconAvatar: string = "ASSETS/Characters/Yone/HUD/Yone_Circle_1.dds"
        mContextualActionData: link = "Characters/Yone/CAC/Yone_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Yone/HUD/Yone_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Yone/HUD/Yone_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Yone/Skins/Skin1/Resources"
    }
    "Characters/Yone/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x63a4d78d = 0xdbf28027
            0x60a4d2d4 = 0xdcf281ba
            0x7e3a9512 = 0x4fc5b260
            0x7d3a937f = 0x52c5b719
            0xc4ad1748 = 0x9f2363b2
            0xc7ad1c01 = 0x9e23621f
            0xc6ad1a6e = 0x9d23608c
            0xd7ea6d12 = 0x159aa754
            0xd9c14947 = 0x5027f231
            0x3aea7571 = 0x846bda97
            0xb7ca2f9f = 0x7263e5b5
            0x7e975f0f = 0xf27c7889
            0xd549ca68 = 0x8a3f05b6
            0x25fe03c2 = 0xb780e164
            0x0ed03fec = 0x0062ee56
            0x51acefb4 = "Characters/Yone/Skins/Skin0/Particles/Yone_Base_Q3_Ready_Ring"
            0xd9a9d95b = 0xdee7da75
            0x1b9d45c8 = 0x87b50b96
            0x572e0093 = 0x23443511
            0x0ee611c0 = 0x60580e36
            0x8e9db955 = 0xab054833
            0xf9652d32 = 0xb24cbfe4
            0x9a4e982a = 0x95809540
            0x895e62a4 = 0x068c6c72
            0x5d68ba43 = 0x2447a885
            0xd857a95c = 0x7fc32412
            0xb3bd95a5 = 0x0f2e0d9a
            0x65e51e18 = 0x2a48d6aa
            0xf7495558 = 0x20a2de8e
            0x2ba3e0fb = 0xff9d20cd
            0x804f7574 = 0x92c13bf6
            0x8ea7f7c1 = 0x2bcb7d63
            0xe5276ed8 = 0xf3330626
            0x5972ecea = 0x07d06c70
            0xdcb66da2 = 0x1aecbb9c
            0x6101ff9c = 0x95638bae
            0x64020455 = 0x94638a1b
            0x630202c2 = 0x93638888
            0x5e01fae3 = 0x9a63938d
            0x352bf480 = 0xdab12306
            0x1f86a6e0 = 0x9e2f2f3e
            0x624fed7d = 0x8759be87
            0x69d332b0 = 0x31ab1f1a
            0xb9f30696 = 0x320e5ad4
            0xcb8422f0 = 0xf6e19b8a
            0x9bbae45d = 0xccbc8c1b
            0x97c2425d = 0x69f0b37f
            0xc9ad1f27 = 0x9c235ef9
            0x592073d0 = 0x47c968ea
            0x162881c8 = 0xafa5d572
            0x5574fdd7 = 0x4cf30b99
            0x1fcd45db = 0x6fb88f46
            0x31bb08ba = 0xcf12a253
            0x013f008c = 0x8f7d1f1b
            0x043f0545 = 0x907d20ae
            0x033f03b2 = 0x917d2241
            0xb105b754 = 0x94e30261
            0xa514f09f = 0xddfb7b42
            0xb1e8dcf3 = 0xa04f3ff8
            0xef7ddc33 = 0x892513df
            0xc207423d = 0xa538c39c
            0xd0943066 = 0xaf8b7ce8
            0x408fdd45 = "Characters/Yone/Skins/Skin1/Particles/Yone_Skin01_Z_Death_Dissipate"
            0xfb6e4811 = 0x222edf3a
            0x092220b5 = "Characters/Yone/Skins/Skin1/Particles/Yone_Skin01_Z_Death_Respawn"
            0xd62be997 = 0x06864bd5
            0x06e7de43 = 0x9507d309
            0xac7f804e = 0x8a251572
            0xc82db79f = 0x2a7ea281
            0xbeba46b2 = 0xa0ca19d8
            0x347f5937 = 0xcf5b6f05
            0x11d3f64b = 0xa9ad6905
            0xb2ad3130 = 0x6203dc4d
            0xf80e1e6f = 0x74a075a8
            0x57d52a71 = 0x7f0dcd0b
            0xc44eb555 = 0x161c9300
            0x51230789 = 0x48b9899e
            0xfe51af78 = 0xb456eb3f
            0xfe8d8bc7 = 0x1a92c543
            0xc0a81801 = 0x3b42d6d6
            0x6f3530b3 = 0xbac4c496
        }
    }
    "Characters/Yone/Skins/Skin1/Materials/Diffuse_Tint_inst" = StaticMaterialDef {
        Name: string = "Characters/Yone/Skins/Skin1/Materials/Diffuse_Tint_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_TX_CM.dds"
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Tint_Color"
                Value: vec4 = { 0.247058824, 0.258823544, 0.349019617, 1 }
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Diffuse_Tint"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
    "Characters/Yone/Skins/Skin1/Particles/Yone_Skin01_Z_Death_Respawn" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "dust"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x3dbe415d {
                    Flags: u8 = 1
                    Radius: f32 = 40
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.266964287
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.500007629 }
                            { 1, 1, 1, 0.500007629 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -60
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1.20000005
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.5
                    ErosionFeatherOut: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_clouds_curly_erode_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.511262774, 0, 0 }
                            { 0.976554811, 0, 0 }
                            { 1.12864447, 0, 0 }
                            { 1.20000005, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_clouds_curly_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                UvScale: embed = ValueVector2 {
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.48456791
                                    0.48456791
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 0, 10 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00199997, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.827127635
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.517318428
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Sparks"
                Importance: u8 = 0
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 100, 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        100
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        100
                                        -200
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 100, 1, 1 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 180
                        }
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1, 0 }
                        { 0, 0, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.894117653, 0.666666687, 0.670588255, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                        }
                        Values: list[vec4] = {
                            { 0.894117653, 0.666666687, 0.670588255, 0 }
                            { 0.894117653, 0.666666687, 0.670588255, 1 }
                            { 0.894117653, 0.666666687, 0.670588255, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                DirectionVelocityScale: f32 = 0.00700000022
                DirectionVelocityMinScale: f32 = 0
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 64, 30, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 64, 30, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.200000003, 0.200000003, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.100000001, 0.300000012, 1.5 }
                            { 0.200000003, 0.300000012, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_Petals_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                UvScale: embed = ValueVector2 {
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.48456791
                                    0.48456791
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 0, 10 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.435294122, 0.615686297, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.551820755
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.435294122, 0.615686297, 1 }
                            { 1, 0.435294122, 0.615686297, 0.118894182 }
                            { 1, 0.435294122, 0.615686297, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionMapTexture: string = "ASSETS/Shared/Particles/Generic_Blue_Cubemap.dds"
                    ReflectionOpacityDirect: f32 = -1
                    ReflectionFresnel: f32 = 0.100000001
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 1 }
                    Fresnel: f32 = 10
                    FresnelColor: vec4 = { 0, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00199997, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Base/Particles/common_color-hold.dds"
                NumFrames: u16 = 4
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.400000006, 0.200000003 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Base1"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.325490206, 0.650980413, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.325490206, 0.650980413, 1 }
                            { 1, 0.325490206, 0.650980413, 0 }
                        }
                    }
                }
                Pass: i16 = -650
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1.00999999, 1.00999999 }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Base/Particles/common_color-hold.dds"
                UvMode: u8 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 0 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 5 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Yone/Skins/Base/Particles/Yone_Base_Smoky_Noise.dds"
                }
            }
        }
        ParticleName: string = "Yone_Skin01_Z_Death_Respawn"
        ParticlePath: string = "Characters/Yone/Skins/Skin1/Particles/Yone_Skin01_Z_Death_Respawn"
        Flags: u16 = 199
    }
    "Characters/Yone/Skins/Skin1/Particles/Yone_Skin01_Z_Death_Dissipate" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Base"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                            0x300c9a9c
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                            0x300c9a9c
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.059998475, 0.0899977088, 0.190005347, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.059998475, 0.0899977088, 0.190005347, 0.500007629 }
                            { 0.059998475, 0.0899977088, 0.190005347, 0 }
                        }
                    }
                }
                Pass: i16 = -650
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00100005, 1.00999999, 1.00999999 }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Base/Particles/common_color-hold.dds"
                UvMode: u8 = 1
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 0 }
                }
                UvScale: embed = ValueVector2 {
                    ConstantValue: vec2 = { 5, 5 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Yone/Skins/Base/Particles/Yone_Base_Smoky_Noise.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    0.5
                }
                EmitterName: string = "dust"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 0, -50 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 0, -50 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.266964287
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.500007629 }
                            { 1, 1, 1, 0.500007629 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -60
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 5
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1.20000005
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.5
                    ErosionFeatherOut: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_clouds_curly_erode_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.511262774, 0, 0 }
                            { 0.976554811, 0, 0 }
                            { 1.12864447, 0, 0 }
                            { 1.20000005, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_clouds_curly_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                UvScale: embed = ValueVector2 {
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.48456791
                                    0.48456791
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 0, 10 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                            0x300c9a9c
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                            0x300c9a9c
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00199997, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Yone_Skin01_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 30
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            30
                            15
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.827127635
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    0.517318428
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            3
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "Sparks"
                Importance: u8 = 0
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0.200000003, 5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0.200000003, 5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 20, 15, 1 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -2
                                        2
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        5
                                        0
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.262411356
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -200
                                        -100
                                        300
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 20, 15, 1 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1, 0 }
                        { 0, 0, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.894117653, 0.666666687, 0.670588255, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                        }
                        Values: list[vec4] = {
                            { 0.894117653, 0.666666687, 0.670588255, 0 }
                            { 0.894117653, 0.666666687, 0.670588255, 1 }
                            { 0.894117653, 0.666666687, 0.670588255, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 90, 0 }
                }
                DirectionVelocityScale: f32 = 0.00700000022
                DirectionVelocityMinScale: f32 = 0
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 64, 30, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 64, 30, 10 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.200000003, 0.200000003, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.100000001, 0.300000012, 1.5 }
                            { 0.200000003, 0.300000012, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_Petals_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 2, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                UvScale: embed = ValueVector2 {
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.48456791
                                    0.48456791
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Fresnel2"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 10 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 0, 10 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                            0x300c9a9c
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            "BODY"
                            0xbe2f5538
                            0x75eb4807
                            0x300c9a9c
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.36470589, 0.650980413, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.551820755
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.36470589, 0.650980413, 1 }
                            { 1, 0.36470589, 0.650980413, 0.118894182 }
                            { 1, 0.36470589, 0.650980413, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    ReflectionMapTexture: string = "ASSETS/Shared/Particles/Generic_Blue_Cubemap.dds"
                    ReflectionOpacityDirect: f32 = -1
                    ReflectionFresnel: f32 = 0.100000001
                    ReflectionFresnelColor: vec4 = { 0, 0, 0, 1 }
                    Fresnel: f32 = 10
                    FresnelColor: vec4 = { 0, 0, 0, 1 }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                HasPostRotateOrientation: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.00199997, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Base/Particles/common_color-hold.dds"
                NumFrames: u16 = 4
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.400000006, 0.200000003 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "dust1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 0, -50 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 0, -50 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.500007629 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.266964287
                            0.899999976
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.500007629 }
                            { 1, 1, 1, 0.500007629 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -60
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    DeltaIn: f32 = 5
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1.20000005
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.5
                    ErosionFeatherOut: f32 = 0.5
                    ErosionMapName: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_clouds_curly_erode_01.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 0, 1, 0, 0 }
                    }
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.511262774, 0, 0 }
                            { 0.976554811, 0, 0 }
                            { 1.12864447, 0, 0 }
                            { 1.20000005, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_clouds_curly_01.dds"
                NumFrames: u16 = 4
                PaletteDefinition: pointer = VfxPaletteDefinitionData {
                    PaletteTexture: string = "ASSETS/Characters/Yone/Skins/Skin01/Particles/Yone_Skin01_colorGrad.dds"
                    PaletteSelector: embed = ValueVector3 {
                        ConstantValue: vec3 = { 1, 0, 0 }
                    }
                    PaletteCount: i32 = 16
                }
                TexDiv: vec2 = { 2, 2 }
                UvScale: embed = ValueVector2 {
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.48456791
                                    0.48456791
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { 1, 1 }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Yone_Skin01_Z_Death_Dissipate"
        ParticlePath: string = "Characters/Yone/Skins/Skin1/Particles/Yone_Skin01_Z_Death_Dissipate"
        Flags: u16 = 199
    }
}
