#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7.bin"
    "DATA/Characters/Twitch/Twitch.bin"
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Twitch/Animations/Skin4.bin"
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Twitch_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin55_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63.bin"
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin4_Skins_Skin6_Skins_Skin7.bin"
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Twitch_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin21_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7.bin"
}
entries: map[hash,embed] = {
    "Characters/Twitch/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "CrimeCityTwitch"
        MetaDataTags: string = "faction:zaun,gender:male,skinline:crimecity"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Twitch/Skins/Skin04/TwitchLoadScreen_4.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Twitch"
                "TwitchSkin04"
                "GangsterTwitch"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Twitch_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Twitch/Skins/Base/Twitch_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Twitch/Skins/Base/Twitch_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Twitch/Skins/Base/Twitch_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Twitch_Attack2DGeneral"
                        "Play_vo_Twitch_BuyItem2DGeneral"
                        "Play_vo_Twitch_BuyItem2DLastWhisper"
                        "Play_vo_Twitch_BuyItem2DPotion"
                        "Play_vo_Twitch_BuyItem2DWard"
                        "Play_vo_Twitch_Death3D"
                        "Play_vo_Twitch_FirstEncounter3DJanna"
                        "Play_vo_Twitch_FirstEncounter3DLeona"
                        "Play_vo_Twitch_FirstEncounter3DSinged"
                        "Play_vo_Twitch_FirstEncounter3DZac"
                        "Play_vo_Twitch_Joke3DGeneral"
                        "Play_vo_Twitch_Laugh3DGeneral"
                        "Play_vo_Twitch_Move2DStandard"
                        "Play_vo_Twitch_Recall3DGeneral"
                        "Play_vo_Twitch_Taunt3DGeneral"
                        "Play_vo_Twitch_TwitchCritAttack_cast3D"
                        "Play_vo_Twitch_TwitchExpunge_cast3D"
                        "Play_vo_Twitch_TwitchFullAutomatic_cast3D"
                        "Play_vo_Twitch_TwitchHideInShadows_cast3D"
                        "Play_vo_Twitch_TwitchHideInShadowsBuff_OnBuffActivate"
                        "Play_vo_Twitch_TwitchVenomCask_cast3D"
                        "Play_vo_Twitch_UseItem2DPotion"
                        "Play_vo_Twitch_UseItem2DWard"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Twitch_Skin04_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Twitch/Skins/Skin04/Twitch_Skin04_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Twitch/Skins/Skin04/Twitch_Skin04_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_GangsterTwitch_TwitchBasicAttack2_OnHit"
                        "Play_sfx_GangsterTwitch_TwitchBasicAttack2_OnMissileCast"
                        "Play_sfx_GangsterTwitch_TwitchBasicAttack3_OnHit"
                        "Play_sfx_GangsterTwitch_TwitchBasicAttack3_OnMissileCast"
                        "Play_sfx_GangsterTwitch_TwitchBasicAttack_OnHit"
                        "Play_sfx_GangsterTwitch_TwitchBasicAttack_OnMissileCast"
                        "Play_sfx_GangsterTwitch_TwitchCritAttack_OnHit"
                        "Play_sfx_GangsterTwitch_TwitchCritAttack_OnMissileCast"
                        "Play_sfx_GangsterTwitch_TwitchFullAutomatic_OnBuffActivate"
                        "Play_sfx_GangsterTwitch_TwitchFullAutomatic_OnBuffDeactivate"
                        "Play_sfx_GangsterTwitch_TwitchFullAutomatic_OnCast"
                        "Play_sfx_GangsterTwitch_TwitchSprayAndPrayAttack_OnHit"
                        "Play_sfx_GangsterTwitch_TwitchSprayAndPrayAttack_OnMissileCast"
                        "Play_sfx_TwitchSkin04_Taunt3D_buffactivate"
                        "Stop_sfx_GangsterTwitch_TwitchBasicAttack2_OnMissileCast"
                        "Stop_sfx_GangsterTwitch_TwitchBasicAttack3_OnMissileCast"
                        "Stop_sfx_GangsterTwitch_TwitchBasicAttack_OnMissileCast"
                        "Stop_sfx_GangsterTwitch_TwitchCritAttack_OnMissileCast"
                        "Stop_sfx_GangsterTwitch_TwitchFullAutomatic_OnBuffActivate"
                        "Stop_sfx_GangsterTwitch_TwitchSprayAndPrayAttack_OnMissileCast"
                    }
                }
                BankUnit {
                    Name: string = "Twitch_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Twitch/Skins/Base/Twitch_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Twitch/Skins/Base/Twitch_Base_SFX_events.bnk"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Twitch/Animations/Skin4"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Twitch/Skins/Skin04/twitch_gangster.skl"
            SimpleSkin: string = "ASSETS/Characters/Twitch/Skins/Skin04/twitch_gangster.skn"
            Texture: string = "ASSETS/Characters/Twitch/Skins/Skin04/twitch_gangster_TX_CM.dds"
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 140, 160, 140 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Twitch_Cheese_Mat"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Twitch/Skins/Base/twitch_cheese_TX_CM.dds"
                    Submesh: string = "Twitch_cheese_Mat"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x49c3f916
                    mEndingJointName: hash = 0x458136d2
                    mDefaultMaskName: hash = 0xef7cfc3b
                    mMaxBoneAngle: f32 = 50
                    mDampingValue: f32 = 4
                    mVelMultiplier: f32 = -0.800000012
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xe1283076
                    mEndingJointName: hash = 0xe6283855
                    mDefaultMaskName: hash = 0xef7cfc3b
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xa0df9f04
                    mEndingJointName: hash = 0x9ddf9a4b
                    mDefaultMaskName: hash = 0xef7cfc3b
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Twitch_Idle"
                BoneName: string = "root"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Twitch/HUD/Twitch_Circle_4.dds"
        mContextualActionData: link = "Characters/Twitch/CAC/Twitch_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Twitch/HUD/Twitch_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Twitch/HUD/Twitch_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Twitch/Skins/Skin4/Resources"
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_Weapon_Glow_L" = VfxSystemDefinitionData {
        ParticleName: string = "Twitch_Skin04_R_Weapon_Glow_L"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_Weapon_Glow_L"
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_Weapon_Glow_R" = VfxSystemDefinitionData {
        ParticleName: string = "Twitch_Skin04_R_Weapon_Glow_R"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_Weapon_Glow_R"
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            20
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.129999995
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                EmitterName: string = "Muzzle_Flash"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/Twitch_Skin04_Z_Poision_Smoke_Colormap.dds"
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 40
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 0, -180 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 65, 65, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 65, 65, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 2, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_Z_Muzzle_Flash.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            10
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "glow"
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_alpha_12.dds"
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.800000012 }
                }
                Pass: i16 = 100
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 100 }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/Twitch_Skin04_Z_Orange_Glow.dds"
            }
        }
        SimpleEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash"
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_alpha_12.dds"
                BlendMode: u8 = 4
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/Twitch_Skin04_E_Tar_Flash.dds"
                0xbc022424: pointer = 0x7f70a2b2 {
                    BirthScale: embed = ValueFloat {
                        ConstantValue: f32 = 120
                    }
                    Scale: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.150000006
                                1
                            }
                        }
                    }
                    BirthRotation: embed = ValueFloat {
                        ConstantValue: f32 = 1
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        360
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                1
                            }
                        }
                    }
                    ParticleBind: vec2 = { 1, 1 }
                }
            }
        }
        ParticleName: string = "Twitch_Skin04_AA_cas"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_cas"
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 160
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                }
                ParticleLinger: option[f32] = {}
                EmitterName: string = "trail_streak"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.300000012, 0.150000006, 0.100000001, 0.200000003 }
                            { 0.300000012, 0.150000006, 0.100000001, 0.0500000007 }
                            { 0.300000012, 0.150000006, 0.100000001, 0.0500000007 }
                            { 0.300000012, 0.150000006, 0, 0.100000001 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 22, 8 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_W_Mis_Trail.dds"
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 105
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "poison"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 40 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 40, 40 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 5, -10, 5 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0.00700000022
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 5, -10, 5 }
                            }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_alpha_12.dds"
                BlendMode: u8 = 4
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 40 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    3
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 40, 40 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_AA_Posion_Smoke_Cloud.dds"
                NumFrames: u16 = 8
                TexDiv: vec2 = { 4, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 35, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.649999976, 0.649999976, 0.649999976 }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin05/Particles/cannonballtex_04.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet2"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 30, 5 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/common_color-white32.dds"
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.649999976, 0.649999976, 0.649999976 }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin05/Particles/cannonballtex_04.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet3"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { -20, 30, -5 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/common_color-white32.dds"
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.620000005, 0.620000005, 0.620000005 }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin05/Particles/cannonballtex_04.dds"
            }
        }
        ParticleName: string = "Twitch_Skin04_R_mis"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_mis"
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_tar" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "flash"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_alpha_12.dds"
                BlendMode: u8 = 4
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 160, 160 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.550000012, 0.550000012, 0.550000012 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/Twitch_Skin04_E_Tar_Flash.dds"
            }
        }
        ParticleName: string = "Twitch_Skin04_AA_tar"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_tar"
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 80
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "poison"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 40, 40 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 40, 40 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 5, -10, 5 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0.00700000022
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 5, -10, 5 }
                            }
                        }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_alpha_12.dds"
                BlendMode: u8 = 4
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 20, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    3
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    3
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 20, 20 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_AA_Posion_Smoke_Cloud.dds"
                NumFrames: u16 = 8
                TexDiv: vec2 = { 4, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 150
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.10000002
                }
                ParticleLinger: option[f32] = {}
                EmitterName: string = "trail"
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 0.200000003, 0.349999994, 0, 0.200000003 }
                            { 0.200000003, 0.349999994, 0, 0.0500000007 }
                            { 0.200000003, 0.349999994, 0, 0.0500000007 }
                            { 0.200000003, 0.349999994, 0, 0 }
                        }
                    }
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 8, 8 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.100000001, 0.100000001, 0.100000001 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_AirSpiritStreak.dds"
                StartFrame: u16 = 1
                TexDiv: vec2 = { 2, 2 }
            }
        }
        SimpleEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 35, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                DoesCastShadow: flag = true
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/cannonballtex_04.dds"
                0xbc022424: pointer = 0x7f70a2b2 {
                    BirthScale: embed = ValueFloat {
                        ConstantValue: f32 = 0.649999976
                    }
                    ParticleBind: vec2 = { 1, 1 }
                    Orientation: u8 = 2
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet2"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/common_color-white32.dds"
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                DoesCastShadow: flag = true
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/cannonballtex_04.dds"
                0xbc022424: pointer = 0x7f70a2b2 {
                    BirthScale: embed = ValueFloat {
                        ConstantValue: f32 = 0.649999976
                    }
                    ParticleBind: vec2 = { 1, 1 }
                    Orientation: u8 = 2
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet3"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -35, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                DoesCastShadow: flag = true
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/cannonballtex_04.dds"
                0xbc022424: pointer = 0x7f70a2b2 {
                    BirthScale: embed = ValueFloat {
                        ConstantValue: f32 = 0.649999976
                    }
                    ParticleBind: vec2 = { 1, 1 }
                    Orientation: u8 = 2
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "bullet4"
                Importance: u8 = 2
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 15, -70, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/common_sphere.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/common_color-white32.dds"
                BlendMode: u8 = 3
                MeshRenderFlags: u8 = 0
                DoesCastShadow: flag = true
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/cannonballtex_04.dds"
                0xbc022424: pointer = 0x7f70a2b2 {
                    BirthScale: embed = ValueFloat {
                        ConstantValue: f32 = 0.649999976
                    }
                    ParticleBind: vec2 = { 1, 1 }
                    Orientation: u8 = 2
                }
            }
        }
        ParticleName: string = "Twitch_Skin04_AA_mis"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_mis"
        Flags: u16 = 140
    }
    "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_W_Mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Bottle"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/twitch_skin04_w_bottle.scb"
                    }
                }
                BlendMode: u8 = 3
                Pass: i16 = 100
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -60 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 460, 600 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2.54999995, 2.54999995, 2.54999995 }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Skin04/Particles/Twitch_Skin04_W_Bottle_Txt.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 45
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Venom_Trail"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 1 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mCutoff: f32 = 1100
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 410, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.699999988 }
                            { 1, 1, 1, 0.400000006 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 85, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 0.200000003, 0.200000003, 0.200000003 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_W_Mis_Trail.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.400000006, 0 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.200000003
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1.5
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Venom_Mist"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 200, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 500, 500 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -100, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 30, 1, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -10
                                        10
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 30, 1, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                Times: list[f32] = {
                                    0
                                    1
                                }
                                Values: list[f32] = {
                                    0
                                    1500
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Venom_Bomb_Splash_A.dds"
                BlendMode: u8 = 1
                Pass: i16 = -10
                ColorLookUpTypeY: u8 = 3
                ColorLookUpScales: vec2 = { 1, 0.5 }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 60, 60, 60 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 30, 30, 30 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_Z_Smoke_01.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 200
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1.29999995
                }
                EmitterName: string = "Venom_Trail_Drip"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 250, 1000, 250 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 1000, 250 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -400, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -400, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 30, 1, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -10
                                        10
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 30, 1, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                Times: list[f32] = {
                                    0
                                    1
                                }
                                Values: list[f32] = {
                                    0
                                    1500
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Venom_Bomb_Splash_A.dds"
                Pass: i16 = 100
                DisableBackfaceCull: bool = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 8, 8, 8 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 20, 20, 20 }
                            { 50, 50, 50 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/twitch_venom_bomb_splash.dds"
                NumFrames: u16 = 8
                StartFrame: u16 = 3
                TexDiv: vec2 = { 4, 2 }
            }
        }
        SimpleEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    10
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Venom_Bottle_Glow"
                ParticleColorTexture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_W_Glow_Colormap.dds"
                MeshRenderFlags: u8 = 0
                Texture: string = "ASSETS/Characters/Twitch/Skins/Base/Particles/Twitch_Base_Z_Green_Glow.dds"
                0xbc022424: pointer = 0x7f70a2b2 {
                    BirthScale: embed = ValueFloat {
                        ConstantValue: f32 = 110
                    }
                    Scale: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                1
                                1.10000002
                                0.899999976
                            }
                        }
                    }
                    BirthRotation: embed = ValueFloat {
                        ConstantValue: f32 = 360
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                360
                            }
                        }
                    }
                    BirthRotationalVelocity: embed = ValueFloat {
                        ConstantValue: f32 = 220
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        -1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[f32] = {
                                220
                            }
                        }
                    }
                    ParticleBind: vec2 = { 1, 1 }
                }
            }
        }
        ParticleName: string = "Twitch_Skin04_W_Mis"
        ParticlePath: string = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_W_Mis"
    }
    "Characters/Twitch/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Twitch_AA_cas" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_cas"
            "Twitch_AA_crit_tar" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_AA_crit_tar"
            "Twitch_AA_mis" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_mis"
            "Twitch_AA_tar" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_AA_tar"
            "Twitch_Crit_cas" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Crit_cas"
            "Twitch_E_cas" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_E_cas"
            "Twitch_E_Mis" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_E_Mis"
            "Twitch_E_Range_Indicator" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_E_Range_Indicator"
            "Twitch_E_tar" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_E_tar"
            "Twitch_Idle" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Idle"
            "Twitch_P_Icon_Child" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Icon_Child"
            "Twitch_P_Impact_Stack_06" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Impact_Stack_06"
            "Twitch_P_Minion" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Minion"
            "Twitch_P_Smoke" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Smoke"
            "Twitch_P_Stack6_Child" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack6_Child"
            "Twitch_P_Stack_01" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack_01"
            "Twitch_P_Stack_02" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack_02"
            "Twitch_P_Stack_03" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack_03"
            "Twitch_P_Stack_04" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack_04"
            "Twitch_P_Stack_05" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack_05"
            "Twitch_P_Stack_06" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_P_Stack_06"
            "Twitch_Q_Bamf" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Bamf"
            "Twitch_Q_Buff_Canister" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Buff_Canister"
            "Twitch_Q_Buff_Hands" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Buff_Hands"
            "Twitch_Q_Camouflage_Ring" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Camouflage_Ring"
            "Twitch_Q_Camouflage_Ring_Decay" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Camouflage_Ring_Decay"
            "Twitch_Q_Cas_Invisible" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Cas_Invisible"
            "Twitch_Q_Haste" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Haste"
            "Twitch_Q_Invisible" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Invisible"
            "Twitch_Q_Invisiible_Outro" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_Q_Invisiible_Outro"
            "Twitch_recall_start_sound" = "Characters/Twitch/Skins/Skin0/Particles/twitch_base_recall_start_sound"
            "Twitch_recall_start_VO" = "Characters/Twitch/Skins/Skin0/Particles/twitch_base_recall_start_VO"
            "Twitch_R_Buff" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_R_Buff"
            "Twitch_R_cas" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_R_cas"
            "Twitch_R_mis" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_mis"
            "Twitch_R_Tar" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_R_Tar"
            "Twitch_R_Weapon_Glow" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_R_Weapon_Glow"
            "Twitch_R_Weapon_Glow_L" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_Weapon_Glow_L"
            "Twitch_R_Weapon_Glow_R" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_R_Weapon_Glow_R"
            "Twitch_W_cas" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_W_cas"
            "Twitch_W_Debuff_buf" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_W_Debuff_buf"
            "Twitch_W_indicator_ally_01" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_W_indicator_ally_01"
            "Twitch_W_indicator_enemy_01" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_W_indicator_enemy_01"
            "Twitch_W_Mis" = "Characters/Twitch/Skins/Skin4/Particles/Twitch_Skin04_W_Mis"
            "Twitch_W_Persist" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_W_Persist"
            "Twitch_W_Tar" = "Characters/Twitch/Skins/Skin0/Particles/Twitch_Base_W_Tar"
            0x2616582e = 0x00000000
            0xbf1604bd = 0x00000000
            0x7b1a84a9 = 0x00000000
            0x036a1da0 = 0x00000000
            0x8a3eb02e = 0x00000000
            0x0d924bb7 = 0x00000000
        }
    }
}
