#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Sylas_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Sylas/Sylas.bin"
    "DATA/Characters/Sylas/Animations/Skin8.bin"
    "DATA/Sylas_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin0_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Sylas_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Sylas/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 2
        ChampionSkinName: string = "SylasSkin10"
        SkinParent: i32 = 8
        MetaDataTags: string = "faction:demacia,gender:male,race:human,skinline:freljord"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Sylas/Skins/Skin08/SylasLoadScreen_8.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Sylas/Skins/Skin08/SylasLoadscreen_8_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Sylas"
                "SylasSkin08"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Sylas_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Sylas/Skins/Base/Sylas_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Sylas/Skins/Base/Sylas_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Sylas/Skins/Base/Sylas_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Sylas_Attack2D"
                        "Play_vo_Sylas_AttackChampion2D"
                        "Play_vo_Sylas_AttackChampion2DDemacian"
                        "Play_vo_Sylas_Death3D"
                        "Play_vo_Sylas_EnemyFirstEncounter3DEzreal"
                        "Play_vo_Sylas_EnemyFirstEncounter3DFiora"
                        "Play_vo_Sylas_EnemyFirstEncounter3DForeignDemacians"
                        "Play_vo_Sylas_EnemyFirstEncounter3DGalio"
                        "Play_vo_Sylas_EnemyFirstEncounter3DGaren"
                        "Play_vo_Sylas_EnemyFirstEncounter3DJarvanIV"
                        "Play_vo_Sylas_EnemyFirstEncounter3DJinx"
                        "Play_vo_Sylas_EnemyFirstEncounter3DLux"
                        "Play_vo_Sylas_EnemyFirstEncounter3DNoxian"
                        "Play_vo_Sylas_EnemyFirstEncounter3DPoppy"
                        "Play_vo_Sylas_EnemyFirstEncounter3DPrisoners"
                        "Play_vo_Sylas_EnemyFirstEncounter3DQuinn"
                        "Play_vo_Sylas_EnemyFirstEncounter3DRyze"
                        "Play_vo_Sylas_EnemyFirstEncounter3DSona"
                        "Play_vo_Sylas_EnemyFirstEncounter3DTaliyah"
                        "Play_vo_Sylas_EnemyFirstEncounter3DTwitch"
                        "Play_vo_Sylas_EnemyFirstEncounter3DVastaya"
                        "Play_vo_Sylas_EnemyFirstEncounter3DVayne"
                        "Play_vo_Sylas_EnemyFirstEncounter3DYasuo"
                        "Play_vo_Sylas_EnemyFirstEncounter3DZed"
                        "Play_vo_Sylas_FirstMove2D"
                        "Play_vo_Sylas_Joke3D"
                        "Play_vo_Sylas_JokeResponse3D"
                        "Play_vo_Sylas_KillChampion3DGalio"
                        "Play_vo_Sylas_KillChampion3DGaren"
                        "Play_vo_Sylas_KillChampion3DJarvanIV"
                        "Play_vo_Sylas_KillChampion3DLux"
                        "Play_vo_Sylas_KillChampion3DUltimate"
                        "Play_vo_Sylas_Laugh3DGeneral"
                        "Play_vo_Sylas_Move2D"
                        "Play_vo_Sylas_MoveOrder2D"
                        "Play_vo_Sylas_MoveOrder2DLong"
                        "Play_vo_Sylas_MoveOrder2DRally"
                        "Play_vo_Sylas_RecallLeadIn3D"
                        "Play_vo_Sylas_Respawn2D"
                        "Play_vo_Sylas_SylasBasicAttack_OnCast"
                        "Play_vo_Sylas_SylasE_OnCast"
                        "Play_vo_Sylas_SylasQ_OnCast"
                        "Play_vo_Sylas_SylasR2_cast"
                        "Play_vo_Sylas_SylasR_OnCast"
                        "Play_vo_Sylas_SylasR_SpellCastR1"
                        "Play_vo_Sylas_SylasR_SpellCastR1Amumu"
                        "Play_vo_Sylas_SylasR_SpellCastR1Annie"
                        "Play_vo_Sylas_SylasR_SpellCastR1AOE"
                        "Play_vo_Sylas_SylasR_SpellCastR1Brand"
                        "Play_vo_Sylas_SylasR_SpellCastR1Fiddlesticks"
                        "Play_vo_Sylas_SylasR_SpellCastR1Fiora"
                        "Play_vo_Sylas_SylasR_SpellCastR1Galio"
                        "Play_vo_Sylas_SylasR_SpellCastR1Garren"
                        "Play_vo_Sylas_SylasR_SpellCastR1Jarvan"
                        "Play_vo_Sylas_SylasR_SpellCastR1Kayle"
                        "Play_vo_Sylas_SylasR_SpellCastR1Lame"
                        "Play_vo_Sylas_SylasR_SpellCastR1Lux"
                        "Play_vo_Sylas_SylasR_SpellCastR1Morgana"
                        "Play_vo_Sylas_SylasR_SpellCastR1Poppy"
                        "Play_vo_Sylas_SylasR_SpellCastR1Quinn"
                        "Play_vo_Sylas_SylasR_SpellCastR1Ryze"
                        "Play_vo_Sylas_SylasR_SpellCastR1Sona"
                        "Play_vo_Sylas_SylasR_SpellCastR1Support"
                        "Play_vo_Sylas_SylasR_SpellCastR1Sylas"
                        "Play_vo_Sylas_SylasR_SpellCastR1Teemo"
                        "Play_vo_Sylas_SylasR_SpellCastR1Thresh"
                        "Play_vo_Sylas_SylasR_SpellCastR1Time"
                        "Play_vo_Sylas_SylasR_SpellCastR1Transformation"
                        "Play_vo_Sylas_SylasR_SpellCastR1Tryhard"
                        "Play_vo_Sylas_SylasR_SpellCastR1Yasuo"
                        "Play_vo_Sylas_SylasR_SpellCastR1Zed"
                        "Play_vo_Sylas_SylasW_OnCast"
                        "Play_vo_Sylas_Taunt3D"
                        "Play_vo_SylasSkin01_RecallLeadIn3D"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Sylas_Skin08_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Sylas/Skins/Skin08/Sylas_Skin08_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Sylas/Skins/Skin08/Sylas_Skin08_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_SylasSkin08_Dance_cast"
                        "Play_sfx_SylasSkin08_Dance_loop"
                        "Play_sfx_SylasSkin08_Death3D_cast"
                        "Play_sfx_SylasSkin08_Joke_cast"
                        "Play_sfx_SylasSkin08_Laugh_cast"
                        "Play_sfx_Sylasskin08_Recall_cast"
                        "Play_sfx_SylasSkin08_Recall_end"
                        "Play_sfx_SylasSkin08_Respawn_cast"
                        "Play_sfx_SylasSkin08_SylasBasicAttack2_OnCast"
                        "Play_sfx_SylasSkin08_SylasBasicAttack2_OnHit"
                        "Play_sfx_SylasSkin08_SylasBasicAttack_OnCast"
                        "Play_sfx_SylasSkin08_SylasBasicAttack_OnHit"
                        "Play_sfx_SylasSkin08_SylasCritAttack_OnCast"
                        "Play_sfx_SylasSkin08_SylasCritAttack_OnHit"
                        "Play_sfx_SylasSkin08_SylasE2_hit"
                        "Play_sfx_SylasSkin08_SylasE2_hittarget"
                        "Play_sfx_SylasSkin08_SylasE2_OnCast"
                        "Play_sfx_SylasSkin08_SylasE2_OnMissileCast"
                        "Play_sfx_SylasSkin08_SylasE3_cast"
                        "Play_sfx_SylasSkin08_SylasE3_cast_target"
                        "Play_sfx_SylasSkin08_SylasE3_hit"
                        "Play_sfx_SylasSkin08_SylasE_OnCast"
                        "Play_sfx_SylasSkin08_SylasPassiveAttack_OnCast"
                        "Play_sfx_SylasSkin08_SylasPassiveAttack_OnHit"
                        "Play_sfx_SylasSkin08_SylasQ1_hit"
                        "Play_sfx_SylasSkin08_SylasQ2_hit"
                        "Play_sfx_SylasSkin08_SylasQ_OnCast"
                        "Play_sfx_SylasSkin08_SylasR2_cast"
                        "Play_sfx_SylasSkin08_SylasR2_self_cast"
                        "Play_sfx_SylasSkin08_SylasR_hit"
                        "Play_sfx_SylasSkin08_SylasR_OnCast"
                        "Play_sfx_SylasSkin08_SylasR_OnMissileLaunch"
                        "Play_sfx_SylasSkin08_SylasRCosmeticMissile_OnHit"
                        "Play_sfx_SylasSkin08_SylasW_hit"
                        "Play_sfx_SylasSkin08_SylasW_OnCast"
                        "Play_sfx_SylasSkin08_Taunt_cast"
                        "Stop_sfx_SylasSkin08_SylasR_OnMissileLaunch"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Sylas/Animations/Skin8"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Sylas/Skins/Skin08/Sylas_Skin08.skl"
            SimpleSkin: string = "ASSETS/Characters/Sylas/Skins/Skin08/Sylas_Skin08.skn"
            Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_TX_CM.dds"
            SkinScale: f32 = 1.10000002
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 150, 150, 150 }
            }
            Material: link = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Frosty_Body_mat_inst"
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "statue, hoodoff"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Chains_inst"
                    Submesh: string = "chain_left"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Chains_inst"
                    Submesh: string = "chain_right"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Chains_inst"
                    Submesh: string = "gauntlet_left"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Chains_inst"
                    Submesh: string = "gauntlet_right"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Recall_TX_CM.dds"
                    Submesh: string = "statue"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_RecallB_TX_CM.dds"
                    Submesh: string = "hoodoff"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x53af33cb
                    mEndingJointName: hash = 0x57af3a17
                    mDefaultMaskName: hash = 0xef7cfc3b
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x2a70ae49
                    mEndingJointName: hash = 0x2d70b302
                    mDefaultMaskName: hash = 0xef7cfc3b
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Sylas_Idle_Arm"
                BoneName: string = "L_Buffbone_Gauntlet"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Sylas_Idle_Arm"
                BoneName: string = "R_Buffbone_Gauntlet"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Sylas/HUD/Sylas_Circle_8.dds"
        mContextualActionData: link = 0xf6852e86
        IconCircle: option[string] = {
            "ASSETS/Characters/Sylas/HUD/Sylas_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Sylas/HUD/Sylas_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Sylas/Skins/Skin10/Resources"
        0x87b1d303: list2[pointer] = {
            0x67ac9672 {
                0x43c8c7b1: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = "Characters/Sylas/Spells/SylasRBuff"
                }
                0x071f3c1d: list2[embed] = {
                    0x00fa43e4 {
                        BoneName: string = "L_Buffbone_Gauntlet"
                        EffectKey: hash = "Sylas_R_Hand_Buff"
                    }
                    0x00fa43e4 {
                        BoneName: string = "R_Buffbone_Gauntlet"
                        EffectKey: hash = "Sylas_R_Hand_Buff"
                    }
                    0x00fa43e4 {
                        BoneName: string = "L_Chain_Spl3"
                        EffectKey: hash = "Sylas_R_Ult_chain_sparks"
                    }
                    0x00fa43e4 {
                        BoneName: string = "L_Chain_Spl6"
                        EffectKey: hash = "Sylas_R_Ult_chain_sparks"
                    }
                    0x00fa43e4 {
                        BoneName: string = "R_Chain_Spl3"
                        EffectKey: hash = "Sylas_R_Ult_chain_sparks"
                    }
                    0x00fa43e4 {
                        BoneName: string = "R_Chain_Spl6"
                        EffectKey: hash = "Sylas_R_Ult_chain_sparks"
                    }
                    0x00fa43e4 {
                        EffectKey: hash = 0x1f29eae7
                    }
                }
            }
        }
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_GroundAoE" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.800000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dustring"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.499000013
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -0.600000024
                                    0.600000024
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 220, 10, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 30, 0, 300 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 320 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 40, 320 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.439993888 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0627451017, 0, 0.121568628, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0878243521
                            0.204191625
                            0.404524297
                            0.731869578
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0627451017, 0, 0.121568628, 0 }
                            { 0.0627451017, 0, 0.121568628, 0.675814986 }
                            { 0.0627451017, 0, 0.121568628, 1 }
                            { 0.0627451017, 0, 0.121568628, 0.560006082 }
                            { 0.0627451017, 0, 0.121568628, 0.137254909 }
                            { 0.0627451017, 0, 0.121568628, 0 }
                        }
                    }
                }
                Pass: i16 = -15
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Illaoi/Skins/Skin02/Particles/Illaoi_Skin02_Q_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 60, 1.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 60, 1.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 2, 2, 2 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Illaoi/Skins/Skin02/Particles/Illaoi_Skin02_Q_Smoke_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Illaoi/Skins/Skin02/Particles/Illaoi_Skin02_Q_cas_smoke_mult.dds"
                    TexDivMult: vec2 = { 2, 2 }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.800000012
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.400000006
                                        0.600000024
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 1 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Chains"
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -12, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, -3960, 0 }
                            { 0, -3960, 0 }
                            { 0, -0, 0 }
                            { 0, -0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 290, 150 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Q_LONG_Chain_01.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Q_LONG_Chain_01.skl"
                        mAnimationName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Q_LONG_Chain_01.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.376470596, 0.529411793, 0.717647076, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.201587304
                            0.254661173
                            0.599947929
                            0.658131659
                            0.699999988
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                            { 0.376470596, 0.529411793, 0.717647076, 1 }
                            { 0.37164405, 0.529411793, 0.717647076, 1 }
                            { 0.376470596, 0.529411793, 0.717647076, 1 }
                            { 0.376470596, 0.529411793, 0.717647076, 1 }
                            { 0.376470596, 0.529411793, 0.717647076, 0.319996953 }
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                        }
                    }
                }
                ModulationFactor: vec4 = { 2, 2, 2, 1 }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 2
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.400000006
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                2
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/FN_Universal_Smoke_Mult_Red_001.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 1, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1.14999998, 1.29999995 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "CraterBottom"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 360 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0705882385, 0.0745098069, 0.0941176489, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.540001512 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.774499118
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.540001512 }
                            { 1, 1, 1, 0.540001512 }
                            { 1, 1, 1, 0.378005177 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -680
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_Q_crack_dissolve.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 410, 100, 0 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 2 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_indicator.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "FloorGlow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 370 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.435294122, 0.615686297, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.682539701
                            1
                        }
                        Values: list[vec4] = {
                            { 0.435294122, 0.615686297, 1, 1 }
                            { 0.435294122, 0.615686297, 1, 1 }
                            { 0.27824682, 0.393556327, 0.639215708, 0.419607848 }
                            { 0.290196091, 0.410457522, 0.666666687, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {}
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 380, 110, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 1, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_Q_ImpactGround.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0299999993
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Swipe_Mesh_ADD"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 900 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 2 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 370 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeMesh.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.270588249, 0.56078434, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.733146071
                            1
                        }
                        Values: list[vec4] = {
                            { 0.270588249, 0.56078434, 1, 1 }
                            { 0.270588249, 0.56078434, 1, 0.800000012 }
                            { 0.221776247, 0.459623218, 0.819607854, 0.200000003 }
                            { 0.177208766, 0.367258757, 0.654901981, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 15
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 20
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 270, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 9, 10 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1.29999995, 1, 1 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeTxt.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 4, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.200000003, 0 }
                }
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0299999993
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Swipe_Mesh_Dark"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 2 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 370 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeMesh.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0941176489, 0.0705882385, 0.254901975, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.733146071
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0941176489, 0.0705882385, 0.254901975, 1 }
                            { 0.0941176489, 0.0705882385, 0.254901975, 0.800000012 }
                            { 0.0771395639, 0.057854671, 0.208919644, 0.200000003 }
                            { 0.06163783, 0.0462283753, 0.166935787, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                AlphaRef: u8 = 15
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 20
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 270, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 9, 10 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1.29999995, 1, 1 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeTxt.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.200000003, 0 }
                }
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    0.800000012
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.349999994
                        }
                    }
                }
                Lifetime: option[f32] = {
                    1.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "bright"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1000, 206, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.499000013
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.600000024
                                    -0.600000024
                                    0.600000024
                                    0.600000024
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1000, 206, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 6, 6, 6 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 6, 6, 6 }
                        }
                    }
                }
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { -200, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 250, 700, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 700, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 0, 0, 250 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 0, 370 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 0, 370 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.219607845, 0.270588249, 1, 0.792156875 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.219607845, 0.270588249, 1, 0.792156875 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 11
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                0.699999988
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/FN_Universal_Smoke_Mult_Red_001.dds"
                }
                IsDirectionOriented: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 100, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_FrostOut.dds"
                TexAddressModeBase: u8 = 2
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_prison_mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.5, 0.5 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 2 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.100000001, 2 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 0 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 0 }
                            }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Sylas_Skin10_Q_GroundAoE"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_GroundAoE"
        Flags: u16 = 198
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_Root" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.330000013
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wings_main"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 0, 50 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_E2_LONG_Chain_01.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_E2_LONG_Chain_01.skl"
                        mAnimationName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_E2_LONG_Chain_01.anm"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.709803939, 0.796078444, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.123758413
                            0.378590792
                            0.70799613
                            1
                        }
                        Values: list[vec4] = {
                            { 0.709803939, 0.796078444, 1, 0 }
                            { 0.709803939, 0.796078444, 1, 1 }
                            { 0.553925395, 0.621253371, 0.78039217, 1 }
                            { 0.553925395, 0.621253371, 0.78039217, 0.250980407 }
                            { 0.473202616, 0.530718982, 0.666666687, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.241269842
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1.79999995, 1.20000005, 1.20000005 }
                            { 1, 1, 1.79999995 }
                            { 1, 1.0051384, 1.30513835 }
                            { 1, 1, 1 }
                            { 1, 1, 0.982213438 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0299999993
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "CenterFlare"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 90, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.11999695, 0.110002287, 0.200000003, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.155826554
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 4
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 90 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 90 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 350, 200, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.400000006, 0.400000006, 0.400000006 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Flame_Ring.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.330000013
                }
                ParticleLinger: option[f32] = {
                    0.100000001
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterName: string = "wings_main1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 20, 0, 50 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_E2_LONG_Chain_01.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_E2_LONG_Chain_01.skl"
                        mAnimationName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_E2_LONG_Chain_01.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.779995441, 0.779995441, 0.779995441, 0.429999232 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.300000012
                            0.634741604
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.190005347 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.241269842
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1.79999995, 1.20000005, 1.20000005 }
                            { 1, 1, 1.79999995 }
                            { 1, 1.0051384, 1.30513835 }
                            { 1, 1, 1 }
                            { 1, 1, 0.982213438 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    0.300000012
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Flash_Ground"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 80, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00499999989
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.184313729, 0.498039216, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.184313729, 0.498039216, 1, 1 }
                            { 0.184313729, 0.498039216, 1, 1 }
                            { 0.184313729, 0.498039216, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                MeshRenderFlags: u8 = 0
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 35, 35, 35 }
                            { 5, 5, 5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Flare-Omnimax.DDS"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.360000014
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                    1.29999995
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.360000014
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "dustPoofs1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 500, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 4, 10 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 60, 50, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 60, 50, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 80, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0431372561, 0.250980407, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.97999543 }
                            { 1, 1, 1, 0.659998477 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -10
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.600000024
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 150, 150 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 150, 150 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.306233048
                            0.644986451
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.800000012, 0.800000012 }
                            { 1.02189779, 0.555013537, 0.555013537 }
                            { 1.20000005, 0.284010857, 0.284010857 }
                            { 1.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_FrostOut.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.360000014
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                    1.29999995
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.360000014
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "dustPoofs2"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 500, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 500, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 4, 10 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -50, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 60, 50, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 60, 50, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 80, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00400000019
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.388235301, 0.635294139, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.97999543 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.600000024
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 150, 150 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 150, 150, 150 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.306233048
                            0.644986451
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.800000012, 0.800000012 }
                            { 1.02189779, 0.555013537, 0.555013537 }
                            { 1.20000005, 0.284010857, 0.284010857 }
                            { 1.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_FrostOut.dds"
            }
        }
        ParticleName: string = "Sylas_Skin10_E_Root"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_Root"
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_chain_R" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Chain5"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 200, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { -1, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { -5, 0, -25 }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.160784319, 0.407843143, 0.866666675, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.160784319, 0.407843143, 0.866666675, 0 }
                            { 0.160784319, 0.407843143, 0.866666675, 1 }
                            { 0.160784319, 0.407843143, 0.866666675, 1 }
                        }
                    }
                }
                Pass: i16 = -10
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_chain_mult2.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Chain6"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 200, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { -10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { -5, 0, -25 }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.368627459, 0.674509823, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.368627459, 0.674509823, 1, 0 }
                            { 0.368627459, 0.674509823, 1, 1 }
                            { 0.368627459, 0.674509823, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -9
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_chain_mult2.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "back4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 400, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { -10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { -5, 0, -25 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.164705887, 0.164705887, 1, 0.470588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -9
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.300000012
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Dissolve_Cloudy_01.dds"
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 47, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.899999976, 1, 1 }
                            { 1.10000002, 1, 1 }
                            { 0.899999976, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Dissolve_Cloudy_02.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "tip4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 270, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { -10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { -5, 0, -25 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.203921571, 0.298039228, 0.909803927, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.203932583
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -8
                ModulationFactor: vec4 = { 2, 2, 2, 1 }
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 55, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_E_mis_tip.dds"
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.340000004
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.340000004
                        }
                    }
                }
                Lifetime: option[f32] = {
                    0.600000024
                }
                EmitterName: string = "trailing1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 200, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                    2.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 200, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0800030529, 0.37000075, 1, 0.76000613 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0800030529, 0.37000075, 1, 0 }
                            { 0.0800030529, 0.37000075, 1, 0.76000613 }
                            { 0.0800030529, 0.37000075, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -9
                AlphaRef: u8 = 15
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 55, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.5
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.699999988
                                    -0.5
                                    0.5
                                    0.699999988
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 55, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Z_Glow.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    0.600000024
                }
                EmitterName: string = "sparks"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -600 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.34117648, 0.482352942, 1, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.719996929 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.719996929 }
                            { 0.450980008, 0.286274999, 1, 0 }
                        }
                    }
                }
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 60, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 60, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_FrostCrystals.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Sylas_Skin10_E_chain_R"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_chain_R"
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_R_hookmis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1.39999998
                }
                ParticleLinger: option[f32] = {
                    0.550000012
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ChainStriaght"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.753968239
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 0.160006106, 0.0899977088, 0.489997715, 0.349996179 }
                                { 0, 0, 0, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 100, 1 }
                            Dynamics: pointer = VfxAnimatedVector3fVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {}
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            1
                                            1.20000005
                                        }
                                    }
                                    VfxProbabilityTableData {}
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[vec3] = {
                                    { 0, 100, 1 }
                                }
                            }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0784313753, 0.23137255, 0.513725519, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0784313753, 0.23137255, 0.513725519, 1 }
                            { 0.0784313753, 0.23137255, 0.513725519, 1 }
                            { 0.0513648614, 0.148804307, 0.513725519, 0 }
                        }
                    }
                }
                Pass: i16 = 9
                ColorLookUpTypeY: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "HeadStay3"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -110, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_MissileMesh.scb"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.800000012, 0.800000012, 0.800000012, 0.56078434 }
                }
                Pass: i16 = 43
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -3, -90, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 0.5, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1.5
                }
                EmitterName: string = "HeadStay4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -110, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_MissileMesh.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.800000012, 0.800000012, 0.800000012, 0.56078434 }
                }
                Pass: i16 = 44
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { -3, -90, -90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.699999988, 0.5, 0.600000024 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 17
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "Swirl_Expand"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Height: f32 = 100
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwirlMesh01.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0899977088, 0.130006865, 0.250003815, 0.489997715 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0899977088, 0.130006865, 0.250003815, 0.489997715 }
                            { 0.0899977088, 0.130006865, 0.250003815, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 2, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 2, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 0.5 }
                            { 1, 0.300000012, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_P_SwipeTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 2 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 17
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.800000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "Swirl_Expand1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 500, 0 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Height: f32 = 100
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwirlMesh01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.220004573, 0.519996941, 1, 0.570000768 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.220004573, 0.519996941, 1, 0.570000768 }
                            { 0.220004573, 0.519996941, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 0.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 0.5 }
                            { 1, 0.300000012, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_WindSwirl01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 2 }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 17
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                EmitterName: string = "Swirl_Expand2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                0x3bf0b4ed: pointer = 0x12ab94a6 {
                    Height: f32 = 100
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwirlMesh01.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.360006094, 0.519996941, 1, 0.250003815 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.360006094, 0.519996941, 1, 0.250003815 }
                            { 0.360006094, 0.519996941, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -360
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -300, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 2, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.10000002
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 2, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 1, 0.5 }
                            { 1, 0.300000012, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_WindSwirl01.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0, 2 }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 65
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.660000026
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                    1.29999995
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.660000026
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    3
                }
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "dustPoofs"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 4, 10 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -150, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 60, 50, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 60, 50, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1, 0 }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0431372561, 0.250980407, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.97999543 }
                            { 1, 1, 1, 0.659998477 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.600000024
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_FrostOut.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.660000026
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.75
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                    1.29999995
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.660000026
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.200000003
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {
                    1
                }
                EmitterName: string = "dustPoofs1"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.300000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1500, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1500, 0, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 4, 10 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -150, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 60, 50, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 60, 50, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1, 0 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.388235301, 0.635294139, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.400000006
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.97999543 }
                            { 1, 1, 1, 0.659998477 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0.600000024
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 130, 150, 150 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 130, 150, 150 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.306233048
                            0.644986451
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0.800000012, 0.800000012 }
                            { 1.02189779, 0.555013537, 0.555013537 }
                            { 1.20000005, 0.284010857, 0.284010857 }
                            { 1.5, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_FrostOut.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.550000012
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ChainStriaght1"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.753968239
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0.349019617 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 100, 1 }
                            Dynamics: pointer = VfxAnimatedVector3fVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {}
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            1
                                            1.20000005
                                        }
                                    }
                                    VfxProbabilityTableData {}
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[vec3] = {
                                    { 0, 100, 1 }
                                }
                            }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.784313738, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0, 0.784313738, 1, 1 }
                            { 0, 0.784313738, 1, 1 }
                            { 0, 0.504421353, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 10
                ColorLookUpTypeY: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.550000012
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "ChainStriaght2"
                0xb929b43e: pointer = 0x9b19f2b5 {
                    0x2fec8a25: flag = true
                    0x6b77a8ca: embed = ValueColor {
                        Dynamics: pointer = VfxAnimatedColorVariableData {
                            Times: list[f32] = {
                                0
                                0.753968239
                                1
                            }
                            Values: list[vec4] = {
                                { 1, 1, 1, 1 }
                                { 1, 1, 1, 0.349019617 }
                                { 1, 1, 1, 0 }
                            }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 0, 1 }
                            Dynamics: pointer = VfxAnimatedVector3fVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {}
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            1
                                            1.20000005
                                        }
                                    }
                                    VfxProbabilityTableData {}
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[vec3] = {
                                    { 0, 0, 1 }
                                }
                            }
                        }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.215686277, 0.752941191, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.215686277, 0.752941191, 1, 1 }
                            { 0.215686277, 0.752941191, 1, 1 }
                            { 0.141253367, 0.484244525, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 11
                ColorLookUpTypeY: u8 = 3
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Z_Glow.dds"
            }
        }
        ParticleName: string = "Sylas_Skin10_R_hookmis"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_R_hookmis"
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_GroundAoE_R" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "CraterBottom"
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 360 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0705882385, 0.0745098069, 0.0941176489, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.540001512 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.774499118
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0.540001512 }
                            { 1, 1, 1, 0.540001512 }
                            { 1, 1, 1, 0.378005177 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = -680
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.300000012
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_Q_crack_dissolve.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                ParticleIsLocalOrientation: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 410, 100, 0 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 2 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_indicator.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0500000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 10
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.349999994
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    0.800000012
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.349999994
                        }
                    }
                }
                Lifetime: option[f32] = {
                    1.25
                }
                IsSingleParticle: flag = true
                EmitterName: string = "bright1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1000, 206, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.499000013
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.600000024
                                    -0.600000024
                                    0.600000024
                                    0.600000024
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1000, 206, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 6, 6, 6 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 6, 6, 6 }
                        }
                    }
                }
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { -200, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 250, 700, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 250, 700, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 0, 0, 250 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 0, 370 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 0, 370 }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.219607845, 0.270588249, 1, 0.792156875 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.219607845, 0.270588249, 1, 0.792156875 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 11
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.100000001
                                0.699999988
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/FN_Universal_Smoke_Mult_Red_001.dds"
                }
                IsDirectionOriented: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 100, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 100, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_FrostOut.dds"
                TexAddressModeBase: u8 = 2
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_prison_mult.dds"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.5, 0.5 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 2 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.100000001, 2 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 0 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 0 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "FloorGlow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[f32] = {
                            1
                            1
                            0
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 10, 370 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.435294122, 0.615686297, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.682539701
                            1
                        }
                        Values: list[vec4] = {
                            { 0.435294122, 0.615686297, 1, 1 }
                            { 0.435294122, 0.615686297, 1, 1 }
                            { 0.27824682, 0.393556327, 0.639215708, 0.419607848 }
                            { 0.290196091, 0.410457522, 0.666666687, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaRef: u8 = 0
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {}
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, -90, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 380, 110, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 1, 2, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_Q_ImpactGround.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Chains"
                Velocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -12, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0, -3960, 0 }
                            { 0, -3960, 0 }
                            { 0, -0, 0 }
                            { 0, -0, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 290, 150 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Q_LONG_Chain_01.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Q_LONG_Chain_01.skl"
                        mAnimationName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Q_LONG_Chain_01.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.700007617 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.376470596, 0.529411793, 0.717647076, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.201587304
                            0.254661173
                            0.599947929
                            0.658131659
                            0.699999988
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                            { 0.376470596, 0.529411793, 0.717647076, 1 }
                            { 0.37164405, 0.529411793, 0.717647076, 1 }
                            { 0.376470596, 0.529411793, 0.717647076, 1 }
                            { 0.376470596, 0.529411793, 0.717647076, 1 }
                            { 0.376470596, 0.529411793, 0.717647076, 0.319996953 }
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                            { 0.376470596, 0.529411793, 0.717647076, 0 }
                        }
                    }
                }
                ModulationFactor: vec4 = { 2, 2, 2, 1 }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 2
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.400000006
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                2
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/FN_Universal_Smoke_Mult_Red_001.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 1, 0 }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1.14999998, 1.29999995 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0299999993
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.150000006
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Swipe_Mesh_ADD"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 900 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 2 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 370 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeMesh.scb"
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.270588249, 0.56078434, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.733146071
                            1
                        }
                        Values: list[vec4] = {
                            { 0.270588249, 0.56078434, 1, 1 }
                            { 0.270588249, 0.56078434, 1, 0.800000012 }
                            { 0.221776247, 0.459623218, 0.819607854, 0.200000003 }
                            { 0.177208766, 0.367258757, 0.654901981, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 15
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 20
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 270, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 9, 10 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1.29999995, 1, 1 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeTxt.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 4, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.200000003, 0 }
                }
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.0299999993
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.25
                }
                ParticleLinger: option[f32] = {
                    11
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Swipe_Mesh_Dark"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 2 }
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 0, 370 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeMesh.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0941176489, 0.0705882385, 0.254901975, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.733146071
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0941176489, 0.0705882385, 0.254901975, 1 }
                            { 0.0941176489, 0.0705882385, 0.254901975, 0.800000012 }
                            { 0.0771395639, 0.057854671, 0.208919644, 0.200000003 }
                            { 0.06163783, 0.0462283753, 0.166935787, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                AlphaRef: u8 = 15
                SoftParticleParams: pointer = VfxSoftParticleDefinitionData {
                    BeginIn: f32 = 20
                    DeltaIn: f32 = 30
                }
                DisableBackfaceCull: bool = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 270, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 9, 10 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 1.29999995, 1, 1 }
                            { 1.10000002, 1, 1 }
                            { 1, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_SwipeTxt.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                BirthUvoffset: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.200000003, 0 }
                }
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.800000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.600000024
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    0.800000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Dustring"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 220, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.499000013
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1.5
                                    -0.600000024
                                    0.600000024
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 220, 10, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                    Size: vec3 = { 30, 0, 300 }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 40, 320 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 40, 320 }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.439993888 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0627451017, 0, 0.121568628, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.0878243521
                            0.204191625
                            0.404524297
                            0.731869578
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0627451017, 0, 0.121568628, 0 }
                            { 0.0627451017, 0, 0.121568628, 0.675814986 }
                            { 0.0627451017, 0, 0.121568628, 1 }
                            { 0.0627451017, 0, 0.121568628, 0.560006082 }
                            { 0.0627451017, 0, 0.121568628, 0.137254909 }
                            { 0.0627451017, 0, 0.121568628, 0 }
                        }
                    }
                }
                Pass: i16 = -15
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                1
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.150000006
                    ErosionFeatherOut: f32 = 0.150000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Illaoi/Skins/Skin02/Particles/Illaoi_Skin02_Q_SmokeErode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                    ErosionMapAddressMode: u8 = 0
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -20
                                    20
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 60, 1.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 60, 1.5 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                            { 2, 2, 2 }
                            { 3, 3, 3 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Illaoi/Skins/Skin02/Particles/Illaoi_Skin02_Q_Smoke_01.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Illaoi/Skins/Skin02/Particles/Illaoi_Skin02_Q_cas_smoke_mult.dds"
                    TexDivMult: vec2 = { 2, 2 }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.800000012
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.400000006
                                        0.600000024
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 1 }
                            }
                        }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 1, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 1, 1 }
                            }
                        }
                    }
                }
            }
        }
        ParticleName: string = "Sylas_Skin10_Q_GroundAoE_R"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_GroundAoE_R"
        Flags: u16 = 198
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_outro_chains" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.800000012
                }
                ParticleLinger: option[f32] = {}
                Lifetime: option[f32] = {
                    0.100000001
                }
                IsSingleParticle: flag = true
                EmitterLinger: option[f32] = {}
                EmitterName: string = "Avatar1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0xcbf1d972
                            0x25d17c1f
                        }
                        mSubmeshesToDrawAlways: list[hash] = {
                            0xcbf1d972
                            0x25d17c1f
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.643137276, 0.643137276, 0.643137276, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.449999988
                        }
                        Values: list[vec4] = {
                            { 0.521568656, 0.43921569, 0.113725491, 0 }
                            { 0.820004582, 0.620004594, 0.110002287, 0 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                DoesCastShadow: flag = true
                UvScrollClamp: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
                TexAddressModeBase: u8 = 2
            }
        }
        ParticleName: string = "Sylas_Skin10_Q_outro_chains"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_outro_chains"
    }
    "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_chain" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "tip"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 270, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { 10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { 5, 0, -25 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.203921571, 0.298039228, 0.909803927, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.203932583
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -8
                ModulationFactor: vec4 = { 2, 2, 2, 1 }
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 55, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_E_mis_tip.dds"
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Chain4"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 200, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { 10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { 5, 0, -25 }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.160784319, 0.407843143, 0.866666675, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.160784319, 0.407843143, 0.866666675, 0 }
                            { 0.160784319, 0.407843143, 0.866666675, 1 }
                            { 0.160784319, 0.407843143, 0.866666675, 1 }
                        }
                    }
                }
                Pass: i16 = -10
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_chain_mult2.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "back1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 400, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { 10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { 5, 0, -25 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.164705887, 0.164705887, 1, 0.470588237 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -9
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.300000012
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Dissolve_Cloudy_01.dds"
                }
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 47, 1, 1 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 0.899999976, 1, 1 }
                            { 1.10000002, 1, 1 }
                            { 0.899999976, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Dissolve_Cloudy_02.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {
                    0.200000003
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Chain5"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveBeam {
                    mBeam: embed = VfxBeamDefinitionData {
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0, 200, 0 }
                        }
                        mLocalSpaceSourceOffset: vec3 = { 10, 0, 0 }
                        mLocalSpaceTargetOffset: vec3 = { 5, 0, -25 }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.368627459, 0.674509823, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec4] = {
                            { 0.368627459, 0.674509823, 1, 0 }
                            { 0.368627459, 0.674509823, 1, 1 }
                            { 0.368627459, 0.674509823, 1, 1 }
                        }
                    }
                }
                Pass: i16 = -9
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 1, 1 }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_R_ChainMisTXT.dds"
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 1.5, 0 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Sylas/Skins/Base/Particles/Sylas_Base_E_chain_mult2.dds"
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    10.3000002
                }
                Lifetime: option[f32] = {
                    0.600000024
                }
                EmitterName: string = "sparks"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, -200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 5, 5 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 50, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 50, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {}
                        ValueFloat {}
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 0 }
                        { 0, 0, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 50 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.34117648, 0.482352942, 1, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.719996929 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.719996929 }
                            { 0.450980008, 0.286274999, 1, 0 }
                        }
                    }
                }
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 60, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 60, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 0 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_FrostCrystals.dds"
                BirthFrameRate: embed = ValueFloat {
                    ConstantValue: f32 = 0
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
        }
        ParticleName: string = "Sylas_Skin10_E_chain"
        ParticlePath: string = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_chain"
    }
    "Characters/Sylas/Skins/Skin10/Materials/Sylas_Frosty_Body_mat_inst" = StaticMaterialDef {
        Name: string = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Frosty_Body_mat_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Overlay_Texture_Ult"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Z_UltOverlayTest.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Overlay_Texture"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_TattoosFX.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Scroll_Texture"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Idle_Tattoos_Glow.dds"
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Scroll_Speed"
                Value: vec4 = { -0.100000001, 0.150000006, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Scroll_Speed_Body"
                Value: vec4 = { 0.159999996, 0.0799999982, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Add_Noise_Color"
                Value: vec4 = { 0.790005326, 0.930006862, 1, 1 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "ULTIMATE"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Sylas_Frosty_Mat"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Add_Noise_Color"
                    Driver: pointer = ColorChooserMaterialDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            mScriptName: string = "SylasRBuff"
                        }
                        mColorOn: vec4 = { 0.247058824, 0.501960814, 0.913725495, 1 }
                        mColorOff: vec4 = { 0.196078435, 0.372549027, 0.788235307, 1 }
                    }
                }
            }
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Overlay_Texture"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = HasBuffDynamicMaterialBoolDriver {
                                mScriptName: string = "SylasRBuff"
                            }
                            TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Sylas_Skin08_TattoosFX_Ult.dds"
                        }
                    }
                }
            }
            StaticSwitch: pointer = DynamicMaterialStaticSwitch {
                Name: string = "ULTIMATE"
                Driver: pointer = HasBuffDynamicMaterialBoolDriver {
                    mScriptName: string = "SylasRBuff"
                }
            }
        }
    }
    "Characters/Sylas/Skins/Skin10/Materials/Sylas_Chains_inst" = StaticMaterialDef {
        Name: string = "Characters/Sylas/Skins/Skin10/Materials/Sylas_Chains_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Z_Color-hold.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "texture_scroll"
                TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin08/Particles/Sylas_Skin08_Q_trail_mult.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 1, 0.666666687, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Size"
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Bias"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Bias"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Diffuse_Alpha_Override"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.730000019, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "fresnel_color_ult"
                Value: vec4 = { 0.250980407, 0.639215708, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.0784313753, 0.400000006, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollRate"
                Value: vec4 = { 0, -0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_size_ult"
                Value: vec4 = { 10.2399998, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "FresnelColor_Bias_ult"
                Value: vec4 = { 0.0974999964, 0.200000003, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "ScrollRate_ult"
                Value: vec4 = { 0.5, -0.100000001, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "INVERT_FRESNEL"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ULTIMATE"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Sylas_Chains"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Diffuse_Texture"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = HasBuffDynamicMaterialBoolDriver {
                                mScriptName: string = "SylasRBuff"
                            }
                            TextureName: string = "ASSETS/Characters/Sylas/Skins/Skin10/Sylas_Skin10_Shackles_TX_CM.dds"
                        }
                    }
                }
            }
            StaticSwitch: pointer = DynamicMaterialStaticSwitch {
                Name: string = "ULTIMATE"
                Driver: pointer = HasBuffDynamicMaterialBoolDriver {
                    mScriptName: string = "SylasRBuff"
                }
            }
        }
    }
    "Characters/Sylas/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Sylas_E_Root" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_Root"
            0x92bce02e = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_E_Banish"
            "Sylas_R_hookmis" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_R_hookmis"
            "Sylas_E_chain" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_chain"
            "Sylas_W_Nova" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_P_Nova"
            "Sylas_W_tar" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_W_tar"
            "Sylas_BA_tar" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_BA_tar"
            "Sylas_E_cas" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_E_cas"
            "Sylas_R_timer" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_timer"
            0x68464318 = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Emote_Death_Sound"
            0x5dd2f61f = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Emote_Joke_Sound"
            0x324c9bc7 = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Emote_Laugh_Sound"
            0x90508386 = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Emote_Taunt_Sound"
            0x5b5c5119 = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Taunt"
            "Sylas_R_Beam" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Beam"
            0x1f29eae7 = 0x209e233e
            "Sylas_W_Hand_Hit" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_W_Hand_Hit"
            "Sylas_Q_GroundAoE" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_GroundAoE"
            "Sylas_Q_POF_charge" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Q_POF_charge"
            "Sylas_Q_POF_tar" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Q_POF_tar"
            "Sylas_W_tar_avatar" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_W_tar_avatar"
            "Sylas_BA_Trail_01" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_BA_Trail_01"
            "Sylas_BA_Trail_02" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_BA_Trail_02"
            "Sylas_E_chain_R" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_E_chain_R"
            "Sylas_R_Cas_Arm" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Cas_Arm"
            "Sylas_R_Cas_Start" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Cas_Start"
            "Sylas_R_Hand_Buff" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Hand_Buff"
            "Sylas_R_Ult_chain_sparks" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Ult_chain_sparks"
            "Sylas_Q_GroundAoE_R" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_GroundAoE_R"
            "Sylas_Q_cas_chains" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Q_cas_chains"
            "Sylas_Q_Test_beam" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Q_Test_beam"
            "Sylas_E_cas_hand" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_E_cas_hand"
            "Sylas_Q_Indicator" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Q_Indicator"
            "Sylas_E_chain_move" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_E_chain_move"
            "Sylas_E_chain_move_R" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_E_chain_move_R"
            "Sylas_Idle_Arm" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Idle_Arm"
            "Sylas_R_Ult_Absorbed_Chest" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Ult_Absorbed_Chest"
            "Sylas_Q_X_Mark_Anticipation" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Q_X_Mark_Anticipation"
            "Sylas_W_Dash_In" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_W_Dash_In"
            "Sylas_P_hit" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_P_hit"
            "Sylas_R_Clone_Transform" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Clone_Transform"
            "Sylas_Q_hit" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Q_hit"
            "Sylas_Q_Indicator_Left" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Q_Indicator_Left"
            "Sylas_P_Hand" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_P_Hand"
            "Sylas_Death_Dust" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Death_Dust"
            "Sylas_Recall_Arm" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Recall_Arm"
            "Sylas_E_cas_swipe" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_E_cas_swipe"
            "Sylas_R_Hit" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Hit"
            "Sylas_Recall_Break" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Recall_Break"
            "Sylas_Recall_Lock" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Recall_Lock"
            "Sylas_Recall_Lock_R" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Recall_Lock_R"
            "Sylas_Recall_Break_R" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Recall_Break_R"
            "Sylas_Recall_Chains" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Recall_Chains"
            "Sylas_Recall_Break_ToRun" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_Recall_Break_ToRun"
            "Sylas_Recall_Break_ToRun_R" = 0x2843ae31
            "Sylas_R_Clone_Transform_Exit" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_R_Clone_Transform_Exit"
            "Sylas_BA_tar_R" = "Characters/Sylas/Skins/Skin8/Particles/Sylas_Skin08_BA_tar_R"
            "Sylas_Emote_Taunt" = "Characters/Sylas/Skins/Skin0/Particles/Sylas_Base_Emote_Taunt"
            "Sylas_Q_outro_chains" = "Characters/Sylas/Skins/Skin10/Particles/Sylas_Skin10_Q_outro_chains"
            0xe8da3ede = 0x752e032f
            0xca3e21c2 = 0x38e58c5d
            0xd415ebfa = 0x052056c3
        }
    }
}
