#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Olaf/Olaf.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Olaf/Animations/Skin0.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin3_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Olaf_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin2_Skins_Skin3_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Olaf/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "BroOlaf"
        MetaDataTags: string = "faction:freljord,gender:male,race:human,element:lightning,skinline:dayjob"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Olaf/Skins/Skin03/OlafLoadScreen_3.PIE_C_14_7.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Olaf/Skins/Skin03/OlafLoadScreen_3_LE.PIE_C_14_7.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Olaf"
                "OlafSkin03"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Olaf_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Olaf/Skins/Base/Olaf_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Olaf/Skins/Base/Olaf_Base_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_Olaf_OlafBasicAttack2_OnCast"
                        "Play_sfx_Olaf_OlafBasicAttack2_OnHit"
                        "Play_sfx_Olaf_OlafBasicAttack3_OnCast"
                        "Play_sfx_Olaf_OlafBasicAttack3_OnHit"
                        "Play_sfx_Olaf_OlafBasicAttack_OnCast"
                        "Play_sfx_Olaf_OlafBasicAttack_OnHit"
                        "Play_sfx_Olaf_OlafCritAttack2_OnCast"
                        "Play_sfx_Olaf_OlafCritAttack2_OnHit"
                        "Play_sfx_Olaf_OlafCritAttack_OnCast"
                        "Play_sfx_Olaf_OlafCritAttack_OnHit"
                        "Play_sfx_Olaf_OlafE_OnCast"
                        "Play_sfx_Olaf_OlafE_OnHit"
                        "Play_sfx_Olaf_OlafQ_grab"
                        "Play_sfx_Olaf_OlafQ_hit"
                        "Play_sfx_Olaf_OlafQ_land"
                        "Play_sfx_Olaf_OlafQ_OnMissileLaunch"
                        "Play_sfx_Olaf_OlafQCast_OnCast"
                        "Play_sfx_Olaf_OlafR_OnBuffActivate"
                        "Play_sfx_Olaf_OlafR_OnCast"
                        "Play_sfx_Olaf_OlafW_OnBuffActivate"
                        "Play_sfx_Olaf_OlafW_OnCast"
                        "Stop_sfx_Olaf_OlafQ_grab"
                        "Stop_sfx_Olaf_OlafQ_OnMissileLaunch"
                        "Stop_sfx_Olaf_OlafR_OnBuffActivate"
                        "Stop_sfx_Olaf_OlafW_OnBuffActivate"
                    }
                }
                BankUnit {
                    Name: string = "Olaf_Skin03_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Olaf/Skins/Skin03/Olaf_Skin03_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Olaf/Skins/Skin03/Olaf_Skin03_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Olaf/Skins/Skin03/Olaf_Skin03_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_OlafSkin03_Attack2DGeneral"
                        "Play_vo_OlafSkin03_Death3D"
                        "Play_vo_OlafSkin03_Joke3DGeneral"
                        "Play_vo_OlafSkin03_Laugh3DGeneral"
                        "Play_vo_OlafSkin03_Move2DStandard"
                        "Play_vo_OlafSkin03_OlafAxeThrowCast_cast3D"
                        "Play_vo_OlafSkin03_OlafBasicAttack_cast3D"
                        "Play_vo_OlafSkin03_OlafCritAttack_cast3D"
                        "Play_vo_OlafSkin03_OlafFrenziedStrikes_cast3D"
                        "Play_vo_OlafSkin03_OlafRagnarok_cast3D"
                        "Play_vo_OlafSkin03_OlafRecklessStrike_cast3D"
                        "Play_vo_OlafSkin03_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Olaf/Animations/Skin0"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Olaf/Skins/Skin03/Olaf_bro.skl"
            SimpleSkin: string = "ASSETS/Characters/Olaf/Skins/Skin03/Olaf_bro.skn"
            Texture: string = "ASSETS/Characters/Olaf/Skins/Skin03/olaf_brolaff_TX_CM.dds"
            SkinScale: f32 = 1.20000005
            SelfIllumination: f32 = 0.5
            UsesSkinVo: bool = true
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
        }
        ArmorMaterial: string = "Flesh"
        IconAvatar: string = "ASSETS/Characters/Olaf/HUD/Olaf_Circle_3.dds"
        mContextualActionData: link = "Characters/Olaf/CAC/Olaf_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Olaf/HUD/Olaf_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Olaf/HUD/Olaf_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/31"
            }
        }
        mResourceResolver: link = "Characters/Olaf/Skins/Skin3/Resources"
    }
    "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_mis" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = "Olaf_Q_ChildTrail"
                        }
                    }
                }
                EmitterName: string = "BrolafMaterialOverride"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, -90, -40 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/olaf_bro_axe.scb"
                    }
                }
                BlendMode: u8 = 1
                DoesCastShadow: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -90, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 1200 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.53999996, 1.25999999, 1.53999996 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.25, 1.25, 1.25 }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/olaf_axe_bro.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_GroundGlow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -150, -90 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.666666687, 0.329411775, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.666666687, 0.329411775, 0 }
                            { 1, 0.666666687, 0.329411775, 1 }
                            { 1, 0.666666687, 0.329411775, 1 }
                            { 1, 0.666666687, 0.329411775, 0 }
                        }
                    }
                }
                Pass: i16 = 23
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 220, 180 }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/Olaf_Q_Shape.dds"
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_Q_Bottom_02.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, -1 }
                    }
                    BirthUvoffsetMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0, 1 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    3
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Temp_GroundGlow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -150, -90 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.568627477, 0.215686277, 0.368627459 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.150000006
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 22
                MiscRenderFlags: u8 = 1
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 220, 180 }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/Olaf_Q_Shape.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                }
                ParticleLinger: option[f32] = {
                    10.1999998
                }
                Lifetime: option[f32] = {
                    0.600000024
                }
                EmitterName: string = "Trail"
                Primitive: pointer = VfxPrimitiveCameraTrail {
                    mTrail: embed = VfxTrailDefinitionData {
                        mMode: u8 = 1
                        mBirthTilingSize: embed = ValueVector3 {
                            ConstantValue: vec3 = { 0.100000001, 0, 0 }
                        }
                        mSmoothingMode: u8 = 2
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.229999244 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0.0199999996
                            0.101000004
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.635294139, 0.313725501, 0 }
                            { 1, 0.454901963, 0.0901960805, 1 }
                            { 1, 0.776470602, 0.411764711, 0 }
                        }
                    }
                }
                Pass: i16 = -1
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 150, 0, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_Q_Beam_01.dds"
                TexDiv: vec2 = { 5000, 1 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.109999999
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.649999976
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.649999976
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    5
                }
                EmitterName: string = "Splashes_IN"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 100, 500, 100 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 100, 500, 100 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 1.5, 3 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -1250, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -1250, 0 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0xba945ee1 {
                    Flags: u8 = 1
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 25, 0 }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.710002303, 0.310002297, 0.37000075 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.285331249
                            0.616613626
                            0.828701198
                            0.999899983
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0.360006094 }
                            { 1, 1, 1, 0.100007631 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 25
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_E_AlphaSlice_1.dds"
                }
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 0, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.499000013
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.5
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 70, 70 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 70, 70 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.29999995, 1.29999995, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_Splash_2x2.dds"
                BirthFrameRate: embed = ValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.180000007
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    2
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "SplatterSmall"
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 30, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        0.800000012
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.5
                                        1
                                        2
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 30, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -90, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.850003839, 0.669993162, 0.209994659 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.00999999978
                            0.349999994
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 5
                ColorLookUpTypeY: u8 = 3
                ColorLookUpScales: vec2 = { 1, 0.25 }
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.300000012
                            }
                            Values: list[f32] = {
                                1
                                0
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_E_Floor_Puddle_erode.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 35, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 35, 1, 1 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.00587099977
                            0.136298418
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.60136759, 1.60136759, 1.60136759 }
                            { 1.65842736, 1.65842736, 1.65842736 }
                            { 1.6411078, 1.6411078, 1.6411078 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_Splash_2x2.dds"
                BirthFrameRate: embed = ValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.699999988
                }
                Lifetime: option[f32] = {
                    0.600000024
                }
                FieldCollectionDefinition: pointer = VfxFieldCollectionDefinitionData {}
                EmitterName: string = "bubbles_front_OktoberGragas"
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.5, 1.5, 0.5 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.5, 1.5, 0.5 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 500, 20 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.800000012
                                    1.20000005
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1000, 0 }
                            { 0, 250, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 4, 5, 4 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 25, 50, 0 }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 10
                        }
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                Times: list[f32] = {
                                    0
                                    1
                                }
                                Values: list[f32] = {
                                    500
                                    -300
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 0, 1.00000012 }
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.694117665, 0.34117648, 1 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.839993894 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.839993894 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 120
                MeshRenderFlags: u8 = 0
                ColorLookUpTypeY: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 6, 6 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0.300000012
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.25
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 6, 6 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.935000002
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 2.5, 2.5, 2.5 }
                            { 2, 2, 2 }
                            { 5, 5, 5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_E_Bubble.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Olaf/Skins/Skin03/Particles/Olaf_Skin03_Bubbles_Mult.dds"
                    TexDivMult: vec2 = { 2, 2 }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0, 1 }
                    }
                }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.449999988
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "GoodOne"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { -80, 10, -100 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.899999976
                                        1.10000002
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { -80, 10, -100 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.250003815 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.490196079, 0.458823532, 0.447058827, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.649999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.490196079, 0.458823532, 0.447058827, 1 }
                            { 0.490196079, 0.440830439, 0.417254895, 1 }
                            { 0.308823168, 0.275294125, 0.254823864, 0.220004573 }
                            { 0.188389078, 0.169134945, 0.161291808, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/Olaf_Base_Q_Gradient.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, 200, 10 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 150, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.600000024, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/Olaf_Base_Q_GroundSmoke02.dds"
                NumFrames: u16 = 2
                TexDiv: vec2 = { 1, 2 }
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 20
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.449999988
                }
                ParticleLinger: option[f32] = {
                    11
                }
                EmitterName: string = "GoodOne1"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 80, 10, -100 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.899999976
                                        1.10000002
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 80, 10, -100 }
                            }
                        }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.250003815 }
                }
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.490196079, 0.458823532, 0.447058827, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.649999976
                            1
                        }
                        Values: list[vec4] = {
                            { 0.490196079, 0.458823532, 0.447058827, 1 }
                            { 0.490196079, 0.440830439, 0.417254895, 1 }
                            { 0.308823168, 0.275294125, 0.254823864, 0.220004573 }
                            { 0.188389078, 0.169134945, 0.161291808, 0 }
                        }
                    }
                }
                Pass: i16 = -2
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                1
                            }
                            Values: list[f32] = {
                                0
                                0
                                1
                            }
                        }
                    }
                    ErosionMapName: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/Olaf_Base_Q_Gradient.dds"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                MiscRenderFlags: u8 = 1
                IsRandomStartFrame: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 180, -20, 10 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 200, 150, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1.10000002
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 200, 150, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.600000024, 2, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Olaf/Skins/Base/Particles/Olaf_Base_Q_GroundSmoke02.dds"
                NumFrames: u16 = 2
                TexDiv: vec2 = { 1, 2 }
            }
        }
        ParticleName: string = "Olaf_Skin03_Q_mis"
        ParticlePath: string = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_mis"
        Flags: u16 = 140
    }
    "Characters/Olaf/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x972741d7 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axeThrow_tar"
            0xa7b33258 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axeThrow_tar_02"
            0x978e5657 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axeThrow_tar_03"
            0x24c8b365 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axe_refresh_indicator"
            0x3603e1a1 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axe_totem_team_id_green"
            0x618e6ad0 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axe_trigger"
            0xfd796c15 = "Characters/Olaf/Skins/Skin0/Particles/olaf_axe_trigger_02"
            "Olaf_BA_tar_01" = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Base_BA_tar_01"
            "Olaf_BA_tar_crit_01" = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Base_BA_tar_crit_01"
            "Olaf_E_cas" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_E_cas"
            "Olaf_E_tar" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_E_tar"
            "Olaf_Q_Axe_Ally" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_Axe_Ally"
            "Olaf_Q_Axe_Enemy" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_Axe_Enemy"
            "Olaf_Q_Axe_Smoke" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_Axe_Smoke"
            "Olaf_Q_buf_pickup" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_buf_pickup"
            "Olaf_Q_mis" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_mis"
            "Olaf_Q_tar" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_tar"
            "Olaf_R_buf" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_R_buf"
            "Olaf_R_buff_weap" = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Base_R_buff_weap"
            "Olaf_W_buf_blood" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_W_buf_blood"
            "Olaf_W_buf_glow" = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Base_W_buf_glow"
            "Olaf_W_cas" = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Base_W_cas"
            "Olaf_W_heal" = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Base_W_heal"
            0x3f10a8c3 = "Characters/Olaf/Skins/Skin0/Particles/olaf_pentakill_axeThrow_tar_02"
            0xc4ced98e = "Characters/Olaf/Skins/Skin0/Particles/olaf_pentakill_axe_totem_team_id_green"
            0xedad8750 = "Characters/Olaf/Skins/Skin0/Particles/Olaf_Pentakill_Q_Cymbal"
            0x57922542 = "Characters/Olaf/Skins/Skin0/Particles/olaf_ragnorok_buff"
            0x85fe6379 = "Characters/Olaf/Skins/Skin0/Particles/olaf_ragnorok_enraged"
            0x887a6f8e = "Characters/Olaf/Skins/Skin0/Particles/olaf_ragnorok_shield_01"
            0x24205cd3 = "Characters/Olaf/Skins/Skin0/Particles/olaf_ragnorok_shield_02"
            0xc2744a5b = "Characters/Olaf/Skins/Skin0/Particles/olaf_recklessStrike_axe_charge"
            0x2942330d = "Characters/Olaf/Skins/Skin3/Particles/olaf_recklessStrike_cas_Skin03"
            0xc2e52f3e = "Characters/Olaf/Skins/Skin3/Particles/olaf_recklessStrike_cas_L_Skin03"
            0x982446dc = "Characters/Olaf/Skins/Skin0/Particles/olaf_recklessSwing_tar_02"
            0xa141a67b = "Characters/Olaf/Skins/Skin0/Particles/olaf_recklessSwing_tar_03"
            0x3ba9de8a = "Characters/Olaf/Skins/Skin0/Particles/olaf_recklessSwing_tar_04"
            0xc4442049 = "Characters/Olaf/Skins/Skin0/Particles/olaf_recklessSwing_tar_05"
            0x7dded75f = "Characters/Olaf/Skins/Skin0/Particles/olaf_viciousStrikes_axes_blood"
            0xbd28bb73 = "Characters/Olaf/Skins/Skin0/Particles/olaf_viciousStrikes_heal"
            0x17d640d3 = "Characters/Olaf/Skins/Skin0/Particles/olaf_viciousStrikes_self"
            0x7574e411 = "Characters/Olaf/Skins/Skin0/Particles/olaf_viciousStrikes_weapon_glow"
            0xa72a08eb = "Characters/Olaf/Skins/Skin0/Particles/olaf_waterLog_debuf"
            0x4ae6c57a = "Characters/Olaf/Skins/Skin0/Particles/olaf_waterLog_Slow"
            "Olaf_Q_ChildTrail" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_ChildTrail"
            "Olaf_BA_Swipe_1" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_BA_Swipe_1"
            "Olaf_BA_Swipe_2" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_BA_Swipe_2"
            "Olaf_BA_Swipe_3" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_BA_Swipe_3"
            "Olaf_E_Swipe" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_E_Swipe"
            "Olaf_Q_cas" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_Q_cas"
            "Olaf_BA_Swipe_Crit" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_BA_Swipe_Crit"
            0xab734289 = 0xcd8fd456
            0xb709cb28 = 0x747644ff
            0xf3b57c16 = 0x30c35bdf
            "Olaf_Skin03_E_Barrel_Child" = "Characters/Olaf/Skins/Skin3/Particles/Olaf_Skin03_E_Barrel_Child"
        }
    }
}
