#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Corki/Corki.bin"
    "DATA/Corki_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Corki/Animations/Skin0.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin2_Skins_Skin3_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin7.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin2_Skins_Skin3_Skins_Skin35_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin7.bin"
    "DATA/Corki_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin3_Skins_Skin4_Skins_Skin7.bin"
}
entries: map[hash,embed] = {
    "Characters/Corki/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "RedBaronCorki"
        MetaDataTags: string = "faction:piltover,race:yordle,gender:male,skinline:legacy"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Corki/Skins/Skin03/CorkiLoadScreen_3.DDS"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Corki"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Corki_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Corki/Skins/Base/Corki_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Corki/Skins/Base/Corki_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    Name: string = "Corki_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Corki/Skins/Base/Corki_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Corki/Skins/Base/Corki_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Corki/Skins/Base/Corki_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Corki_Attack2DGeneral"
                        "Play_vo_Corki_CarpetBombMega_cast3D"
                        "Play_vo_Corki_CorkiLoaded_cast"
                        "Play_vo_Corki_Death3D"
                        "Play_vo_Corki_Joke3DGeneral"
                        "Play_vo_Corki_Laugh3DGeneral"
                        "Play_vo_Corki_Move2DStandard"
                        "Play_vo_Corki_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Corki/Animations/Skin0"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Corki/Skins/Skin03/corki_RedBaron.skl"
            SimpleSkin: string = "ASSETS/Characters/Corki/Skins/Skin03/corki_RedBaron.skn"
            Texture: string = "ASSETS/Characters/Corki/Skins/Skin03/corki_RedBaron.dds"
            SkinScale: f32 = 0.899999976
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Extra"
            "Buffbones"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Corki_Idle_RB_Prop_01"
                BoneName: string = "gun"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Corki_idle_1"
                BoneName: string = "root"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Corki/HUD/Corki_Circle_3.dds"
        mContextualActionData: link = "Characters/Corki/CAC/Corki_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Corki/HUD/Corki_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Corki/HUD/Corki_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/31"
            }
        }
        mResourceResolver: link = "Characters/Corki/Skins/Skin3/Resources"
    }
    "Characters/Corki/Skins/Skin3/Particles/Corki_Skin03_idle_1" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLinger: option[f32] = {}
                EmitterLinger: option[f32] = {}
                EmitterName: string = "X_Avatar"
                Importance: u8 = 2
                0xf50b1a41: pointer = 0xf4e37e07 {
                    CensorPolicy: u8 = 1
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                CensorModulateValue: vec4 = { 1, 1, 1, 0 }
                DepthBiasFactors: vec2 = { -1, -3 }
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                Texture: string = "ASSETS/Characters/Corki/Skins/Skin03/Particles/corki_Skin03_redbaron_X_01.dds"
            }
        }
        ParticleName: string = "Corki_Skin03_idle_1"
        ParticlePath: string = "Characters/Corki/Skins/Skin3/Particles/Corki_Skin03_idle_1"
        Flags: u16 = 199
    }
    "Characters/Corki/Skins/Skin3/Particles/Corki_Skin03_Idle_RB_Prop_01" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1000
                }
                IsSingleParticle: flag = true
                EmitterName: string = "propeller"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -30, 0, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Corki/Skins/Base/Particles/color-hold.dds"
                BlendMode: u8 = 1
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 90, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 90, 1 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    100
                                    200
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 0, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 70, 0 }
                }
                Texture: string = "ASSETS/Characters/Corki/Skins/Base/Particles/common_propeller-spin.dds"
            }
        }
        ParticleName: string = "Corki_Skin03_Idle_RB_Prop_01"
        ParticlePath: string = "Characters/Corki/Skins/Skin3/Particles/Corki_Skin03_Idle_RB_Prop_01"
        SoundPersistentDefault: string = "Play_sfx_Corki_RapidReload_redbaronbuffactivate"
    }
    "Characters/Corki/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0x5aabcda8 = "Characters/Corki/Skins/Skin0/Particles/CorkiBomb_Base_Bomb_Base"
            "Corki_BA_cas" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_BA_cas"
            "Corki_BA_mis" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_BA_mis"
            "Corki_BA_mis_crit" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_BA_mis_crit"
            "Corki_BA_tar" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_BA_tar"
            "Corki_BA_tar_crit" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_BA_tar_crit"
            "Corki_Death_Child" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Death_Child"
            "Corki_Death_01" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Death_01"
            "Corki_E_cas_child" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_E_cas_child"
            "Corki_E_cas" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_E_cas"
            0x6315464f = 0x08a9c2a6
            "Corki_E_tar" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_E_tar"
            "Corki_idle_1" = "Characters/Corki/Skins/Skin3/Particles/Corki_Skin03_idle_1"
            "Corki_Idle_RB_Prop_01" = "Characters/Corki/Skins/Skin3/Particles/Corki_Skin03_Idle_RB_Prop_01"
            "Corki_Loaded_child" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Loaded_child"
            "Corki_Loaded" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Loaded"
            0x20d04ec7 = 0xb872fc6e
            0xaa1901e9 = 0xf9fdedf6
            "Corki_Q_cas" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Q_cas"
            "Corki_Q_Indicator_Green" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Q_Indicator_Green"
            "Corki_Q_Indicator_Red" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Q_Indicator_Red"
            "Corki_Q_Mis" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Q_Mis"
            "Corki_Q_tar_child" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Q_tar_child"
            "Corki_Q_tar" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_Q_tar"
            0xd26f5eb6 = 0x956c7831
            "Corki_R_mis" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_R_mis"
            "Corki_R_mis_big" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_R_mis_big"
            "Corki_R_tar" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_R_tar"
            "Corki_R_tar_big" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_R_tar_big"
            "Corki_W_AoE_ground_child01" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_AoE_ground_child01"
            "Corki_W_AoE_ground" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_AoE_ground"
            "Corki_W_AoE_ground_enemy" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_AoE_ground_enemy"
            "Corki_W_buff_speed" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_buff_speed"
            "Corki_W_Burn_champion" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_Burn_champion"
            "Corki_W_Burn_minion" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_Burn_minion"
            "Corki_W_cas" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_cas"
            0x3397daeb = 0x548e3726
            0x60e36526 = 0xeb55613f
            "Corki_W_Loaded_tar_ExplosionChild" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_Loaded_tar_ExplosionChild"
            "Corki_W_Loaded_tar" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_Loaded_tar"
            0x31a4d1d4 = 0x00aacab9
            "Corki_W_tar" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_tar"
            "Corki_W_tar_buf" = "Characters/Corki/Skins/Skin0/Particles/Corki_Base_W_tar_buf"
            0xd4922b61 = 0xdb92cdf6
        }
    }
}
