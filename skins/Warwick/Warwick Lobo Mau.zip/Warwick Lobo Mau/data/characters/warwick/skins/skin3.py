#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin5_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Warwick/Warwick.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Warwick/Animations/Skin0.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin16_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin4_Skins_Skin5_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin2_Skins_Skin23_Skins_Skin25_Skins_Skin3_Skins_Skin5_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin2_Skins_Skin3_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin2_Skins_Skin3_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin2_Skins_Skin3_Skins_Skin5_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin2_Skins_Skin3_Skins_Skin6_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Warwick_Skins_Skin0_Skins_Skin2_Skins_Skin3_Skins_Skin8_Skins_Skin9.bin"
}
entries: map[hash,embed] = {
    "Characters/Warwick/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "BigBadWarwick"
        MetaDataTags: string = "faction:zaun,gender:male,skinline:storybook"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Warwick/Skins/Skin03/WarwickLoadscreen_3.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Warwick"
                "Warwick_FUTURE"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Warwick_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Warwick/Skins/Base/Warwick_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Warwick/Skins/Base/Warwick_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Warwick/Skins/Base/Warwick_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Warwick_Attack2DGeneral"
                        "Play_vo_Warwick_Death3D"
                        "Play_vo_Warwick_FirstEncounter3DAhri"
                        "Play_vo_Warwick_FirstEncounter3DAkali"
                        "Play_vo_Warwick_FirstEncounter3DBlitzcrank"
                        "Play_vo_Warwick_FirstEncounter3DCaitlyn"
                        "Play_vo_Warwick_FirstEncounter3DCamille"
                        "Play_vo_Warwick_FirstEncounter3DEkko"
                        "Play_vo_Warwick_FirstEncounter3DEvelynn"
                        "Play_vo_Warwick_FirstEncounter3DJinx"
                        "Play_vo_Warwick_FirstEncounter3DKindred"
                        "Play_vo_Warwick_FirstEncounter3DReksai"
                        "Play_vo_Warwick_FirstEncounter3DRengar"
                        "Play_vo_Warwick_FirstEncounter3DSinged"
                        "Play_vo_Warwick_FirstEncounter3DSoraka"
                        "Play_vo_Warwick_FirstEncounter3DTwitch"
                        "Play_vo_Warwick_FirstEncounter3DUrgot"
                        "Play_vo_Warwick_FirstEncounter3DVi"
                        "Play_vo_Warwick_FirstEncounter3DViktor"
                        "Play_vo_Warwick_FirstEncounter3DYordle"
                        "Play_vo_Warwick_FirstEncounter3DZac"
                        "Play_vo_Warwick_FirstEncounter3DZed"
                        "Play_vo_Warwick_Joke3DGeneral"
                        "Play_vo_Warwick_Kill3DGeneral"
                        "Play_vo_Warwick_Laugh3DGeneral"
                        "Play_vo_Warwick_Move2DFirst"
                        "Play_vo_Warwick_Move2DStandard"
                        "Play_vo_Warwick_Recall3DGeneral"
                        "Play_vo_Warwick_Respawn2DGeneral"
                        "Play_vo_Warwick_Taunt3DGeneral"
                        "Play_vo_Warwick_WarwickBasicAttack2_cast3D"
                        "Play_vo_Warwick_WarwickBasicAttack3_cast3D"
                        "Play_vo_Warwick_WarwickBasicAttack4_cast3D"
                        "Play_vo_Warwick_WarwickBasicAttack_cast3D"
                        "Play_vo_Warwick_WarwickCritAttack_cast3D"
                        "Play_vo_Warwick_WarwickE1"
                        "Play_vo_Warwick_WarwickE2"
                        "Play_vo_Warwick_WarwickQ_Leap_turn"
                        "Play_vo_Warwick_WarwickR_OnCast"
                        "Play_vo_Warwick_WarwickRmiss_OnBuffActivate"
                        "Play_vo_Warwick_WarwickRsound_UltimateEfforts"
                        "Play_vo_Warwick_WarwickWActiveHit"
                        "Play_vo_Warwick_WarwickWActiveMiss"
                        "Stop_vo_Warwick_WarwickRmiss_OnBuffActivate"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Warwick_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Warwick/Skins/Base/Warwick_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Warwick/Skins/Base/Warwick_Base_SFX_events.bnk"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Warwick/Animations/Skin0"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Warwick/Skins/Skin03/Warwick_Skin03.skl"
            SimpleSkin: string = "ASSETS/Characters/Warwick/Skins/Skin03/Warwick_Skin03.skn"
            Texture: string = "ASSETS/Characters/Warwick/Skins/Skin03/Warwick_Skin03_TX_CM.dds"
            SkinScale: f32 = 0.75
            SelfIllumination: f32 = 0.699999988
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
        }
        ArmorMaterial: string = "Flesh"
        IconAvatar: string = "ASSETS/Characters/Warwick/HUD/Warwick_Circle_3.dds"
        mContextualActionData: link = "Characters/Warwick/CAC/Warwick_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Warwick/HUD/Warwick_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Warwick/HUD/Warwick_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/29"
            }
        }
        mResourceResolver: link = "Characters/Warwick/Skins/Skin3/Resources"
    }
    "Characters/Warwick/Skins/Skin3/Particles/Warwick_Skin03_W_cas" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 40
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    0.600000024
                }
                EmitterName: string = "Steam"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 2100, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 90, 2100, 0 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 6, 6, 6 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 0, -20, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, -20, 0 }
                            }
                        }
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.929411829, 0.894117713, 0.501960814 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 0.678430974, 0.694118023, 0.592157006, 1 }
                            { 0.305882007, 0.31764701, 0.294117987, 0 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherOut: f32 = 0.400000006
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_steamjets.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                IsDirectionOriented: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 80, -80, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 80, -80, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 2, 0 }
                            { 1, 1, 1 }
                            { 2, 1, 2 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_steamjets.dds"
                FrameRate: f32 = 8
                NumFrames: u16 = 4
                StartFrame: u16 = 1
                TexAddressModeBase: u8 = 2
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                    0.800000012
                                    0.699999988
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    8
                }
                EmitterName: string = "Ring"
                Importance: u8 = 2
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, 1, 0 }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_W_Rengar_Base_Z_Ring_RGB.dds"
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.545098066, 0.13333334, 0, 0.713725507 }
                }
                MiscRenderFlags: u8 = 1
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 160, 160, 0 }
                }
                Texture: string = "ASSETS/Particles/ball32_02.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    100000
                }
                EmitterName: string = "Ring_FX"
                Disabled: bool = true
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 700, 0, 0 }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                ParticleColorTexture: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_W_Rengar_Base_W_Heal_Spark_RGBA.dds"
                Pass: i16 = 1
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 0, 90 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 5, 40, 10 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 10, 5, 1 }
                            { 30, 5, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_W_Rengar_Base_P_Shafts.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.300000012
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    0.5
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Nova"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 800, 0, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 0, 0, 0 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Particles/Pantheon_Skin06_Z_FireFlicker.dds"
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.450980425, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0, 0.231372997, 0.0117650004, 1 }
                        }
                    }
                }
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_Z_BightSpark.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    4
                }
                EmitterName: string = "Motes"
                Importance: u8 = 2
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 90, 30, 90 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 90, 30, 90 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                ParticleColorTexture: string = "ASSETS/Particles/Pantheon_Skin06_Z_FireFlicker.dds"
                BlendMode: u8 = 2
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 1, 0.533333361, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 0, 0.231372997, 0.0117650004, 1 }
                        }
                    }
                }
                ColorLookUpTypeY: u8 = 3
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 0, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_Z_BightSpark.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 55
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "PlasmaAddBurst1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 800, 430, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                    -0.5
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 800, 430, 300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3, 3 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 20, 20, 20 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        0
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 20, 20, 20 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -8, 0 }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 0.400000006, 0, 1 }
                            { 1, 0.937255025, 0.698038995, 1 }
                            { 1, 0.800000012, 0, 1 }
                            { 1, 0.450980008, 0, 1 }
                            { 0.407842994, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.200000003
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_plasma_sharp.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 80, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                    -0.400000006
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 80, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.10000002, 1.10000002, 2 }
                            { 1, 1, 0.800000012 }
                            { 0.800000012, 2, 1 }
                            { 0.5, 2, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Particles/color-hold.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 55
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.200000003
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.200000003
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    0.400000006
                }
                EmitterName: string = "PlasmaAddBurst"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 800, 430, 300 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                    -0.5
                                    -1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 800, 430, 300 }
                        }
                    }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 6, 6, 6 }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 20, 20, 20 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        0
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 20, 20, 20 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -8, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 1, 0, 0, 1 }
                            { 0.407842994, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.200000003
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_plasma_sharp.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 80, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                    -0.400000006
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 80, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.10000002, 1.10000002, 2 }
                            { 1, 1, 0.800000012 }
                            { 0.800000012, 2, 1 }
                            { 0.5, 2, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Particles/color-hold.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    8
                }
                EmitterName: string = "PlasmaAdd"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 130, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 20, 20, 20 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        0
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 20, 20, 20 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -8, 0 }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            0.300000012
                            0.400000006
                            0.5
                        }
                        Values: list[vec4] = {
                            { 1, 0.400000006, 0, 1 }
                            { 1, 0.937255025, 0.698038995, 1 }
                            { 1, 0.800000012, 0, 1 }
                            { 1, 0.450980008, 0, 1 }
                            { 0.407842994, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.200000003
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_plasma_sharp.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 70, 60, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    0.75
                                    0.750999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    0.400000006
                                    1
                                    -0.400000006
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 70, 60, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.10000002, 1.10000002, 2 }
                            { 1, 1, 0.800000012 }
                            { 0.800000012, 3, 1 }
                            { 0.5, 5, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Particles/color-hold.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 34
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.400000006
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.400000006
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                Lifetime: option[f32] = {
                    8
                }
                EmitterName: string = "Plasma1"
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 130, 200 }
                }
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 43, 13, 23 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        0
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 43, 13, 23 }
                            }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 20, 0 }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.709803998, 0, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.25
                            0.322284013
                            0.400000006
                            0.5
                            0.75
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 0.709803998, 0, 0, 0 }
                            { 0.709803998, 0, 0, 1 }
                            { 0.189281315, 0, 0, 1 }
                            { 0.704236984, 0, 0, 1 }
                            { 0.631864727, 0, 0, 1 }
                            { 0.681968331, 0, 0, 1 }
                            { 0.283921599, 0, 0, 1 }
                            { 0.45928508, 0, 0, 1 }
                            { 0.164229482, 0, 0, 1 }
                        }
                    }
                }
                Pass: i16 = 5
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.200000003
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0
                    ErosionFeatherOut: f32 = 0.300000012
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_plasma_sharp.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsDirectionOriented: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 40, 20, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    0.75
                                    0.750999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    0.400000006
                                    1
                                    -0.400000006
                                    -1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    0
                                    0.5
                                    2
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 40, 20, 0 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1.5, 1.5, 2 }
                            { 1, 1, 0.800000012 }
                            { 0.800000012, 3, 1 }
                            { 0.5, 5, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Particles/color-hold.dds"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 15
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Smoke"
                Disabled: bool = true
                Importance: u8 = 2
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 100, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { 80, 80, 20 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0
                                        1
                                    }
                                }
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        -1
                                        1
                                    }
                                }
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { 80, 80, 20 }
                            }
                        }
                    }
                    EmitRotationAngles: list[embed] = {
                        ValueFloat {
                            ConstantValue: f32 = 1
                            Dynamics: pointer = VfxAnimatedFloatVariableData {
                                ProbabilityTables: list[pointer] = {
                                    VfxProbabilityTableData {
                                        KeyTimes: list[f32] = {
                                            0
                                            1
                                        }
                                        KeyValues: list[f32] = {
                                            0
                                            360
                                        }
                                    }
                                }
                                Times: list[f32] = {
                                    0
                                }
                                Values: list[f32] = {
                                    1
                                }
                            }
                        }
                    }
                    EmitRotationAxes: list[vec3] = {
                        { 0, 1.00000012, 0 }
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.717647016, 0, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.800000012
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 0.717647016, 0, 1 }
                            { 0.356862992, 0, 0, 1 }
                            { 0, 0, 0, 1 }
                        }
                    }
                }
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0.100000001
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Warwick/Skins/Base/Particles/Warwick_Base_idle_smoke.dds"
                    ErosionMapAddressMode: u8 = 0
                }
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 120, 120, 300 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            0.800000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 0.800000012 }
                            { 1, 3, 1 }
                            { 0.5, 5, 1.10000002 }
                        }
                    }
                }
                Texture: string = "ASSETS/Particles/color-hold.dds"
                NumFrames: u16 = 2
                TexDiv: vec2 = { 2, 2 }
            }
        }
        SimpleEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.899999976
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                    0.800000012
                                    0.699999988
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "Override"
                Importance: u8 = 2
                ParticleColorTexture: string = "ASSETS/Particles/color-hold.dds"
                MeshRenderFlags: u8 = 0
                Texture: string = "ASSETS/Characters/Warwick/Skins/Skin03/Particles/Warwick_Skin03_W_AmpOverride.dds"
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        Priority: i32 = 2
                        BaseTexture: string = "ASSETS/Characters/Warwick/Skins/Skin03/Particles/Warwick_Skin03_W_AmpOverride.dds"
                        TransitionTexture: string = "ASSETS/Particles/color-hold.dds"
                        TransitionSample: f32 = 0.078125
                    }
                }
            }
        }
        ParticleName: string = "Warwick_Skin03_W_cas"
        ParticlePath: string = "Characters/Warwick/Skins/Skin3/Particles/Warwick_Skin03_W_cas"
    }
    "Characters/Warwick/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Warwick_Basic_Attack_Hit_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_Basic_Attack_Hit_01"
            "Warwick_Basic_Attack_Hit_Passive_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_Basic_Attack_Hit_Passive_01"
            "Warwick_BA_Swipe_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_01"
            "Warwick_BA_Swipe_02" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_02"
            "Warwick_BA_Swipe_03" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_03"
            "Warwick_BA_Swipe_04" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_04"
            "Warwick_BA_Swipe_crit" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_crit"
            "Warwick_BA_Swipe_fast_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_fast_01"
            "Warwick_BA_Swipe_fast_02" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_fast_02"
            "Warwick_BA_Swipe_fast_03" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_fast_03"
            "Warwick_BA_Swipe_fast_04" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_BA_Swipe_fast_04"
            "Warwick_Crit_Attack_Hit_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_Crit_Attack_Hit_01"
            "Warwick_E2_Cas" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_E2_cas"
            "Warwick_E_BlockHit" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_E_BlockHit"
            "Warwick_E_cas" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_E_cas"
            "Warwick_E_cas_self" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_E_cas_self"
            "Warwick_idle_back" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_idle_back"
            "Warwick_P_Swipe_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_01"
            "Warwick_P_Swipe_02" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_02"
            "Warwick_P_Swipe_03" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_03"
            "Warwick_P_Swipe_04" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_04"
            "Warwick_P_Swipe_fast_01" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_fast_01"
            "Warwick_P_Swipe_fast_02" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_fast_02"
            "Warwick_P_Swipe_fast_03" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_p_Swipe_fast_03"
            "Warwick_P_Swipe_fast_04" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_P_Swipe_fast_04"
            "Warwick_Q_Hit" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_Q_Hit"
            "Warwick_Q_OutOfRange" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_Q_OutOfRange"
            "Warwick_Q_OutOfRange_Fade" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_Q_OutOfRange_Fade"
            "Warwick_R_cas" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_cas"
            "Warwick_R_Missed" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_Missed"
            "Warwick_R_Range_Ring" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_Range_Ring"
            "Warwick_R_Range_Ring_Grow" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_Range_Ring_Grow"
            "Warwick_R_Range_Ring_Shrink" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_Range_Ring_Shrink"
            "Warwick_R_slashDark" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_slashDark"
            "Warwick_R_slashDarkLines" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_slashDarkLines"
            "Warwick_R_tar" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_tar"
            "Warwick_R_tar1" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_tar1"
            "Warwick_R_tar2" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_tar2"
            "Warwick_R_tar3" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_tar3"
            "Warwick_R_tar_sequence" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_R_tar_sequence"
            "Warwick_WP_Activate_Sound" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_WP_Activate_Sound"
            "Warwick_W_AnnounceToEnemySound" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_AnnounceToEnemySound"
            "Warwick_W_AnnounceToEnemyVO" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_AnnounceToEnemyVO"
            "Warwick_W_CameraBoundVFX_Direction" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_CameraBoundVFX_Direction"
            "Warwick_W_CameraBoundVFX_Far" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_CameraBoundVFX_Far"
            "Warwick_W_CameraBoundVFX_Initial_Far" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_CameraBoundVFX_Initial_Far"
            "Warwick_W_CameraBoundVFX_Initial_Near" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_CameraBoundVFX_Initial_Near"
            "Warwick_W_CameraBoundVFX_Near" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_CameraBoundVFX_Near"
            "Warwick_W_cas" = "Characters/Warwick/Skins/Skin3/Particles/Warwick_Skin03_W_cas"
            "Warwick_W_EyeGlow_L" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_EyeGlow_L"
            "Warwick_W_EyeGlow_R" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_EyeGlow_R"
            "Warwick_W_ScentTrail" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_ScentTrail"
            "Warwick_W_ScentTrail_Self" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_ScentTrail_Self"
            "Warwick_W_ScentTrail_Self_Path" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_ScentTrail_Self_Path"
            "Warwick_W_Tar" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_Tar"
            "Warwick_W_tar_overhead" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_tar_overhead"
            "Warwick_W_tar_overhead_downwardoffset" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_tar_overhead_downwardoffset"
            "Warwick_W_tar_overhead_jungle" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_tar_overhead_jungle"
            "Warwick_W_Victim_SoundPersistent_Outro" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_Victim_SoundPersistent_Outro"
            "Warwick_W_Victim_SoundPersistent_WarwickOnly" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_Victim_SoundPersistent_WarwickOnly"
            "Warwick_W_Victim_SoundPersistent_WarwickOnly_Outro" = "Characters/Warwick/Skins/Skin0/Particles/Warwick_Base_W_Victim_SoundPersistent_WarwickOnly_Outro"
        }
    }
}
