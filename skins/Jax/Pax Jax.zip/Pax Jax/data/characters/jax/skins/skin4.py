#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Jax/Jax.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin2_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Jax/Animations/Skin4.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jax_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin4_Skins_Skin6_Skins_Skin8.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin2_Skins_Skin32_Skins_Skin4_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Jax_Skins_Skin0_Skins_Skin1_Skins_Skin12_Skins_Skin2_Skins_Skin32_Skins_Skin4_Skins_Skin6_Skins_Skin8.bin"
}
entries: map[hash,embed] = {
    "Characters/Jax/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "PAXJax"
        MetaDataTags: string = "gender:male"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Jax/Skins/Skin04/JaxLoadScreen_4.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Jax"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Jax_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Jax/Skins/Base/Jax_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Jax/Skins/Base/Jax_Base_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_Jax_Dance3D_buffactivate"
                        "Play_sfx_Jax_DanceIn3D_buffactivate"
                        "Play_sfx_Jax_Death3D_cast"
                        "Play_sfx_Jax_Fish3D_cast_buffactivate"
                        "Play_sfx_Jax_Fish3D_catch_buffactivate"
                        "Play_sfx_Jax_Fish3D_idle_buffactivate"
                        "Play_sfx_Jax_Homeguard3D_loop"
                        "Play_sfx_Jax_Homeguard3D_run_01"
                        "Play_sfx_Jax_Homeguard3D_run_02"
                        "Play_sfx_Jax_IdleIn3D_buffactivate"
                        "Play_sfx_Jax_JaxBasicAttack2_OnCast"
                        "Play_sfx_Jax_JaxBasicAttack2_OnHit"
                        "Play_sfx_Jax_JaxBasicAttack3_OnCast"
                        "Play_sfx_Jax_JaxBasicAttack3_OnHit"
                        "Play_sfx_Jax_JaxBasicAttack_OnCast"
                        "Play_sfx_Jax_JaxBasicAttack_OnHit"
                        "Play_sfx_Jax_JaxCritAttack_OnCast"
                        "Play_sfx_Jax_JaxCritAttack_OnHit"
                        "Play_sfx_Jax_JaxE_hit"
                        "Play_sfx_Jax_JaxE_OnBuffActivate"
                        "Play_sfx_Jax_JaxE_OnBuffDeactivate"
                        "Play_sfx_Jax_JaxQ_cast"
                        "Play_sfx_Jax_JaxQ_hit"
                        "Play_sfx_Jax_JaxR_buffactivate"
                        "Play_sfx_Jax_JaxR_hit_aoe"
                        "Play_sfx_Jax_JaxR_OnBuffDeactivate"
                        "Play_sfx_Jax_JaxR_OnCast"
                        "Play_sfx_Jax_JaxRPassiveAttack_buffactivate"
                        "Play_sfx_Jax_JaxRPassiveAttack_OnCast"
                        "Play_sfx_Jax_JaxRPassiveAttack_OnHit"
                        "Play_sfx_Jax_JaxTowerAttack_OnHit"
                        "Play_sfx_Jax_JaxW_hit"
                        "Play_sfx_Jax_JaxW_OnBuffActivate"
                        "Play_sfx_Jax_JaxW_OnBuffDeactivate"
                        "Play_sfx_Jax_JaxW_OnCast"
                        "Play_sfx_Jax_JaxWAttack_OnCast"
                        "Play_sfx_Jax_Joke3D_buffactivate"
                        "Play_sfx_Jax_Laugh3D_buffactivate"
                        "Play_sfx_Jax_Recall3D_buffactivate"
                        "Play_sfx_Jax_Respawn3D_buffactivate"
                        "Play_sfx_Jax_Taunt3D_buffactivate"
                        "Stop_sfx_Jax_Fish3D_cast_buffactivate"
                        "Stop_sfx_Jax_Fish3D_catch_buffactivate"
                        "Stop_sfx_Jax_Homeguard3D_loop"
                        "Stop_sfx_Jax_IdleIn3D_buffactivate"
                        "Stop_sfx_Jax_JaxE_OnBuffActivate"
                        "Stop_sfx_Jax_JaxE_OnBuffDeactivate"
                        "Stop_sfx_Jax_JaxQ_cast"
                        "Stop_sfx_Jax_JaxR_buffactivate"
                        "Stop_sfx_Jax_JaxR_hit_aoe"
                        "Stop_sfx_Jax_JaxRPassiveAttack_buffactivate"
                        "Stop_sfx_Jax_JaxW_OnBuffActivate"
                    }
                }
                BankUnit {
                    Name: string = "Jax_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jax/Skins/Base/Jax_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jax/Skins/Base/Jax_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Jax/Skins/Base/Jax_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Jax_Attack2DBaron"
                        "Play_vo_Jax_Attack2DGeneral"
                        "Play_vo_Jax_Attack2DHerald"
                        "Play_vo_Jax_Death3D"
                        "Play_vo_Jax_FirstEncounter3DAatrox"
                        "Play_vo_Jax_FirstEncounter3DAscended"
                        "Play_vo_Jax_FirstEncounter3DBelVeth"
                        "Play_vo_Jax_FirstEncounter3DChoGath"
                        "Play_vo_Jax_FirstEncounter3DDarkin"
                        "Play_vo_Jax_FirstEncounter3DFiora"
                        "Play_vo_Jax_FirstEncounter3DGaren"
                        "Play_vo_Jax_FirstEncounter3DGeneral"
                        "Play_vo_Jax_FirstEncounter3DGragas"
                        "Play_vo_Jax_FirstEncounter3DIllaoi"
                        "Play_vo_Jax_FirstEncounter3DKaiSa"
                        "Play_vo_Jax_FirstEncounter3DKassadin"
                        "Play_vo_Jax_FirstEncounter3DKayle"
                        "Play_vo_Jax_FirstEncounter3DKSante"
                        "Play_vo_Jax_FirstEncounter3DMalzahar"
                        "Play_vo_Jax_FirstEncounter3DNasus"
                        "Play_vo_Jax_FirstEncounter3DShurima"
                        "Play_vo_Jax_FirstEncounter3DVoid"
                        "Play_vo_Jax_FirstEncounter3DZilean"
                        "Play_vo_Jax_JaxBasicAttack2_cast3D"
                        "Play_vo_Jax_JaxBasicAttack3_cast3D"
                        "Play_vo_Jax_JaxBasicAttack_cast3D"
                        "Play_vo_Jax_JaxCritAttack_cast3D"
                        "Play_vo_Jax_JaxE_cast3D"
                        "Play_vo_Jax_JaxQ_cast3D"
                        "Play_vo_Jax_JaxR_cast3D"
                        "Play_vo_Jax_JaxW_cast3D"
                        "Play_vo_Jax_Joke3DGeneral"
                        "Play_vo_Jax_JokeResponse3DGeneral"
                        "Play_vo_Jax_Kill3DAatrox"
                        "Play_vo_Jax_Kill3DAnivia"
                        "Play_vo_Jax_Kill3DAzir"
                        "Play_vo_Jax_Kill3DBelVeth"
                        "Play_vo_Jax_Kill3DChoGath"
                        "Play_vo_Jax_Kill3DFiora"
                        "Play_vo_Jax_Kill3DFirst"
                        "Play_vo_Jax_Kill3DGeneral"
                        "Play_vo_Jax_Kill3DKaiSa"
                        "Play_vo_Jax_Kill3DKSante"
                        "Play_vo_Jax_Kill3DMalzahar"
                        "Play_vo_Jax_Kill3DNasus"
                        "Play_vo_Jax_Kill3DPenta"
                        "Play_vo_Jax_Kill3DRenekton"
                        "Play_vo_Jax_Kill3DTurret"
                        "Play_vo_Jax_Laugh3DGeneral"
                        "Play_vo_Jax_Move2DFirst"
                        "Play_vo_Jax_Move2DLong"
                        "Play_vo_Jax_Move2DRiver"
                        "Play_vo_Jax_Move2DStandard"
                        "Play_vo_Jax_Recall3DGeneral"
                        "Play_vo_Jax_Respawn2DGeneral"
                        "Play_vo_Jax_Shop2DOpen"
                        "Play_vo_Jax_Taunt3DGeneral"
                        "Play_vo_Jax_TauntResponse3DGeneral"
                        "Play_vo_Jax_Unique3DFishingEnd"
                        "Play_vo_Jax_Unique3DFishingStart"
                    }
                    VoiceOver: bool = true
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Jax/Animations/Skin4"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Jax/Skins/Skin04/Jax_Skin04.skl"
            SimpleSkin: string = "ASSETS/Characters/Jax/Skins/Skin04/Jax_Skin04.skn"
            Texture: string = "ASSETS/Characters/Jax/Skins/Skin04/Jax_Skin04_TX_CM.dds"
            SkinScale: f32 = 0.899999976
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 240, 245, 240 }
            }
            InitialSubmeshToHide: string = "Bluefish, Goldfish"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Jax/Skins/Skin04/Jax_Skin04_Weapon_TX_CM.dds"
                    Submesh: string = "Weapon"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Jax/Skins/Base/Jax_Base_Fish_TX_CM.tex"
                    Submesh: string = "Bluefish"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Jax/Skins/Base/Jax_Base_Fish_TX_CM.tex"
                    Submesh: string = "Goldfish"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IconAvatar: string = "ASSETS/Characters/Jax/HUD/Jax_Circle_4.dds"
        mContextualActionData: link = "Characters/Jax/CAC/Jax_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Jax/HUD/Jax_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Jax/HUD/Jax_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/1"
            }
        }
        mResourceResolver: link = "Characters/Jax/Skins/Skin4/Resources"
        0x87b1d303: list2[pointer] = {
            0x67ac9672 {
                0x43c8c7b1: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = 0x188e7d2d
                }
                0x071f3c1d: list2[embed] = {
                    0x00fa43e4 {
                        BoneName: string = "Weapon_Head_Stretch2"
                        EffectKey: hash = "Jax_W_buf"
                    }
                }
            }
            0x67ac9672 {
                0x43c8c7b1: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = 0x9bae7ded
                }
                0x071f3c1d: list2[embed] = {
                    0x00fa43e4 {
                        EffectKey: hash = "Jax_E_buf"
                    }
                }
            }
            0x67ac9672 {
                0x43c8c7b1: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = 0x2a07a776
                }
                0x071f3c1d: list2[embed] = {
                    0x00fa43e4 {
                        BoneName: string = "Weapon_Head_Stretch2"
                        EffectKey: hash = 0x2412f467
                    }
                }
            }
        }
    }
    "Characters/Jax/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Jax_BA_crit" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_BA_crit"
            "Jax_BA_tar" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_BA_tar"
            "Jax_E_buf" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_E_buf"
            "Jax_E_cas" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_E_cas"
            "Jax_E_tar" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_E_tar"
            "Jax_Q_tar" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_Q_tar"
            "Jax_R_buf" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_R_buf"
            "Jax_R_tar" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_R_tar"
            "Jax_W_buf" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_W_buf"
            "Jax_W_tar" = "Characters/Jax/Skins/Skin0/Particles/Jax_base_W_tar"
            "Jax_R_Hit_Both" = "Characters/Jax/Skins/Skin0/Particles/Jax_Base_R_Hit_Both"
            "Jax_Q_cas" = "Characters/Jax/Skins/Skin0/Particles/Jax_Base_Q_cas"
            "Jax_Q_Avatar" = "Characters/Jax/Skins/Skin0/Particles/Jax_Base_Q_Avatar"
            "Jax_Q_HandGlow" = "Characters/Jax/Skins/Skin0/Particles/Jax_Base_Q_HandGlow"
            0x72aedb5c = 0x4fd1ea24
            0xff4f3a56 = 0x2b986d9e
            0x2412f467 = 0x107b965f
            0x0120a0c5 = 0xba6b60fd
            0x2af60790 = 0x8ec0ffa8
            0x39f6a69f = 0xf13dbf27
            0x858e06d9 = 0x103d7561
            0x688acfbd = 0x8a299bc5
            0x233c700c = 0x9c969e03
            0x987844f4 = 0xd39417fc
            0xbd3476eb = 0x234ceb93
            0xcc14c221 = "Characters/Jax/Skins/Skin0/Particles/Jax_base_BA_tar"
            0xd0eed9db = "Characters/Jax/Skins/Skin0/Particles/Jax_base_BA_tar"
            0xe211fd52 = 0x58a590aa
            0xe111fbbf = 0x57a58f17
            0x80a0eaac = 0xc05240c4
            0x46a48489 = 0x1e531c01
            0x37c12ede = 0x83eb9d76
            0x5cfbf9ba = 0x0e083aa2
            0xd9ed55ef = 0x44449157
            0xe1285697 = 0x2b20ee7f
            0xe238b694 = "Characters/Jax/Skins/Skin0/Particles/Jax_base_E_tar"
            0x1d22b0a9 = 0xa366ec71
            0x9b844890 = "Characters/Jax/Skins/Skin0/Particles/Jax_base_E_cas"
        }
    }
}
