#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Vayne_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43.bin"
    "DATA/Characters/Vayne/Vayne.bin"
    "DATA/Characters/Vayne/Animations/Skin14.bin"
    "DATA/Vayne_Skins_Skin14_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin32_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43.bin"
    "DATA/Vayne_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Vayne_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin3_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin5_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Vayne_Skins_Skin12_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin32_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43.bin"
    "DATA/Vayne_Skins_Skin14_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24.bin"
}
entries: map[hash,embed] = {
    "Characters/Vayne/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "VayneSkin14"
        AttributeFlags: u32 = 1
        MetaDataTags: string = "faction:demacia,gender:female,race:human,skinline:spiritblossom,subfaction:akana"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Vayne/Skins/Skin14/VayneLoadScreen_14.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Vayne/Skins/Skin14/VayneLoadscreen_14_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Vayne"
                "VayneSkin14"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Vayne_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Vayne/Skins/Base/Vayne_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Vayne/Skins/Base/Vayne_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Vayne/Skins/Base/Vayne_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Vayne_Attack2DGeneral"
                        "Play_vo_Vayne_Death3D"
                        "Play_vo_Vayne_Joke3DGeneral"
                        "Play_vo_Vayne_Laugh3DGeneral"
                        "Play_vo_Vayne_Move2DStandard"
                        "Play_vo_Vayne_Spell2DWLevelUp"
                        "Play_vo_Vayne_Taunt3DGeneral"
                        "Play_vo_Vayne_VayneCondemn_cast3D"
                        "Play_vo_Vayne_VayneInquisition_cast3D"
                        "Play_vo_Vayne_VayneTumble_cast3D"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Vayne_Skin14_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Vayne/Skins/Skin14/Vayne_Skin14_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Vayne/Skins/Skin14/Vayne_Skin14_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_VayneSkin14_Recall3D_buffactivate"
                        "Play_sfx_VayneSkin14_VayneBasicAttack2_OnCast"
                        "Play_sfx_VayneSkin14_VayneBasicAttack2_OnHit"
                        "Play_sfx_VayneSkin14_VayneBasicAttack2_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneBasicAttack2_OnMissileLaunch"
                        "Play_sfx_VayneSkin14_VayneBasicAttack_OnCast"
                        "Play_sfx_VayneSkin14_VayneBasicAttack_OnHit"
                        "Play_sfx_VayneSkin14_VayneBasicAttack_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneBasicAttack_OnMissileLaunch"
                        "Play_sfx_VayneSkin14_VayneCondemn_OnCast"
                        "Play_sfx_VayneSkin14_VayneCondemnMissile_hit"
                        "Play_sfx_VayneSkin14_VayneCondemnMissile_OnHit"
                        "Play_sfx_VayneSkin14_VayneCondemnMissile_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneCondemnMissile_OnMissileLaunch"
                        "Play_sfx_VayneSkin14_VayneCritAttack_OnCast"
                        "Play_sfx_VayneSkin14_VayneCritAttack_OnHit"
                        "Play_sfx_VayneSkin14_VayneCritAttack_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneCritAttack_OnMissileLaunch"
                        "Play_sfx_VayneSkin14_VayneInquisition_OnBuffActivate"
                        "Play_sfx_VayneSkin14_VayneInquisition_OnBuffDeactivate"
                        "Play_sfx_VayneSkin14_VayneInquisition_OnCast"
                        "Play_sfx_VayneSkin14_VayneSilveredBolts_hit"
                        "Play_sfx_VayneSkin14_VayneSilveredBolts_OnBuffActivate"
                        "Play_sfx_VayneSkin14_VayneTumble_OnCast"
                        "Play_sfx_VayneSkin14_VayneTumbleAttack_OnHit"
                        "Play_sfx_VayneSkin14_VayneTumbleAttack_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneTumbleAttack_OnMissileLaunch"
                        "Play_sfx_VayneSkin14_VayneTumbleBonus_OnBuffActivate"
                        "Play_sfx_VayneSkin14_VayneTumbleFade_cast"
                        "Play_sfx_VayneSkin14_VayneTumbleFade_OnBuffActivate"
                        "Play_sfx_VayneSkin14_VayneTumbleFade_OnBuffDeactivate"
                        "Play_sfx_VayneSkin14_VayneTumbleUltAttack_OnHit"
                        "Play_sfx_VayneSkin14_VayneTumbleUltAttack_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneTumbleUltAttack_OnMissileLaunch"
                        "Play_sfx_VayneSkin14_VayneUltAttack_OnHit"
                        "Play_sfx_VayneSkin14_VayneUltAttack_OnMissileCast"
                        "Play_sfx_VayneSkin14_VayneUltAttack_OnMissileLaunch"
                        "Stop_sfx_VayneSkin14_VayneInquisition_OnBuffActivate"
                        "Stop_sfx_VayneSkin14_VayneTumbleAttack_OnMissileLaunch"
                        "Stop_sfx_VayneSkin14_VayneTumbleBonus_OnBuffActivate"
                        "Stop_sfx_VayneSkin14_VayneTumbleFade_cast"
                        "Stop_sfx_VayneSkin14_VayneTumbleFade_OnBuffActivate"
                        "Stop_sfx_VayneSkin14_VayneTumbleUltAttack_OnMissileLaunch"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Vayne/Animations/Skin14"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Vayne/Skins/Skin14/Vayne_Skin14.skl"
            SimpleSkin: string = "ASSETS/Characters/Vayne/Skins/Skin14/Vayne_Skin14.skn"
            Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Vayne_Skin14_TX_CM.dds"
            SkinScale: f32 = 1.12
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 97.3199997, 194.639999, 97.3199997 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "SpiritWisp tree ulton"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Vayne_Skin14_Tree_TX_CM.dds"
                    Submesh: string = "tree"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Vayne_Skin14_SpiritWisp_TX_CM.dds"
                    Submesh: string = "SpiritWisp"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = "Characters/Vayne/Skins/Skin14/Materials/ScrollBloomFresnel_inst"
                    Submesh: string = "crossbow1"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x5a22f14e
                    mEndingJointName: hash = 0x90b51841
                    mDampingValue: f32 = 2
                    mVelMultiplier: f32 = 0
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = 0x9af5e51c
                BoneName: string = "R_HeelRoll_end"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = 0x426a45c2
                BoneName: string = "L_HeelRoll_end"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Vayne/HUD/Vayne_Circle_14.dds"
        mContextualActionData: link = "Characters/Vayne/CAC/Vayne_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Vayne/HUD/Vayne_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Vayne/HUD/Vayne_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Vayne/Skins/Skin14/Resources"
    }
    "Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_R_buf_cntr" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "VayneTextureSwap"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { 0, -75, 0 }
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "BODY"
                            0x2e4ddba0
                            "UltOn"
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Pass: i16 = -500
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_TX_CM_Invert.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Bow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "UltOn"
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0, 0, 1 }
                }
                Pass: i16 = 11
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.200000003
                    FresnelColor: vec4 = { 0.34117648, 0.768627465, 1, 0 }
                }
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Activate"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x811c9dc5
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0941176489, 0.80392158, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0941176489, 0.80392158, 1, 1 }
                            { 0.0941176489, 0.80392158, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 13
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Activate1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            0x811c9dc5
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0117647061, 0, 0.137254909, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0117647061, 0, 0.137254909, 1 }
                            { 0.0117647061, 0, 0.137254909, 0 }
                        }
                    }
                }
                Pass: i16 = 12
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                            { 1.04999995, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_color-hold.dds"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.699999988
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Variant_"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.300000012
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_SwooshMesh.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0549019612, 0.0313725509, 0.223529413, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0549019612, 0.0313725509, 0.223529413, 1 }
                            { 0.0549019612, 0.0313725509, 0.223529413, 1 }
                            { 0.0549019612, 0.0313725509, 0.223529413, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_ErosionWisps.dds"
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.50999999
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -90
                                    -90
                                    90
                                    90
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 7, 0.629999995, 0.629999995 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0, 0 }
                            { 1, 0, 0 }
                            { 1.20000005, 0, 0 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Q_Dot.dds"
                TexAddressModeBase: u8 = 2
                ParticleUvScrollRate: embed = IntegratedValueVector2 {
                    ConstantValue: vec2 = { 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec2] = {
                            { 2, 0 }
                            { 0.100000001, 0 }
                            { 0, 0 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Variant_1"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 5, 0 }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 50, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 50, 0 }
                        }
                    }
                }
                0x563d4a22: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 30, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_W_CircleDecal.scb"
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0549019612, 0.0313725509, 0.223529413, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0549019612, 0.0313725509, 0.223529413, 1 }
                            { 0.0549019612, 0.0313725509, 0.223529413, 1 }
                            { 0.0549019612, 0.0313725509, 0.223529413, 0 }
                        }
                    }
                }
                Pass: i16 = 1
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0.200000003
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionSliceWidth: f32 = 1
                    ErosionMapName: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_ErosionWisps.dds"
                }
                DisableBackfaceCull: bool = true
                MiscRenderFlags: u8 = 1
                IsUniformScale: flag = true
                IsGroundLayer: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.39999998, 3, 2 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 0.400000006, 0.400000006, 0.400000006 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Q_Dot.dds"
                TexAddressModeBase: u8 = 2
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 50
                }
                Lifetime: option[f32] = {
                    0.300000012
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Bow1"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveAttachedMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSubmeshesToDraw: list[hash] = {
                            "UltOn"
                        }
                        mLockMeshToAttachment: bool = true
                    }
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 0.0235294122, 0.152941182, 1, 1 }
                }
                Pass: i16 = 11
                DepthBiasFactors: vec2 = { -1, -1 }
                IsUniformScale: flag = true
                IsLocalOrientation: flag = false
                Texture: string = "ASSETS/Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_Z_color-hold.dds"
            }
        }
        ParticleName: string = "Vayne_Skin14_R_buf_cntr"
        ParticlePath: string = "Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_R_buf_cntr"
    }
    "Characters/Vayne/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Vayne_BA_Crit_Mis" = 0xaed79a87
            "Vayne_BA_crit_tar" = 0x71c00abb
            "Vayne_BA_mis" = 0x9b1940de
            "Vayne_BA_tar" = 0x75a4a60a
            "Vayne_E_mis" = 0x788bc8da
            "Vayne_E_tar" = 0x6522baa6
            "Vayne_E_terrain_tar" = 0xfda3d1bc
            "Vayne_P_speed_buf" = 0x0e7fdb77
            "Vayne_Q_buf" = 0xc536a60c
            "Vayne_Q_cas" = 0x65c202f0
            "Vayne_Q_tar" = 0xa93fc75a
            "Vayne_R_buf_chst" = 0x7c2c08ee
            "Vayne_R_buf_cntr" = "Characters/Vayne/Skins/Skin14/Particles/Vayne_Skin14_R_buf_cntr"
            "Vayne_R_buf_grnd" = 0xfc118f55
            "Vayne_R_cas_invisible" = 0x995305ed
            "Vayne_R_cas_invisible02" = "Characters/Vayne/Skins/Skin0/Particles/Vayne_Base_R_cas_invisible02"
            "Vayne_R_mis" = 0xe77f1917
            "Vayne_R_speed_buf" = 0x864f6c25
            "Vayne_R_tar" = 0x0d8ff1ab
            "Vayne_W_Ring1" = 0x90d3b052
            "Vayne_W_Ring2" = 0x8fd3aebf
            "Vayne_W_tar" = 0xf9ea37e8
            "Vayne_Z_HelixSparkler" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_HelixSparkler"
            "Vayne_Z_SphereSparkler" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_SphereSparkler"
            "Vayne_Z_SphereSparkler2" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_SphereSparkler2"
            "Vayne_Z_SphereSparkler3" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_SphereSparkler3"
            "Vayne_Z_RecallFirework1" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_RecallFirework1"
            "Vayne_Z_SphereSparklerRecall1" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_SphereSparklerRecall1"
            "Vayne_Z_SphereSparklerRecall2" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_SphereSparklerRecall2"
            "Vayne_Z_RecallFirework2" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_RecallFirework2"
            "Vayne_Z_RecallFirework3" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_RecallFirework3"
            "Vayne_Z_HelixSparklerRecall" = "Characters/Vayne/Skins/Skin12/Particles/Vayne_Skin12_Z_HelixSparklerRecall"
            0x998c0bd7 = 0x85b94b57
            0xfbc3bc09 = 0x07040f89
            0x9af5e51c = 0xd1d0009c
            0x426a45c2 = 0xe9fa8d42
            0x2ede17ba = 0x65b8333a
            0x8eb65cbf = 0xc590783f
            0xa4b67f61 = 0xdb909ae1
            "Vayne_R_BA_Cas" = 0x13dd04c7
            0x9b62c4a3 = 0xe3835323
            0xd82bf7e5 = 0x204c8665
            0x715de024 = 0xb97e6ea4
            0xa602886d = 0xee2316ed
            0x9972e023 = 0xcfb652a3
            0x8ba6d6a3 = 0x96e72a23
            0xd8590979 = 0x7fe950f9
        }
    }
    "Characters/Vayne/Skins/Skin14/Materials/ScrollBloomFresnel_inst" = StaticMaterialDef {
        Name: string = "Characters/Vayne/Skins/Skin14/Materials/ScrollBloomFresnel_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Texture"
                TextureName: string = "ASSETS/Characters/Vayne/Skins/Skin14/Vayne_Skin14_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 0.0470588244, 0.588235319, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0.0666666701, 0.125490203, 1, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 3.41000009, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Alpha_Control"
                Value: vec4 = { 0.692499995, 0, 0, 0 }
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/ScrollBloomFresnel"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
}
