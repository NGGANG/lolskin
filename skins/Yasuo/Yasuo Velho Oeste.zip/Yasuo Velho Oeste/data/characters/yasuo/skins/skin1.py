#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Yasuo/Yasuo.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Characters/Yasuo/Animations/Skin1.bin"
    "DATA/Yasuo_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin56_Skins_Skin57_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin68_Skins_Skin69_Skins_Skin7_Skins_Skin70_Skins_Skin71_Skins_Skin72_Skins_Skin73_Skins_Skin74_Skins_Skin75_Skins_Skin76_Skins_Skin8.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin56_Skins_Skin58_Skins_Skin59_Skins_Skin6_Skins_Skin60_Skins_Skin61_Skins_Skin62_Skins_Skin63_Skins_Skin64_Skins_Skin65_Skins_Skin66_Skins_Skin67_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin18_Skins_Skin2_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin18_Skins_Skin2_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin2_Skins_Skin34_Skins_Skin4_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin55_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Yasuo_Skins_Skin0_Skins_Skin1_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
    "DATA/Yasuo_Skins_Skin1_Skins_Skin4_Skins_Skin5_Skins_Skin6_Skins_Skin7_Skins_Skin8.bin"
}
entries: map[hash,embed] = {
    "Characters/Yasuo/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "YasuoSkin01"
        MetaDataTags: string = "gender:male,faction:ionia,race:human,element:wind,skinline:highnoon"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Yasuo/Skins/Skin01/YasuoLoadScreen_1.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Yasuo"
                "YasuoSkin01"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Yasuo_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    Name: string = "Yasuo_Base_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Base/Yasuo_Base_SFX_events.bnk"
                    }
                }
                BankUnit {
                    Name: string = "Yasuo_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Yasuo_Attack2DGeneral"
                        "Play_vo_Yasuo_Death3D"
                        "Play_vo_Yasuo_FirstEncounter3DMasterYi"
                        "Play_vo_Yasuo_FirstEncounter3DRiven"
                        "Play_vo_Yasuo_FirstEncounter3DShen"
                        "Play_vo_Yasuo_FirstEncounter3DYone"
                        "Play_vo_Yasuo_Joke3DGeneral"
                        "Play_vo_Yasuo_Kill3DYone"
                        "Play_vo_Yasuo_Laugh3DGeneral"
                        "Play_vo_Yasuo_Move2DFirst"
                        "Play_vo_Yasuo_Move2DLong"
                        "Play_vo_Yasuo_Move2DStandard"
                        "Play_vo_Yasuo_Taunt3DGeneral"
                        "Play_vo_Yasuo_YasuoBasicAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack6_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack_cast3D"
                        "Play_vo_Yasuo_YasuoEDash_cast3D"
                        "Play_vo_Yasuo_YasuoQ1_cast3D"
                        "Play_vo_Yasuo_YasuoQ2_cast3D"
                        "Play_vo_Yasuo_YasuoQ3Wrapper_cast3D"
                        "Play_vo_Yasuo_YasuoQWrapper_cast3D"
                        "Play_vo_Yasuo_YasuoRDummySpell_OnCast"
                        "Play_vo_Yasuo_YasuoW_cast3D"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Yasuo_Base_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Yasuo/Skins/Base/Yasuo_Base_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_Yasuo_Attack2DGeneral"
                        "Play_vo_Yasuo_Death3D"
                        "Play_vo_Yasuo_FirstEncounter3DMasterYi"
                        "Play_vo_Yasuo_FirstEncounter3DRiven"
                        "Play_vo_Yasuo_FirstEncounter3DShen"
                        "Play_vo_Yasuo_FirstEncounter3DYone"
                        "Play_vo_Yasuo_Joke3DGeneral"
                        "Play_vo_Yasuo_Kill3DYone"
                        "Play_vo_Yasuo_Laugh3DGeneral"
                        "Play_vo_Yasuo_Move2DFirst"
                        "Play_vo_Yasuo_Move2DLong"
                        "Play_vo_Yasuo_Move2DStandard"
                        "Play_vo_Yasuo_Taunt3DGeneral"
                        "Play_vo_Yasuo_YasuoBasicAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack6_cast3D"
                        "Play_vo_Yasuo_YasuoBasicAttack_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack2_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack3_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack4_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack5_cast3D"
                        "Play_vo_Yasuo_YasuoCritAttack_cast3D"
                        "Play_vo_Yasuo_YasuoEDash_cast3D"
                        "Play_vo_Yasuo_YasuoQ1_cast3D"
                        "Play_vo_Yasuo_YasuoQ2_cast3D"
                        "Play_vo_Yasuo_YasuoQ3Wrapper_cast3D"
                        "Play_vo_Yasuo_YasuoQWrapper_cast3D"
                        "Play_vo_Yasuo_YasuoRDummySpell_OnCast"
                        "Play_vo_Yasuo_YasuoW_cast3D"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Yasuo_Skin01_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Skin01/Yasuo_Skin01_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Yasuo/Skins/Skin01/Yasuo_Skin01_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_YasuoSkin01_Dance3D_buffactivate"
                        "Play_sfx_YasuoSkin01_Dance3D_buffactivate_leadin"
                        "Play_sfx_YasuoSkin01_Recall_leadin"
                        "Play_sfx_YasuoSkin01_Recall_leadout"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack2_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack2_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack3_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack3_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack4_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack4_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack5_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack5_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack6_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack6_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoBasicAttack_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack2_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack2_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack3_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack3_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack4_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack4_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack5_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack5_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoCritAttack_OnHit"
                        "Play_sfx_YasuoSkin01_YasuoQ2_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoQ_hit"
                        "Play_sfx_YasuoSkin01_YasuoQW_OnCast"
                        "Play_sfx_YasuoSkin01_YasuoSheathSpark_buffactivate"
                        "Stop_sfx_YasuoSkin01_Recall_leadin"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Yasuo/Animations/Skin1"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Yasuo_Skin01.skl"
            SimpleSkin: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Yasuo_Skin01.skn"
            Texture: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Yasuo_Skin01_TX_CM.dds"
            SkinScale: f32 = 0.930000007
            SelfIllumination: f32 = 0.699999988
            BrushAlphaOverride: f32 = 0.449999988
            OverrideBoundingBox: option[vec3] = {
                { 230, 180, 230 }
            }
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "Yasuo_Instrument_Mat"
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Mask"
            "BottleFix_Skin01"
        }
        IconAvatar: string = "ASSETS/Characters/Yasuo/HUD/Yasuo_Circle_1.dds"
        mContextualActionData: link = "Characters/Yasuo/CAC/Yasuo_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Yasuo/HUD/Yasuo_Circle.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Yasuo/HUD/Yasuo_Square.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            UnitHealthBarStyle: u8 = 10
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = "Emblems/29"
            }
        }
        mResourceResolver: link = "Characters/Yasuo/Skins/Skin1/Resources"
    }
    "Characters/Yasuo/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "Yasuo_BA_Crit_hit_01" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_Crit_hit_01"
            "Yasuo_BA_Crit_hit_02" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_Crit_hit_02"
            "Yasuo_BA_Crit_hit_03" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_Crit_hit_03"
            "Yasuo_BA_Crit_hit_04" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_Crit_hit_04"
            "Yasuo_BA_hit_tar_01" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_hit_tar_01"
            "Yasuo_BA_hit_tar_02" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_hit_tar_02"
            "Yasuo_BA_hit_tar_03" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_hit_tar_03"
            "Yasuo_BA_hit_tar_04" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_BA_hit_tar_04"
            "Yasuo_BA_trail_1" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_BA_trail_1"
            "Yasuo_BA_trail_2" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_BA_trail_2"
            "Yasuo_BA_trail_3" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_BA_trail_3"
            "Yasuo_BA_trail_4" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_BA_trail_4"
            "Yasuo_Dance_flute_wind" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_Dance_flute_wind"
            0x635797df = 0x7896c4cf
            "Yasuo_Emote_dance_in_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_dance_in_sound"
            "Yasuo_Emote_dance_sound" = "Characters/Yasuo/Skins/Skin1/Particles/yasuo_skin01_emote_dance_sound"
            "Yasuo_Emote_death_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_death_sound"
            "Yasuo_Emote_joke_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_joke_sound"
            "Yasuo_Emote_laugh_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_laugh_sound"
            "Yasuo_Emote_taunt2_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt2_sound"
            "Yasuo_Emote_taunt_generic" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_generic"
            "Yasuo_Emote_taunt_interactive_ninja" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_interactive_ninja"
            "Yasuo_Emote_taunt_interactive_riven" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_interactive_riven"
            "Yasuo_Emote_taunt_interactive_yi" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_interactive_yi"
            "Yasuo_Emote_taunt_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Emote_taunt_sound"
            "Yasuo_EQ3_cas" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_EQ3_cas"
            "Yasuo_EQ_cas" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_EQ_cas"
            "Yasuo_EQ_SwordGlow" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_EQ_SwordGlow"
            "Yasuo_E_Dash" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_dash"
            "Yasuo_E_dash_hit" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_dash_hit"
            "Yasuo_E_timer1" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_timer1"
            "Yasuo_E_timer2" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_timer2"
            "Yasuo_E_timer3" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_timer3"
            "Yasuo_E_timer4" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_timer4"
            "Yasuo_E_timer5" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_E_timer5"
            "Yasuo_I_sheath_spark" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_I_sheath_spark"
            "Yasuo_NightmareBot_E_timer1" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_NightmareBot_E_timer1"
            "Yasuo_NightmareBot_E_timer2" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_NightmareBot_E_timer2"
            "Yasuo_NightmareBot_E_timer3" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_NightmareBot_E_timer3"
            "Yasuo_NightmareBot_E_timer4" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_NightmareBot_E_timer4"
            "Yasuo_NightmareBot_E_timer5" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_NightmareBot_E_timer5"
            "Yasuo_Passive_Activate" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_passive_activate"
            "Yasuo_Passive_Burst" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_Passive_Burst"
            "Yasuo_Q3_Hand" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q3_Hand"
            "Yasuo_Q3_Indicator_Ring" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q3_Indicator_Ring"
            "Yasuo_Q3_Indicator_Ring_alt" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q3_Indicator_Ring_alt"
            "Yasuo_Q_Hand" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_Hand"
            "Yasuo_Q_hit_tar" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_Q_hit_tar"
            "Yasuo_Q_sound" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_sound"
            "Yasuo_Q_WindStrike" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_Q_WindStrike"
            "Yasuo_Q_WindStrike_02" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_Q_windstrike_02"
            "Yasuo_Q_wind_hit_tar" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_Q_wind_hit_tar"
            "Yasuo_Q_wind_mis" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_Q_wind_mis"
            "Yasuo_Q_wind_ready_buff" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_Q_wind_ready_buff"
            0xc542e434 = 0x229383e4
            0x36a5a16b = "Characters/Yasuo/Skins/Skin1/Particles/yasuo_skin01_recall_start_sound"
            "Yasuo_R_cantcast_beam" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_R_cantcast_beam"
            "Yasuo_R_cas_marker_01" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_R_cas_marker_01"
            "Yasuo_R_CloneVFX" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_R_CloneVFX"
            "Yasuo_R_dash" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_R_dash"
            "Yasuo_R_impact_tar" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_R_impact_tar"
            "Yasuo_R_indicator_beam" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_R_indicator_beam"
            "Yasuo_R_land_tar" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_R_land_tar"
            "Yasuo_R_slash_cas" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_R_slash_cas"
            "Yasuo_R_SwordGlow" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_R_SwordGlow"
            "Yasuo_R_tar_imp_01" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_R_tar_imp_01"
            0xf90ee152 = 0xadd28902
            0xf80edfbf = 0xacd2876f
            "Yasuo_Taunt_spit" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_base_Taunt_spit"
            "Yasuo_Wall_XinZhao_OLD" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Wall_XinZhao_OLD"
            "Yasuo_W_windwall1" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_w_windwall1"
            "Yasuo_W_windwall2" = "Characters/Yasuo/Skins/Skin1/Particles/yasuo_skin01_w_windwall2"
            "Yasuo_W_windwall3" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_W_windwall3"
            "Yasuo_W_windwall4" = "Characters/Yasuo/Skins/Skin1/Particles/yasuo_skin01_w_windwall4"
            "Yasuo_W_windwall5" = "Characters/Yasuo/Skins/Skin1/Particles/yasuo_skin01_w_windwall5"
            "Yasuo_W_windwall_activate" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_W_windwall_activate"
            "Yasuo_W_Windwall_big_impact" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_W_windwall_big_impact"
            "Yasuo_W_windwall_enemy_01" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_w_windwall_enemy_01"
            "Yasuo_W_windwall_enemy_02" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_w_windwall_enemy_02"
            "Yasuo_W_windwall_enemy_03" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_w_windwall_enemy_03"
            "Yasuo_W_windwall_enemy_04" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_w_windwall_enemy_04"
            "Yasuo_W_windwall_enemy_05" = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_skin01_w_windwall_enemy_05"
            "Yasuo_Q_Odyssey_Wandering_wind_mis" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_wind_mis"
            "Yasuo_Q_Odyssey_Growing_wind_mis" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_wind_mis"
            "Yasuo_Q_Odyssey_Wandering_Growing_wind_mis" = "Characters/Yasuo/Skins/Skin0/Particles/Yasuo_Base_Q_wind_mis"
            0x2135861a = "Characters/Yasuo/Skins/Skin1/Particles/yasuo_skin01_recall_end_sound"
        }
    }
    "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_R_SwordGlow" = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Lifetime: option[f32] = {
                    14.5
                }
                EmitterName: string = "Sword_glow"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { -170, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1.29999995
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { -170, 0, 0 }
                        }
                    }
                }
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -30, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                Primitive: pointer = VfxPrimitiveArbitraryQuad {}
                BlendMode: u8 = 4
                Pass: i16 = 10
                ColorLookUpTypeY: u8 = 3
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1.20000005
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -1
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 50, 50, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.25
                            0.699999988
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 0, 0 }
                            { 1, 1, 1 }
                            { 0.800000012, 0.699999988, 0.5 }
                            { 1, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Particles/Yasuo_skin01_W_windwall_block_impact.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { 0.100000001, 1 }
                }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Color_Yasuo_skin01_Q_hit_tar.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 4 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.200000003
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.100000001, 4 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 100
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    2
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.5
                        }
                    }
                }
                Lifetime: option[f32] = {
                    14.5
                }
                EmitterName: string = "Sword_glow2"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    100
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    100
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    100
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                0x3bf0b4ed: pointer = 0x4f4e2ed7 {
                    EmitOffset: embed = ValueVector3 {
                        ConstantValue: vec3 = { -1, 0, 0 }
                        Dynamics: pointer = VfxAnimatedVector3fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        1
                                        200
                                    }
                                }
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {}
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec3] = {
                                { -1, 0, 0 }
                            }
                        }
                    }
                }
                BlendMode: u8 = 1
                Color: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 1, 1, 0.75 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 0.75 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                Pass: i16 = 15
                IsRandomStartFrame: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 45, 45, 45 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1.20000005
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -0.5
                                    -1
                                    1
                                    0.5
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 45, 45, 45 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.5, 0.5, 0.5 }
                            { 1.29999995, 1.29999995, 1.29999995 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Yasuo_W_wind_wispy.dds"
                NumFrames: u16 = 16
                TexDiv: vec2 = { 4, 4 }
                TextureMult: pointer = 0xb097c1bd {
                    TextureMult: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Color_Yasuo_skin01_passive_shield.dds"
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 0.100000001, 4 }
                        Dynamics: pointer = VfxAnimatedVector2fVariableData {
                            ProbabilityTables: list[pointer] = {
                                VfxProbabilityTableData {}
                                VfxProbabilityTableData {
                                    KeyTimes: list[f32] = {
                                        0
                                        1
                                    }
                                    KeyValues: list[f32] = {
                                        0.200000003
                                        1
                                    }
                                }
                            }
                            Times: list[f32] = {
                                0
                            }
                            Values: list[vec2] = {
                                { 0.100000001, 4 }
                            }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 14.5
                }
                ParticleLinger: option[f32] = {
                    1
                }
                Lifetime: option[f32] = {
                    1
                }
                EmitterName: string = "texture_swap"
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                MaterialOverrideDefinitions: list[embed] = {
                    VfxMaterialOverrideDefinitionData {
                        Priority: i32 = 1
                        BaseTexture: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Particles/Yasuo_skin01_R_sword_text_swap.dds"
                        TransitionTexture: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Color_yasuo_w_windwall_dust.dds"
                        TransitionSample: f32 = 0.0625
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 7
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    14.5
                }
                EmitterName: string = "sword_wind"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -30, 0, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Yasuo_base_R_sword_wind2.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Color_Yasuo_Q_wind.dds"
                Pass: i16 = 20
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -90, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -90, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.75, 0.75, 0.649999976 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.75, 0.75, 0.649999976 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Particles/Yasuo_skin01_Q_wind_hit_tar.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.800000012, 0.150000006 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.60000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { -0.800000012, 0.150000006 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 5
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.699999988
                }
                ParticleLinger: option[f32] = {
                    10.6999998
                }
                Lifetime: option[f32] = {
                    14.5
                }
                EmitterName: string = "sword_wind_sub"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                0x3bf0b4ed: pointer = 0xee39916f {
                    EmitOffset: vec3 = { -50, 0, 0 }
                }
                0x4ffce322: pointer = 0xb13097f0 {
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.00499999989
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Yasuo_base_R_sword_wind2.sco"
                    }
                }
                ParticleColorTexture: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Color_Yasuo_E_dash_timer_tar.dds"
                BlendMode: u8 = 2
                Pass: i16 = 20
                DisableBackfaceCull: bool = true
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -90, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -90, 1 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.75, 0.75, 0.75 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.600000024
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.20000005
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0.75, 0.75, 0.75 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Particles/Yasuo_skin01_Q_wind_hit_tar.dds"
                UvMode: u8 = 2
                BirthUvScrollRate: embed = ValueVector2 {
                    ConstantValue: vec2 = { -0.800000012, 0.150000006 }
                    Dynamics: pointer = VfxAnimatedVector2fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    1.60000002
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec2] = {
                            { -0.800000012, 0.150000006 }
                        }
                    }
                }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 2
                }
                Lifetime: option[f32] = {
                    14
                }
                EmitterName: string = "distort"
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -120
                                    -80
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -30
                                    30
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -30
                                    30
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                        }
                    }
                }
                BirthAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -30, 0 }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleColorTexture: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Color_yasuo_R_Land_distort.dds"
                BlendMode: u8 = 1
                Pass: i16 = 10
                ColorLookUpTypeY: u8 = 3
                DistortionDefinition: pointer = VfxDistortionDefinitionData {
                    Distortion: f32 = 0.00999999978
                    NormalMapTexture: string = "ASSETS/Characters/Yasuo/Skins/Skin01/Particles/Yasuo_skin01_R_sword_heat_distort.dds"
                }
                ParticleIsLocalOrientation: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    360
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 50, 50, 50 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.300000012
                            1
                        }
                        Values: list[vec3] = {
                            { 0.200000003, 0.200000003, 0.200000003 }
                            { 1, 1, 1 }
                            { 0.5, 0.5, 0.5 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Yasuo/Skins/Base/Particles/Yasuo_Q_sword_distort.dds"
            }
        }
        ParticleName: string = "Yasuo_Skin01_R_SwordGlow"
        ParticlePath: string = "Characters/Yasuo/Skins/Skin1/Particles/Yasuo_Skin01_R_SwordGlow"
    }
}
