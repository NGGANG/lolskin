#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Characters/Leblanc/Animations/Skin20.bin"
    "DATA/Characters/Leblanc/Leblanc.bin"
    "DATA/Leblanc_Skins_Root_Skins_Skin0_Skins_Skin1_Skins_Skin10_Skins_Skin11_Skins_Skin12_Skins_Skin13_Skins_Skin14_Skins_Skin15_Skins_Skin16_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin2_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin29_Skins_Skin3_Skins_Skin30_Skins_Skin31_Skins_Skin32_Skins_Skin33_Skins_Skin34_Skins_Skin35_Skins_Skin36_Skins_Skin37_Skins_Skin38_Skins_Skin39_Skins_Skin4_Skins_Skin40_Skins_Skin41_Skins_Skin42_Skins_Skin43_Skins_Skin44_Skins_Skin45_Skins_Skin46_Skins_Skin47_Skins_Skin48_Skins_Skin49_Skins_Skin5_Skins_Skin50_Skins_Skin51_Skins_Skin52_Skins_Skin53_Skins_Skin54_Skins_Skin6_Skins_Skin7_Skins_Skin8_Skins_Skin9.bin"
    "DATA/Leblanc_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin33_Skins_Skin34_Skins_Skin54.bin"
    "DATA/Leblanc_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28.bin"
    "DATA/Leblanc_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin34.bin"
    "DATA/Leblanc_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin26_Skins_Skin27_Skins_Skin28_Skins_Skin33_Skins_Skin34.bin"
}
entries: map[hash,embed] = {
    "Characters/Leblanc/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "LeblancSkin20"
        MetaDataTags: string = "skinline:coven,gender:female,race:human,subfaction:blackrose"
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Leblanc/Skins/Skin20/LeblancLoadScreen_20.dds"
        }
        LoadscreenVintage: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Leblanc/Skins/Skin20/LeblancLoadscreen_20_LE.dds"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Leblanc"
                "LeblancSkin20"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Leblanc_Skin20_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_LeblancSkin20_Attack2DGeneral"
                        "Play_vo_LeblancSkin20_Death3D"
                        "Play_vo_LeblancSkin20_Joke3DGeneral"
                        "Play_vo_LeblancSkin20_Laugh3DGeneral"
                        "Play_vo_LeblancSkin20_LeblancCloneDeath_OnCast"
                        "Play_vo_LeblancSkin20_LeblancE_cast3D"
                        "Play_vo_LeblancSkin20_LeblancQ_cast3D"
                        "Play_vo_LeblancSkin20_LeblancRE_cast3D"
                        "Play_vo_LeblancSkin20_LeblancRQ_cast3D"
                        "Play_vo_LeblancSkin20_LeblancRW_cast3D"
                        "Play_vo_LeblancSkin20_LeblancW_cast3D"
                        "Play_vo_LeblancSkin20_Move2DStandard"
                        "Play_vo_LeblancSkin20_Taunt3DGeneral"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Leblanc_Skin20_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_SFX_events.bnk"
                    }
                    Events: list[string] = {
                        "Play_sfx_LeblancSkin20_LeblancBasicAttack2_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancBasicAttack2_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancBasicAttack3_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancBasicAttack3_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancBasicAttack_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancBasicAttack_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancCritAttack_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancCritAttack_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancE_OnBuffActivate"
                        "Play_sfx_LeblancSkin20_LeblancE_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancEMissile_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancEMissile_OnMissileLaunch"
                        "Play_sfx_LeblancSkin20_LeblancERoot_OnBuffActivate"
                        "Play_sfx_LeblancSkin20_LeblancP_deactivate"
                        "Play_sfx_LeblancSkin20_LeblancP_OnBuffDeactivate"
                        "Play_sfx_LeblancSkin20_LeblancQ_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancQ_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancQ_OnMissileLaunch"
                        "Play_sfx_LeblancSkin20_LeblancQDetonate_OnBuffCast"
                        "Play_sfx_LeblancSkin20_LeblancQMark_OnBuffActivate"
                        "Play_sfx_LeblancSkin20_LeblancRE_OnBuffActivate"
                        "Play_sfx_LeblancSkin20_LeblancRE_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancREMissile_OnMissileLaunch"
                        "Play_sfx_LeblancSkin20_LeblancRERoot_OnBuffActivate"
                        "Play_sfx_LeblancSkin20_LeblancRQ_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancRQ_OnHit"
                        "Play_sfx_LeblancSkin20_LeblancRQ_OnMissileLaunch"
                        "Play_sfx_LeblancSkin20_LeblancRQDetonate_OnBuffCast"
                        "Play_sfx_LeblancSkin20_LeblancRQMark_OnBuffActivate"
                        "Play_sfx_LeblancSkin20_LeblancRW_hitlocation"
                        "Play_sfx_LeblancSkin20_LeblancRW_missilelaunch"
                        "Play_sfx_LeblancSkin20_LeblancRW_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancRW_poof"
                        "Play_sfx_LeblancSkin20_LeblancRWreturn_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancW_hitlocation"
                        "Play_sfx_LeblancSkin20_LeblancW_missilelaunch"
                        "Play_sfx_LeblancSkin20_LeblancW_OnCast"
                        "Play_sfx_LeblancSkin20_LeblancW_poof"
                        "Play_sfx_LeblancSkin20_LeblancWReturn_OnCast"
                        "Play_sfx_LeblancSkin20_Recall3D_buffactivate"
                        "Stop_sfx_LeblancSkin20_LeblancE_OnBuffActivate"
                        "Stop_sfx_LeblancSkin20_LeblancEMissile_OnMissileLaunch"
                        "Stop_sfx_LeblancSkin20_LeblancERoot_OnBuffActivate"
                        "Stop_sfx_LeblancSkin20_LeblancQ_OnMissileLaunch"
                        "Stop_sfx_LeblancSkin20_LeblancQMark_OnBuffActivate"
                        "Stop_sfx_LeblancSkin20_LeblancRE_OnBuffActivate"
                        "Stop_sfx_LeblancSkin20_LeblancREMissile_OnMissileLaunch"
                        "Stop_sfx_LeblancSkin20_LeblancRERoot_OnBuffActivate"
                        "Stop_sfx_LeblancSkin20_LeblancRQ_OnMissileLaunch"
                        "Stop_sfx_LeblancSkin20_LeblancRQMark_OnBuffActivate"
                        "Stop_sfx_LeblancSkin20_Recall3D_buffactivate"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = "Characters/Leblanc/Animations/Skin20"
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20.skl"
            SimpleSkin: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20.skn"
            Texture: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_TX_CM.dds"
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 135, 211, 135 }
            }
            Material: link = "Characters/Leblanc/Skins/Skin20/Materials/Specular_Fresnel_Masked_inst"
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "LeftWing RightWing Mirror MirrorGlass"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_Mirror_TX_CM.dds"
                    Submesh: string = "Mirror"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_Mirror_TX_CM.dds"
                    Submesh: string = "MirrorGlass"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        DefaultAnimations: list[string] = {
            "Spin"
        }
        IdleParticlesEffects: list[embed] = {
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "LeBlanc_idle"
                BoneName: string = "BUFFBONE_CSTM_LAMP"
            }
            SkinCharacterDataProperties_CharacterIdleEffect {
                EffectKey: hash = "Leblanc_Z_FeatherIdleTrail"
                BoneName: string = "BUFFBOND_GLB_GROUND_LOC"
            }
        }
        IconAvatar: string = "ASSETS/Characters/Leblanc/HUD/Leblanc_Circle_20.dds"
        mContextualActionData: link = "Characters/Leblanc/CAC/Leblanc_Base"
        IconCircle: option[string] = {
            "ASSETS/Characters/Leblanc/HUD/Leblanc_Circle_0.dds"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Leblanc/HUD/Leblanc_Square_0.dds"
        }
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "BUFFBONE_GLB_Healthbar_LOC"
            UnitHealthBarStyle: u8 = 10
        }
        mResourceResolver: link = "Characters/Leblanc/Skins/Skin20/Resources"
    }
    "Characters/Leblanc/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            "LeBlanc_BA_Crit_tar" = 0x508a2a25
            "LeBlanc_BA_mis" = 0x444635a0
            "LeBlanc_BA_tar" = 0x83d82e6c
            "LeBlanc_E_buf" = 0x0e38411e
            "LeBlanc_E_chain" = 0x77458ada
            "LeBlanc_E_chain_purple" = 0x057f86b5
            "LeBlanc_E_indicator_ring" = 0xb1265fc1
            "LeBlanc_E_indicator_ring2" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_E_indicator_ring2"
            "LeBlanc_E_mis" = 0x28f81dc4
            "LeBlanc_E_Shackle_self_idle_01" = 0xc3115900
            "LeBlanc_E_tar" = 0xb32d1a60
            "LeBlanc_E_tar_02" = 0x6c02fa8f
            "LeBlanc_E_tar_Epic" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_E_tar_Epic"
            "LeBlanc_idle" = 0x037549f7
            "LeBlanc_idle_crystalSm" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_idle_crystalSm"
            "LeBlanc_P_buf_cancel_charge_sound" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_buf_cancel_charge_sound"
            "LeBlanc_P_Image" = 0x6a844de1
            "LeBlanc_P_imageDeath" = 0x6e95c9f9
            "LeBlanc_P_Poof" = 0xff22576c
            "LeBlanc_P_Tar_Mark" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark"
            "Leblanc_P_Tar_Mark_Detonate" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark_Detonate"
            "LeBlanc_P_Tar_Mark_enemy" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark_enemy"
            "LeBlanc_P_Tar_Mark_Epic" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark_Epic"
            "LeBlanc_P_Tar_Mark_Epic_enemy" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark_Epic_enemy"
            "LeBlanc_P_Tar_Mark_Minion" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark_Minion"
            "LeBlanc_P_Tar_Mark_Minion_Enemy" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Tar_Mark_Minion_enemy"
            "LeBlanc_P_Timer" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Timer"
            "LeBlanc_P_Timer_Epic" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_P_Timer_Epic"
            "LeBlanc_Q_mis" = 0x2ee15318
            "LeBlanc_Q_tar" = 0x3b7a0a44
            "LeBlanc_RE_buf" = 0x40a94506
            "LeBlanc_RE_tar" = 0x059e50a8
            "LeBlanc_RE_tar_02" = 0x160fc537
            "LeBlanc_RE_tar_Epic" = 0x50451618
            "LeBlanc_RQ_tar" = 0x81902dac
            "LeBlanc_RW_aoe_impact_02" = 0xc07cd88c
            "LeBlanc_RW_return_indicator" = 0xdb1c3713
            "LeBlanc_RW_Return_indicator_death" = 0xb68debc6
            "LeBlanc_RW_return_indicator_Enemy" = 0x11ecc958
            "LeBlanc_RW_tar" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_RW_tar"
            "LeBlanc_R_buf" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_R_buf"
            "LeBlanc_R_buf_persist_sound" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_R_buf_persist_sound"
            "LeBlanc_R_buf_sound" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_R_buf_sound"
            "LeBlanc_R_clone_create_sound" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_R_clone_create_sound"
            "LeBlanc_W_aoe_impact" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_W_aoe_impact"
            "LeBlanc_W_aoe_impact_02" = 0x86e3b5f4
            "LeBlanc_W_cas" = 0x65a972ac
            "LeBlanc_W_mis" = 0xf39c0ef2
            "LeBlanc_W_return_activation" = 0xb695c8b6
            "LeBlanc_W_return_indicator" = 0xfedd7d7b
            "LeBlanc_W_Return_indicator_death" = 0x142efd8e
            "LeBlanc_W_return_indicator_Enemy" = 0x72b06aa0
            "LeBlanc_W_tar_02" = 0xc3994831
            "Leblanc_Q_Tar_Mark" = 0x302d6914
            "LeBlanc_RE_chain" = 0x56219232
            "LeBlanc_RE_mis" = 0x2b39faec
            "LeBlanc_RQ_mis" = 0x44789de0
            "LeBlanc_RQ_Tar_Mark" = 0x291980dc
            "LeBlanc_MirrorImagePoof" = 0xda71cf93
            "Leblanc_Q_Tar_Mark_Detonate" = 0x1f7ca825
            "Leblanc_RQ_Tar_Mark_Detonate" = 0x1c66034d
            "Leblanc_RW_mis" = 0xae04899a
            0xbd66c07e = 0x00000000
            0x2f66bcae = 0x00000000
            "Leblanc_Z_FeatherIdleTrail" = 0x0aab0511
            "Leblanc_Z_Recall_StaffWisp" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_Z_Recall_StaffWisp"
            "Leblanc_Z_Recall_LogoSig" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_Z_Recall_LogoSig"
            "Leblanc_Z_Recall_Cloud" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_Z_Recall_Cloud"
            "Leblanc_Z_Recall_FingerSnap" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_Z_Recall_FingerSnap"
            "Leblanc_Z_Recall_Trophy" = "Characters/Leblanc/Skins/Skin19/Particles/Leblanc_Skin19_Z_Recall_Trophy"
            0x48be9cfc = 0xd26f5118
            0xdbd07bb4 = 0x913dc680
            0xaa8b042b = 0x7e9ecb1f
            0x089a798c = 0xccad9e50
            0x148edf04 = 0xe5f843a8
            0x24bf606a = 0x10cbf7ae
        }
    }
    "Characters/Leblanc/Skins/Skin20/Materials/Specular_Fresnel_Masked_inst" = StaticMaterialDef {
        Name: string = "Characters/Leblanc/Skins/Skin20/Materials/Specular_Fresnel_Masked_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Diffuse_Color"
                TextureName: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_TX_CM.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "Mask"
                TextureName: string = "ASSETS/Characters/Leblanc/Skins/Skin20/Leblanc_Skin20_TX_CM_Mask.dds"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                SamplerName: string = "iridescentTex"
                TextureName: string = "ASSETS/Shared/Materials/Default_Gradient.dds"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 1, 0, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 0.159999996, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Bias"
                Value: vec4 = { 0.435000002, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "MaxSpec"
                Value: vec4 = { 34.1300011, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "LQ_Lighting_Intensity"
                Value: vec4 = { 0.5, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "RimLightOffset"
                Value: vec4 = { -0.419999987, -0.419999987, -0.419999987, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SpecularColor"
                Value: vec4 = { 1, 0.764705896, 0.435294122, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "IridescentControl"
                Value: vec4 = { 1, 0.5, 0.5, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "IRIDESCENCE_ON"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Specular_Fresnel_Masked"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
    }
}
